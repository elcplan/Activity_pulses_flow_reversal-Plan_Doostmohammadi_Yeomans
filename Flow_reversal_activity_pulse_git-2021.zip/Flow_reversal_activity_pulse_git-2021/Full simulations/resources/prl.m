function prl

%istart1 = input('please input variable1: ');

clearvars -global Frames cnt cdataf
clearvars -global nx ny nz cnt
clearvars -global dx dy dz ux uy uz qc phi S tau fcoef Spoly
clearvars -global strx stry strx strmag
global nx ny nz cnt yescon
global dx dy dz ux uy uz qc phi S tau fcoef
global dxpoly dypoly dzpoly Spoly lengths
global strx stry strz strmag
rpara=readpara;
nx=rpara(1);ny=rpara(2);nz=rpara(3);
istart=rpara(4);iend=rpara(5);igap=rpara(6);
%plotgeometry(nx,ny,nz);
vrms=[];
nbin=round(max([nx ny nz])/100);
nbin=1;
nstream=2;
cnt=0;
vieo=0;
if(exist('istart1')) if(istart1>istart) istart=istart1; end; end;
%set(gcf,'Visible','Off');
iswithvideo=0;
if(iswithvideo==1)
    vidObj = VideoWriter('velfield.avi');
    vidObj.Quality = 100;
    vidObj.FrameRate
    open(vidObj);
end
istart=0;
igap=igap*10;
iend=280000;
iswithpoly=1;
xmin=70;
xmax=130;
ymin=70;
ymax=130;

%istart=6000;%iend=10000; igap1=500;
for i=istart:igap:iend
    %pause();
    cnt=cnt+1;
    %if(i==0) i=1; end;
    readdata(i,iswithpoly);
    %vrms=rmsvelocity(i,vrms);
    %subplot(1,2,1);
%     [X,Y,Z]=meshgrid(1:nx,1:ny,1:nz);
%     assignin('base','X',X);
%     assignin('base','Y',Y);
%     assignin('base','Z',Z);
%     assignin('base','phi',phi);
%     assignin('base','u',ux);
%     assignin('base','v',uy);
%     assignin('base','w',uz);
%     isosurface(X,Y,Z,phi,0.5);
%     axis([0 50 0 50 0 50]);
%    figure(1);
%    plotfreeenergy(i);
     figure(1);
     %max(max(lengths));
     %min(transpose(min(phi))
     %min(transpose(min(phi)))
     plotconcentration(i,nx,ny,nz,phi);
%     figure(2);
%     plotdirector(i,nx,ny,nz,dx,dy,dz,S,phi,1);
%     figure(4);
%     plotchirality(i,nx,ny,nz,dz,phi);
%     figure(4);
%     plotdirector(i,nx,ny,nz,dx,dy,dz,S,phi,1);
%     figure(5);
%     plotsumx(i,nx,ny,nz,dx,dy,phi);
   
    %[C qh]=contour(phi,[0.5 0.5]);
    %set(qh,'Linewidth',2); hold on;
    %subplot(1,2,2);
%      figure(4);
%      plotvorticity(i,nx,ny,nz,ux,uy);
%      figure(4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     plotvelocity(i,nx,ny,nz,ux,uy,1);
     %plotstress(i,nx,ny,nz,strx,stry,2);
    %qvcorr(i,nx,ny,qc,uz);
     
    %plotcharges(i,nx,ny,nz,qc);
  
%    figure(3);
%    plotorder(i,nx,ny,nz,S);
%    figure(3);
nxec=nx;
[xec,yec] = meshgrid(0:2:nxec,0:2:nxec);
%u=(yec-30);
%v=(xec-30);
%u = 10./nxec*2*3.1415926535.*cos(xec/nxec*2*3.1415926535).*sin(yec/nxec*2*3.1415926535);
%v = -10./nxec*2*3.1415926535.*sin(xec/nxec*2*3.1415926535).*cos(yec/nxec*2*3.1415926535);
%quiver(xec,yec,u,v);
%hold on;
    plotdirector(i,nx,ny,nz,dx,dy,dz,S,phi,1);
    hold on;
    if (iswithpoly==1)
        plotpolydirector(i,nx,ny,nz,dxpoly,dypoly,dzpoly,Spoly,phi,1,lengths);
    end
    hold off;
    %pause();  
    % hold off;
  %  w_x(cnt)=sum(phi(ny/2,:));
  %  w_y(cnt)=sum(phi(:,nx/2));
    %figure(3);
    %plot(i,(w_x(cnt)/w_y(cnt)),'b*'); hold on;
    %set(gca,'XTickLabel',[]);set(gca,'YTickLabel',[]);
    %set(gca,'XTick',[]);set(gca,'YTick',[]);
    %sing_vort_stream_direct(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,S,vrms,nstream,nbin);
    %sing_velocity_direct(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,qc,vrms,nstream,nbin);
    %subs1D_vel_direct(i,nx,ny,nz,ux,uy,uz,dx,dy,dz);
    %sing_panel_direct_stream(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,vrms,nstream,nbin);
    %plot_direct_defects_vel(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,vrms,nstream,nbin);
    %plot_direct_defects(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,vrms,nstream,nbin);
    %plot_direct_charges(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,S,qc,vrms,nstream,nbin);
    %plotconcentration(i,nx,ny,nz,phi);
    %plot_direct_conc(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,S,phi,vrms,nstream,nbin);
    %plot_direct_order(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,S,phi,vrms,nstream,nbin);
    %axis([1 100 1 100]);
    %stressanalysis(i);
    %stresscalc(i);
    %forceanalysis(i);
    %dataanalysis(vrms,nx,ny,nz,ux,uy,uz,dx,dy,dz,qc,i,1,0)%second last-nbin, last-when to start
    %tracertrack(i,vrms,nstream)
    %defectstrack(i,vrms,nstream)
    %poisecomparison(i,nx,ny,nz,ux,uy);
    %energycalculations(i,nx,ny,nz,ux,uy);%second last-tau, last - fcoef
    %xlim([xmin xmax]);
    %ylim([ymin ymax]);
    figure(2)
    velprof(nx,ny,nz,ux,uy,uz,i,istart,igap,iend);
    if(iswithpoly)
    figure(4);
    aaa=contourf(lengths.*(1-phi));
    minl=min(min(lengths.*(1-phi)));
    maxl=max(max(lengths.*(1-phi)));
    caxis([minl maxl]);
    colorbar;
    drawnow;
    end
    figure(5);
    plotvelmagnitude(i,nx,ny,nz,ux,uy);
    %plotvorticity(i,nx,ny,nz,ux,uy);
    if(iswithvideo==1)
        currFrame=getframe;
        writeVideo(vidObj,currFrame);
        %print(sprintf('fig_%d',i),'-depsc');
    end
    %framecap(vieo,i,iend);
    phi;
    %pause();
end
if(iswithvideo==1)
    close(vidObj);
end

%plot(vrms,'c*');
% figure(3);
% plot(istart:igap:iend,(w_x(:)./w_y(:)));

function framecap(vieo,i,iend)
global Frames cnt cdataf
axis tight;
%if(exist('pics')~=7) mkdir pics; end;
%rpic=horzcat('pics/at',int2str(i),'.eps');
%print(gcf,'-depsc',rpic);
if(vieo>0)
    pause(0.1);
    if(cnt==1)
        Frames=getframe(gcf);
        cdataf=size(Frames.cdata);
    end
    frame=getframe(gcf);
    cdata_size = size(frame.cdata); % Find the size of the current frame
    frame.cdata=frame.cdata(1:cdataf(1)-5,1:cdataf(2)-5,1:cdataf(3));
    Frames(cnt)=frame;
    if(i>=iend)
        movie2avi(Frames,'test.avi','fps',10);
    end;
end

function answ=sing_panel_direct_stream(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,vrms,nstream,nbin)
if(nz==1)
    nz2=1;
    uxs=squeeze(ux(:,:,nz2)); dxs=squeeze(dx(:,:,nz2));
    uys=squeeze(uy(:,:,nz2)); dys=squeeze(dy(:,:,nz2));
    uzs=squeeze(uz(:,:,nz2)); dzs=squeeze(dz(:,:,nz2));
else
    nz2=nz/2;
    uxs=transpose(squeeze(ux(:,:,nz2))); dxs=transpose(squeeze(dx(:,:,nz2)));
    uys=transpose(squeeze(uy(:,:,nz2))); dys=transpose(squeeze(dy(:,:,nz2)));
    uzs=transpose(squeeze(uz(:,:,nz2))); dzs=transpose(squeeze(dz(:,:,nz2)));
end;
subplot(2,2,1);
plotdirector(i,nx,ny,nz,dxs,dys,nbin);
title('Director field');
subplot(2,2,2);
plotstreamline(i,nx,ny,nz,uxs,uys,nstream,vrms(length(vrms)));
title(horzcat('streamlines ',int2str(i)));
subplot(2,2,3);
plot(uzs(:,ny/2),1:ny,'b'); hold on;
plot(uzs(nx/2,:),1:ny,'r--');
title('u_z');
subplot(2,2,4);
plot(uxs(:,ny/2),1:ny,'b'); hold on;
plot(uxs(nx/2,:),1:ny,'r--');
plot(uys(:,ny/2),1:ny,'g'); hold on;
plot(uys(nx/2,:),1:ny,'c--');
title('u_x and u_y');
drawnow;
answ=0;

function answ=plot_direct_defects(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,vrms,nstream,nbin)
if(nz==1)
    nz2=1;
    uxs=squeeze(ux(:,:,nz2)); dxs=squeeze(dx(:,:,nz2));
    uys=squeeze(uy(:,:,nz2)); dys=squeeze(dy(:,:,nz2));
    uzs=squeeze(uz(:,:,nz2)); dzs=squeeze(dz(:,:,nz2));
else
    nz2=nz/2;
    uxs=transpose(squeeze(ux(:,:,nz2))); dxs=transpose(squeeze(dx(:,:,nz2)));
    uys=transpose(squeeze(uy(:,:,nz2))); dys=transpose(squeeze(dy(:,:,nz2)));
    uzs=transpose(squeeze(uz(:,:,nz2))); dzs=transpose(squeeze(dz(:,:,nz2)));
end;
cla;
plotdefects(i,nx,ny,nz,dxs,dys,nbin);
plotdirector(i,nx,ny,nz,dxs,dys,nbin);
%axis normal;
title(horzcat('Director field ',int2str(i)));
drawnow;
answ=0;

function answ=plot_direct_charges(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,S,qc,vrms,nstream,nbin)
if(nz==1)
    nz2=1;
    dxs=squeeze(dx(:,:,nz2));
    dys=squeeze(dy(:,:,nz2));
    dzs=squeeze(dz(:,:,nz2));
else
    nz2=nz/2;
    dxs=transpose(squeeze(dx(:,:,nz2)));
    dys=transpose(squeeze(dy(:,:,nz2)));
    dzs=transpose(squeeze(dz(:,:,nz2)));
end;
cla;
plotcharges(i,nx,ny,nz,qc);
plotdirector(i,nx,ny,nz,dxs,dys,S,nbin,1);
%axis normal;
title(horzcat('Director field ',int2str(i)));
drawnow;
answ=0;

function answ=plot_direct_conc(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,S,phi,vrms,nstream,nbin)
if(nz==1)
    nz2=1;
    dxs=squeeze(dx(:,:,nz2));
    dys=squeeze(dy(:,:,nz2));
    dzs=squeeze(dz(:,:,nz2));
else
    nz2=nz/2;
    dxs=transpose(squeeze(dx(:,:,nz2)));
    dys=transpose(squeeze(dy(:,:,nz2)));
    dzs=transpose(squeeze(dz(:,:,nz2)));
end;
cla;
plotconcentration(i,nx,ny,nz,phi);
plotdirector(i,nx,ny,nz,dxs,dys,S,nbin,1);
%axis normal;
title(horzcat('Director field ',int2str(i)));
drawnow;
answ=0;

function answ=plot_direct_order(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,S,phi,vrms,nstream,nbin)
if(nz==1)
    nz2=1;
    dxs=squeeze(dx(:,:,nz2));
    dys=squeeze(dy(:,:,nz2));
    dzs=squeeze(dz(:,:,nz2));
else
    nz2=nz/2;
    dxs=transpose(squeeze(dx(:,:,nz2)));
    dys=transpose(squeeze(dy(:,:,nz2)));
    dzs=transpose(squeeze(dz(:,:,nz2)));
end;
cla;
plotorder(i,nx,ny,nz,S);
plotdirector(i,nx,ny,nz,dxs,dys,S,nbin,1);
%axis normal;
title(horzcat('Director field ',int2str(i)));
drawnow;
answ=0;

function answ=plotvelocity(i,nx,ny,nz,ux,uy,nbin);
[x,y]=meshgrid(1:nbin:nx,1:nbin:ny);
ux4=ux(1:nbin:ny,1:nbin:nx);
uy4=uy(1:nbin:ny,1:nbin:nx);
max(max(uy4))
max(max(ux4))
ux4(abs(ux4)<0.0002)=0;
uy4(abs(ux4)<0.0002)=0;
vh=quiver(x,y,ux4,uy4,'AutoScale','on','LineWidth',1);
set(vh,'Color','r');
%axis tight; axis equal;
%title(horzcat('Velocity field ',int2str(i)));
drawnow;
%hold on;
answ=0;

function answ=plotstress(i,nx,ny,nz,strx,stry,nbin);
[x,y]=meshgrid(1:nbin:nx,1:nbin:ny);
ux4=strx(1:nbin:ny,1:nbin:nx);
uy4=stry(1:nbin:ny,1:nbin:nx);
%ux4(abs(ux4)<0.001)=0;
%uy4(abs(ux4)<0.001)=0;
vh=quiver(x,y,ux4,uy4,'AutoScale','on');
set(vh,'Color','g');
%axis tight; axis equal;
%title(horzcat('Velocity field ',int2str(i)));
drawnow;
%hold on;
answ=0;

function answ=plotdirector(i,nx,ny,nz,dx,dy,dz,S,phi,nb)
    %dxxx=dx.*phi;
    %dyyy=dy.*phi;
    %S=S.*phi;
    dx4=reshape(sum(sum(reshape(dx,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    dy4=reshape(sum(sum(reshape(dy,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    dz4=reshape(sum(sum(reshape(dz,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);

    S=reshape(sum(sum(reshape(S,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);

    nrm=sqrt(dx4.*dx4 + dy4.*dy4 + dz4.*dz4);
    
    dx4=dx4./nrm;
    dy4=dy4./nrm;
    
    dx(8,:)
    dy(8,:)
   
[x4,y4]=meshgrid(linspace(1,nx,nx/nb),linspace(1,ny,ny/nb));
%qh=quiver(x4-dx4,y4-dy4,S.*dx4,S.*dy4,'ShowArrowHead','Off');
qh=quiver(x4,y4,S.*dx4,S.*dy4,'ShowArrowHead','Off');

set(qh,'Color','k');
%axis tight;axis equal;

drawnow;

answ=0;

function answ=plotpolydirector(i,nx,ny,nz,dxpoly,dypoly,dzpoly,Spoly,phi,nb,lengths)
    %dxxx=dxpoly.*(phi);
    %dyyy=dypoly.*(phi);
    Spoly=Spoly.*abs(lengths).*(1-phi);
    dx4=reshape(sum(sum(reshape(dxpoly,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    dy4=reshape(sum(sum(reshape(dypoly,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    dz4=reshape(sum(sum(reshape(dzpoly,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    Spoly=reshape(sum(sum(reshape(Spoly,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);

    nrm=sqrt(dx4.*dx4 + dy4.*dy4 + dz4.*dz4);
    
    dx4=dx4./nrm;
    dy4=dy4./nrm;
    
    atan(dy4(50)/dx4(50))*180/(atan(1.0)*4)
    
[x4,y4]=meshgrid(linspace(1,nx,nx/nb),linspace(1,ny,ny/nb));
qh=quiver(x4,y4,Spoly.*dx4,Spoly.*dy4,'ShowArrowHead','Off','Autoscale','on');

set(qh,'Color','blue');
%axis tight;axis equal;

drawnow;

answ=0;

function answ=plotconcentration(i,nx,ny,nz,phi)
global S
cla;
colormap gray
[c qh]=contourf(phi);
phi;
%isosurface(phi,0.5);
%patch('Faces',f,'Vertices',v)
%axis tight;
%axis equal;
shading flat;
maxq=max(max(phi))
minq=min(min(phi))
%if(maxq<0.5) maxq=0.5; end;
%if(minq>-0.5) minq=-0.5; end;
set(qh,'LineStyle','none');
%set(qh,'LineColor','b');
caxis([minq maxq]);
colorbar;
title(horzcat('Timesteps: ',int2str(i)));
drawnow;
hold on;
%checktanh(nx,ny,phi)
answ=0;

function answ=plotchirality(i,nx,ny,nz,dz,phi)
    cla;
    colormap gray;
    
    for j=1:nx
        for k=1:ny
            for l=1:nz
                if phi(j,k,l) < 0.5
                    dz(j,k,l) = NaN;
                end
            end
        end
    end
        
[c,qh]=contourf(dz);

%isosurface(phi,0.5);
%patch('Faces',f,'Vertices',v)
axis tight;
axis equal;
shading flat;
maxq=1;
minq=0;
set(qh,'LineStyle','none');
%set(qh,'LineColor','b');
caxis([minq maxq]);
colorbar;
title(horzcat('Timesteps: ',int2str(i)));
drawnow;
hold on;
%checktanh(nx,ny,phi)
answ=0;

function answ=plotsumx(i,nx,ny,nz,dx,dy,phi)
    sumx = 0;
    sumy = 0;
    for j=1:nx
        for k=1:ny
            for l=1:nz
                if phi(j,k,l) < 0.5
                    dx(j,k,l) = 0;
                    dy(j,k,l) = 0;
                end
                sumx = sumx+dx(j,k,l)^2;
                sumy = sumy+dy(j,k,l)^2;
            end
        end
    end
plot(i,sumx/(nx*ny*nz),'b*');
hold on;
plot(i,sumy/(nx*ny*nz),'r*');
hold on;
answ=0;

function answ=plotorder(i,nx,ny,nz,S)
cla;
colormap hot
qh=contourf(S);
axis tight;
axis equal;
shading flat;
maxq=max(max(S))
minq=min(min(S))
%if(maxq<0.5) maxq=0.5; end;
%if(minq>-0.5) minq=-0.5; end;
caxis([0 0.333]);
colorbar;
%title(horzcat('Order ',int2str(i)));
drawnow;
hold on;
answ=0;

function checktanh(nx,ny,phi)
clf;
ht=10;
Aphi=0.1/3;Bphi=0.1/3;Kphi=0.01*3;
zi=sqrt(2*Kphi/Aphi);
y = 1:ny/2;
p=tanh((y-(ht+0.5))/zi);
plot(phi(:,nx/2));
hold on;
plot(y,-p,'r');
drawnow;
answ=0;

function answ=plot_direct_defects_vel(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,vrms,nstream,nbin)
nx2=nx/2;
if(nx==1) nx2=1; end;
if(nz==1)
    nz2=1;
    uxs=squeeze(ux(:,:,nz2)); dxs=squeeze(dx(:,:,nz2));
    uys=squeeze(uy(:,:,nz2)); dys=squeeze(dy(:,:,nz2));
    uzs=squeeze(uz(:,:,nz2)); dzs=squeeze(dz(:,:,nz2));
else
    nz2=nz/2;
    uxs=transpose(squeeze(ux(:,:,nz2))); dxs=transpose(squeeze(dx(:,:,nz2)));
    uys=transpose(squeeze(uy(:,:,nz2))); dys=transpose(squeeze(dy(:,:,nz2)));
    uzs=transpose(squeeze(uz(:,:,nz2))); dzs=transpose(squeeze(dz(:,:,nz2)));
end;
subplot(2,2,[1 2]);cla;
plotdefects(i,nx,ny,nz,dxs,dys,nbin);
plotdirector(i,nx,ny,nz,dxs,dys,nbin);
%axis normal;
title('Director field');
subplot(2,2,3);cla;
dxsc=dxs(:,nx2);dysc=dys(:,nx2);
%theta=180/pi*atan2(sign(dysc).*dysc,sign(dysc).*dxsc);
theta=(180/pi*atan(dysc./dxsc));
% for cnt=1:length(theta)
%     if(theta(cnt)>90) theta=180-theta; end;
% end;
plot(theta,1:ny,'r*-');
%plotstreamline(i,nx,ny,nz,uxs,uys,nstream,vrms(length(vrms)));
axis normal;
title(horzcat('streamlines ',int2str(i)));
subplot(2,2,4);cla;
plot(uzs(:,nx2),1:ny,'b'); hold on;
%plot(uzs(nx/2,:),1:ny,'r--');
plot(uxs(:,nx2),1:ny,'r'); hold on;
%plot(uxs(nx/2,:),1:ny,'r--');
plot(uys(:,nx2),1:ny,'g'); hold on;
%plot(uys(nx/2,:),1:ny,'c--');
title('u_x and u_y and u_z');
drawnow;
answ=0;

function answ = subs1D_vel_direct(i,nx,ny,nz,ux,uy,uz,dirx,diry,dirz)
subplot(2,2,1);cla;
plot(ux,1:ny,'r');
title(int2str(i));
subplot(2,2,2);cla;
plot(180/pi*(atan(diry./dirx)),1:ny,'r');
subplot(2,2,3); hold off;
plot(uy,1:ny,'g'); hold on;
plot(uz,1:ny,'r--');
subplot(2,2,4); hold off;
plot(dirz,1:ny,'g');
drawnow;
answ=0;

function answ=sing_vort_stream_direct(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,S,vrms,nstream,nbin)
clf;
plotvorticity(i,nx,ny,nz,ux,uy);
plotdirector(i,nx,ny,nz,dx,dy,S,nbin,1)
plotstreamline(i,nx,ny,nz,ux,uy,nstream,vrms(length(vrms)));
drawnow;
answ=0;

function answ=sing_velocity_direct(i,nx,ny,nz,ux,uy,uz,dx,dy,dz,qc,vrms,nstream,nbin)
clf;
subplot(2,1,1);
plotvorticity(i,nx,ny,nz,ux,uy);
plotstreamline(i,nx,ny,nz,ux,uy,nstream,vrms(length(vrms)));
subplot(2,1,2);
plotcharges(i,nx,ny,nz,qc);
plotdirector(i,nx,ny,nz,dx,dy,nbin);
drawnow;
answ=0;

function answ=rmsvelocity(i,vrms)
global ux uy uz qc
aqc=[]; 
if(~isempty(qc)) 
    aqc=sum(sum(abs(qc)));
    if(aqc<0.1) qc(1,1)=0.1; end;
end;
avrms=mean(mean(mean(sqrt(ux.*ux+uy.*uy+uz.*uz))));
fprintf(horzcat('\n',num2str(i),' , ',num2str(avrms),' , ',num2str(aqc)));
vrms=[vrms avrms];
answ=vrms;

function answ=plotvelmagnitude(~,nx,ny,nz,ux,uy)
mg=sqrt(ux.^2+uy.^2);
colormap hot
contourf(mg);
shading flat; 
colorbar;
axis tight; axis equal;
%caxis([0,0.005]);
drawnow;
hold off;
answ=0;

function answ=plotvorticity(i,nx,ny,nz,ux,uy)
dyux=gradient(ux')';
dxuy=gradient(uy);
omgz=dxuy-dyux;
contourf(omgz);
shading flat; colorbar;
axis tight; axis equal;
drawnow;
title(horzcat('Timesteps: ',int2str(i)));
hold on;
answ=0;

function answ=plotstreamline(i,nx,ny,nz,ux,uy,nstream,vrms);
streamslice(ux,uy,nstream);
title(horzcat(int2str(i),',vrms is ',num2str(vrms)));
axis tight;
axis equal;
drawnow;
hold on;
answ=0;


function answ=plotdefects(i,nx,ny,nz,dx,dy,nb)
if(nb>1)
dx4=reshape(sum(sum(reshape(dx,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
dy4=reshape(sum(sum(reshape(dy,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
else
    dx4=dx;
    dy4=dy;
end
[x4 y4]=meshgrid(linspace(1,nx,nx/nb),linspace(1,ny,ny/nb));
wn=calcs(dx4,dy4);
qh=contourf(wn);
axis tight;
axis equal;
shading flat;
caxis([-0.5 0.5]);
drawnow;
hold on;
answ=0;

function answ=plotcharges(i,nx,ny,nz,qc,nb)
%cla;
qc(abs(qc)<0.5)=NaN;
 qh=contourf(qc);
 axis tight;
 axis equal;
 shading flat;
 maxq=max(max(qc));
 minq=min(min(qc));
% %if(maxq<0.5) maxq=0.5; end;
% %if(minq>-0.5) minq=-0.5; end;
% maxq=0.5;minq=-0.5;
 %caxis([minq maxq]);
 drawnow;
%hold on;
%chargearray(i,nx,ny,qc);
answ=0;


function answ=chargearray(it,nx,ny,qc)
xpq=[];ypq=[]; xnq=[]; ynq=[];
for i=2:nx-1
    for j=2:ny-1
        x1=0;y1=0;n1=0;
        if(abs(qc(i,j))>0.4)
            ql=sign(qc(i,j)); x1=i;y1=j;n1=1;qc(i,j)=0;
            for ii=-1:1
                for jj=-1:1
                    if(ql*qc(i+ii,j+jj)>0.4)
                        x1=x1+i+ii;y1=y1+j+jj;n1=n1+1;
                        qc(i+ii,j+jj)=0;
                    end
                end
            end
            if(ql>0)
            xpq=[xpq;x1/n1];ypq=[ypq;y1/n1];
            else
                xnq=[xnq;x1/n1];ynq=[ynq;y1/n1];
            end
        end
    end
end
plot(ypq,xpq,'bo','MarkerSize',10,'MarkerFaceColor','b');
plot(ynq,xnq,'g^','MarkerSize',10,'MarkerFaceColor','g');
answ=0;

function answ=qvcorr(it,nx,ny,qc,uz)
uz=abs(uz)/max(max(uz));
qc(26,52)
v1=0;c1=1;v2=0;c2=11;v3=0;c3=1;v4=0;c4=1;v5=0;c5=1;
v6=0;c6=1;v7=0;c7=1;v8=0;c8=1;v9=0;c9=1;v10=0;c10=1;
for i=2:nx-1
    for j=2:ny-1
        if(-0.5 <= qc(i,j) && qc(i,j) <= -0.4) 
            v1=v1+uz(i,j);c1=c1+1;
        elseif(-0.4 < qc(i,j) && qc(i,j) < -0.3) 
            v2=v2+uz(i,j);c2=c2+1;
        elseif(-0.3 <= qc(i,j) & qc(i,j) < -0.2) 
            v3=v3+uz(i,j);c3=c3+1;
        elseif(-0.2 <= qc(i,j) & qc(i,j) < -0.1) 
            v4=v4+uz(i,j);c4=c4+1;
        elseif(-0.1 <= qc(i,j) & qc(i,j) < 0.0) 
            v5=v5+uz(i,j);c5=c5+1;
        elseif(0.0 <= qc(i,j) & qc(i,j) < 0.1) 
            v6=v6+uz(i,j);c6=c6+1;
        elseif(0.1 <= qc(i,j) & qc(i,j) < 0.2) 
            v7=v7+uz(i,j);c7=c7+1;
        elseif(0.2 <= qc(i,j) & qc(i,j) < 0.3) 
            v8=v8+uz(i,j);c8=c8+1;
        elseif(0.3 <= qc(i,j) & qc(i,j) < 0.4) 
            v9=v9+uz(i,j);c9=c9+1;
        elseif(0.4 <= qc(i,j) & qc(i,j) <= 0.5) 
            v10=v10+uz(i,j);c10=c10+1;
        end
            
    end
end
v=[v1/c1 v2/c2 v3/c3 v4/c4 v5/c5 v6/c6 v7/c7 v8/c8 v9/c9 v10/c10]
c=[c1 c2 c3 c4 c5 c6 c7 c8 c9 c10]
bar([-0.9:0.2:0.9],v);
answ=0;

function answ=plotfreeenergy(i)

global order elasticity concen surftens anchor elecf chiral smectic freeenergy
A = horzcat('../data/output/energy',int2str(i),'.dat');
A = load(A);
order = A(1,1);
elasticity = A(1,2);
concen = A(1,3);
surftens = A(1,4);
anchor = A(1,5);
elecf = A(1,6);
chiral = A(1,7);
smectic = A(1,8);
freeenergy = order+elasticity+concen+surftens+anchor+elecf+chiral+smectic;
plot(i,order,'b*'); hold on;
plot(i,elasticity,'r*'); hold on;
plot(i,concen,'y*'); hold on;
plot(i,surftens,'g*'); hold on;
plot(i,anchor,'k*'); hold on;
plot(i,elecf,'co'); hold on;
plot(i,chiral,'m*'); hold on;
plot(i,smectic,'c*'); hold on;
plot(i,freeenergy,'ko'); hold on;
legend('Landau-de Gennes','Elasticity','Mixing','Surface tension','Anchoring','Electric field','Chirality','Smectic','Total','Location','northwest');
answ=0;

function answ=readdata(i,iswithpoly)
global nx ny nz yescon
global dx dy dz ux uy uz qc phi S lengths
global dxpoly dypoly dzpoly Spoly
global strx stry strz strmag

A = horzcat('../data/output/dir',int2str(i),'.dat');
if (iswithpoly==1)
    Apoly = horzcat('../data/output/cdir',int2str(i),'.dat');
    A = horzcat('../data/output/lengths',int2str(i),'.dat');
    A = load(A);
    lengths=transpose(reshape(A,nx,ny,nz));
    %lengths=(lengths.*lengths)*3-3;
    %lengths(abs(lengths-1)<0.001)=1.000;
else
    Apoly=A;
end

A = horzcat('../data/output/dir',int2str(i),'.dat');
it=1;
while(~exist(A))
    pause(it);
    it=it+1;
    if(it>10)
        break;
    end
end
if(nz>1)
    A = load(A);
    dx=reshape(A(:,1),nx,ny,nz);
    dy=reshape(A(:,2),nx,ny,nz);
    dz=reshape(A(:,3),nx,ny,nz);
    A = horzcat('../data/output/vel',int2str(i),'.dat');
    A = load(A);
    rh=reshape(A(:,1),nx,ny,nz);
    ux=reshape(A(:,2),nx,ny,nz);
    uy=reshape(A(:,3),nx,ny,nz);
    uz=reshape(A(:,4),nx,ny,nz);
    A = horzcat('../data/output/phi',int2str(i),'.dat');
    A = load(A);
    phi=reshape(A,nx,ny,nz);
else
    A = load(A);
    dx=transpose(reshape(A(:,1),nx,ny,nz));
    dy=transpose(reshape(A(:,2),nx,ny,nz));
    dz=transpose(reshape(A(:,3),nx,ny,nz));
    S=transpose(reshape(A(:,4),nx,ny,nz));
    
    Apoly = load(Apoly);
    dxpoly=transpose(reshape(Apoly(:,1),nx,ny,nz));
    dypoly=transpose(reshape(Apoly(:,2),nx,ny,nz));
    dzpoly=transpose(reshape(Apoly(:,3),nx,ny,nz));
    Spoly=transpose(reshape(Apoly(:,4),nx,ny,nz));
    
    A = horzcat('../data/output/vel',int2str(i),'.dat');
    A = load(A);
    rh=transpose(reshape(A(:,1),nx,ny,nz));
    ux=transpose(reshape(A(:,2),nx,ny,nz));
    uy=transpose(reshape(A(:,3),nx,ny,nz));
    uz=transpose(reshape(A(:,4),nx,ny,nz));
    
    A = horzcat('../data/output/vel',int2str(i),'.dat');
    A = load(A);
    strmag=transpose(reshape(A(:,1),nx,ny,nz));
    strx=transpose(reshape(A(:,2),nx,ny,nz));
    stry=transpose(reshape(A(:,3),nx,ny,nz));
    strz=transpose(reshape(A(:,4),nx,ny,nz));
    %strmag=strmag+0.25;%for elastic stresses, unless code is changed
    strx=strx.*strmag;
    stry=stry.*strmag;
    strz=strz.*strmag;
    
    A = horzcat('../data/output/chag',int2str(i),'.dat');
    if(exist(A))
        A = load(A);
        qc=transpose(reshape(A,nx,ny,nz));
    else
        qc=[];
    end
    A = horzcat('../data/output/phi',int2str(i),'.dat');%phi
    if(exist(A))
        A = load(A);
        yescon=1;
        phi=transpose(reshape(A(:,1),nx,ny,nz));
        %phi=lengths.*(1-phi).*(1-phi);
    else
        yescon=0;
        phi=[];
    end
end;
%clf;
answ=0;

function answ=readpara
global nx ny nz
fid=fopen('../src/parameters.h');
for i=1:4
tline = fgetl(fid);
end
nx=fscanf(fid,'%*s %*s %d',1);
fgetl(fid);
ny=fscanf(fid,'%*s %*s %d',1);
fgetl(fid);
nz=fscanf(fid,'%*s %*s %d',1);
for i=1:3
tline = fgetl(fid);
end
istart=fscanf(fid,'%*s %*s %d',1);
fgetl(fid);
iend=fscanf(fid,'%*s %*s %d',1);
fgetl(fid);
igap=fscanf(fid,'%*s %*s %d',1);
fgetl(fid);
answ=[nx ny nz istart iend igap];

function answ=plotgeometry(nx,ny,nz)
A = load('../data/output/wedge_geometry.dat');
geom=reshape(A(:,1),nx+2,ny+2,nz+2);
geom(:,:,3)=[];geom(:,:,1)=[];
geom=transpose(geom);
clf;
contour(geom);
shading flat;
axis equal;
drawnow;
answ=0;

function answ=calcs(diryp,dirzp)
dry=diryp;
drz=dirzp;
[m n]=size(dry);
wn=zeros(size(dry));
for j=2:n-1
    for i=2:m-1
        if((i==11)&&(j==70))
            i
        end
        ax1=[dry(i+1,j) drz(i+1,j)];
        ax2=[dry(i-1,j) drz(i-1,j)];
        ax3=[dry(i,j-1) drz(i,j-1)];
        ax4=[dry(i,j+1) drz(i,j+1)];
        ax5=[dry(i+1,j-1) drz(i+1,j-1)];
        ax6=[dry(i-1,j-1) drz(i-1,j-1)];
        ax7=[dry(i+1,j+1) drz(i+1,j+1)];
        ax8=[dry(i-1,j+1) drz(i-1,j+1)];
        
        dang=wang(ax1,ax5);
        dang=dang+wang(ax5,ax3);
        dang=dang+wang(ax3,ax6);
        dang=dang+wang(ax6,ax2);
        dang=dang+wang(ax2,ax8);
        dang=dang+wang(ax8,ax4);
        dang=dang+wang(ax4,ax7);
        dang=dang+wang(ax7,ax1);
        
        wn(i,j)=dang/2/pi;
    end
end
answ=wn;

function answ=wang(ax1,ax2)
ang=atan2(abs(det([ax1;ax2])),dot(ax1,ax2));
if(ang>pi/2)
    ax2=-ax2;
end;
m=det([ax1;ax2]);
ang=sign(m)*atan2(abs(m),dot(ax1,ax2));
answ=ang;

function dataanalysis(vrms,nx,ny,nz,ux,uy,uz,dx,dy,dz,qc,i,nb,tm)
%calcorrelations(nx,ny,nz,ux,uy,dx,dy,i,nb,tm);
calcnoofdefects(nx,ny,nz,dx,dy,dz,qc,i,tm);
calcavgcorrelations(i,nb,vrms)

function calcnoofdefects(nx,ny,nz,dx,dy,dz,qc,tm,tmax)
if(tmax>tm) return; end;
if(isempty(qc))
    wn=calcs(dx,dy);
else
    wn=qc;
end
wnr=round(2*wn);
wnrp=sum(sum((wnr+abs(wnr))/2))/4;
wnrn=sum(sum((abs(wnr)-wnr)/2))/4;
nlp=sqrt(ny*nz/wnrp);
nln=sqrt(ny*nz/wnrn);
nla=sqrt(ny*nz/(wnrp+wnrn));
if(exist('vcorrs')~=7) mkdir vcorrs; end;
if(tmax==tm)
    fid = fopen('vcorrs/hwn.txt','wt');
else
    fid = fopen('vcorrs/hwn.txt','a');
end
fprintf(fid,'%6.5f %6.5f %6.5f %6.5f %6.5f %6.5f %6.5f\n',[tm wnrp wnrn wnrp+wnrn nlp nln nla]');
fclose(fid);

function calcorrelations(nx,ny,nz,ux,uy,dx,dy,tm,nb,tmax)
if(tmax>tm) return; end;
dyux=gradient(ux')';
dxuy=gradient(uy);
ov=dxuy-dyux;
xx=dx.*dx;
yy=dy.*dy;
xy=dx.*dy;
if(nb>1)
    v=reshape(sum(sum(reshape(ux,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    w=reshape(sum(sum(reshape(uy,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    omg=reshape(sum(sum(reshape(ov,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    dxx=reshape(sum(sum(reshape(xx,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    dxy=reshape(sum(sum(reshape(xy,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    dyy=reshape(sum(sum(reshape(yy,[nb ny/nb nb nx/nb]),1),3),[ny/nb nx/nb])/(nb*nb);
    p=sqrt(dxx).*sign(dxy); q = sqrt(dyy);
else
    v=ux; w=uy; p=dx; q=dy; omg=ov;
end
[m n]=size(v);
[y z] = meshgrid(linspace(1,m,m),linspace(1,n,n));
crnt=0;
radn=(1:m)-1;
drad=1;
corrm=zeros(size(radn));
oorrm=zeros(size(radn));
dorrm=zeros(size(radn));
v0norm=0;
omnorm=0;
d0norm=0;
for i=1:n
    for j=1:m
        rdist=sqrt((y-i).^2+(z-j).^2);
        v0norm=v0norm+v(j,i)*v(j,i)+w(j,i)*w(j,i);
        omnorm=omnorm+omg(j,i)*omg(j,i);
        d0norm=d0norm+p(j,i)*p(j,i)+q(j,i)*q(j,i);
        for k=1:m
            vecta=[];
            ndist=find((rdist>=radn(k))&(rdist<radn(k)+drad));
            if(~isempty(ndist))
                vectb = [v(ndist) w(ndist)];
                vecta = repmat([v(j,i) w(j,i)],size(ndist));
                corrm(k)=corrm(k)+mean(sum(vecta.*vectb,2));
                vectb=omg(ndist);
                vecta=omg(j,i);
                oorrm(k)=oorrm(k)+mean(vecta*vectb);
                vecta=[];
                vectb = [p(ndist) q(ndist)];
                vecta = repmat([p(j,i) q(j,i)],size(ndist));
                u1v1=vecta(:,1).*vectb(:,1);
                u2v2=vecta(:,2).*vectb(:,2);
                dotv=u1v1+u2v2;
                u1v2=vecta(:,1).*vectb(:,2);
                u2v1=vecta(:,2).*vectb(:,1);
                cros=u1v2-u2v1;
                ang=atan2(abs(cros),dotv);
                cx=repmat(ang>(pi/2),1,2);
                vectb=(1-2*cx).*vectb;
                dorrm(k)=dorrm(k)+mean(sum(vecta.*vectb,2));
            end
        end
    end
        %semilogx(corrm); hold on;pause(1);
end

Y=linspace(1,ny,ny/nb);
if(exist('vcorrs')~=7) mkdir vcorrs; end;

af=[Y' corrm'/(m*n)];
fid = fopen(horzcat('vcorrs/vcorr',num2str(tm),'_',num2str(nb),'.dat'),'wt');
fprintf(fid,'%6.2f %0.7g\n',af');
fclose(fid);
af=[Y' dorrm'/(m*n)];
fid = fopen(horzcat('vcorrs/dcorr',num2str(tm),'_',num2str(nb),'.dat'),'wt');
fprintf(fid,'%6.2f %0.7g\n',af');
fclose(fid);
af=[Y' oorrm'/(m*n)];
fid = fopen(horzcat('vcorrs/ocorr',num2str(tm),'_',num2str(nb),'.dat'),'wt');
fprintf(fid,'%6.2f %0.7g\n',af');
fclose(fid);

function calcavgcorrelations(i,nb,vrms)
global cnt vv dd oo
%Vrms averaging
if(cnt==1)
    fid = fopen('vcorrs/vrms.txt','wt');
else
    fid = fopen('vcorrs/vrms.txt','a');
end
fprintf(fid,'%6.2f %0.7g\n',[i vrms(cnt)]');
fclose(fid);
ac=load('vcorrs/vrms.txt');
fid = fopen(horzcat('vcorrs/vrmsavg.txt'),'wt');
fprintf(fid,'%0.7f',mean(ac(:,2)));
%vv correlations averaging
if(cnt==1) vv=0; dd=0; oo=0; end;
acv = horzcat('vcorrs/vcorr',num2str(i),'_',num2str(nb),'.dat');
if(~(exist(acv)))
    disp(sprintf('breaking at %d',i));
    return;
end;
acd = horzcat('vcorrs/dcorr',num2str(i),'_',num2str(nb),'.dat');
aco = horzcat('vcorrs/ocorr',num2str(i),'_',num2str(nb),'.dat');
a=load(acv); vv= vv+a(:,2); af=[a(:,1) vv/cnt];
fid = fopen(horzcat('vcorrs/vcorravg','_',num2str(nb),'.dat'),'wt');
fprintf(fid,'%6.2f %0.7g\n',af'); fclose(fid);
a=load(acd); dd= dd+a(:,2); af=[a(:,1) dd/cnt];
fid = fopen(horzcat('vcorrs/dcorravg','_',num2str(nb),'.dat'),'wt');
fprintf(fid,'%6.2f %0.7g\n',af'); fclose(fid);
a=load(aco); oo= oo+a(:,2); af=[a(:,1) oo/cnt];
fid = fopen(horzcat('vcorrs/ocorravg','_',num2str(nb),'.dat'),'wt');
fprintf(fid,'%6.2f %0.7g\n',af'); fclose(fid);
%No of defects averaging
ac = load('vcorrs/hwn.txt');
fid = fopen(horzcat('vcorrs/hwnavg.txt'),'wt');
fprintf(fid,'%6.2f',mean(ac(:,2)));

function tracertrack(tm,vrms,nstream)
global nx ny nz cnt
global ux uy uz
A = load(horzcat('../data/output/tracersmsd.dat'));
A(1,:)=[];
clf;
loglog(A(:,1),A(:,2));
figure;
plotstreamline(tm,nx,ny,nz,ux,uy,nstream,vrms(length(vrms)));
axis auto;
hold on;
A = load(horzcat('../data/output/tracersloc.dat'));
for i=1:64
    plot(A(1,2*i),A(1,2*i+1),'g*');
    plot(A(:,2*i),A(:,2*i+1),'r');
end   

function defectstrack(tm,vrms,nstream)
global nx ny nz cnt
global dx dy qc
plotcharges(tm,nx,ny,nz,qc);
axis auto;
hold on; grid on;
A = dlmread(horzcat('../data/output/defcoords.dat'));
for i=1:100
    plot(A(1,2*i),A(1,2*i+1),'w*');
    plot(A(:,2*i),A(:,2*i+1),'r');
end 

function stresscalc(i)
global nx ny nz
A = load(horzcat('../data/output/isos',int2str(i),'.dat'));
ixx=transpose(reshape(A(:,1),nx,ny,nz));
iyy=transpose(reshape(A(:,2),nx,ny,nz));
izz=transpose(reshape(A(:,3),nx,ny,nz));
A = load(horzcat('../data/output/anisos',int2str(i),'.dat'));
axx=transpose(reshape(A(:,1),nx,ny,nz));
ayy=transpose(reshape(A(:,2),nx,ny,nz));
azz=transpose(reshape(A(:,3),nx,ny,nz));
axy=transpose(reshape(A(:,4),nx,ny,nz));
A = load(horzcat('../data/output/elast',int2str(i),'.dat'));
exx=transpose(reshape(A(:,1),nx,ny,nz));
eyy=transpose(reshape(A(:,2),nx,ny,nz));
ezz=transpose(reshape(A(:,3),nx,ny,nz));
exy=transpose(reshape(A(:,4),nx,ny,nz));
A = load(horzcat('../data/output/sigma',int2str(i),'.dat'));
sxx=transpose(reshape(A(:,1),nx,ny,nz));
syy=transpose(reshape(A(:,2),nx,ny,nz));
szz=transpose(reshape(A(:,3),nx,ny,nz));
sxy=transpose(reshape(A(:,4),nx,ny,nz));
A = load(horzcat('../data/output/tau',int2str(i),'.dat'));
txx=transpose(reshape(A(:,1),nx,ny,nz));
tyy=transpose(reshape(A(:,2),nx,ny,nz));
tzz=transpose(reshape(A(:,3),nx,ny,nz));
txy=transpose(reshape(A(:,4),nx,ny,nz));
% clf; hold on
% plot(reshape(sxx,nx*ny,1),'ro');
% plot(reshape(syy,nx*ny,1),'r*');
% plot(reshape(sxy,nx*ny,1),'r+');
% clf; hold on
% plot(reshape(axx,nx*ny,1),'go');
% plot(reshape(ayy,nx*ny,1),'g*');
% plot(reshape(axy,nx*ny,1),'g+');
aaa = axx;
cla;
colormap jet
[c qh]=contourf(aaa);
%isosurface(phi,0.5);
%patch('Faces',f,'Vertices',v)
axis tight;
axis equal;
shading flat;
maxq=max(max(aaa));
minq=min(min(aaa));
if(maxq==minq) maxq=minq*0.99; end;
%if(minq>-0.5) minq=-0.5; end;
set(qh,'LineStyle','none');
%set(qh,'LineColor','b');
caxis([minq maxq]);
colorbar;
title(horzcat('Timesteps: ',int2str(i)));
drawnow;
hold on;
%checktanh(nx,ny,phi)
answ=0;

function stressanalysis(i)
global nx ny nz
A = load(horzcat('../data/output/visc',int2str(i),'.dat'));
exx=transpose(reshape(A(:,1),nx,ny,nz));
eyy=transpose(reshape(A(:,2),nx,ny,nz));
ezz=transpose(reshape(A(:,3),nx,ny,nz));
exy=transpose(reshape(A(:,4),nx,ny,nz));
A = load(horzcat('../data/output/acti',int2str(i),'.dat'));
axx=transpose(reshape(A(:,1),nx,ny,nz));
ayy=transpose(reshape(A(:,2),nx,ny,nz));
azz=transpose(reshape(A(:,3),nx,ny,nz));
axy=transpose(reshape(A(:,4),nx,ny,nz));
A = load(horzcat('../data/output/pass',int2str(i),'.dat'));
pxx=transpose(reshape(A(:,1),nx,ny,nz));
pyy=transpose(reshape(A(:,2),nx,ny,nz));
pzz=transpose(reshape(A(:,3),nx,ny,nz));
pxy=transpose(reshape(A(:,4),nx,ny,nz));
A = load(horzcat('../data/output/pasa',int2str(i),'.dat'));
qxx=0;%transpose(reshape(A(:,1),nx,ny,nz));
qyy=0;%transpose(reshape(A(:,2),nx,ny,nz));
qzz=0;%transpose(reshape(A(:,3),nx,ny,nz));
qxy=transpose(reshape(A(:,4),nx,ny,nz));
A = load(horzcat('../data/output/isopas',int2str(i),'.dat'));
ixx=transpose(reshape(A(:,2),nx,ny,nz));
A = load(horzcat('../data/output/varpas',int2str(i),'.dat'));
vpxx=transpose(reshape(A(:,1),nx,ny,nz));
vpyy=transpose(reshape(A(:,2),nx,ny,nz));
vpzz=transpose(reshape(A(:,3),nx,ny,nz));
vpxy=transpose(reshape(A(:,4),nx,ny,nz));
A = load(horzcat('../data/output/lampas',int2str(i),'.dat'));
lpxx=transpose(reshape(A(:,1),nx,ny,nz));
lpyy=transpose(reshape(A(:,2),nx,ny,nz));
lpzz=transpose(reshape(A(:,3),nx,ny,nz));
lpxy=transpose(reshape(A(:,4),nx,ny,nz));
stressalone(i,exy,axy,pxy,qxy,'off');
stressalone(i,exx,axx,pxx,qxx,'');
stressalone(i,eyy,ayy,pyy,qyy,'');
stressdirector(i,exy,axy,pxy,qxy);
clf; hold on
plot(reshape(lpxx,nx*ny,1),'ro');
plot(reshape(lpyy,nx*ny,1),'r*');
plot(reshape(lpxy,nx*ny,1),'r+');
plot(reshape(vpxx,nx*ny,1),'go');
plot(reshape(vpyy,nx*ny,1),'g*');
plot(reshape(vpxy,nx*ny,1),'g+');
plot(reshape(qxy,nx*ny,1),'yo');
plot(reshape(ixx,nx*ny,1),'o');
legend('xx-lam','yy-lam','xy-lam','xx-var','yy-var','xy-var','anti','iso');
clf; hold on
plot(reshape(vpxx,nx*ny,1),'go');
plot(reshape(vpyy,nx*ny,1),'g*');
plot(reshape(vpxy,nx*ny,1),'g+');
plot(reshape(ixx,nx*ny,1),'o');
legend('xx-var','yy-var','xy-var','iso');
 
function stressalone(i,exy,axy,pxy,qxy,leg)
global nx ny nz
if(isempty(leg))
    pxy=pxy+0.25;
end;
maxxy=max([max(max(exy)) max(max(axy)) max(max(pxy+qxy))]);
minxy=min([min(min(exy)) min(min(axy)) min(min(pxy+qxy))]);
fig1=figure; subplot(1,3,1);
contourf(-exy); shading flat; axis tight; grid on;hold on;
caxis([minxy maxxy]);
title(horzcat('-ve viscous stress - ',leg,'diagonal'));
subplot(1,3,2);
contourf(axy); shading flat; axis tight; grid on;hold on;
caxis([minxy maxxy]);
title(horzcat('Active stress - ',leg,'diagonal'));
subplot(1,3,3);
contourf(pxy+qxy); shading flat; axis tight; grid on;hold on;
caxis([minxy maxxy]);
title(horzcat('Passive stress - ',leg,'diagonal'));
pexyl = reshape(exy,nx*ny,1);
paxyl = reshape(axy,nx*ny,1);
ppxyl = reshape(pxy+qxy,nx*ny,1);
figure;
[nh ch]=hist([pexyl paxyl ppxyl],20);
bar(ch,nh/(nx*ny)*100);
ylabel('% Number of points in an interval of stress');
xlabel('Stress');
legend('Viscous','Active','Passive');
1;

function stressdirector(i,exy,axy,pxy,qxy)
global nx ny nz
global dx dy dz ux uy uz qc
maxxy=max([max(max(exy)) max(max(axy)) max(max(pxy+qxy))]);
minxy=min([min(min(exy)) min(min(axy)) min(min(pxy+qxy))]);
fig1=figure;
contourf(exy); shading flat; axis tight; grid on;hold on;
caxis([minxy maxxy]);
title('Viscous stress - off diagonal');
plotdirector(i,nx,ny,nz,dx,dy,1);
fig2=figure;
contourf(axy); shading flat; axis tight; grid on;hold on;
caxis([minxy maxxy]);
title('Active stress - offdiagonal');
plotdirector(i,nx,ny,nz,dx,dy,1);
fig3=figure;
contourf(pxy+qxy); shading flat; axis tight; grid on;hold on;
caxis([minxy maxxy]);
title('Passive stress - offdiagonal');
plotdirector(i,nx,ny,nz,dx,dy,1);
1;

function forceanalysis(i)
global nx ny nz
A = load(horzcat('../data/output/vforce',int2str(i),'.dat'));
ex=transpose(reshape(A(:,1),nx,ny,nz));
ey=transpose(reshape(A(:,2),nx,ny,nz));
ez=transpose(reshape(A(:,3),nx,ny,nz));
A = load(horzcat('../data/output/aforce',int2str(i),'.dat'));
ax=transpose(reshape(A(:,1),nx,ny,nz));
ay=transpose(reshape(A(:,2),nx,ny,nz));
az=transpose(reshape(A(:,3),nx,ny,nz));
A = load(horzcat('../data/output/pforce',int2str(i),'.dat'));
px=transpose(reshape(A(:,1),nx,ny,nz));
py=transpose(reshape(A(:,2),nx,ny,nz));
pz=transpose(reshape(A(:,3),nx,ny,nz));
A = load(horzcat('../data/output/qforce',int2str(i),'.dat'));
qx=transpose(reshape(A(:,1),nx,ny,nz));
qy=transpose(reshape(A(:,2),nx,ny,nz));
qz=transpose(reshape(A(:,3),nx,ny,nz));
%forcebarplot(i,ex,ey,ax,ay,px,py,qx,qy);
forcemagdirector(i,ex,ey,ax,ay,px,py,qx,qy);
%forcealone(i,ex,ey,ax,ay,px,py,qx,qy);

function forcebarplot(i,ex,ey,ax,ay,px,py,qx,qy)
global nx ny nz
[Y1, I]=sort(abs(reshape(ax,nx*ny,1))) ;
Y = abs(reshape(ex,nx*ny,1));
Y2 = Y(I);
Y = abs(reshape(px+qx,nx*ny,1));
Y3 = Y(I);
x=(1:nx*ny)/(nx*ny)*100;
%ty=Y1+Y2+Y3;
tymax = max([max(Y1+Y2) max(Y1+Y3)]);
n=nx*ny;
ncut=round(0.01*n);
figure;
subplot(1,2,1);
bar(x(ncut:n),[Y1(ncut:n) Y2(ncut:n)],'stacked')
legend('Active','Viscous'); axis tight;
set(gca,'YLim',[0 tymax]);
subplot(1,2,2);
bar(x(ncut:n),[Y1(ncut:n) Y3(ncut:n)],'stacked')
legend('Active','Elastic'); axis tight;
set(gca,'YLim',[0 tymax]);
figure
ncut=round(0.9*n);
subplot(1,2,1);
bar(x(ncut:n),[Y1(ncut:n) Y2(ncut:n)],'stacked')
legend('Active','Viscous'); axis tight;
set(gca,'YLim',[0 tymax]);
subplot(1,2,2);
bar(x(ncut:n),[Y1(ncut:n) Y3(ncut:n)],'stacked')
legend('Active','Elastic'); axis tight;
set(gca,'YLim',[0 tymax]);
figure
ncut=round(0.99*n);
subplot(1,2,1);
bar(x(ncut:n),[Y1(ncut:n) Y2(ncut:n)],'stacked')
legend('Active','Viscous'); axis tight;
set(gca,'YLim',[0 tymax]);
subplot(1,2,2);
bar(x(ncut:n),[Y1(ncut:n) Y3(ncut:n)],'stacked')
legend('Active','Elastic'); axis tight;
set(gca,'YLim',[0 tymax]);
figure
ncut=round(0.995*n);
subplot(1,2,1);
bar(x(ncut:n),[Y1(ncut:n) Y2(ncut:n)],'stacked')
legend('Active','Viscous'); axis tight;
set(gca,'YLim',[0 tymax]);
subplot(1,2,2);
bar(x(ncut:n),[Y1(ncut:n) Y3(ncut:n)],'stacked')
legend('Active','Elastic'); axis tight;
set(gca,'YLim',[0 tymax]);
1;

function forcemagdirector(i,ex,ey,ax,ay,px,py,qx,qy)
global nx ny nz
global dx dy dz ux uy uz qc
nc=20;
%nx1=230;nx2=290;ny1=230;ny2=290;
%nx1=130;nx2=200;ny1=80; ny2=150;
%nx1=70;nx2=130;ny1=40; ny2=100;
nx1=130;nx2=190;ny1=20; ny2=80;
ef=sqrt(ex.*ex+ey.*ey);
af=sqrt(ax.*ax+ay.*ay);
pf=sqrt((px+qx).*(px+qx)+(py+qy).*(py+qy));
maxxy=max([max(max(ef)) max(max(af)) max(max(pf))]);
minxy=min([min(min(ef)) min(min(af)) min(min(pf))]);
fig1=gcf; subplot(1,3,1);
contourf(ef,nc); shading flat; axis tight; grid on;hold on;
plotdirector(i,nx,ny,nz,dx,dy,1);
caxis([minxy maxxy]); hold off;
title('Viscous force');axis([nx1 nx2 ny1 ny2]);
subplot(1,3,2);
contourf(af,nc); shading flat; axis tight; grid on;hold on;
plotdirector(i,nx,ny,nz,dx,dy,1);
title('Active force');axis([nx1 nx2 ny1 ny2]);
caxis([minxy maxxy]); hold off;
subplot(1,3,3);
contourf(pf,nc); shading flat; axis tight; grid on;hold on;
plotdirector(i,nx,ny,nz,dx,dy,1);
caxis([minxy maxxy]); hold off;
title('Passive force');axis([nx1 nx2 ny1 ny2]);
drawnow;
1;

function poisecomparison(i,nx,ny,nz,u,v)
vmax=0;
tau=2.5;
g=0.0001;
mu=(tau-0.5)/3;
h = ny/2;
if(i==0) display(horzcat('tau = ',num2str(tau),', g = ',num2str(g))); end;
hd = linspace(-h,h,ny+1);
ut = (1 - (hd/h).^2)*g*h*h/2/mu;
%u = u';v=v';
if(vmax==0) vmax=abs(max(max(max(u)))); end;
subplot(2,1,1);
%quiver(u,v);
plot(u/max(u),1:ny);
hold on;
plot(ut/max(ut),hd+h+0.5,'r');
hold off;
title(horzcat('time = ',int2str(i)));
subplot(2,1,2);
plot(u,1:ny);
hold on;
plot(ut,hd+h+0.5,'r');
hold off;
pause(1)
1;

function energycalculations(i,nx,ny,nz,ux,uy);
global tau fcoef
if(i==0)
    tau = input('please input tau:');
    fcoef = input('please input fcoef: ');
end
Lx = (tau-0.5)/3*del2(ux);
Ly = (tau-0.5)/3*del2(uy);
Gx = fcoef*ux;
Gy = fcoef*uy;
Rx = Gx./Lx;
Ry = Gy./Ly;
meaL = sum(sum(abs(Lx)+abs(Ly)))/(nx*ny);
meaG = sum(sum(abs(Gx)+abs(Gy)))/(nx*ny);
fprintf(horzcat(', Vis/Fri = ',num2str(meaL/meaG)));
% figure;;
% subplot(2,1,1);
% contourf(Rx);
% shading flat;
% subplot(2,1,2);
% contourf(Ry);
% shading flat;
1;

function velprof(nx,ny,nz,ux,uy,uz,i,istart,igap,iend)
clf
uxave=zeros(ny,1);
for ii=1:ny
    for jj=1:nx
        uxave(ii)=uxave(ii)+ux(ii,jj);
    end
end
uxave=uxave/nx;minux=min(uxave);maxux=max(uxave);

uxmin=-0.02;
uxmax=0.02;
if(minux>uxmin) minux=uxmin; end
if(maxux<uxmax) maxux=uxmax; end

phidim=15;actint=3;polyint=8;
uxaveact=uxave(1:phidim,1);uxavepoly=uxave(phidim+1:ny,1);
itot=iend-istart;
icolor=(i-istart)/itot;
if(itot<1) icolor=1; end
plot(uxaveact,1:phidim,'-or','MarkerIndices',1:actint:length(uxaveact),'MarkerSize',5,'MarkerFaceColor',[1 1-icolor 1-icolor]);
hold on;
xline(0,'--k');
yline(phidim,'--g');
plot(uxavepoly,phidim+1:ny,'-or','MarkerIndices',1:polyint:length(uxavepoly),'MarkerSize',5,'MarkerFaceColor',[1 1-icolor 1-icolor]);
hold off;


if (i<100000)||(i>120000)
    dim = [0.15 0.88 0.1 0.02];
    str = {'\color[rgb]{0.0 0.5 0.0}Activity ON'};
    annotation('textbox',dim,'Color','red','String',str,'FitBoxToText','on');
else
    dim = [0.15 0.88 0.1 0.02];
    str = {'\color{red}Activity OFF'};
    annotation('textbox',dim,'Color','red','String',str,'FitBoxToText','on');
end
%%%%%quiver not working properly
% nact=floor(phidim/actint);
% npoly=floor((ny-phidim)/polyint);
% uxquiver=zeros(nact+npoly,4);
% for(i=1:nact) 
%     uxquiver(i,1)=0;
%     uxquiver(i,2)=i*actint;
%     uxquiver(i,3)=0;
%     uxquiver(i,4)=uxave(i*actint);
%     %quiver(0,i,uxave(i),0,'b','AutoScale','on','LineWidth',1);
% end
% for(i=1:npoly) 
%     uxquiver(nact+i,1)=0;
%     uxquiver(nact+i,2)=phidim+i*polyint;
%     uxquiver(nact+i,3)=0;
%     uxquiver(nact+i,4)=uxave(phidim+i*polyint);
%     %quiver(0,i,uxave(i),0,'b','AutoScale','on','LineWidth',1);
% end
% uxquiver
% uxquiver(:,4)=12*uxquiver(:,4)
% quiver(uxquiver(:,1),uxquiver(:,2),uxquiver(:,3),uxquiver(:,4),'b','AutoScale','off')
xlim([minux maxux]);
xlabel('Mean horizontal velocity u_x');
ylabel('y-position');
title(horzcat('Velocity profile t=',int2str(i)));



1;