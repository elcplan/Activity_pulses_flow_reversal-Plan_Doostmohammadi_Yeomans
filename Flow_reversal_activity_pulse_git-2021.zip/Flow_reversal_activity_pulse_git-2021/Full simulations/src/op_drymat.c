void dryhydrodynamics(lblattice *latv, lclattice *latc, wedge *latw, int t) {
int lps[26];/*These are for normal and mixed CDs*/
double wls[3]={0.5, 0.5, 0.5};
int *lpv=&lps[0];/*These will be used if nowedge*/
double *wlp=&wls[0];
int lpt, lpx,lmx,lpy,lmy,lpz,lmz;
double force[3];
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      lpt = (i*ny2+j)*nz2+k;
      //printf("%f %f %f %f %f %f\n",latc->qnew[lcq*lpt],latc->qnew[lcq*lpt+1],latc->qnew[lcq*lpt+2],latc->qnew[lcq*lpt+3],latc->qnew[lcq*lpt+4],latc->qnew[lcq*lpt+5]);
      if(isgeom) {
        lpv=&latw->lpv[lpt*2*lbd];
        wlp=&latw->wlp[lpt*lbd]; }
      else {
        derivativesN(i,j,k,&lpv[0]); }
      lpx = lpv[0]*lcq;//(((i+1)*ny2+j  )*nz2+k  )*lcq;/*for derivatives*/
      lmx = lpv[1]*lcq;//(((i-1)*ny2+j  )*nz2+k  )*lcq;
      lpy = lpv[2]*lcq;//(( i   *ny2+j+1)*nz2+k  )*lcq;
      lmy = lpv[3]*lcq;//(( i   *ny2+j-1)*nz2+k  )*lcq;
      lpz = lpv[4]*lcq;//(( i   *ny2+j  )*nz2+k+1)*lcq;
      lmz = lpv[5]*lcq;//(( i   *ny2+j  )*nz2+k-1)*lcq;
      /*Active forces*/
      force[0]=-zetalc*(wlp[0]*(latc->q[lpx  ]-latc->q[lmx  ])+wlp[1]*(latc->q[lpy+3]-latc->q[lmy+3])+wlp[2]*(latc->q[lpz+4]-latc->q[lmz+4]));
      force[1]=-zetalc*(wlp[0]*(latc->q[lpx+3]-latc->q[lmx+3])+wlp[1]*(latc->q[lpy+1]-latc->q[lmy+1])+wlp[2]*(latc->q[lpz+5]-latc->q[lmz+5]));
      force[2]=-zetalc*(wlp[0]*(latc->q[lpx+4]-latc->q[lmx+4])+wlp[1]*(latc->q[lpy+5]-latc->q[lmy+5])+wlp[2]*(latc->q[lpz+2]-latc->q[lmz+2]));
      for(int m=0;m<lbd;m++) latv->u[lpt*lbd+m]=force[m]/fcoef;
} } }
return;
}
