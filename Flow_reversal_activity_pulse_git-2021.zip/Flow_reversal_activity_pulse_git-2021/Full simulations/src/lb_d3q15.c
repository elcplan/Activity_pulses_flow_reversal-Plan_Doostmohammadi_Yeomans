//* functions associated with d3q15 lattice LB simulation*/

/*LB initialisation and setting parameters*/
lblattice *lbsetting() {

/*structure mlat describes all parameters associated with lb*/
lblattice *lat = d3q15_initialise();	/*initialises a D3Q15 lattice, allocates sufficient memories, function defined below*/	

return lat;
}

/////////////////////////////////

/*Lattice initialisation for d3q15*/
lblattice *d3q15_initialise(lblattice *lat) {
lat=(lblattice *)malloc(sizeof(lblattice));/*variable associated with all lattice parameters*/

lat->wt = (double *)malloc(lbq*sizeof(double));/*weights*/
lat->xi = (double *)malloc(lbd*lbq*sizeof(double));/*velocities*/
lat->complement = (int *)malloc(lbq*sizeof(int));/*velocities*/

lat->f = (double *)malloc(nx2*ny2*nz2*lbq*sizeof(double));/*distribution functions*/
lat->fnew = (double *)malloc(nx2*ny2*nz2*lbq*sizeof(double));/*distribution functions*/
lat->u = (double *)malloc(nx2*ny2*nz2*lbd*sizeof(double));/*macroscopic velocities*/
lat->rho = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*densities*/
lat->force = (double *)malloc(nx2*ny2*nz2*lbd*sizeof(double));/*forcing at each locations*/
lat->p = (double *)malloc(nx2*ny2*nz2*lbq*sizeof(double));/*distribution functions*/
lat->o = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*vorticity 2D*/

lat->tbwall=0;/*information about top-bottom wall bc, by default it is zero meaning no wall*/

if(forcea||isdragbody||isdragboun) {lat->vstress = (double *)malloc(nx2*ny2*nz2*lbd*2*sizeof(double));}/*viscous stresses to do analysis later*/

double *wt=&lat->wt[0];
double *xi=&lat->xi[0];
int *complement=&lat->complement[0];

/* Weights of velocites */
wt[0] = 2.0 / 9.0;
wt[1] = wt[2] = wt[3] = wt[4] = wt[5] = wt[6] = 1.0 / 9.0;
wt[7] = wt[8] = wt[9] = wt[10]=	wt[11] = wt[12] = wt[13] = wt[14] = 1.0 / 72.0;

/* Velocities*/
xi[0]  = 0.0; xi[1]  = 0.0; xi[2]  = 0.0; /*s=0*/
xi[3]  = 1.0; xi[4]  = 0.0; xi[5]  = 0.0; /*1*/ /*s=1*/
xi[6]  =-1.0; xi[7]  = 0.0; xi[8]  = 0.0; /*2*/
xi[9]  = 0.0; xi[10] = 1.0; xi[11] = 0.0; /*3*/
xi[12] = 0.0; xi[13] =-1.0; xi[14] = 0.0; /*4*/
xi[15] = 0.0; xi[16] = 0.0; xi[17] = 1.0; /*5*/
xi[18] = 0.0; xi[19] = 0.0; xi[20] =-1.0; /*6*/
xi[21] = 1.0; xi[22] = 1.0; xi[23] = 1.0; /*7 */ /*s=2*/
xi[24] = 1.0; xi[25] = 1.0; xi[26] =-1.0; /*8 */
xi[27] = 1.0; xi[28] =-1.0; xi[29] = 1.0; /*9 */
xi[30] = 1.0; xi[31] =-1.0; xi[32] =-1.0; /*10*/
xi[33] =-1.0; xi[34] = 1.0; xi[35] = 1.0; /*11*/
xi[36] =-1.0; xi[37] = 1.0; xi[38] =-1.0; /*12*/
xi[39] =-1.0; xi[40] =-1.0; xi[41] = 1.0; /*13*/
xi[42] =-1.0; xi[43] =-1.0; xi[44] =-1.0; /*14*/

/*complement of velocities*/
complement[0]=0;
complement[1] =2; complement[2] =1;
complement[3] =4; complement[4] =3;
complement[5] =6; complement[6] =5;
complement[7] =14;complement[14]=7;
complement[8] =13;complement[13]=8;
complement[9] =12;complement[12]=9;
complement[10]=11;complement[11]=10;

/*Body force */
lat->bforce = (double *)malloc(lbd*sizeof(double));/*body forces*/
lat->bforce[0] = gx; lat->bforce[1] = gy; lat->bforce[2] = gz;

lat->Dt=timestep;/*time increment*/
lat->cs2=(1./(lat->Dt))*(1./(lat->Dt))/3.;

return lat;
}

///////////////////////////////////////////////////////////////////////////////

/*Equilibrium calculation without 2nd moment balance*/
void normalfeqcal(lblattice *lat, int i, int j, int k,double *feq) {
double tem1,tem2;
double *u=lat->u+(((i*ny2+j)*nz2+k)*lbd);
double rho=*(lat->rho+((i*ny2+j)*nz2+k));
double *xi=&lat->xi[0];
double *wt=&lat->wt[0];
double cs2=lat->cs2;
for(int m=0;m<lbq;m++) {
   tem1=xi[m*lbd]*u[0]+xi[m*lbd+1]*u[1]+xi[m*lbd+2]*u[2];
   tem2=0.0;
   for(int ix=0;ix<lbd;ix++){
      for(int jx=0;jx<lbd;jx++){
         tem2=tem2+(u[ix]*u[jx]*(xi[m*lbd+ix]*xi[m*lbd+jx]-cs2*kdelta[ix][jx]));
      }
   }
   feq[m]=wt[m]*rho*(1+tem1/cs2+tem2/2.0/cs2/cs2);
}
return;
}

/*Calculation of equilibrium function feq, Denniston, 2004, PTRSLA*/
void feqcal(lblattice *latv, lclattice *latc, int i, int j, int k,double *feq) {
double *xi=&latv->xi[0];
double *u=latv->u+(((i*ny2+j)*nz2+k)*lbd);
double rho=*(latv->rho+((i*ny2+j)*nz2+k));
int l=((i*ny2+j)*nz2+k)*2*lbd;
double sigma[3][3];
sigma[0][0]=latc->estress[l  ];sigma[0][1]=latc->estress[l+3];sigma[0][2]=latc->estress[l+4];
sigma[1][0]=latc->estress[l+3];sigma[1][1]=latc->estress[l+1];sigma[1][2]=latc->estress[l+5];
sigma[2][0]=latc->estress[l+4];sigma[2][1]=latc->estress[l+5];sigma[2][2]=latc->estress[l+2];

double trb3 = (sigma[0][0]+sigma[1][1]+sigma[2][2])/3.;
double A2 = -trb3/10.;
double A1 = A2;
double A0 = rho - 14.*A2;

double B2 = rho/24.;
double B1 = 8.*B2;

double C2 =-B2;
double C1 = 2.*C2;
double C0 = -2.*rho/3.;

double D2 = rho/16.;
double D1 = 8.*D2; 

double E2[3][3];


for(int p=0;p<3;p++)
   for(int q=0;q<3;q++) E2[p][q] = (-sigma[p][q]+trb3*kdelta[p][q])/16.; 

double u2 = u[0]*u[0]+u[1]*u[1]+u[2]*u[2];
double tem1,tem2;
feq[0] = A0+C0*u2;
for(int m=1;m<=6;m++) {
  tem1 = u[0]*xi[3*m+0]+u[1]*xi[3*m+1]+u[2]*xi[3*m+2];
  tem2 = 0;
  for(int p=0;p<3;p++)
    for(int q=0;q<3;q++) tem2=tem2+E2[p][q]*xi[3*m+p]*xi[3*m+q];
      feq[m] = A1+B1*tem1+C1*u2+D1*tem1*tem1+8.*tem2;
}

for(int m=7;m<=14;m++) {
  tem1 = u[0]*xi[3*m+0]+u[1]*xi[3*m+1]+u[2]*xi[3*m+2];
  tem2 = 0;
  for(int p=0;p<3;p++)
    for(int q=0;q<3;q++) tem2=tem2+E2[p][q]*xi[3*m+p]*xi[3*m+q];
      feq[m] = A2+B2*tem1+C2*u2+D2*tem1*tem1+tem2;
}
return;
}

/*To calculate where to propagate*///Not using right now
/*int lbnewwall(int i, int j, int k, int m,int wall) {
i=i+lat->xi[lbd*m];
j=j+lat->xi[lbd*m+1];
k=k+lat->xi[lbd*m+2];
if(j==0) {if(!wall)j=ny;};
if(j==ny+1) {if(!wall)j=1;};
if(i==0) i=nx;
if(k==0) k=nz;
if(i==nx+1) i=1;
if(k==nz+1) k=1;
return ((i*ny2+j)*nz2+k)*lbq+m;
}*/


///////////////////////////////////// Collision operators///////////
/*no collisions*/
void nocolliding(lblattice *latv,lclattice *latc, wedge *latw) {
int l,lpt,inew,jnew;
double Dt=latv->Dt;
forcedistributions(latv);
for(int i=1;i<=nx;i++) {
  inew=i*ny2;
  for(int j=1;j<=ny;j++) {
    jnew=(inew+j)*nz2;
    for(int k=1;k<=nz;k++) {
    	lpt=jnew+k;
      if(latw->w[lpt]>=0) {
    	l=lpt*lbq;
  	  for(int m=0;m<lbq;m++) {
        latv->fnew[l+m]=latv->f[l+m]+Dt*latv->p[l+m];
	    };};};};};
return;
}

/*lb collisions*/
void lbcolliding(lblattice *latv,lclattice *latc, wedge *latw) {
double feq[lbq];
int l,lpt,inew,jnew;
double Dt=latv->Dt;
forcedistributions(latv);
for(int i=1;i<=nx;i++) {
  inew=i*ny2;
  for(int j=1;j<=ny;j++) {
    jnew=(inew+j)*nz2;
    for(int k=1;k<=nz;k++) {
    	lpt=jnew+k;
      if(latw->w[lpt]>=0) {
    	l=lpt*lbq;
      feqcal(latv,latc,i,j,k,feq);
  	  //normalfeqcal(mlat,i,j,k,feq);
  	  for(int m=0;m<lbq;m++) {
        latv->fnew[l+m]=latv->f[l+m]-(latv->f[l+m]-feq[m])*Dt/taulb+Dt*latv->p[l+m];
	    };};};};};
return;
}

///////////////////////////////// Streaming operators/////////////
/*lb streaming*/
void streaming(lblattice *latv, wedge *latw) {
int l,lpt,lnew,inew,jnew,is,js,ks;
int lmin=0;
int lmax=nx2*ny2*nz2*lbq;
double *xi=&latv->xi[0];
for(int i=0;i<nx2;i++) {
  inew=i*ny2;
  for(int j=0;j<ny2;j++) {
    jnew=(inew+j)*nz2;
    for(int k=0;k<nz2;k++) {
      lpt=jnew+k;
      if(latw->w[lpt]>=-1) {
      l=lpt*lbq;
      for(int m=0;m<lbq;m++) { 	/*Whenever we stream to is=-1 or is=nx2 or js=-1 or js=ny2 or ks=-1 or ks=nz2*/
        is=i+xi[lbd*m]; 	/*which are actually outside the domain cannot represent a point in the bulk.*/
        js=j+xi[lbd*m+1]; 	/*At most these can be points on borders which we will not be using up in */
        ks=k+xi[lbd*m+2];	/*collision and we will always be safe with i,j,k running from 0 to nxyz2*/
	lnew=((is*ny2+js)*nz2+ks)*lbq;	/*See notebook if in doubt*/
        if(lnew>=lmin) {
          if(lnew<=lmax) {latv->f[lnew+m]=latv->fnew[l+m]; }; };
    } } } } };
return;
}

/*hydrodyanmical variable calculations*/
void hydrocalc(lblattice *lat) {
int iw, jw, kw, dw, l;
double rho, u[3];
double *xi=&lat->xi[0];
//double Dt=lat->Dt;
for(int i=1;i<=nx;i++) {
  iw=i*ny2;
  for(int j=1;j<=ny;j++) {
    jw=(iw+j)*nz2;
    for(int k=1;k<=nz;k++) {
      kw=jw+k;
      l=kw*lbq;
      dw=kw*lbd;
      rho=0.0;
      u[0]=0.0;
      u[1]=0.0;
      u[2]=0.0;
      for(int m=0;m<lbq;m++) {
        rho+=lat->f[l+m];
        u[0]+=lat->f[l+m]*xi[m*lbd];
        u[1]+=lat->f[l+m]*xi[m*lbd+1];
        u[2]+=lat->f[l+m]*xi[m*lbd+2]; } 
      lat->rho[kw]=rho;
      /*as in Miha's*/
      lat->u[dw]  =(u[0])/rho;
      lat->u[dw+1]=(u[1])/rho;
      lat->u[dw+2]=(u[2])/rho;
//Emmanuel's comment: What are these comments below for?
      /*lat->u[dw]  =(u[0]+0.5*Dt*lat->force[dw])/rho;
      lat->u[dw+1]=(u[1]+0.5*Dt*lat->force[dw+1])/rho;
      lat->u[dw+2]=(u[2]+0.5*Dt*lat->force[dw+2])/rho;*/
	  } } }
return;
}

/*Calculating the distribution functions associated with the forcing*/
void forcedistributions(lblattice *latv) {
//double fakt=1-0.5/taulb;
//double tem0;
double tem1;
double cs2=latv->cs2;
//double cs4=cs2*cs2;
int inew,jnew,knew,l;
double force[3];
double *xi=&latv->xi[0];
double *wt=&latv->wt[0];
for(int i=1;i<=nx;i++) {
  inew=i*ny2;
  for(int j=1;j<=ny;j++) {
    jnew=(inew+j)*nz2;
    for(int k=1;k<=nz;k++) {
      knew=(jnew+k)*lbd;
      l=(jnew+k)*lbq;
      force[0]=latv->force[knew];
      force[1]=latv->force[knew+1];
      force[2]=latv->force[knew+2];
      for(int m=0;m<lbq;m++) {
//Emmanueel's comment: I will not delete the comments here yet...
///*correct ones*/ /*but then we are not including force in velocity calcs*/
        /*tem0=(xi[lbd*m]*latv->u[knew]+xi[lbd*m+1]*latv->u[knew+1]+xi[lbd*m+2]*latv->u[knew+2])/cs4;
        tem1=((xi[lbd*m]-latv->u[knew])/cs2+tem0*xi[lbd*m])*force[0];
	tem1=tem1+((xi[lbd*m+1]-latv->u[knew+1])/cs2+tem0*xi[lbd*m+1])*force[1];
  	tem1=tem1+((xi[lbd*m+2]-latv->u[knew+2])/cs2+tem0*xi[lbd*m+2])*force[2];
        latv->p[l+m]=wt[m]*fakt*tem1;*/
	/*as in mihas*/ /*this is correct only for a constant force, but ppl seem to be using this so do we*/
	tem1=(xi[lbd*m]/cs2)*force[0]+(xi[lbd*m+1]/cs2)*force[1]+(xi[lbd*m+2]/cs2)*force[2];
        latv->p[l+m]=wt[m]*tem1;
	    } } } }
return;
}
