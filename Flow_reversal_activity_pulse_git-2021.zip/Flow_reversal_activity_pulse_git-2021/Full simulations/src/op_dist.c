/*This is a draft to calculate values a distance d from inside the phase */
void stiffness(lblattice *latv,  lclattice *latc, int tm){

FILE *aaaptr, *aabptr;
char nname[500];
//int freq=100;
//if(tm%freq==0){
sprintf(nname,"%s/output/aaa%d.dat",DPATH,tm);
aaaptr=fopen(nname,"w");
sprintf(nname,"%s/output/aab%d.dat",DPATH,tm);
aabptr=fopen(nname,"w");
//}

int dmin2,dist2;
int imin, jmin;
float **smatrix, **dc;
float *diag,*offdiag,*diag2,*offdiag2,*dirmin;
smatrix = matrix(1,3,1,3);
dc = matrix(1,3,1,3);
diag=vector(1,3);
offdiag=vector(1,3);
diag2=vector(1,3);
offdiag2=vector(1,3);
dirmin=vector(1,3);
int evmax, evmax2;
double *c=&latc->c[0];
double *phi=&latc->phi[0];

dirmin[1]=1.0;
dirmin[2]=0.0;
dirmin[3]=0.0;

//Emmanuel
double maxd=sqrt(nx*nx+ny*ny);
int Nbin=(int)maxd+1;
double gap=1;//maxd/(double)Nbin;
float *bin_dist,*bin_stress,*bin_length,*bin_vrms;
bin_dist=vector(1,Nbin);
bin_stress=vector(1,Nbin);
bin_length=vector(1,Nbin);
bin_vrms=vector(1,Nbin);
for(int i=0;i<Nbin;i++){
bin_dist[i]=0.0;
bin_stress[i]=0.0;
bin_length[i]=0.0;
bin_vrms[i]=0.0;
};
int ibin;

//printf("Here. part 1\n");
for(int ipt=1;ipt<=nx;ipt++) {
for(int jpt=1;jpt<=ny;jpt++) {
for(int kpt=1;kpt<=nz;kpt++) {
	int lpt = (ipt*ny2+jpt)*nz2+kpt;
	if(phi[lpt]<0.95){
	
	int lptcc=lpt*lcc;
	dmin2=nx*ny;
	dist2=nx*ny;
	for(int i=1;i<=nx;i++) {
	for(int j=1;j<=ny;j++) {
	for(int k=1;k<=nz;k++) {
		int l = (i*ny2+j)*nz2+k;
		if(phi[l]>0.95){
		dist2=((double)i-(double)ipt)*((double)i-(double)ipt)+((double)j-(double)jpt)*((double)j-(double)jpt);
		if(dist2<dmin2){
		dmin2=dist2;
		imin=i;
		jmin=j;
		dirmin[1]=((double)i-(double)ipt)/sqrt(dist2);
		dirmin[2]=((double)j-(double)jpt)/sqrt(dist2);
		} //end if
		}//end if phi[l]
	}}} //end i,j
	//printf("nearest point:%d,%d,%d,%f,%f.\n",imin,jmin,dmin2,dirmin[1],dirmin[2]);

//////////////////////////////////////////////////////////calculate the principal stresses
//define smatrix
//printf("Here. part 2\n");
int las=lpt*lcd*lcd;
int lsy=lpt*lcd*2;
smatrix[1][1]=latc->bstress[las]+latc->estress[lsy];
smatrix[2][2]=latc->bstress[las+1]+latc->estress[lsy+1];
smatrix[3][3]=latc->bstress[las+2]+latc->estress[lsy+2];
smatrix[1][2]=latc->bstress[las+3]+latc->estress[lsy+3];
smatrix[1][3]=latc->bstress[las+4]+latc->estress[lsy+4];
smatrix[2][3]=latc->bstress[las+5]+latc->estress[lsy+5];
smatrix[2][1]=latc->bstress[las+6]+latc->estress[lsy+3];
smatrix[3][1]=latc->bstress[las+7]+latc->estress[lsy+4];
smatrix[3][2]=latc->bstress[las+8]+latc->estress[lsy+5];
//double smatnorm=smatrix[1][1]*smatrix[1][1]+smatrix[1][2]*smatrix[1][2]+smatrix[1][3]*smatrix[1][3]
//		+smatrix[2][1]*smatrix[2][1]+smatrix[2][2]*smatrix[2][2]+smatrix[2][3]*smatrix[2][3]
//		+smatrix[3][1]*smatrix[3][1]+smatrix[3][2]*smatrix[3][2]+smatrix[3][3]*smatrix[3][3];
//comment out for 0510

//calculate principal stresses and direction from smatrix
//printf("Here. part 3\n");
prin_eigen(smatrix,lbd,diag,offdiag,&evmax);
//if(ipt==35) {printf("%d,%d---%f %f %f: %d.\n",ipt,jpt,diag[1],diag[2],diag[3],evmax);};


//check dirmin direction and principal stress direction
//printf("Here. part 4\n");
//double dotp=smatrix[1][evmax]*dirmin[1]+smatrix[2][evmax]*dirmin[2]+smatrix[3][evmax]*dirmin[3]; //commented out 0510

//define cmatrix and calculate elongation
//printf("Here. part 5\n");
double *cloc=&c[lptcc];
double length=(cloc[0]+cloc[1]+cloc[2]);

// Check cdir vs principal stress
      dc[1][1]=latc->c[lptcc];  dc[1][2]=latc->c[lptcc+3];dc[1][3]=latc->c[lptcc+4];
      dc[2][1]=latc->c[lptcc+3];dc[2][2]=latc->c[lptcc+1];dc[2][3]=latc->c[lptcc+5];
      dc[3][1]=latc->c[lptcc+4];dc[3][2]=latc->c[lptcc+5];dc[3][3]=latc->c[lptcc+2];
      //if(latw->w[l]==swall) {printf("%d %f %f %f\n",l,dc[1][1],dc[2][2],dc[1][2]);}
      //if(~((isgeom)&&(latw->w[l]<swall))) {
      prin_eigen(dc,lbd,diag2,offdiag2,&evmax2);
      //} //end if ~isgeom
/*      tred2(dc,lbd,diag2,offdiag2);
      tqli(diag2,offdiag2,lbd,dc);
      evmax2=1;
      if(diag2[2]>diag2[evmax2]) evmax2=2;
      if(diag2[3]>diag2[evmax2]) evmax2=3;
 
      	if(fabs(diag2[evmax2])<1e-10) {dc[1][evmax2]=0;dc[2][evmax2]=0;dc[3][evmax2]=0;}
      	if(diag2[evmax2]<-100) {dc[1][evmax2]=0;dc[2][evmax2]=0;dc[3][evmax2]=0;}
*/
	double dotp2=smatrix[1][evmax]*dc[1][evmax2]+smatrix[2][evmax]*dc[2][evmax2]+smatrix[3][evmax]*dc[3][evmax2];


double udirnorm=sqrt(latv->u[lpt*lbd]*latv->u[lpt*lbd]+latv->u[lpt*lbd+1]*latv->u[lpt*lbd+1]+latv->u[lpt*lbd+2]*latv->u[lpt*lbd+2]);
double aa,bb,cc;
aa=latv->u[lpt*lbd]/udirnorm;
bb=latv->u[lpt*lbd+1]/udirnorm;
cc=latv->u[lpt*lbd+2]/udirnorm;
//double udots=smatrix[1][evmax]*aa+smatrix[2][evmax]*bb+smatrix[3][evmax]*cc;  //comment out for 0510
//double udotc=aa*dc[1][evmax2]+bb*dc[2][evmax2]+cc*dc[3][evmax2];		//comment out for 0510

fprintf(aaaptr,"%d %f %f %f %f\n",dmin2,diag[evmax],length,dotp2,udirnorm);

//calculate averages for same distances
//printf("Here. part 6\n");
ibin=sqrt(dmin2)/gap;
bin_dist[ibin]=bin_dist[ibin]+0.001;
bin_stress[ibin]=bin_stress[ibin]+diag[evmax];
bin_length[ibin]=bin_length[ibin]+length;
bin_vrms[ibin]=bin_vrms[ibin]+udirnorm;


}//end if phi[l]
}}} //end ipt,jpt

//printf("Here. part 7\n");
//if(tm%freq==0){
//Emmanuel: write binning
for (int i=0;i<Nbin;i++){
bin_stress[i]=bin_stress[i]/(bin_dist[i])/1000;
bin_length[i]=bin_length[i]/(bin_dist[i])/1000;
bin_vrms[i]=bin_vrms[i]/(bin_dist[i])/1000;
fprintf(aabptr,"%f %f %f %f \n",((double)i-1.0)*gap+gap/2.0,bin_stress[i],bin_vrms[i],bin_length[i]);
}//end for


fclose(aaaptr);
fclose(aabptr);
//}

	return;
}

/////////////////////////////////////////////////////////////////////////////////////////
void stiffness_nopoly(lblattice *latv,  lclattice *latc, int tm){

FILE *aaaptr, *aabptr;
char nname[500];
//int freq=100;
//if(tm%freq==0){
sprintf(nname,"%s/output/aaa_nopoly%d.dat",DPATH,tm);
aaaptr=fopen(nname,"w");
sprintf(nname,"%s/output/aab%d.dat",DPATH,tm);
aabptr=fopen(nname,"w");
//}

int dmin2,dist2;
int imin, jmin;
float **smatrix;//, **dc;//commented out 0510
float *diag,*offdiag,*diag2,*offdiag2,*dirmin;
smatrix = matrix(1,3,1,3);
//dc = matrix(1,3,1,3);
diag=vector(1,3);
offdiag=vector(1,3);
diag2=vector(1,3);
offdiag2=vector(1,3);
dirmin=vector(1,3);
int evmax; //,evmax2; //commented out 0510
//double *c=&latc->c[0];
double *phi=&latc->phi[0];

dirmin[1]=1.0;
dirmin[2]=0.0;
dirmin[3]=0.0;

//Emmanuel
double maxd=sqrt(nx*nx+ny*ny);
int Nbin=(int)maxd+1;
double gap=1;//maxd/(double)Nbin;
float *bin_dist,*bin_stress,*bin_vrms;
bin_dist=vector(1,Nbin);
bin_stress=vector(1,Nbin);
bin_vrms=vector(1,Nbin);
for(int i=0;i<Nbin;i++){
bin_dist[i]=0.0;
bin_stress[i]=0.0;
bin_vrms[i]=0.0;
};
int ibin;

//printf("Here. part 1\n");
for(int ipt=1;ipt<=nx;ipt++) {
for(int jpt=1;jpt<=ny;jpt++) {
for(int kpt=1;kpt<=nz;kpt++) {
	int lpt = (ipt*ny2+jpt)*nz2+kpt;
	if(phi[lpt]<0.95){
	
	//int lptcc=lpt*lcc;
	dmin2=nx*ny;
	dist2=nx*ny;
	for(int i=1;i<=nx;i++) {
	for(int j=1;j<=ny;j++) {
	for(int k=1;k<=nz;k++) {
		int l = (i*ny2+j)*nz2+k;
		if(phi[l]>0.95){
		dist2=((double)i-(double)ipt)*((double)i-(double)ipt)+((double)j-(double)jpt)*((double)j-(double)jpt);
		if(dist2<dmin2){
		dmin2=dist2;
		imin=i;
		jmin=j;
		dirmin[1]=((double)i-(double)ipt)/sqrt(dist2);
		dirmin[2]=((double)j-(double)jpt)/sqrt(dist2);
		} //end if
		}//end if phi[l]
	}}} //end i,j
	//printf("nearest point:%d,%d,%d,%f,%f.\n",imin,jmin,dmin2,dirmin[1],dirmin[2]);

//////////////////////////////////////////////////////////calculate the principal stresses
//define smatrix
//printf("Here. part 2\n");
int las=lpt*lcd*lcd;
int lsy=lpt*lcd*2;
smatrix[1][1]=latc->bstress[las]+latc->estress[lsy];
smatrix[2][2]=latc->bstress[las+1]+latc->estress[lsy+1];
smatrix[3][3]=latc->bstress[las+2]+latc->estress[lsy+2];
smatrix[1][2]=latc->bstress[las+3]+latc->estress[lsy+3];
smatrix[1][3]=latc->bstress[las+4]+latc->estress[lsy+4];
smatrix[2][3]=latc->bstress[las+5]+latc->estress[lsy+5];
smatrix[2][1]=latc->bstress[las+6]+latc->estress[lsy+3];
smatrix[3][1]=latc->bstress[las+7]+latc->estress[lsy+4];
smatrix[3][2]=latc->bstress[las+8]+latc->estress[lsy+5];
//double smatnorm=smatrix[1][1]*smatrix[1][1]+smatrix[1][2]*smatrix[1][2]+smatrix[1][3]*smatrix[1][3]
//		+smatrix[2][1]*smatrix[2][1]+smatrix[2][2]*smatrix[2][2]+smatrix[2][3]*smatrix[2][3]
//		+smatrix[3][1]*smatrix[3][1]+smatrix[3][2]*smatrix[3][2]+smatrix[3][3]*smatrix[3][3];
//commented out 0510

//calculate principal stresses and direction from smatrix
//printf("Here. part 3\n");
tred2(smatrix,lbd,diag,offdiag);
tqli(diag,offdiag,lbd,smatrix);
evmax=1;
if(diag[2]>diag[evmax]) evmax=2;
if(diag[3]>diag[evmax]) evmax=3;
if(fabs(diag[evmax])<1e-10) {
smatrix[1][evmax]=0;smatrix[2][evmax]=0;smatrix[3][evmax]=0;}
if(diag[evmax]<-100) {smatrix[1][evmax]=0;smatrix[2][evmax]=0;smatrix[3][evmax]=0;}

//check dirmin direction and principal stress direction
//printf("Here. part 4\n");
//double dotp=smatrix[1][evmax]*dirmin[1]+smatrix[2][evmax]*dirmin[2]+smatrix[3][evmax]*dirmin[3];//comment out for 0510

//define cmatrix and calculate elongation
//printf("Here. part 5\n");

/*nopoly
double *cloc=&c[lptcc];
double length=(cloc[0]+cloc[1]+cloc[2]);

// Check cdir vs principal stress
      dc[1][1]=latc->c[lptcc];  dc[1][2]=latc->c[lptcc+3];dc[1][3]=latc->c[lptcc+4];
      dc[2][1]=latc->c[lptcc+3];dc[2][2]=latc->c[lptcc+1];dc[2][3]=latc->c[lptcc+5];
      dc[3][1]=latc->c[lptcc+4];dc[3][2]=latc->c[lptcc+5];dc[3][3]=latc->c[lptcc+2];
      //if(latw->w[l]==swall) {printf("%d %f %f %f\n",l,dc[1][1],dc[2][2],dc[1][2]);}
      //if(~((isgeom)&&(latw->w[l]<swall))) {
      tred2(dc,lbd,diag2,offdiag2);
      tqli(diag2,offdiag2,lbd,dc);
      evmax2=1;
      if(diag2[2]>diag2[evmax2]) evmax2=2;
      if(diag2[3]>diag2[evmax2]) evmax2=3;
      //} //end if ~isgeom
      	if(fabs(diag2[evmax2])<1e-10) {dc[1][evmax2]=0;dc[2][evmax2]=0;dc[3][evmax2]=0;}
      	if(diag2[evmax2]<-100) {dc[1][evmax2]=0;dc[2][evmax2]=0;dc[3][evmax2]=0;}
	double dotp2=smatrix[1][evmax]*dc[1][evmax2]+smatrix[2][evmax]*dc[2][evmax2]+smatrix[3][evmax]*dc[3][evmax2];
*/ //nopoly

//if(tm%freq==0&&phi[lpt]<0.95){ 
//&&fabs(dotp2)>0.90&&ipt>18&&ipt<42&&jpt>18&&jpt<42&&
double udirnorm=sqrt(latv->u[lpt*lbd]*latv->u[lpt*lbd]+latv->u[lpt*lbd+1]*latv->u[lpt*lbd+1]+latv->u[lpt*lbd+2]*latv->u[lpt*lbd+2]);
double aa,bb,cc;
aa=latv->u[lpt*lbd]/udirnorm;
bb=latv->u[lpt*lbd+1]/udirnorm;
cc=latv->u[lpt*lbd+2]/udirnorm;
double udots=smatrix[1][evmax]*aa+smatrix[2][evmax]*bb+smatrix[3][evmax]*cc;
//double udotc=aa*dc[1][evmax2]+bb*dc[2][evmax2]+cc*dc[3][evmax2];

//printf("At %d,%d.\n",ipt,jpt);
//printf("dotp2=%f\n",dotp2);
//printf("dotp=%f,smatnorm=%f\n",dotp,smatnorm);
//printf("..........dotp2=%f,eig=%f\n",dotp2,diag[evmax]);
//printf("Dir:principalstress:%f,%f,%f.\n",smatrix[1][evmax],smatrix[2][evmax],smatrix[3][evmax]);
//printf("Dir:Cdir:%f,%f,%f.\n",dc[1][evmax2],dc[2][evmax2],dc[3][evmax2]);
//printf("%d %f %d %f \n",evmax,diag[evmax],evmax2,diag2[evmax2]);
//printf("%f %f %f %f\n",dirmin[1],dirmin[2],dirmin[3],diag[evmax]);
//printf("udir:%f,%f,%f.\n",aa,bb,cc);
//printf("udots=%f,udotc=%f.\n",udots,udotc);

fprintf(aaaptr,"%d %f %f %f\n",dmin2,diag[evmax],udots,udirnorm);

//calculate averages for same distances
//printf("Here. part 6\n");
ibin=sqrt(dmin2)/gap;
bin_dist[ibin]=bin_dist[ibin]+0.001;
bin_stress[ibin]=bin_stress[ibin]+diag[evmax];
bin_vrms[ibin]=bin_vrms[ibin]+udirnorm;
//}//end if tm%freq==0


}//end if phi[l]
}}} //end ipt,jpt

//printf("Here. part 7\n");
//if(tm%freq==0){
//Emmanuel: write binning
for (int i=0;i<Nbin;i++){
bin_stress[i]=bin_stress[i]/(bin_dist[i])/1000;
bin_vrms[i]=bin_vrms[i]/(bin_dist[i])/1000;
fprintf(aabptr,"%f %f %f \n",((double)i-1.0)*gap+gap/2.0,bin_stress[i],bin_vrms[i]);
}//end for

fclose(aaaptr);
fclose(aabptr);
//}

	return;
}


/*
tred2(smatrix,lbd,diag,offdiag);
tqli(diag,offdiag,lbd,smatrix);
evmax=1;
if(diag[2]>diag[evmax]) evmax=2;
if(diag[3]>diag[evmax]) evmax=3;

if(fabs(diag[evmax])<1e-10) {printf("%f\n",diag[evmax]);
smatrix[1][evmax]=0;smatrix[2][evmax]=0;smatrix[3][evmax]=0;}
if(diag[evmax]<-100) {smatrix[1][evmax]=0;smatrix[2][evmax]=0;smatrix[3][evmax]=0;}
*/

