/*Emmanuel: Functions related to chiral setup. Mostly to calculate stress I think.*/

void l1forchiral(double *q, int l, int *lps, double *l1hchiral, double *lCh, double *lap, double *dqx, double *dqy,double *dqz) {
    int lpx=lps[0]*lcq,lmx=lps[1]*lcq,lpy=lps[2]*lcq,lmy=lps[3]*lcq,lpz=lps[4]*lcq,lmz=lps[5]*lcq;/*face*/
    int lpxpy=lps[14]*lcq,    lmxpy=lps[15]*lcq,  lpxmy=lps[16]*lcq,  lmxmy=lps[17]*lcq;/*edges*/
    int lpxpz=lps[18]*lcq,    lmxpz=lps[19]*lcq,  lpxmz=lps[20]*lcq,  lmxmz=lps[21]*lcq;
    int lpypz=lps[22]*lcq,    lmypz=lps[23]*lcq,  lpymz=lps[24]*lcq,  lmymz=lps[25]*lcq;
    int llc=l*lcq;
    double d1d1q11=q[lpx+0]+q[lmx+0]-2*q[llc+0];
    double d1d2q11=(q[lpxpy+0]-q[lpxmy+0]-q[lmxpy+0]+q[lmxmy+0])/4.0;
    double d1d3q11=(q[lpxpz+0]-q[lpxmz+0]-q[lmxpz+0]+q[lmxmz+0])/4.0;
    double d2d2q22=q[lpy+1]+q[lmy+1]-2*q[llc+1];
    double d1d2q22=(q[lpxpy+1]-q[lpxmy+1]-q[lmxpy+1]+q[lmxmy+1])/4.0;
    double d2d3q22=(q[lpypz+1]-q[lpymz+1]-q[lmypz+1]+q[lmymz+1])/4.0;
    double d3d3q33=q[lpz+2]+q[lmz+2]-2*q[llc+2];
    double d1d3q33=(q[lpxpz+2]-q[lpxmz+2]-q[lmxpz+2]+q[lmxmz+2])/4.0;
    double d2d3q33=(q[lpypz+2]-q[lpymz+2]-q[lmypz+2]+q[lmymz+2])/4.0;
    double d1d1q12=q[lpx+3]+q[lmx+3]-2*q[llc+3];
    double d2d2q12=q[lpy+3]+q[lmy+3]-2*q[llc+3];
    double d1d2q12=(q[lpxpy+3]-q[lpxmy+3]-q[lmxpy+3]+q[lmxmy+3])/4.0;
    double d1d3q12=(q[lpxpz+3]-q[lpxmz+3]-q[lmxpz+3]+q[lmxmz+3])/4.0;
    double d2d3q12=(q[lpypz+3]-q[lpymz+3]-q[lmypz+3]+q[lmymz+3])/4.0;
    double d1d1q13=q[lpx+4]+q[lmx+4]-2*q[llc+4];
    double d3d3q13=q[lpz+4]+q[lmz+4]-2*q[llc+4];
    double d1d2q13=(q[lpxpy+4]-q[lpxmy+4]-q[lmxpy+4]+q[lmxmy+4])/4.0;
    double d1d3q13=(q[lpxpz+4]-q[lpxmz+4]-q[lmxpz+4]+q[lmxmz+4])/4.0;
    double d2d3q13=(q[lpypz+4]-q[lpymz+4]-q[lmypz+4]+q[lmymz+4])/4.0;
    double d2d2q23=q[lpy+5]+q[lmy+5]-2*q[llc+5];
    double d3d3q23=q[lpz+5]+q[lmz+5]-2*q[llc+5];
    double d1d2q23=(q[lpxpy+5]-q[lpxmy+5]-q[lmxpy+5]+q[lmxmy+5])/4.0;
    double d1d3q23=(q[lpxpz+5]-q[lpxmz+5]-q[lmxpz+5]+q[lmxmz+5])/4.0;
    double d2d3q23=(q[lpypz+5]-q[lpymz+5]-q[lmypz+5]+q[lmymz+5])/4.0;
    double dedgqeg=d1d1q11+d2d2q22+d3d3q33;
    l1hchiral[0]=2.0*d1d1q11-2.0/3.0*dedgqeg;
    l1hchiral[1]=2.0*d2d2q22-2.0/3.0*dedgqeg;
    l1hchiral[2]=2.0*d3d3q33-2.0/3.0*dedgqeg;
    l1hchiral[3]=2.0*d1d1q12;
    l1hchiral[4]=2.0*d1d1q13;
    l1hchiral[5]=2.0*d2d2q23;
    double h4=d1d1q11+2*d1d2q12+2*d1d3q13+d2d2q22+2*d2d3q23+d3d3q33;
    double h3_11=2*dqz[3]-2*dqy[4];
    double h3_22=2*dqx[5]-2*dqz[3];
    double h3_33=2*dqy[4]-2*dqx[5];
    double h3_12=dqz[1]-dqy[5]-dqz[0]+dqx[4];
    double h3_13=dqz[5]-dqy[2]+dqy[0]-dqx[3];
    double h3_23=dqy[3]-dqx[1]-dqz[4]+dqx[2];
    double h2_11=2*lap[0]-2*d1d1q11-2*d1d2q12-2*d1d3q13;
    double h2_22=2*lap[1]-2*d1d2q12-2*d2d2q22-2*d2d3q23;
    double h2_33=2*lap[2]-2*d1d3q13-2*d2d3q23-2*d3d3q33;
    double h2_12=2*lap[3]-d1d1q12-d1d2q22-d1d3q23-d1d2q11-d2d2q12-d2d3q13;
    double h2_13=2*lap[4]-d1d1q13-d1d2q23-d1d3q33-d1d3q11-d2d3q12-d3d3q13;
    double h2_23=2*lap[5]-d1d2q13-d2d2q23-d2d3q33-d1d3q12-d2d3q22-d3d3q23;
    double h1_11=2*dqy[4]-2*dqz[3]+4*Cpit*q[llc+0];
    double h1_22=2*dqz[3]-2*dqx[5]+4*Cpit*q[llc+1];
    double h1_33=2*dqx[5]-2*dqy[4]+4*Cpit*q[llc+2];
    double h1_12=dqy[5]-dqz[1]-dqx[4]+dqz[0]+4*Cpit*q[llc+3];
    double h1_13=dqy[2]-dqz[5]+dqx[3]-dqy[0]+4*Cpit*q[llc+4];
    double h1_23=dqx[1]-dqy[3]-dqx[2]+dqz[4]+4*Cpit*q[llc+5];
    lCh[0]=-Cpit*h1_11+0.5*(h2_11+2*Cpit*h3_11)+h4/3.;
    lCh[1]=-Cpit*h1_22+0.5*(h2_22+2*Cpit*h3_22)+h4/3.;
    lCh[2]=-Cpit*h1_33+0.5*(h2_33+2*Cpit*h3_33)+h4/3.;
    lCh[3]=-Cpit*h1_12+0.5*(h2_12+2*Cpit*h3_12);
    lCh[4]=-Cpit*h1_13+0.5*(h2_13+2*Cpit*h3_13);
    lCh[5]=-Cpit*h1_23+0.5*(h2_23+2*Cpit*h3_23);
}

void l2l3derivforh(double *q, int l, int *lps, double *l2h, double *l3h, double *lap, double *dqx, double *dqy, double *dqz) {
    int lpx=lps[0]*lcq,lmx=lps[1]*lcq,lpy=lps[2]*lcq,lmy=lps[3]*lcq,lpz=lps[4]*lcq,lmz=lps[5]*lcq;/*face*/
    /*int lpxpypz=lps[6]*lcq, lpxpymz=lps[7]*lcq, lpxmypz=lps[8]*lcq, lpxmymz=lps[9]*lcq;*//*corner*/
    /*int lmxpypz=lps[10]*lcq,lmxpymz=lps[11]*lcq,lmxmypz=lps[12]*lcq,lmxmymz=lps[13]*lcq;*/
    int lpxpy=lps[14]*lcq,    lmxpy=lps[15]*lcq,  lpxmy=lps[16]*lcq,  lmxmy=lps[17]*lcq;/*edges*/
    int lpxpz=lps[18]*lcq,    lmxpz=lps[19]*lcq,  lpxmz=lps[20]*lcq,  lmxmz=lps[21]*lcq;
    int lpypz=lps[22]*lcq,    lmypz=lps[23]*lcq,  lpymz=lps[24]*lcq,  lmymz=lps[25]*lcq;
    int llc=l*lcq;//, lpxq=lpx*lcq, lmxq=lmx*lcq, lpyq=lpy*lcq, lmyq=lmy*lcq, lpzq=lpz*lcq, lmzq=lmz*lcq;
    double d1d1q11=q[lpx+0]+q[lmx+0]-2*q[llc+0];
    double d2d2q11=q[lpy+0]+q[lmy+0]-2*q[llc+0];
    double d3d3q11=q[lpz+0]+q[lmz+0]-2*q[llc+0];
    double d1d2q11=(q[lpxpy+0]-q[lpxmy+0]-q[lmxpy+0]+q[lmxmy+0])/4.0;
    double d1d3q11=(q[lpxpz+0]-q[lpxmz+0]-q[lmxpz+0]+q[lmxmz+0])/4.0;
    double d2d3q11=(q[lpypz+0]-q[lpymz+0]-q[lmypz+0]+q[lmymz+0])/4.0;
    double d1d1q22=q[lpx+1]+q[lmx+1]-2*q[llc+1];
    double d2d2q22=q[lpy+1]+q[lmy+1]-2*q[llc+1];
    double d3d3q22=q[lpz+1]+q[lmz+1]-2*q[llc+1];
    double d1d2q22=(q[lpxpy+1]-q[lpxmy+1]-q[lmxpy+1]+q[lmxmy+1])/4.0;
    double d1d3q22=(q[lpxpz+1]-q[lpxmz+1]-q[lmxpz+1]+q[lmxmz+1])/4.0;
    double d2d3q22=(q[lpypz+1]-q[lpymz+1]-q[lmypz+1]+q[lmymz+1])/4.0;
    double d1d1q33=q[lpx+2]+q[lmx+2]-2*q[llc+2];
    double d2d2q33=q[lpy+2]+q[lmy+2]-2*q[llc+2];
    double d3d3q33=q[lpz+2]+q[lmz+2]-2*q[llc+2];
    double d1d2q33=(q[lpxpy+2]-q[lpxmy+2]-q[lmxpy+2]+q[lmxmy+2])/4.0;
    double d1d3q33=(q[lpxpz+2]-q[lpxmz+2]-q[lmxpz+2]+q[lmxmz+2])/4.0;
    double d2d3q33=(q[lpypz+2]-q[lpymz+2]-q[lmypz+2]+q[lmymz+2])/4.0;
    double d1d1q12=q[lpx+3]+q[lmx+3]-2*q[llc+3];
    double d2d2q12=q[lpy+3]+q[lmy+3]-2*q[llc+3];
    double d3d3q12=q[lpz+3]+q[lmz+3]-2*q[llc+3];
    double d1d2q12=(q[lpxpy+3]-q[lpxmy+3]-q[lmxpy+3]+q[lmxmy+3])/4.0;
    double d1d3q12=(q[lpxpz+3]-q[lpxmz+3]-q[lmxpz+3]+q[lmxmz+3])/4.0;
    double d2d3q12=(q[lpypz+3]-q[lpymz+3]-q[lmypz+3]+q[lmymz+3])/4.0;
    double d1d1q13=q[lpx+4]+q[lmx+4]-2*q[llc+4];
    double d2d2q13=q[lpy+4]+q[lmy+4]-2*q[llc+4];
    double d3d3q13=q[lpz+4]+q[lmz+4]-2*q[llc+4];
    double d1d2q13=(q[lpxpy+4]-q[lpxmy+4]-q[lmxpy+4]+q[lmxmy+4])/4.0;
    double d1d3q13=(q[lpxpz+4]-q[lpxmz+4]-q[lmxpz+4]+q[lmxmz+4])/4.0;
    double d2d3q13=(q[lpypz+4]-q[lpymz+4]-q[lmypz+4]+q[lmymz+4])/4.0;
    double d1d1q23=q[lpx+5]+q[lmx+5]-2*q[llc+5];
    double d2d2q23=q[lpy+5]+q[lmy+5]-2*q[llc+5];
    double d3d3q23=q[lpz+5]+q[lmz+5]-2*q[llc+5];
    double d1d2q23=(q[lpxpy+5]-q[lpxmy+5]-q[lmxpy+5]+q[lmxmy+5])/4.0;
    double d1d3q23=(q[lpxpz+5]-q[lpxmz+5]-q[lmxpz+5]+q[lmxmz+5])/4.0;
    double d2d3q23=(q[lpypz+5]-q[lpymz+5]-q[lmypz+5]+q[lmymz+5])/4.0;
    double dedgqeg=d1d1q11+d1d2q12+d1d3q13+d1d2q12+d2d2q22+d2d3q23+d1d3q13+d2d3q23+d3d3q33;
    l2h[0]=d1d1q11+d1d2q12+d1d3q13+d1d1q11+d1d2q12+d1d3q13-2.0/3.0*dedgqeg;
    l2h[1]=d1d2q12+d2d2q22+d2d3q23+d1d2q12+d2d2q22+d2d3q23-2.0/3.0*dedgqeg;
    l2h[2]=d1d3q13+d2d3q23+d3d3q33+d1d3q13+d2d3q23+d3d3q33-2.0/3.0*dedgqeg;
    l2h[3]=d1d2q11+d2d2q12+d2d3q13+d1d1q12+d1d2q22+d1d3q23;
    l2h[4]=d1d3q11+d2d3q12+d3d3q13+d1d1q13+d1d2q23+d1d3q33;
    l2h[5]=d1d3q12+d2d3q22+d3d3q23+d1d2q13+d2d2q23+d2d3q33;
    double dkqge2 =dqx[0]*dqx[0]+dqx[1]*dqx[1]+dqx[2]*dqx[2]+2*dqx[3]*dqx[3]+2*dqx[4]*dqx[4]+2*dqx[5]*dqx[5];
    dkqge2+=dqy[0]*dqy[0]+dqy[1]*dqy[1]+dqy[2]*dqy[2]+2*dqy[3]*dqy[3]+2*dqy[4]*dqy[4]+2*dqy[5]*dqy[5];
    dkqge2+=dqz[0]*dqz[0]+dqz[1]*dqz[1]+dqz[2]*dqz[2]+2*dqz[3]*dqz[3]+2*dqz[4]*dqz[4]+2*dqz[5]*dqz[5];
    l3h[0]=-0.5*(dqx[0]*dqx[0]+dqx[3]*dqx[3]+dqx[4]*dqx[4]+dqx[3]*dqx[3]+dqx[1]*dqx[1]+dqx[5]*dqx[5]+dqx[4]*dqx[4]+dqx[5]*dqx[5]+dqx[2]*dqx[2]);
    l3h[0]+=dqx[0]*dqx[0]+dqx[3]*dqy[0]+dqx[4]*dqz[0]+dqy[3]*dqx[0]+dqy[1]*dqy[0]+dqy[5]*dqz[0]+dqz[4]*dqx[0]+dqz[5]*dqy[0]+dqz[2]*dqz[0];
    l3h[0]+=q[llc+0]*d1d1q11+q[llc+3]*d1d2q11+q[llc+4]*d1d3q11+q[llc+3]*d1d2q11+q[llc+1]*d2d2q11+q[llc+5]*d2d3q11+q[llc+4]*d1d3q11+q[llc+5]*d2d3q11+q[llc+2]*d3d3q11;
    l3h[0]+=-1./6.*dkqge2;
    l3h[1]=-0.5*(dqy[0]*dqy[0]+dqy[3]*dqy[3]+dqy[4]*dqy[4]+dqy[3]*dqy[3]+dqy[1]*dqy[1]+dqy[5]*dqy[5]+dqy[4]*dqy[4]+dqy[5]*dqy[5]+dqy[2]*dqy[2]);
    l3h[1]+=dqx[0]*dqx[1]+dqx[3]*dqy[1]+dqx[4]*dqz[1]+dqy[3]*dqx[1]+dqy[1]*dqy[1]+dqy[5]*dqz[1]+dqz[4]*dqx[1]+dqz[5]*dqy[1]+dqz[2]*dqz[1];
    l3h[1]+=q[llc+0]*d1d1q22+q[llc+3]*d1d2q22+q[llc+4]*d1d3q22+q[llc+3]*d1d2q22+q[llc+1]*d2d2q22+q[llc+5]*d2d3q22+q[llc+4]*d1d3q22+q[llc+5]*d2d3q22+q[llc+2]*d3d3q22;
    l3h[1]+=-1./6.*dkqge2;
    l3h[2]=-0.5*(dqz[0]*dqz[0]+dqz[3]*dqz[3]+dqz[4]*dqz[4]+dqz[3]*dqz[3]+dqz[1]*dqz[1]+dqz[5]*dqz[5]+dqz[4]*dqz[4]+dqz[5]*dqz[5]+dqz[2]*dqz[2]);
    l3h[2]+=dqx[0]*dqx[2]+dqx[3]*dqy[2]+dqx[4]*dqz[2]+dqy[3]*dqx[2]+dqy[1]*dqy[2]+dqy[5]*dqz[2]+dqz[4]*dqx[2]+dqz[5]*dqy[2]+dqz[2]*dqz[2];
    l3h[2]+=q[llc+0]*d1d1q33+q[llc+3]*d1d2q33+q[llc+4]*d1d3q33+q[llc+3]*d1d2q33+q[llc+1]*d2d2q33+q[llc+5]*d2d3q33+q[llc+4]*d1d3q33+q[llc+5]*d2d3q33+q[llc+2]*d3d3q33;
    l3h[2]+=-1./6.*dkqge2;
    l3h[3]=-0.5*(dqx[0]*dqy[0]+dqx[3]*dqy[3]+dqx[4]*dqy[4]+dqx[3]*dqy[3]+dqx[1]*dqy[1]+dqx[5]*dqy[5]+dqx[4]*dqy[4]+dqx[5]*dqy[5]+dqx[2]*dqy[2]);
    l3h[3]+=dqx[0]*dqx[3]+dqx[3]*dqy[3]+dqx[4]*dqz[3]+dqy[3]*dqx[3]+dqy[1]*dqy[3]+dqy[5]*dqz[3]+dqz[4]*dqx[3]+dqz[5]*dqy[3]+dqz[2]*dqz[3];
    l3h[3]+=q[llc+0]*d1d1q12+q[llc+3]*d1d2q12+q[llc+4]*d1d3q12+q[llc+3]*d1d2q12+q[llc+1]*d2d2q12+q[llc+5]*d2d3q12+q[llc+4]*d1d3q12+q[llc+5]*d2d3q12+q[llc+2]*d3d3q12;
    l3h[4]=-0.5*(dqx[0]*dqz[0]+dqx[3]*dqz[3]+dqx[4]*dqz[4]+dqx[3]*dqz[3]+dqx[1]*dqz[1]+dqx[5]*dqz[5]+dqx[4]*dqz[4]+dqx[5]*dqz[5]+dqx[2]*dqz[2]);
    l3h[4]+=dqx[0]*dqx[4]+dqx[3]*dqy[4]+dqx[4]*dqz[4]+dqy[3]*dqx[4]+dqy[1]*dqy[4]+dqy[5]*dqz[4]+dqz[4]*dqx[4]+dqz[5]*dqy[4]+dqz[2]*dqz[4];
    l3h[4]+=q[llc+0]*d1d1q13+q[llc+3]*d1d2q13+q[llc+4]*d1d3q13+q[llc+3]*d1d2q13+q[llc+1]*d2d2q13+q[llc+5]*d2d3q13+q[llc+4]*d1d3q13+q[llc+5]*d2d3q13+q[llc+2]*d3d3q13;
    l3h[5]=-0.5*(dqy[0]*dqz[0]+dqy[3]*dqz[3]+dqy[4]*dqz[4]+dqy[3]*dqz[3]+dqy[1]*dqz[1]+dqy[5]*dqz[5]+dqy[4]*dqz[4]+dqy[5]*dqz[5]+dqy[2]*dqz[2]);
    l3h[5]+=dqx[0]*dqx[5]+dqx[3]*dqy[5]+dqx[4]*dqz[5]+dqy[3]*dqx[5]+dqy[1]*dqy[5]+dqy[5]*dqz[5]+dqz[4]*dqx[5]+dqz[5]*dqy[5]+dqz[2]*dqz[5];
    l3h[5]+=q[llc+0]*d1d1q23+q[llc+3]*d1d2q23+q[llc+4]*d1d3q23+q[llc+3]*d1d2q23+q[llc+1]*d2d2q23+q[llc+5]*d2d3q23+q[llc+4]*d1d3q23+q[llc+5]*d2d3q23+q[llc+2]*d3d3q23;
    /*l3h[ab]=-0.5*(daq[0]*dbq[0]+daq[3]*dbq[3]+daq[4]*dbq[4]+daq[3]*dbq[3]+daq[1]*dbq[1]+daq[5]*dbq[5]+daq[4]*dbq[4]+daq[5]*dbq[5]+daq[2]*dbq[2])
     l3h[ab]+=dqx[0]*dqxab+dqx[3]*dqyab+dqx[4]*dqzab+dqy[3]*dqxab+dqy[1]*dqyab+dqy[5]*dqzab+dqz[4]*dqxab+dqz[5]*dqyab+dqz[2]*dqzab
     l3h[ab]+=q[llc+0]*d1d1qab+q[llc+3]*d1d2qab+q[llc+4]*d1d3qab+q[llc+3]*d2d1qab+q[llc+1]*d2d2qab+q[llc+5]*d2d3qab+q[llc+4]*d3d1qab+q[llc+5]*d3d2qab+q[llc+2]*d3d3qab
     l3h[ab]+=-1./6.*deltab*dkqge2*/
}

void l2l3forstress(double *q, int l,double *dqx, double *dqy, double *dqz, double *l2s, double *l3s, double *l2p, double *l3p) {
    *l2p=dqx[0]*dqx[0]+dqy[3]*dqx[0]+dqz[4]*dqx[0]+dqx[0]*dqy[3]+dqy[3]*dqy[3]+dqz[4]*dqy[3]+dqx[0]*dqz[4]+dqy[3]*dqz[4]+dqz[4]*dqz[4]
    +dqx[3]*dqx[3]+dqy[1]*dqx[3]+dqz[5]*dqx[3]+dqx[3]*dqy[1]+dqy[1]*dqy[1]+dqz[5]*dqy[1]+dqx[3]*dqz[5]+dqy[1]*dqz[5]+dqz[5]*dqz[5]
    +dqx[4]*dqx[4]+dqy[5]*dqx[4]+dqz[2]*dqx[4]+dqx[4]*dqy[5]+dqy[5]*dqy[5]+dqz[2]*dqy[5]+dqx[4]*dqz[2]+dqy[5]*dqz[2]+dqz[2]*dqz[2];
    *l3p=q[0]*dqx[0]*dqx[0]+q[3]*dqy[0]*dqx[0]+q[4]*dqz[0]*dqx[0]+q[3]*dqx[0]*dqy[0]+q[1]*dqy[0]*dqy[0]+q[5]*dqz[0]*dqy[0]+q[4]*dqx[0]*dqz[0]+q[5]*dqy[0]*dqz[0]+q[2]*dqz[0]*dqz[0]
    +q[0]*dqx[3]*dqx[3]+q[3]*dqy[3]*dqx[3]+q[4]*dqz[3]*dqx[3]+q[3]*dqx[3]*dqy[3]+q[1]*dqy[3]*dqy[3]+q[5]*dqz[3]*dqy[3]+q[4]*dqx[3]*dqz[3]+q[5]*dqy[3]*dqz[3]+q[2]*dqz[3]*dqz[3]
    +q[0]*dqx[4]*dqx[4]+q[3]*dqy[4]*dqx[4]+q[4]*dqz[4]*dqx[4]+q[3]*dqx[4]*dqy[4]+q[1]*dqy[4]*dqy[4]+q[5]*dqz[4]*dqy[4]+q[4]*dqx[4]*dqz[4]+q[5]*dqy[4]*dqz[4]+q[2]*dqz[4]*dqz[4]
    +q[0]*dqx[3]*dqx[3]+q[3]*dqy[3]*dqx[3]+q[4]*dqz[3]*dqx[3]+q[3]*dqx[3]*dqy[3]+q[1]*dqy[3]*dqy[3]+q[5]*dqz[3]*dqy[3]+q[4]*dqx[3]*dqz[3]+q[5]*dqy[3]*dqz[3]+q[2]*dqz[3]*dqz[3]
    +q[0]*dqx[1]*dqx[1]+q[3]*dqy[1]*dqx[1]+q[4]*dqz[1]*dqx[1]+q[3]*dqx[1]*dqy[1]+q[1]*dqy[1]*dqy[1]+q[5]*dqz[1]*dqy[1]+q[4]*dqx[1]*dqz[1]+q[5]*dqy[1]*dqz[1]+q[2]*dqz[1]*dqz[1]
    +q[0]*dqx[5]*dqx[5]+q[3]*dqy[5]*dqx[5]+q[4]*dqz[5]*dqx[5]+q[3]*dqx[5]*dqy[5]+q[1]*dqy[5]*dqy[5]+q[5]*dqz[5]*dqy[5]+q[4]*dqx[5]*dqz[5]+q[5]*dqy[5]*dqz[5]+q[2]*dqz[5]*dqz[5]
    +q[0]*dqx[4]*dqx[4]+q[3]*dqy[4]*dqx[4]+q[4]*dqz[4]*dqx[4]+q[3]*dqx[4]*dqy[4]+q[1]*dqy[4]*dqy[4]+q[5]*dqz[4]*dqy[4]+q[4]*dqx[4]*dqz[4]+q[5]*dqy[4]*dqz[4]+q[2]*dqz[4]*dqz[4]
    +q[0]*dqx[5]*dqx[5]+q[3]*dqy[5]*dqx[5]+q[4]*dqz[5]*dqx[5]+q[3]*dqx[5]*dqy[5]+q[1]*dqy[5]*dqy[5]+q[5]*dqz[5]*dqy[5]+q[4]*dqx[5]*dqz[5]+q[5]*dqy[5]*dqz[5]+q[2]*dqz[5]*dqz[5]
    +q[0]*dqx[2]*dqx[2]+q[3]*dqy[2]*dqx[2]+q[4]*dqz[2]*dqx[2]+q[3]*dqx[2]*dqy[2]+q[1]*dqy[2]*dqy[2]+q[5]*dqz[2]*dqy[2]+q[4]*dqx[2]*dqz[2]+q[5]*dqy[2]*dqz[2]+q[2]*dqz[2]*dqz[2];
    
    l2s[0]=dqx[0]*dqx[0]+dqx[3]*dqx[3]+dqx[4]*dqx[4]+dqx[0]*dqy[3]+dqx[3]*dqy[1]+dqx[4]*dqy[5]+dqx[0]*dqz[4]+dqx[3]*dqz[5]+dqx[4]*dqz[2];
    l2s[1]=dqy[3]*dqx[0]+dqy[1]*dqx[3]+dqy[5]*dqx[4]+dqy[3]*dqy[3]+dqy[1]*dqy[1]+dqy[5]*dqy[5]+dqy[3]*dqz[4]+dqy[1]*dqz[5]+dqy[5]*dqz[2];
    l2s[2]=dqz[4]*dqx[0]+dqz[5]*dqx[3]+dqz[2]*dqx[4]+dqz[4]*dqy[3]+dqz[5]*dqy[1]+dqz[2]*dqy[5]+dqz[4]*dqz[4]+dqz[5]*dqz[5]+dqz[2]*dqz[2];
    l2s[3]=dqx[3]*dqx[0]+dqx[1]*dqx[3]+dqx[5]*dqx[4]+dqx[3]*dqy[3]+dqx[1]*dqy[1]+dqx[5]*dqy[5]+dqx[3]*dqz[4]+dqx[1]*dqz[5]+dqx[5]*dqz[2];
    l2s[4]=dqx[4]*dqx[0]+dqx[5]*dqx[3]+dqx[2]*dqx[4]+dqx[4]*dqy[3]+dqx[5]*dqy[1]+dqx[2]*dqy[5]+dqx[4]*dqz[4]+dqx[5]*dqz[5]+dqx[2]*dqz[2];
    l2s[5]=dqy[4]*dqx[0]+dqy[5]*dqx[3]+dqy[2]*dqx[4]+dqy[4]*dqy[3]+dqy[5]*dqy[1]+dqy[2]*dqy[5]+dqy[4]*dqz[4]+dqy[5]*dqz[5]+dqy[2]*dqz[2];
    /*l2s[ab]=daqb1*d1q11+daqb2*d1q12+daqb3*d1q13+daqb1*d2q21+daqb2*d2q22+daqb3*d2q23+daqb1*d3q31+daqb2*d3q32+daqb3*d3q33;*/
    l3s[0]=dqx[0]*q[0]*dqx[0]+dqx[3]*q[0]*dqx[3]+dqx[4]*q[0]*dqx[4]+dqx[3]*q[0]*dqx[3]+dqx[1]*q[0]*dqx[1]+dqx[5]*q[0]*dqx[5]+dqx[4]*q[0]*dqx[4]+dqx[5]*q[0]*dqx[5]+dqx[2]*q[0]*dqx[2]+
    dqx[0]*q[3]*dqy[0]+dqx[3]*q[3]*dqy[3]+dqx[4]*q[3]*dqy[4]+dqx[3]*q[3]*dqy[3]+dqx[1]*q[3]*dqy[1]+dqx[5]*q[3]*dqy[5]+dqx[4]*q[3]*dqy[4]+dqx[5]*q[3]*dqy[5]+dqx[2]*q[3]*dqy[2]+
    dqx[0]*q[4]*dqz[0]+dqx[3]*q[4]*dqz[3]+dqx[4]*q[4]*dqz[4]+dqx[3]*q[4]*dqz[3]+dqx[1]*q[4]*dqz[1]+dqx[5]*q[4]*dqz[5]+dqx[4]*q[4]*dqz[4]+dqx[5]*q[4]*dqz[5]+dqx[2]*q[4]*dqz[2];
    l3s[1]=dqy[0]*q[3]*dqx[0]+dqy[3]*q[3]*dqx[3]+dqy[4]*q[3]*dqx[4]+dqy[3]*q[3]*dqx[3]+dqy[1]*q[3]*dqx[1]+dqy[5]*q[3]*dqx[5]+dqy[4]*q[3]*dqx[4]+dqy[5]*q[3]*dqx[5]+dqy[2]*q[3]*dqx[2]+
    dqy[0]*q[1]*dqy[0]+dqy[3]*q[1]*dqy[3]+dqy[4]*q[1]*dqy[4]+dqy[3]*q[1]*dqy[3]+dqy[1]*q[1]*dqy[1]+dqy[5]*q[1]*dqy[5]+dqy[4]*q[1]*dqy[4]+dqy[5]*q[1]*dqy[5]+dqy[2]*q[1]*dqy[2]+
    dqy[0]*q[5]*dqz[0]+dqy[3]*q[5]*dqz[3]+dqy[4]*q[5]*dqz[4]+dqy[3]*q[5]*dqz[3]+dqy[1]*q[5]*dqz[1]+dqy[5]*q[5]*dqz[5]+dqy[4]*q[5]*dqz[4]+dqy[5]*q[5]*dqz[5]+dqy[2]*q[5]*dqz[2];
    l3s[2]=dqz[0]*q[4]*dqx[0]+dqz[3]*q[4]*dqx[3]+dqz[4]*q[4]*dqx[4]+dqz[3]*q[4]*dqx[3]+dqz[1]*q[4]*dqx[1]+dqz[5]*q[4]*dqx[5]+dqz[4]*q[4]*dqx[4]+dqz[5]*q[4]*dqx[5]+dqz[2]*q[4]*dqx[2]+
    dqz[0]*q[5]*dqy[0]+dqz[3]*q[5]*dqy[3]+dqz[4]*q[5]*dqy[4]+dqz[3]*q[5]*dqy[3]+dqz[1]*q[5]*dqy[1]+dqz[5]*q[5]*dqy[5]+dqz[4]*q[5]*dqy[4]+dqz[5]*q[5]*dqy[5]+dqz[2]*q[5]*dqy[2]+
    dqz[0]*q[2]*dqz[0]+dqz[3]*q[2]*dqz[3]+dqz[4]*q[2]*dqz[4]+dqz[3]*q[2]*dqz[3]+dqz[1]*q[2]*dqz[1]+dqz[5]*q[2]*dqz[5]+dqz[4]*q[2]*dqz[4]+dqz[5]*q[2]*dqz[5]+dqz[2]*q[2]*dqz[2];
    l3s[3]=dqx[0]*q[3]*dqx[0]+dqx[3]*q[3]*dqx[3]+dqx[4]*q[3]*dqx[4]+dqx[3]*q[3]*dqx[3]+dqx[1]*q[3]*dqx[1]+dqx[5]*q[3]*dqx[5]+dqx[4]*q[3]*dqx[4]+dqx[5]*q[3]*dqx[5]+dqx[2]*q[3]*dqx[2]+
    dqx[0]*q[1]*dqy[0]+dqx[3]*q[1]*dqy[3]+dqx[4]*q[1]*dqy[4]+dqx[3]*q[1]*dqy[3]+dqx[1]*q[1]*dqy[1]+dqx[5]*q[1]*dqy[5]+dqx[4]*q[1]*dqy[4]+dqx[5]*q[1]*dqy[5]+dqx[2]*q[1]*dqy[2]+
    dqx[0]*q[5]*dqz[0]+dqx[3]*q[5]*dqz[3]+dqx[4]*q[5]*dqz[4]+dqx[3]*q[5]*dqz[3]+dqx[1]*q[5]*dqz[1]+dqx[5]*q[5]*dqz[5]+dqx[4]*q[5]*dqz[4]+dqx[5]*q[5]*dqz[5]+dqx[2]*q[5]*dqz[2];
    l3s[4]=dqx[0]*q[4]*dqx[0]+dqx[3]*q[4]*dqx[3]+dqx[4]*q[4]*dqx[4]+dqx[3]*q[4]*dqx[3]+dqx[1]*q[4]*dqx[1]+dqx[5]*q[4]*dqx[5]+dqx[4]*q[4]*dqx[4]+dqx[5]*q[4]*dqx[5]+dqx[2]*q[4]*dqx[2]+
    dqx[0]*q[5]*dqy[0]+dqx[3]*q[5]*dqy[3]+dqx[4]*q[5]*dqy[4]+dqx[3]*q[5]*dqy[3]+dqx[1]*q[5]*dqy[1]+dqx[5]*q[5]*dqy[5]+dqx[4]*q[5]*dqy[4]+dqx[5]*q[5]*dqy[5]+dqx[2]*q[5]*dqy[2]+
    dqx[0]*q[2]*dqz[0]+dqx[3]*q[2]*dqz[3]+dqx[4]*q[2]*dqz[4]+dqx[3]*q[2]*dqz[3]+dqx[1]*q[2]*dqz[1]+dqx[5]*q[2]*dqz[5]+dqx[4]*q[2]*dqz[4]+dqx[5]*q[2]*dqz[5]+dqx[2]*q[2]*dqz[2];
    l3s[5]=dqy[0]*q[4]*dqx[0]+dqy[3]*q[4]*dqx[3]+dqy[4]*q[4]*dqx[4]+dqy[3]*q[4]*dqx[3]+dqy[1]*q[4]*dqx[1]+dqy[5]*q[4]*dqx[5]+dqy[4]*q[4]*dqx[4]+dqy[5]*q[4]*dqx[5]+dqy[2]*q[4]*dqx[2]+
    dqy[0]*q[5]*dqy[0]+dqy[3]*q[5]*dqy[3]+dqy[4]*q[5]*dqy[4]+dqy[3]*q[5]*dqy[3]+dqy[1]*q[5]*dqy[1]+dqy[5]*q[5]*dqy[5]+dqy[4]*q[5]*dqy[4]+dqy[5]*q[5]*dqy[5]+dqy[2]*q[5]*dqy[2]+
    dqy[0]*q[2]*dqz[0]+dqy[3]*q[2]*dqz[3]+dqy[4]*q[2]*dqz[4]+dqy[3]*q[2]*dqz[3]+dqy[1]*q[2]*dqz[1]+dqy[5]*q[2]*dqz[5]+dqy[4]*q[2]*dqz[4]+dqy[5]*q[2]*dqz[5]+dqy[2]*q[2]*dqz[2];
    /*l3s[ab]=daq11*qb1*d1q11+daq21*qb1*d1q12+daq31*qb1*d1q31+daq12*qb1*d1q12+daq22*qb1*d1q22+daq32*qb1*d1q32+daq13*qb1*d1q13+daq23*qb1*d1q23+daq33*qb1*d1q33+
     daq11*qb2*d2q11+daq21*qb2*d2q21+daq31*qb2*d2q31+daq12*qb2*d2q12+daq22*qb2*d2q22+daq32*qb2*d2q32+daq13*qb2*d2q13+daq23*qb2*d2q23+daq33*qb2*d2q33+
     daq11*qb3*d3q11+daq21*qb3*d3q21+daq31*qb3*d3q31+daq12*qb3*d3q12+daq22*qb3*d3q22+daq32*qb3*d3q32+daq13*qb3*d3q13+daq23*qb3*d3q23+daq33*qb3*d3q33;*/
    return;
}

void lchiralforstress(double *q, int l, double *dqx, double *dqy, double *dqz, double *lCs, double *l1s ) {
    //daqgn*(2*dbqgn-dgqbn-dgqbn+2*Cpit*(exbg*Qxn+exbn*qxg+eybg*Qyn+eybn*qyg+ezbg*Qzn+ezbn*qzg))+
    //daqxn*(2*dbqxn-dxqbn-dxqbn+2*Cpit*(exbn*qxx+eybx*Qyn+eybn*qyx+ezbx*Qzn+ezbn*qzx))+daqyn*(2*dbqyn-dyqbn-dyqbn+2*Cpit*(exby*Qxn+exbn*qxy+eybn*qyy+ezby*Qzn+ezbn*qzy))+daqzn*(2*dbqzn-dzqbn-dzqbn+2*Cpit*(exbz*Qxn+exbn*qxz+eybz*Qyn+eybn*qyz+ezbn*qzz))
    //daqxx*(2*dbqxx-dxqbx-dxqbx+2*Cpit*(eybx*Qyx+eybx*qyx+ezbx*Qzx+ezbx*qzx))+daqyx*(2*dbqyx-dyqbx-dyqbx+2*Cpit*(exby*Qxx+eybx*qyy+ezby*Qzx+ezbx*qzy))+daqzx*(2*dbqzx-dzqbx-dzqbx+2*Cpit*(exbz*Qxx+eybz*Qyx+eybx*qyz+ezbx*qzz))+daqxy*(2*dbqxy-dxqby-dxqby+2*Cpit*(exby*qxx+eybx*Qyy+ezbx*Qzy+ezby*qzx))+daqyy*(2*dbqyy-dyqby-dyqby+2*Cpit*(exby*Qxy+exby*qxy+ezby*Qzy+ezby*qzy))+daqzy*(2*dbqzy-dzqby-dzqby+2*Cpit*(exbz*Qxy+exby*qxz+eybz*Qyy+ezby*qzz))+daqxz*(2*dbqxz-dxqbz-dxqbz+2*Cpit*(exbz*qxx+eybx*Qyz+eybz*qyx+ezbx*Qzz))+daqyz*(2*dbqyz-dyqbz-dyqbz+2*Cpit*(exby*Qxz+exbz*qxy+eybz*qyy+ezby*Qzz))+daqzz*(2*dbqzz-dzqbz-dzqbz+2*Cpit*(exbz*Qxz+exbz*qxz+eybz*Qyz+eybz*qyz))
    l1s[0]=dqx[0]*dqx[0]+dqx[3]*dqx[3]+dqx[4]*dqx[4];
    l1s[1]=dqy[3]*dqy[3]+dqy[1]*dqy[1]+dqy[5]*dqy[5];
    l1s[2]=dqz[4]*dqz[4]+dqz[5]*dqz[5]+dqz[2]*dqz[2];
    l1s[3]=dqy[3]*dqx[3]+dqy[1]*dqx[1]+dqy[5]*dqx[5];
    l1s[4]=dqz[4]*dqx[4]+dqz[5]*dqx[5]+dqz[2]*dqx[2];
    l1s[5]=dqz[4]*dqy[4]+dqz[5]*dqy[5]+dqz[2]*dqy[2];
    
    lCs[0]=
    dqx[0]*(2*dqx[0]-dqx[0]-dqx[0])+
    dqx[3]*(2*dqx[3]-dqy[0]-dqy[0]+2*Cpit*(q[4]))+
    dqx[4]*(2*dqx[4]-dqz[0]-dqz[0]+2*Cpit*(-q[3]))+
    dqx[3]*(2*dqx[3]-dqx[3]-dqx[3]+2*Cpit*(q[4]))+
    dqx[1]*(2*dqx[1]-dqy[3]-dqy[3]+2*Cpit*(q[5]+q[5]))+
    dqx[5]*(2*dqx[5]-dqz[3]-dqz[3]+2*Cpit*(-q[1]+q[2]))+
    dqx[4]*(2*dqx[4]-dqx[4]-dqx[4]+2*Cpit*(-q[3]))+
    dqx[5]*(2*dqx[5]-dqy[4]-dqy[4]+2*Cpit*(-q[1]+q[2]))+
    dqx[2]*(2*dqx[2]-dqz[4]-dqz[4]+2*Cpit*(-q[5]-q[5]));
    double lCsxy=
    dqx[0]*(2*dqy[0]-dqx[3]-dqx[3]+2*Cpit*(-q[4]-q[4]))+
    dqx[3]*(2*dqy[3]-dqy[3]-dqy[3]+2*Cpit*(-q[5]))+
    dqx[4]*(2*dqy[4]-dqz[3]-dqz[3]+2*Cpit*(q[0]-q[2]))+
    dqx[3]*(2*dqy[3]-dqx[1]-dqx[1]+2*Cpit*(-q[5]))+
    dqx[1]*(2*dqy[1]-dqy[1]-dqy[1])+
    dqx[5]*(2*dqy[5]-dqz[1]-dqz[1]+2*Cpit*(q[3]))+
    dqx[4]*(2*dqy[4]-dqx[5]-dqx[5]+2*Cpit*(q[0]-q[2]))+
    dqx[5]*(2*dqy[5]-dqy[5]-dqy[5]+2*Cpit*(q[3]))+
    dqx[2]*(2*dqy[2]-dqz[5]-dqz[5]+2*Cpit*(q[4]+q[4]));
    double lCsxz=
    dqx[0]*(2*dqz[0]-dqx[4]-dqx[4]+2*Cpit*(q[3]+q[3]))+
    dqx[3]*(2*dqz[3]-dqy[4]-dqy[4]+2*Cpit*(-q[0]+q[1]))+
    dqx[4]*(2*dqz[4]-dqz[4]-dqz[4]+2*Cpit*(q[5]))+
    dqx[3]*(2*dqz[3]-dqx[5]-dqx[5]+2*Cpit*(-q[0]+q[1]))+
    dqx[1]*(2*dqz[1]-dqy[5]-dqy[5]+2*Cpit*(-q[3]-q[3]))+
    dqx[5]*(2*dqz[5]-dqz[5]-dqz[5]+2*Cpit*(-q[4]))+
    dqx[4]*(2*dqz[4]-dqx[2]-dqx[2]+2*Cpit*(q[5]))+
    dqx[5]*(2*dqz[5]-dqy[2]-dqy[2]+2*Cpit*(-q[4]))+
    dqx[2]*(2*dqz[2]-dqz[2]-dqz[2]);
    double lCsyx=
    dqy[0]*(2*dqx[0]-dqx[0]-dqx[0])+
    dqy[3]*(2*dqx[3]-dqy[0]-dqy[0]+2*Cpit*(q[4]))+
    dqy[4]*(2*dqx[4]-dqz[0]-dqz[0]+2*Cpit*(-q[3]))+
    dqy[3]*(2*dqx[3]-dqx[3]-dqx[3]+2*Cpit*(q[4]))+
    dqy[1]*(2*dqx[1]-dqy[3]-dqy[3]+2*Cpit*(q[5]+q[5]))+
    dqy[5]*(2*dqx[5]-dqz[3]-dqz[3]+2*Cpit*(-q[1]+q[2]))+
    dqy[4]*(2*dqx[4]-dqx[4]-dqx[4]+2*Cpit*(-q[3]))+
    dqy[5]*(2*dqx[5]-dqy[4]-dqy[4]+2*Cpit*(-q[1]+q[2]))+
    dqy[2]*(2*dqx[2]-dqz[4]-dqz[4]+2*Cpit*(-q[5]-q[5]));
    lCs[1]=
    dqy[0]*(2*dqy[0]-dqx[3]-dqx[3]+2*Cpit*(-q[4]-q[4]))+
    dqy[3]*(2*dqy[3]-dqy[3]-dqy[3]+2*Cpit*(-q[5]))+
    dqy[4]*(2*dqy[4]-dqz[3]-dqz[3]+2*Cpit*(q[0]-q[2]))+
    dqy[3]*(2*dqy[3]-dqx[1]-dqx[1]+2*Cpit*(-q[5]))+
    dqy[1]*(2*dqy[1]-dqy[1]-dqy[1])+
    dqy[5]*(2*dqy[5]-dqz[1]-dqz[1]+2*Cpit*(q[3]))+
    dqy[4]*(2*dqy[4]-dqx[5]-dqx[5]+2*Cpit*(q[0]-q[2]))+
    dqy[5]*(2*dqy[5]-dqy[5]-dqy[5]+2*Cpit*(q[3]))+
    dqy[2]*(2*dqy[2]-dqz[5]-dqz[5]+2*Cpit*(q[4]+q[4]));
    double lCsyz=
    dqy[0]*(2*dqz[0]-dqx[4]-dqx[4]+2*Cpit*(q[3]+q[3]))+
    dqy[3]*(2*dqz[3]-dqy[4]-dqy[4]+2*Cpit*(-q[0]+q[1]))+
    dqy[4]*(2*dqz[4]-dqz[4]-dqz[4]+2*Cpit*(q[5]))+
    dqy[3]*(2*dqz[3]-dqx[5]-dqx[5]+2*Cpit*(-q[0]+q[1]))+
    dqy[1]*(2*dqz[1]-dqy[5]-dqy[5]+2*Cpit*(-q[3]-q[3]))+
    dqy[5]*(2*dqz[5]-dqz[5]-dqz[5]+2*Cpit*(-q[4]))+
    dqy[4]*(2*dqz[4]-dqx[2]-dqx[2]+2*Cpit*(q[5]))+
    dqy[5]*(2*dqz[5]-dqy[2]-dqy[2]+2*Cpit*(-q[4]))+
    dqy[2]*(2*dqz[2]-dqz[2]-dqz[2]);
    double lCszx=
    dqz[0]*(2*dqx[0]-dqx[0]-dqx[0])+
    dqz[3]*(2*dqx[3]-dqy[0]-dqy[0]+2*Cpit*(q[4]))+
    dqz[4]*(2*dqx[4]-dqz[0]-dqz[0]+2*Cpit*(-q[3]))+
    dqz[3]*(2*dqx[3]-dqx[3]-dqx[3]+2*Cpit*(q[4]))+
    dqz[1]*(2*dqx[1]-dqy[3]-dqy[3]+2*Cpit*(q[5]+q[5]))+
    dqz[5]*(2*dqx[5]-dqz[3]-dqz[3]+2*Cpit*(-q[1]+q[2]))+
    dqz[4]*(2*dqx[4]-dqx[4]-dqx[4]+2*Cpit*(-q[3]))+
    dqz[5]*(2*dqx[5]-dqy[4]-dqy[4]+2*Cpit*(-q[1]+q[2]))+
    dqz[2]*(2*dqx[2]-dqz[4]-dqz[4]+2*Cpit*(-q[5]-q[5]));
    double lCszy=
    dqz[0]*(2*dqy[0]-dqx[3]-dqx[3]+2*Cpit*(-q[4]-q[4]))+
    dqz[3]*(2*dqy[3]-dqy[3]-dqy[3]+2*Cpit*(-q[5]))+
    dqz[4]*(2*dqy[4]-dqz[3]-dqz[3]+2*Cpit*(q[0]-q[2]))+
    dqz[3]*(2*dqy[3]-dqx[1]-dqx[1]+2*Cpit*(-q[5]))+
    dqz[1]*(2*dqy[1]-dqy[1]-dqy[1])+
    dqz[5]*(2*dqy[5]-dqz[1]-dqz[1]+2*Cpit*(q[3]))+
    dqz[4]*(2*dqy[4]-dqx[5]-dqx[5]+2*Cpit*(q[0]-q[2]))+
    dqz[5]*(2*dqy[5]-dqy[5]-dqy[5]+2*Cpit*(q[3]))+
    dqz[2]*(2*dqy[2]-dqz[5]-dqz[5]+2*Cpit*(q[4]+q[4]));
    lCs[2]=
    dqz[0]*(2*dqz[0]-dqx[4]-dqx[4]+2*Cpit*(q[3]+q[3]))+
    dqz[3]*(2*dqz[3]-dqy[4]-dqy[4]+2*Cpit*(-q[0]+q[1]))+
    dqz[4]*(2*dqz[4]-dqz[4]-dqz[4]+2*Cpit*(q[5]))+
    dqz[3]*(2*dqz[3]-dqx[5]-dqx[5]+2*Cpit*(-q[0]+q[1]))+
    dqz[1]*(2*dqz[1]-dqy[5]-dqy[5]+2*Cpit*(-q[3]-q[3]))+
    dqz[5]*(2*dqz[5]-dqz[5]-dqz[5]+2*Cpit*(-q[4]))+
    dqz[4]*(2*dqz[4]-dqx[2]-dqx[2]+2*Cpit*(q[5]))+
    dqz[5]*(2*dqz[5]-dqy[2]-dqy[2]+2*Cpit*(-q[4]))+
    dqz[2]*(2*dqz[2]-dqz[2]-dqz[2]);
    lCs[3] = 0.5*(lCsxy + lCsyx);/*xy*/
    lCs[4] = 0.5*(lCsxz + lCszx);/*xz*/
    lCs[5] = 0.5*(lCsyz + lCszy);/*yz*/
    lCs[6] = 0.5*(lCsxy - lCsyx);/*xy*/
    lCs[7] = 0.5*(lCsxz - lCszx);/*xz*/
    lCs[8] = 0.5*(lCsyz - lCszy);/*yz*/
    //printf("%g %g %g %g %g %g %g %g %g\n",lCs[0],lCs[1],lCs[2],lCs[3],lCs[4],lCs[5],lCs[6],lCs[7],lCs[8]);
    return;
}

