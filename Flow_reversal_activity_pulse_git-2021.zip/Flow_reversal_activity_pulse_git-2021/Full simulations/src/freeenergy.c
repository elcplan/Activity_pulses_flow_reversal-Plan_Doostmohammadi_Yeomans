/*Printing the free energy contributions*/
void freeenergyprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
    FILE *eptr;
    char nname[500];
    sprintf(nname,"%s/output/energy%d.dat",DPATH,tm); eptr=fopen(nname,"w");
    int lps[26];/*These are for normal and mixed CDs*/
    double wls[3]={0.5, 0.5, 0.5};
    int *lpv=&lps[0];/*These will be used if nowedge*/
    double *wlp=&wls[0];
    double *q=&latc->q[0];
    int lpt,lptcq;
    double delu[9],strain[6],vortic[3];
    double dqx[6],dqy[6],dqz[6];/*derivatives of q locally*/
    double order[1]={0.0},elasticity[1]={0.0},concen[1]={0.0},surftens[1]={0.0},anchor[1]={0.0},elec[1]={0.0},chiral[1]={0.0},smectic[1]={0.0};
    double ordersum=0.0,elasticitysum=0.0,concensum=0.0,surftenssum=0.0,anchorsum=0.0,elecsum=0.0,chiralsum=0.0,smecticsum=0.0;
    double *u=&latv->u[0];
    for(int k=1;k<=nz;k++) {
        for(int j=1;j<=ny;j++) {
            for(int i=1;i<=nx;i++) {
                lpt = (i*ny2+j)*nz2+k;
                lptcq=lpt*lcq;
                derivativesN(i,j,k,&lps[0]);
                derivativesQ(q,&dqx[0],&dqy[0],&dqz[0],&lps[0]);
                if(isgeom) {lpv=&latw->lpv[lpt*2*lbd];wlp=&latw->wlp[lpt*lbd];};
                derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);
                liqcfreeenergy(latc,lpt,latv->rho[lpt],&dqx[0],&dqy[0],&dqz[0],&order[0],&elasticity[0],&concen[0],&surftens[0],&anchor[0],&elec[0],&chiral[0],&smectic[0],&lps[0],tm);
                ordersum+=order[0];
                elasticitysum+=elasticity[0];
                concensum+=concen[0];
                surftenssum+=surftens[0];
                anchorsum+=anchor[0];
                elecsum+=elec[0];
                chiralsum+=chiral[0];
                smecticsum+=smectic[0];
            } } }
    fprintf(eptr,"%f %f %f %f %f %f %f %f\n",ordersum,elasticitysum,concensum,surftenssum,anchorsum,elecsum,chiralsum,smecticsum);
    fclose(eptr);
}

/*Calculating all the free energy contributions*/
void liqcfreeenergy(lclattice *lat, int l, double rho, double *dqx, double *dqy, double *dqz, double *order, double *elasticity, double *concen, double *surftens, double *anchor, double *elec, double *chiral, double *smectic, int *lps, int tm) {
    double l2s[6]={0,0,0,0,0,0};
    double l3s[6]={0,0,0,0,0,0};
    double l2p=0.0;
    double l3p=0.0;
    double *q=&(lat->q[l*lcq]);
    if(sconst>0) { l2l3forstress(q,l,dqx,dqy,dqz,&l2s[0],&l3s[0],&l2p,&l3p); };
    double Q2=q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+2*(q[3]*q[3]+q[4]*q[4]+q[5]*q[5]);
    double Q3=q[0]*q[0]*q[0]+q[1]*q[1]*q[1]+q[2]*q[2]*q[2]+3*q[0]*q[3]*q[3]+3*q[0]*q[4]*q[4]+3*q[1]*q[3]*q[3]+3*q[1]*q[5]*q[5]+3*q[2]*q[4]*q[4]+3*q[2]*q[5]*q[5]+6*q[3]*q[5]*q[4];
    double phi,mu;
    double diff2=dqx[0]*dqx[0]+dqy[0]*dqy[0]+dqz[0]*dqz[0]+dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]+dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]
    +dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]+dqx[1]*dqx[1]+dqy[1]*dqy[1]+dqz[1]*dqz[1]+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]
    +dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]+dqx[2]*dqx[2]+dqy[2]*dqy[2]+dqz[2]*dqz[2];
    double Alceff=Alc,Blceff=Blc,Clceff=Clc;
    if(inphase) {
        phi=lat->phi[l];
        double etaphi=eta0lcphi-etaslcphi*(phi-phibar)*(phi-phibar);
        Alceff=A0lcphi*phi*phi*(1.0-etaphi/3.0);
        Blceff=-A0lcphi*phi*phi*etaphi*Beq0;
        Clceff=A0lcphi*phi*phi*etaphi;
        mu=lat->mu[l];
        double dphidx=0.5*(lat->phi[lps[0]]-lat->phi[lps[1]]);
        double dphidy=0.5*(lat->phi[lps[2]]-lat->phi[lps[3]]);
        double dphidz=0.5*(lat->phi[lps[4]]-lat->phi[lps[5]]);
        smectic[0]=0.0;
        concen[0]=0.5*Aphi*phi*phi*(1-phi)*(1-phi);
        //concen[0] = 0.5*Aphi*(phi-phi0)*(phi-phi0)+0.25*Bphi*(phi-phi0)*(phi-phi0)*(phi-phi0)*(phi-phi0);
        surftens[0]=0.5*Kphi*(dphidx*dphidx+dphidy*dphidy+dphidz*dphidz);
        anchor[0]=Lw*(dphidx*dphidx*q[0]+2*dphidx*dphidy*q[3]+2*dphidx*dphidz*q[4]+dphidy*dphidy*q[1]+2*dphidy*dphidz*q[5]+dphidz*dphidz*q[2]);
        
        if(issmectic) {
            float **dq;
            float *diag,*offdiag;
            dq = matrix(1,3,1,3);
            diag=vector(1,3);
            offdiag=vector(1,3);
            
            dq[1][1]=q[0];  dq[1][2]=q[3];dq[1][3]=q[4];
            dq[2][1]=q[3];dq[2][2]=q[1];dq[2][3]=q[5];
            dq[3][1]=q[4];dq[3][2]=q[5];dq[3][3]=q[2];
            
            tred2(dq,lbd,diag,offdiag);
            tqli(diag,offdiag,lbd,dq);
            int evmax=1;
            
            if(diag[2]>diag[evmax]) evmax=2;
            if(diag[3]>diag[evmax]) evmax=3;
            
            if(abs(diag[evmax]<1e-10)) {dq[1][evmax]=0;dq[2][evmax]=0;dq[3][evmax]=0;}
            if(diag[evmax]<-100) {dq[1][evmax]=0;dq[2][evmax]=0;dq[3][evmax]=0;}
            
            smectic[0]=-CSme*SQR(dq[3][evmax]);
            
            free_matrix(dq, 1,3,1,3);
            free_vector(diag, 1,3);
            free_vector(offdiag, 1,3);
        }
        
        if(ischiral) {
            chiral[0]=0.5*KClc*((dqy[4]-dqz[3]+2*Cpit*q[0])*(dqy[4]-dqz[3]+2*Cpit*q[0])
                                +(dqy[5]-dqz[1]+2*Cpit*q[3])*(dqy[5]-dqz[1]+2*Cpit*q[3])
                                +(dqy[2]-dqz[5]+2*Cpit*q[4])*(dqy[2]-dqz[5]+2*Cpit*q[4])
                                +(dqz[0]-dqx[4]+2*Cpit*q[3])*(dqz[0]-dqx[4]+2*Cpit*q[3])
                                +(dqz[3]-dqx[5]+2*Cpit*q[1])*(dqz[3]-dqx[5]+2*Cpit*q[1])
                                +(dqz[4]-dqx[2]+2*Cpit*q[5])*(dqz[4]-dqx[2]+2*Cpit*q[5])
                                +(dqx[3]-dqy[0]+2*Cpit*q[4])*(dqx[3]-dqy[0]+2*Cpit*q[4])
                                +(dqx[1]-dqy[3]+2*Cpit*q[5])*(dqx[1]-dqy[3]+2*Cpit*q[5])
                                +(dqx[5]-dqy[4]+2*Cpit*q[2])*(dqx[5]-dqy[4]+2*Cpit*q[2]))
                        +0.5*Klc*(dqx[0]*dqx[0]+dqy[3]*dqy[3]+dqz[4]*dqz[4]+
                                  dqx[3]*dqx[3]+dqy[1]*dqy[1]+dqz[5]*dqz[5]+
                                  dqx[4]*dqx[4]+dqy[5]*dqy[5]+dqz[2]*dqz[2]);
        }
        
        if(iselectric&&(tm>telecini)&&(tm<telecend)) {
            elec[0]=-fsperm*dielan*phi*(elecf[0]*elecf[0]*q[0]+elecf[1]*elecf[1]*q[1]+elecf[2]*elecf[2]*q[2]+2*elecf[0]*elecf[1]*q[3]+2*elecf[0]*elecf[2]*q[4]+2*elecf[1]*elecf[2]*q[5]);
        }
    }
    order[0]=0.5*Alceff*Q2+Blceff/3.0*Q3+0.25*Clceff*Q2*Q2;
    elasticity[0]=0.5*Klc*diff2*(1-ischiral)+0.5*K2lc*l2p+0.5*K3lc*l3p;
    return;
}

