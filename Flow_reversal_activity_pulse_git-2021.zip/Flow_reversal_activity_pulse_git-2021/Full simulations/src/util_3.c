/*function to swap f and fnew after each iteration*/
void swapffs(double **f, double **fnew)
{
double *temp;
temp = *f;
*f = *fnew;
*fnew = temp;
return;
}

/*function to copy each q and qmid after each iteration*/
void copyffs(double *f, double *fnew, int lq)
{
for (int l=0;l<=n2max*lq; l++) {
fnew[l] = f[l];}
return;
}

/*function to calculate the totals to check conservation*/
double sumof(double *f, int num, int *w,int flag)
{
if(!flag) return 0;
double sum=0.0;
int l,lpt;
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
	    lpt=(i*ny2+j)*nz2+k;
      if(w[lpt]>=0) {
	    for(int m=0;m<num;m++) {
	    l=lpt*num+m;
	    sum=sum+f[l];
      //printf("%d %d %d %d %d %f %f\n",i,j,k,lpt,w[lpt],f[l],sum);
      }; }; }; }; };
return sum;
}

/*function to calculate the totals to monitor*/
void totmom(double *v, double *rho, int *w, double *sumd)
{
sumd[0]=0.0;
sumd[1]=0.0;
sumd[2]=0.0;
sumd[3]=0.0;
int l,lpt;
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
	    lpt=(i*ny2+j)*nz2+k;
      if(w[lpt]>=0) {
	    for(int m=0;m<lbd;m++) {
	    l=lpt*lbd+m;
	    sumd[m]=sumd[m]+rho[lpt]*v[l];
	    sumd[3]=sumd[3]+v[l]*v[l];
      }; }; }; }; };
      sumd[3] = sqrt(sumd[3]/(nx*ny*nz));
return ;
}

/*function to create a float matrix with given number of rows and columns*/
float **fmatrix(int nrl,int nrh,int ncl,int nch)
{
int i;
int nr=nrh-nrl+1;
int nc=nch-ncl+1;
float **m;
/*check before using it again*/
/*allocate pointers to rows*/
m = (float **)malloc(nr*sizeof(float *));
for(i=0;i<nc;i++) m[i] = (float *) malloc(nc*sizeof(float));
return m;
}

double lap_oonopuri(double *lap_ptr,int *lps, int lpt) {
double ret_val=(
(lap_ptr[lps[0]]+lap_ptr[lps[1]]+lap_ptr[lps[2]]+lap_ptr[lps[3]]+lap_ptr[lps[4]]+lap_ptr[lps[5]])*6.0/80.0+
(lap_ptr[lps[14]]+lap_ptr[lps[16]]+lap_ptr[lps[15]]+lap_ptr[lps[17]]+lap_ptr[lps[22]]+lap_ptr[lps[23]]+
 lap_ptr[lps[24]]+lap_ptr[lps[25]]+lap_ptr[lps[20]]+lap_ptr[lps[18]]+lap_ptr[lps[19]]+lap_ptr[lps[21]])*3.0/80.0+
(lap_ptr[lps[6]]+lap_ptr[lps[7]]+lap_ptr[lps[10]]+lap_ptr[lps[11]]+lap_ptr[lps[8]]+lap_ptr[lps[9]]+lap_ptr[lps[12]]+lap_ptr[lps[13]])*1.0/80.0- lap_ptr[lpt])/0.275;
return(ret_val);
}
