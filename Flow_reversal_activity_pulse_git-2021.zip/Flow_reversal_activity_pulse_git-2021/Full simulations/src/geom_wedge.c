/* functions associated with wedge geometry*/

/*wedge initialisation*/
wedge *wedge_initialise(lblattice *latv) {
isgeom=iswedge||isbox||iscir||istwowedge||((fbouncond==2)&&(qbouncond==1));
wedge *lat=(wedge *)malloc(sizeof(wedge));/*variable associated with all wedge parameters*/

lat->w = (int *)malloc(nx2*ny2*nz2*sizeof(int));/*marker*/
lat->partmark = (int *)malloc(nx2*ny2*nz2*sizeof(int));/*marker*/
if(tini>0) {printf("Initial geometry will be read \n");init_readg(lat);}
if(!isgeom) {simply_fill_marker(lat); }    //Emmanuel: if isgeom is not 1, the "marker" is filled with 1's and 0' s
else {
  lat->partloc=(double *)malloc(numofpart*lcd*sizeof(double));
  particle_locations(lat);
  if(iswedge) {wedge_initial(latv, lat);}
  else if(isbox) {box_initial(latv, lat);}
  else if(iscir) {cir_initial(latv, lat);}
  else if(istwowedge) {twowedge_initial(latv, lat);}
  else if((fbouncond==2)&&(qbouncond==1)) {couette_initial(latv, lat);}
  lat->markers= (double *)malloc(numofpart*lcd*sizeof(double));/*velocities*/
  lat->bodyomega= (double *)malloc(numofpart*lcd*sizeof(double));/*velocities*/
  lat->bodyomegaold= (double *)malloc(numofpart*lcd*sizeof(double));/*velocities*/
  lat->numforomega= (double *)malloc(numofpart*sizeof(double));/*useful for multiparticles*/
  lat->denforomega= (double *)malloc(numofpart*sizeof(double));
  lat->torque= (double *)malloc(numofpart*lcd*sizeof(double));/*velocities*/
  lat->torqueold= (double *)malloc(numofpart*lcd*sizeof(double));/*velocities*/
  lat->forceb= (double *)malloc(numofpart*lcd*sizeof(double));/*velocities*/
  lat->forcebold= (double *)malloc(numofpart*lcd*sizeof(double));/*velocities*/
  for(int i=0;i<numofpart*lcd;i++) {
  	lat->bodyomega[i]=0.0;
	lat->bodyomegaold[i]=0.0;
  	lat->torque[i]=0.0;
  	lat->torqueold[i]=0.0;
	lat->forceb[i]=0.0;
	lat->forcebold[i]=0.0;}
  for(int i=0;i<numofpart;i++) {
  	lat->markers[i*lcd+0]=lat->partloc[i*lcd+0];
	lat->markers[i*lcd+1]=lat->partloc[i*lcd+1]+boxdim1*0.5;
	lat->markers[i*lcd+2]=lat->partloc[i*lcd+2];}
  lat->lpv = (int *)malloc(nx2*ny2*nz2*2*lbd*sizeof(int));/*to mark the derivatives*/
  lat->wlp = (double *)malloc(nx2*ny2*nz2*lbd*sizeof(double));/*to mark the derivatives*/
  /*Making an array to calculate the derivatives easily on walls and everywhere*/
  derivNwedge(lat);
  tmlmax=(tmax-tminforang)/tgapforang+1;
  if(angvelcorr) {
    int tml=(tmax-tminforang)/tgapforang+1;
    lat->angseries = (double *)malloc(numofpart*tml*sizeof(double));
    lat->corrang = (double *) malloc(numofpart*tml*sizeof(double));
    lat->corrangrealzn = (int *) malloc(numofpart*tml*sizeof(int));
    for(int i=0;i<tml*numofpart;i++) {lat->corrang[i]=0.0;lat->corrangrealzn[i]=0;}
  }
}
return lat;
}

void particle_locations(wedge *lat) {
double dist=((double)nx)/numofpart;
for(int i=0;i<numofpart;i++) {
    lat->partloc[i*lcd+0]=dist*0.5+i*dist+0.5;
    lat->partloc[i*lcd+1]=ny/2+0.5;
    lat->partloc[i*lcd+2]=nz/2+0.5;
}
return;
}

void couette_initial(lblattice *latv, wedge *lat) {
if(tini==0) {
  couette_fill_marker(lat);
  /*Marking the boundaries of the wedge with markers*/
  wedge_boun_ini(lat,latv);
}
/*Ensure that pbc on side walls for w*/
pbc_copying_planexy_ofint(&lat->w[0],1);/*pbc on xy plane*/
/*Just to ensure that everything on the sides are alright*/
pbc_copying_planeyz_ofint(&lat->w[0],1);/*pbc on yz plane*/
pbc_copying_liney_ofint(&lat->w[0],1);/*pbc on y line @ four edges*/
return;
}

void cir_initial(lblattice *latv, wedge *lat) {
if(tini==0) {
  cir_fill_marker(lat);
  /*Marking the boundaries of the wedge with markers*/
  wedge_boun_ini(lat,latv);
}
/*Ensure that pbc on side walls for w*/
pbc_copying_planexy_ofint(&lat->w[0],1);/*pbc on xy plane*/
/*Just to ensure that everything on the sides are alright*/
pbc_copying_planeyz_ofint(&lat->w[0],1);/*pbc on yz plane*/
pbc_copying_liney_ofint(&lat->w[0],1);/*pbc on y line @ four edges*/
return;
}

void box_initial(lblattice *latv, wedge *lat) {
if(tini==0) {
  box_fill_marker(lat);
  /*Marking the boundaries of the wedge with markers*/
  wedge_boun_ini(lat,latv);
}
/*Ensure that pbc on side walls for w*/
pbc_copying_planexy_ofint(&lat->w[0],1);/*pbc on xy plane*/
/*Just to ensure that everything on the sides are alright*/
pbc_copying_planeyz_ofint(&lat->w[0],1);/*pbc on yz plane*/
pbc_copying_liney_ofint(&lat->w[0],1);/*pbc on y line @ four edges*/
return;
}

void wedge_initial(lblattice *latv, wedge *lat) {
double trad=tan(thetawedge/2.0/180.0*3.14159265359);
if(tini==0) {
  if(hwwedge*trad*2+20>nx) {
    printf("Domain in x direction is too small to accommodate a wedge\n");
    getchar(); return ;
  }
  wedge_fill_marker(lat);
  wedge_bottom_correction(lat);/*to ensure that there are atleast 3 points in liquid at the bottom of the wedge*/
  /*Marking the boundaries of the wedge with markers*/
  wedge_boun_ini(lat,latv);
}
/*Ensure that pbc on side walls for w*/
pbc_copying_planexy_ofint(&lat->w[0],1);/*pbc on xy plane*/
/*Just to ensure that everything on the sides are alright*/
pbc_copying_planeyz_ofint(&lat->w[0],1);/*pbc on yz plane*/
pbc_copying_liney_ofint(&lat->w[0],1);/*pbc on y line @ four edges*/
return;
}

void twowedge_initial(lblattice *latv, wedge *lat) {
if(tini==0) {
  twowedge_fill_marker(lat);
  wedge_bottom_correction(lat);/*to ensure that there are atleast 3 points in liquid at the bottom of the wedge*/
  wedge_top_correction(lat);/*to ensure that there are atleast 3 points in liquid at the top of the wedge*/
  /*Marking the boundaries of the wedge with markers*/
  wedge_boun_ini(lat,latv);
}
/*Ensure that pbc on side walls for w*/
pbc_copying_planexy_ofint(&lat->w[0],1);/*pbc on xy plane*/
/*Just to ensure that everything on the sides are alright*/
pbc_copying_planeyz_ofint(&lat->w[0],1);/*pbc on yz plane*/
pbc_copying_liney_ofint(&lat->w[0],1);/*pbc on y line @ four edges*/
return;
}


void wedge_fill_marker(wedge *lat) {
int l;
double lx,ly;
double xc=nx/2+0.5;
double trad=tan(thetawedge/2.0/180.0*3.14159265359);
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l=(i*ny2+j)*nz2+k;
      lx=i-xc;
      if(lx<0) lx=-lx;
      ly=lx/trad;
      lat->w[l]=score;
      if(j==0)
        lat->w[l]=score;
      else if(j>ny)
        lat->w[l]=swall;
      else if(j==ny)
        lat->w[l]=lwall;
      else if(j>hwwedge)
        lat->w[l]=lcore;
      else if(j>ly)
        lat->w[l]=lcore;
        //if(j==2) printf("%d %d %d %d %d \n",i,j,k,l,lat->w[l]);
};};};
return;
}

void twowedge_fill_marker(wedge *lat) {
int l;
double lx,ly;
double xc=nx/2+0.5;
double yc=ny/2+0.5;
double trad=tan(thetawedge/2.0/180.0*3.14159265359);
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l=(i*ny2+j)*nz2+k;
      lx=i-xc;
      if(lx<0) lx=-lx;
      ly=lx/trad;
      lat->w[l]=score;
      if((j==0)||(j>ny))/*bottom and top boundary*/
        lat->w[l]=score;
      else if((j<yc)&&(j>ly))
        lat->w[l]=lcore;
      else if((j>yc)&&((ny+1-j)>ly))
        lat->w[l]=lcore;
        //if(j==2) printf("%d %d %d %d %d \n",i,j,k,l,lat->w[l]);
};};};
return;
}

void wedge_bottom_correction(wedge *lat) {
int l,l1,l2,bb,bhis;
int *w=&lat->w[0];
for(int k=1;k<=nz;k++) {
  bhis=0;
  for(int j=1;j<=ny;j++) {
    bb=0;
    for(int i=1;i<=nx;i++) {
      l=(i*ny2+j)*nz2+k;
      if(w[l]==lcore) {
        l1=((i+1)*ny2+j)*nz2+k;
        l2=((i+2)*ny2+j)*nz2+k;
        if(w[l2]!=lcore) {
          printf("Replacing %d - %d in j=%d level at k=%d because w[%d]=%d and w[%d]=%d \n",i,i+2,j,k,i,w[l],i+2,w[l2]);
          w[l]=score;
          w[l1]=score;
          w[l2]=score;
          bb=1;
          bhis=bhis+bb;/*scans at least first 10 levels*/
          break;
        }
        else {
          break;
        }
        }; };
    if((bb==0)&&(bhis>0)) break;
    }; };
return;
}

void wedge_top_correction(wedge *lat) {
int l,l1,l2,bb,bhis;
int *w=&lat->w[0];
for(int k=1;k<=nz;k++) {
  bhis=0;
  for(int j=ny;j>=1;j--) {
    bb=0;
    for(int i=1;i<=nx;i++) {
      l=(i*ny2+j)*nz2+k;
      if(w[l]==lcore) {
        l1=((i+1)*ny2+j)*nz2+k;
        l2=((i+2)*ny2+j)*nz2+k;
        if(w[l2]!=lcore) {
          printf("Replacing %d - %d in j=%d level at k=%d because w[%d]=%d and w[%d]=%d \n",i,i+2,j,k,i,w[l],i+2,w[l2]);
          w[l]=score;
          w[l1]=score;
          w[l2]=score;
          bb=1;
          bhis=bhis+bb;/*scans at least first 10 levels*/
          break;
        }
        else {
          break;
        }
        }; };
    if((bb==0)&&(bhis>0)) break;
    }; };
return;
}

void simply_fill_marker(wedge *lat) {
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      lat->w[(i*ny2+j)*nz2+k]=1;
      lat->partmark[(i*ny2+j)*nz2+k]=0;
};};};
return;
}

void wedge_boun_ini(wedge *latw, lblattice *latv) {
double *xi=&latv->xi[0];
int is, js, ks, l, lnew;
int k0=1, lne0;
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]>swall) {
        for(int m=0;m<lbq;m++) {
          is=i+xi[lbd*m];
          js=j+xi[lbd*m+1];
          ks=k+xi[lbd*m+2];
          lnew=(is*ny2+js)*nz2+ks;
          if(latw->w[lnew]<lwall) {
            //printf("%d %d %d %d %d to %d %d %d %d %d \n",i,j,k,l,latw->w[l],is,js,ks,lnew,latw->w[lnew]);
            latw->w[l]=lwall;
            latw->w[lnew]=swall;
	    //printf("%d %d %d %d %d\n",i,j,k,m,latw->w[lnew]);
            if(nz==1) {
              /*Since ks=0/nz+1 are outsiders, pretend that ks=1 and make it part of wall*/
              if((ks==0)||(ks==nz+1)) {
                lne0=(is*ny2+js)*nz2+k0;
                latw->w[lne0]=swall; }; };
          }; }; };
//printf("%d %d %d %d %d \n",i,j,k,l,latw->w[l]);
}; }; };
return;
}

void derivNwedge(wedge *lat) {
int *lpv = &lat->lpv[0];
double *wlp = &lat->wlp[0];
int l2,l1,l;
int *w = &lat->w[0];
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      l=(i*ny2+j)*nz2+k;
      l1=l*lbd;
      l2=l1*2;
      lpv[l2+0] = ((i+1)*ny2+j  )*nz2+k  ;
      lpv[l2+1] = ((i-1)*ny2+j  )*nz2+k  ;
      lpv[l2+2] = ( i   *ny2+j+1)*nz2+k  ;
      lpv[l2+3] = ( i   *ny2+j-1)*nz2+k  ;
      lpv[l2+4] = ( i   *ny2+j  )*nz2+k+1;
      lpv[l2+5] = ( i   *ny2+j  )*nz2+k-1;
      wlp[l1+0]=0.5;
      wlp[l1+1]=0.5;
      wlp[l1+2]=0.5;
      if(w[l]==0) {
        if(w[lpv[l2+0]]<0) {lpv[l2+0]=l;wlp[l1+0]=1;}
        else if(w[lpv[l2+1]]<0) {lpv[l2+1]=l;wlp[l1+0]=1;};
        if(w[lpv[l2+2]]<0) {lpv[l2+2]=l;wlp[l1+1]=1;}
        else if(w[lpv[l2+3]]<0) {lpv[l2+3]=l;wlp[l1+1]=1;};
        if(w[lpv[l2+4]]<0) {lpv[l2+4]=l;wlp[l1+2]=1;}
        else if(w[lpv[l2+5]]<0) {lpv[l2+5]=l;wlp[l1+2]=1;};
      }; }; }; };
return;
}

void box_fill_marker(wedge *lat) {
int l;
double lx,ly;
double xc=nx/2+0.5;
double yc=ny/2+0.5;
double bc=boxdim1/2.;
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l=(i*ny2+j)*nz2+k;
      lat->w[l]=lcore;
      lx=fabs(i-xc);
      ly=fabs(j-yc);
      if((lx < bc) && (ly < bc)) {
        lat->w[l]=score; }
};};};
return;
}

void cir_fill_marker(wedge *lat) {
int l;
double lx,ly,rad;
double xc,yc;
double bc=boxdim1/2.;
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l=(i*ny2+j)*nz2+k;
      lat->w[l]=lcore;
      lat->partmark[l]=0;
      for(int np=0;np<numofpart;np++) {
	xc=lat->partloc[np*lcd];
	yc=lat->partloc[np*lcd+1];
        lx=fabs(i-xc);
        ly=fabs(j-yc);
        rad = sqrt(lx*lx+ly*ly);
        if(rad < bc) {
          lat->w[l]=score;} 
        if(rad < bc+3) {/*two points extra to include swall,lwall*/
	  lat->partmark[l]=np+1;}
      }
      };};};
return;
}

void couette_fill_marker(wedge *lat) {
int l;
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l=(i*ny2+j)*nz2+k;
      lat->w[l]=lcore;
      if((j==0)||(j==ny+1)) {
        lat->w[l]=score; }
};};};
return;
}
