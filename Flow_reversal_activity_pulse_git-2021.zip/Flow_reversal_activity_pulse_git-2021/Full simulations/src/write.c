/*Output functions for actcol*/
void printing(lblattice *latv, lclattice *latc, wedge *latw, deflattice *latd, int tm) {
veldirprinting(latv,latc,latw,tm);
if((tm>tini)&&(tm%writfq==0)) printingfq(latv,latc,latw,tm);
//if(stress&&(tm%writstress==0)) stressprinting(latv, latc, latw, tm);
//if(stresssplit&&(tm%writstress==0)) stresssplitprinting(latv, latc, latw, tm);
//if(forcea&&(tm%writforce==0)) sepforceprinting(latv, latc, latw, tm);
//if(marker&&(tm%writmarker==0)) markerprinting(latv, latc, latw, tm);
//if(isrotn&&(tm%writangvel==0)) angvelprinting(latv, latc, latw, tm);
//if(angvelcorr&&(tm%tgapforangwrite==0)&&(tm>tminforang)) angvelcorrprinting(latv, latc, latw, tm);
//if(((isdragbody)||(isdragboun))) bodyforceprinting(latv, latc, latw, tm);
//if(defects&&(tm%writdefects==0)) defectsprinting(&latc->dcharge[0],tm);
//if(trackdef&&(tm%writdeftrack==0)) alldefectstrackprinting(latd,tm);
//if(indtrack&&(tm%writindtrack==0)) alldefectstrackprinting(latd,tm);
//if(writenergy) freeenergyprinting(latv, latc, latw, tm);
//if(calcstress) stresscalc(latv,latc,latw,tm);
stressgrad(latv,latc,latw,tm);
prinstress(latv,latc,latw,tm);
//if(iswithpoly){stiffness(latv,latc,tm);} else {stiffness_nopoly(latv,latc,tm);};
double velxbefore,velxbefore2,velxafter,velxafter2,reversal;
int k=1;
int j=phidim1;
int i=nx/2;
int l=(i*ny2+j)*nz2+k;
if(tm==99000){
	velxbefore=latv->u[l*lbd];
	velxbefore2=velxbefore/fabs(velxbefore);
	FILE *qptr;
	char nname[500];
	sprintf(nname,"%s/output/reversaltemp.dat",DPATH,tm);  qptr=fopen(nname,"w");
	fprintf(qptr,"%f %f\n",velxbefore,velxbefore2);
	fclose(qptr);
}

if(tm==200000){
	velxafter=latv->u[l*lbd];
	velxafter2=velxafter/fabs(velxafter);

	FILE *qptr;
	char nname[500];
	sprintf(nname,"%s/output/reversaltemp.dat",DPATH,tm);  qptr=fopen(nname,"r");
	fscanf(qptr,"%lf %lf",&velxbefore,&velxbefore2);
//printf("Velxbefore and velxbefore2 %f %f\n",velxbefore,velxbefore2);
	fclose(qptr);
	
//	printf("Here!\n");
	sprintf(nname,"%s/output/reversal.dat",DPATH,tm);  qptr=fopen(nname,"w");
	reversal=velxbefore2*velxafter2;
	fprintf(qptr,"%f %f %f %f %f\n",reversal,velxbefore,velxafter,velxbefore2,velxafter2);
	fclose(qptr);
}

}

void printingfq(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *qptr, *fptr, *pptr, *cptr;
char nname[500];
sprintf(nname,"%s/output/qtensor%d.bin",DPATH,tm);  qptr=fopen(nname,"w");
sprintf(nname,"%s/output/ftensor%d.bin",DPATH,tm);  fptr=fopen(nname,"w");
fwrite(&tm,sizeof(int),1,qptr);
fwrite(&tm,sizeof(int),1,fptr);
fwrite(latc->q,sizeof(double),nx2*ny2*nz2*lcq,qptr);
fwrite(latv->f,sizeof(double),nx2*ny2*nz2*lbq,fptr);
fclose(fptr);
fclose(qptr);
if(inphase) {
  sprintf(nname,"%s/output/phinsor%d.bin",DPATH,tm);  pptr=fopen(nname,"w");
  fwrite(&tm,sizeof(int),1,pptr);
  fwrite(latc->phi,sizeof(double),nx2*ny2*nz2,pptr);
  fclose(pptr);
}

if(iswithpoly) {
sprintf(nname,"%s/output/ctensor%d.bin",DPATH,tm);  cptr=fopen(nname,"w");
fwrite(&tm,sizeof(int),1,cptr);
fwrite(latc->l,sizeof(double),nx2*ny2*nz2*lcc,cptr);
fclose(cptr);

}//end iswithpoly

return;
}

void phiprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *pptr;
char nname[500];
sprintf(nname,"%s/output/phi%d.dat",DPATH,tm); pptr=fopen(nname,"w");
int l;
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      l=(i*ny2+j)*nz2+k;
      fprintf(pptr,"%f\n",latc->phi[l]);
} } }
fclose(pptr);

}

void veldirprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *vptr, *dptr, *polyptr,*lenptr;;
char nname[500];
sprintf(nname,"%s/output/vel%d.dat",DPATH,tm); vptr=fopen(nname,"w");
sprintf(nname,"%s/output/dir%d.dat",DPATH,tm); dptr=fopen(nname,"w");
int l,llb,llc,llf,np;
float **dq;
float *diag,*offdiag;
int evmax;
dq = matrix(1,3,1,3);
diag=vector(1,3);
offdiag=vector(1,3);
double xc=0.0,yc=0.0,zc=0.0;//commented 0510
double wallvel[3]={0.0,0.0,0.0};
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      l=(i*ny2+j)*nz2+k;
      llb=l*lbd;llc=l*lcq;llf=l*lbq;
      if(((isgeom)&&(latw->w[l]<swall))) {
        if(isrotn==1) {
	  np=latw->partmark[l];
	  xc=latw->partloc[(np-1)*lcd+0];
	  yc=latw->partloc[(np-1)*lcd+1];
	  zc=latw->partloc[(np-1)*lcd+2];
	  /*Not writing the actual velocity inside the particle*/
	  wallvel[0] = latw->bodyomega[(np-1)*lcd+1]*(k-zc) - latw->bodyomega[(np-1)*lcd+2]*(j-yc);
	  wallvel[1] = latw->bodyomega[(np-1)*lcd+2]*(i-xc) - latw->bodyomega[(np-1)*lcd+0]*(k-zc);
	  wallvel[2] = latw->bodyomega[(np-1)*lcd+0]*(j-yc) - latw->bodyomega[(np-1)*lcd+1]*(i-xc);
	  }
        fprintf(vptr,"%f %f %f %f\n",rho0,wallvel[0],wallvel[1],wallvel[2]);}
        else {
        fprintf(vptr,"%f %f %f %f\n",latv->rho[l],latv->u[l*lbd],latv->u[l*lbd+1],latv->u[l*lbd+2]);}
      dq[1][1]=latc->q[llc];  dq[1][2]=latc->q[llc+3];dq[1][3]=latc->q[llc+4];
      dq[2][1]=latc->q[llc+3];dq[2][2]=latc->q[llc+1];dq[2][3]=latc->q[llc+5];
      dq[3][1]=latc->q[llc+4];dq[3][2]=latc->q[llc+5];dq[3][3]=latc->q[llc+2];
      //if(latw->w[l]==swall) {printf("%d %f %f %f\n",l,dq[1][1],dq[2][2],dq[1][2]);}
      if(~((isgeom)&&(latw->w[l]<swall))) {
      tred2(dq,lbd,diag,offdiag);
      tqli(diag,offdiag,lbd,dq);
      evmax=1;
      if(diag[2]>diag[evmax]) evmax=2;
      if(diag[3]>diag[evmax]) evmax=3;
	//if(evmax==3) printf("Hi!%d,%d: evmax=%d\n",i,j,evmax);
	//if(evmax==3) printf("Oh no! at %d,%d,%d:%f,%f,%f.\n",i,j,k,dq[1][evmax],dq[2][evmax],dq[3][evmax],diag[evmax]);
	//printf("%f,%f,%f;%f,%f,%f;%f,%f,%f\n",dq[1][1],dq[1][2],dq[1][3],dq[2][1],dq[2][2],dq[2][3],dq[3][1],dq[3][2],dq[3][3]);
	//}
	}
      if(fabs(diag[evmax])<1e-10) {dq[1][evmax]=0;dq[2][evmax]=0;dq[3][evmax]=0;}
      if(diag[evmax]<-100) {dq[1][evmax]=0;dq[2][evmax]=0;dq[3][evmax]=0;}
      fprintf(dptr,"%f %f %f %f\n",dq[1][evmax],dq[2][evmax],dq[3][evmax],diag[evmax]);
      //printf("%f %f %f %f\n",dq[1][1],dq[2][1],dq[3][1],diag[1]);
      //printf("%f %f %f %f\n",dq[1][2],dq[2][2],dq[3][2],diag[2]);
      //printf("%f %f %f %f\n",dq[1][3],dq[2][3],dq[3][3],diag[3]);
} } }
fclose(dptr);


free_matrix(dq,1,3,1,3);
printf("\nsum of f at t = %i is %f, of q is %f, of phi is %f, length of c is %f.\n",tm,sumof(latv->f,lbq,latw->w,1),sumof(latc->q,lcq,latw->w,1),sumof(latc->phi,1,latw->w,inphase),polylength(latc->c,lcc,latw->w,iswithpoly));
double mom[4];
totmom(latv->u,latv->rho,latw->w,&mom[0]);
printf("vrms is %f, x mom is %f, y mom is %f and z mom is %f.\n",mom[3],mom[0],mom[1],mom[2]);
if(isgeom&&(numofpart==1)) {printf(" w_z=%f\n",latw->bodyomega[2]);}else {printf("\n");}
if(inphase) phiprinting(latv,latc,latw,tm);

if (iswithpoly){
sprintf(nname,"%s/output/lengths%d.dat",DPATH,tm);
lenptr=fopen(nname,"w");
for(int k=1;k<=nz;k++) {
for(int j=1;j<=ny;j++) {
for(int i=1;i<=nx;i++) {
int lpt = (i*ny2+j)*nz2+k;
int lptcc=lpt*lcc;
fprintf(lenptr,"%f\n",(latc->c[lptcc]+latc->c[lptcc+1]+latc->c[lptcc+2]-3));
}}}//end i,j,k
fclose(lenptr);


sprintf(nname,"%s/output/cdir%d.dat",DPATH,tm); polyptr=fopen(nname,"w");
int l,llb,llc,llf;
//int np;
float **dc;
float *diag2,*offdiag2;
int evmax;
dc = matrix(1,3,1,3);
diag2=vector(1,3);
offdiag2=vector(1,3);
//double xc,yc,zc;
//double wallvel[3]={0.0,0.0,0.0};
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      l=(i*ny2+j)*nz2+k;
      llb=l*lbd;llc=l*lcc;llf=l*lbq;
/*      if(((isgeom)&&(latw->w[l]<swall))) {
        if(isrotn==1) {
	  np=latw->partmark[l];
	  xc=latw->partloc[(np-1)*lcd+0];
	  yc=latw->partloc[(np-1)*lcd+1];
	  zc=latw->partloc[(np-1)*lcd+2];
	  //Not writing the actual velocity inside the particle
	  wallvel[0] = latw->bodyomega[(np-1)*lcd+1]*(k-zc) - latw->bodyomega[(np-1)*lcd+2]*(j-yc);
	  wallvel[1] = latw->bodyomega[(np-1)*lcd+2]*(i-xc) - latw->bodyomega[(np-1)*lcd+0]*(k-zc);
	  wallvel[2] = latw->bodyomega[(np-1)*lcd+0]*(j-yc) - latw->bodyomega[(np-1)*lcd+1]*(i-xc);
	  }
        fprintf(vptr,"%f %f %f %f\n",rho0,wallvel[0],wallvel[1],wallvel[2]);}
        else {
        fprintf(vptr,"%f %f %f %f\n",latv->rho[l],latv->u[l*lbd],latv->u[l*lbd+1],latv->u[l*lbd+2]);}
*/
      dc[1][1]=latc->c[llc];  dc[1][2]=latc->c[llc+3];dc[1][3]=latc->c[llc+4];
      dc[2][1]=latc->c[llc+3];dc[2][2]=latc->c[llc+1];dc[2][3]=latc->c[llc+5];
      dc[3][1]=latc->c[llc+4];dc[3][2]=latc->c[llc+5];dc[3][3]=latc->c[llc+2];
//printf("%d %f %f %f\n",l,dc[1][1],dc[1][2],dc[1][3]);
//printf("%d %f %f %f\n",l,dc[2][1],dc[2][2],dc[2][3]);
//printf("%d %f %f %f\n",l,dc[3][1],dc[3][2],dc[3][3]);
//printf("\n");
      //if(latw->w[l]==swall) {printf("%d %f %f %f\n",l,dc[1][1],dc[2][2],dc[1][2]);}
      if(~((isgeom)&&(latw->w[l]<swall))) {
      tred2(dc,lbd,diag2,offdiag2);
      tqli(diag2,offdiag2,lbd,dc);
      evmax=1;
      if(diag2[2]>diag2[evmax]) evmax=2;
      if(diag2[3]>diag2[evmax]) evmax=3;
      //printf("The eigenvalues are: %f,%f,%f,evmax=%d.\n",diag2[1],diag2[2],diag2[3],evmax);
					}
      if(fabs(diag2[evmax])<1e-10) {dc[1][evmax]=0;dc[2][evmax]=0;dc[3][evmax]=0;}
      if(diag2[evmax]<-100) {dc[1][evmax]=0;dc[2][evmax]=0;dc[3][evmax]=0;}
      fprintf(polyptr,"%f %f %f %f\n",dc[1][evmax],dc[2][evmax],dc[3][evmax],diag2[evmax]);
      //printf("%f.\n",diag2[evmax]);
//      printf("%f %f %f %f\n",dc[1][1],dc[2][1],dc[3][1],diag2[1]);
//      printf("%f %f %f %f\n",dc[1][2],dc[2][2],dc[3][2],diag2[2]);
//      printf("%f %f %f %f\n",dc[1][3],dc[2][3],dc[3][3],diag2[3]);
//printf("----------------------------\n");
} } }
fclose(polyptr);
}

fclose(vptr); //commented out isgeom, but would need this

}

/*Wedgegeometry*/
void printing_geometry(wedge *lat) {
FILE *wptr;
char nname[500];
sprintf(nname,"%s/wedge_geometry.dat",DPATH);
wptr=fopen(nname,"w");
int l;
for(int k=0;k<nz2;k++) {
  for(int j=0;j<ny2;j++) {
    for(int i=0;i<nx2;i++) {
      l=(i*ny2+j)*nz2+k;
      fprintf(wptr,"%d %d\n",lat->w[l],lat->partmark[l]);
} } }
fclose(wptr);
sprintf(nname,"%s/geometry.bin",DPATH);
wptr=fopen(nname,"w");
fwrite(lat->w,sizeof(int),nx2*ny2*nz2,wptr);
fclose(wptr);
}

/*Stress values for actcol analysis*/
void stressprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *vptr, *aptr, *pstr, *patr;
char nname[500];
sprintf(nname,"%s/output/visc%d.dat",DPATH,tm); vptr=fopen(nname,"w");
sprintf(nname,"%s/output/acti%d.dat",DPATH,tm); aptr=fopen(nname,"w");
sprintf(nname,"%s/output/pass%d.dat",DPATH,tm); pstr=fopen(nname,"w");
sprintf(nname,"%s/output/pasa%d.dat",DPATH,tm); patr=fopen(nname,"w");
int lps[26];/*These are for normal and mixed CDs*/
double wls[3]={0.5, 0.5, 0.5};
int *lpv=&lps[0];/*These will be used if nowedge*/
double *wlp=&wls[0];
int lpt,lptcq;
double delu[9],strain[6],vortic[3];
double as;
double mu=rho0*(taulb-0.5)/3;
double *u=&latv->u[0];
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      lpt = (i*ny2+j)*nz2+k;
      lptcq=lpt*lcq;
      derivativesN(i,j,k,&lps[0]);
      if(isgeom) {lpv=&latw->lpv[lpt*2*lbd];wlp=&latw->wlp[lpt*lbd];};
      derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);
      for (int m=0;m<lcq;m++) {
      fprintf(vptr,"%f ",2*mu*strain[m]);
      as=-zetalc*latc->q[lptcq+m];
      fprintf(aptr,"%f ",as);
      fprintf(pstr,"%f ",latc->estress[lptcq+m]-as);
      fprintf(patr,"%f ",latc->bstress[lpt*lcd*lcd+m]);
      }
      fprintf(vptr,"\n ");
      fprintf(aptr,"\n ");
      fprintf(pstr,"\n ");
      fprintf(patr,"\n ");
} } }
fclose(vptr);
fclose(aptr);
fclose(pstr);
fclose(patr);
}

/*Defects for actcol analysis*/
void defectsprinting(double *q, int tm) {
FILE *cptr;
char nname[500];
sprintf(nname,"%s/output/chag%d.dat",DPATH,tm); cptr=fopen(nname,"w");
int lpt;
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      lpt = (i*ny2+j)*nz2+k;
      fprintf(cptr,"%0.1f ", q[lpt]);
} } }
fclose(cptr);
}

/*Defects tracking printed*/
void defectstrackprinting(deflattice *lat,int tm) {
double rmp, rmn;
FILE *dptr;
char nname[500];
if(tm==tini) {
sprintf(nname,"%s/output/deftrack%d.dat",DPATH,tini); }
else {
sprintf(nname,"%s/output/deftrack%d.dat",DPATH,tm); }
dptr=fopen(nname,"w");
fprintf(dptr,"%d \n",tm);
for(int l=0;l<lat->ndefects;l++) {
  fprintf(dptr,"%d %f %f %f %d %d %d %f \n",lat->defect_tag[l],lat->defect_chg[l], lat->defect_xlc[l], lat->defect_ylc[l], lat->defect_liv[l], lat->defect_lif[l], lat->defect_nop[l], lat->defect_dis[l]);}
fclose(dptr);
if(tm!=tini) {
  sprintf(nname,"%s/output/defrate.dat",DPATH);
  dptr=fopen(nname,"w");
  fprintf(dptr,"%d \n",tm);
  for(int l=0;l<=tm-tini;l++) {
    rmp = lat->nrmsp[l]>0 ? 1.0*lat->drmsp[l]/lat->nrmsp[l]:0;
    rmn = lat->nrmsn[l]>0 ? 1.0*lat->drmsn[l]/lat->nrmsn[l]:0;
    fprintf(dptr,"%d %d %d %f %d %f %f %d %f \n",lat->deftm[l],lat->dalpha[l], lat->dbeta[l],lat->drmsp[l],lat->nrmsp[l],rmp,lat->drmsn[l],lat->nrmsn[l],rmn);} 
  fclose(dptr);}
return;
}

void alldefectstrackprinting(deflattice *lat,int tm) {
if(trackdef&&(tm-tini>timetrackmax)) return;
if(indtrack&&(tm-tini>indtimetrackmax)) return;
if(defcoords||indtrack) {
  FILE *dptr;
  char nname[500];
  sprintf(nname,"%s/output/defcoords.dat",DPATH);
  if(tm==tini) {dptr=fopen(nname,"w");}
  else {dptr=fopen(nname,"a+");}
  fprintf(dptr, "%d ",tm);
  for(int l=0;l<lat->ndefects; l++) {fprintf(dptr, "%f %f ",lat->defect_xanyt[l],lat->defect_yanyt[l]);}
  fprintf(dptr, "\n");
  fclose(dptr);
}
defectstrackprinting(lat,tm);
return;
}

/*Printing the forces*/
void bodyforceprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *tptr,*qptr;
char nname[500];
double tfor[3],tqor[3];
double rfor[3],srfor[3]={0.0,0.0,0.0};
double vfor[3],svfor[3]={0.0,0.0,0.0};
double afor[3],safor[3]={0.0,0.0,0.0};
double pfor[3],spfor[3]={0.0,0.0,0.0};
double qfor[3],sqfor[3]={0.0,0.0,0.0};
double rqor[3],srqor[3]={0.0,0.0,0.0};
double vqor[3],svqor[3]={0.0,0.0,0.0};
double aqor[3],saqor[3]={0.0,0.0,0.0};
double pqor[3],spqor[3]={0.0,0.0,0.0};
double qqor[3],sqqor[3]={0.0,0.0,0.0};
double cx=nx/2.+0.5;
double cy=ny/2.+0.5;
double cz=1.0;
double rad,unx,uny,unz;
int lpt;
sprintf(nname,"%s/output/bforce.dat",DPATH);
if(tm==tini+writ) {tptr=fopen(nname,"w");}
  else {tptr=fopen(nname,"a+");}
sprintf(nname,"%s/output/btorqe.dat",DPATH);
if(tm==tini+writ) {qptr=fopen(nname,"w");}
  else {qptr=fopen(nname,"a+");}
viscousstress(latv,latc,latw);
int jstart=1,jend=ny;
double mu=rho0*(taulb-0.5)/3;
double Rey, dra=0.0,tda=0.0;
if(isdragbody) {
jstart=2,jend=ny-1;
if(nz==1) { 
Rey=topwallvel[0]*(boxdim1)/(mu/rho0);
dra=2.0*M_PI*mu*topwallvel[0]*2.0/(log(7.4/Rey));
if(fbouncond==6) {
  Rey=(shearrate*boxdim1/2.0)*(boxdim1)/(mu/rho0);/*Redefining velocity scale as shearrate * particle rad*/
  dra=2.0*M_PI*mu*(shearrate*boxdim1/2.0)*2.0/(log(7.4/Rey));
  tda=-4*M_PI*mu*(0.5*shearrate)*(boxdim1/2.0)*(boxdim1/2.0);/*Pozrikidis, page 552 in google books - This is the torque required to rotate a cylinder with angular velocity omega, so presumably this should be the torque experienced by the cylinder in simple shear flow as the extensional part will not apply a torque*/
}
}/*Batchelor, page 246*/
else {dra=6*M_PI*mu*topwallvel[0]*boxdim1/2.0;}
}
if(isdragboun) {
jstart=1;jend=ny-1;/*ny-1 because, we want to do it only on one wall*/
dra=0.5*gx*(ny)*nx;/*nx-for total length fo the wall,multiply by 2 for up and down*/
}
for(int k=1;k<=nz;k++) {
  for(int j=jstart;j<=jend;j++) {
    for(int i=1;i<=nx;i++) {
      lpt = (i*ny2+j)*nz2+k;
      rad=sqrt((i-cx)*(i-cx)+(j-cy)*(j-cy)+(k-cz)*(k-cz));
      unx=(i-cx)/rad;uny=(j-cy)/rad;unz=(k-cz)/rad;
      if(isdragboun) {
        if(j==jstart) {unx=0.0;uny=1.0;unz=0.0;}
        if(j==jend) {unx=0.0;uny=-1.0;unz=0.0;}
      }
      if(latw->w[lpt]==0)/*Not taking area integration correctly, should be ok to simply comapare the forces*/
      {
      rfor[0]=-latc->presure[lpt]*unx;rfor[1]=-latc->presure[lpt]*uny;rfor[2]=-latc->presure[lpt]*unz;
      vfor[0]=latc->vstress[lpt*lcq+0]*unx+latc->vstress[lpt*lcq+3]*uny+latc->vstress[lpt*lcq+4]*unz;
      vfor[1]=latc->vstress[lpt*lcq+3]*unx+latc->vstress[lpt*lcq+1]*uny+latc->vstress[lpt*lcq+5]*unz;
      vfor[2]=latc->vstress[lpt*lcq+4]*unx+latc->vstress[lpt*lcq+5]*uny+latc->vstress[lpt*lcq+2]*unz;
      afor[0]=-zetalc*(latc->qnew[lpt*lcq+0]*unx+latc->qnew[lpt*lcq+3]*uny+latc->qnew[lpt*lcq+4]*unz);
      afor[1]=-zetalc*(latc->qnew[lpt*lcq+3]*unx+latc->qnew[lpt*lcq+1]*uny+latc->qnew[lpt*lcq+5]*unz);
      afor[2]=-zetalc*(latc->qnew[lpt*lcq+4]*unx+latc->qnew[lpt*lcq+5]*uny+latc->qnew[lpt*lcq+2]*unz);
      pfor[0]=latc->estress[lpt*lcq+0]*unx+latc->estress[lpt*lcq+3]*uny+latc->estress[lpt*lcq+4]*unz-afor[0]+latc->presure[lpt]*unx;
      pfor[1]=latc->estress[lpt*lcq+3]*unx+latc->estress[lpt*lcq+1]*uny+latc->estress[lpt*lcq+5]*unz-afor[1]+latc->presure[lpt]*uny;
      pfor[2]=latc->estress[lpt*lcq+4]*unx+latc->estress[lpt*lcq+5]*uny+latc->estress[lpt*lcq+2]*unz-afor[2]+latc->presure[lpt]*unz;
      qfor[0]=0;qfor[1]=0;qfor[2]=0;
      rqor[0] = (j-cy)*rfor[2] - (k-cz)*rfor[1]; rqor[1] = (k-cz)*rfor[0] - (i-cx)*rfor[2]; rqor[2] = (i-cx)*rfor[1] - (j-cy)*rfor[0];
      vqor[0] = (j-cy)*vfor[2] - (k-cz)*vfor[1]; vqor[1] = (k-cz)*vfor[0] - (i-cx)*vfor[2]; vqor[2] = (i-cx)*vfor[1] - (j-cy)*vfor[0];
      aqor[0] = (j-cy)*afor[2] - (k-cz)*afor[1]; aqor[1] = (k-cz)*afor[0] - (i-cx)*afor[2]; aqor[2] = (i-cx)*afor[1] - (j-cy)*afor[0];
      pqor[0] = (j-cy)*pfor[2] - (k-cz)*pfor[1]; pqor[1] = (k-cz)*pfor[0] - (i-cx)*pfor[2]; pqor[2] = (i-cx)*pfor[1] - (j-cy)*pfor[0];
      qqor[0] = (j-cy)*qfor[2] - (k-cz)*qfor[1]; qqor[1] = (k-cz)*qfor[0] - (i-cx)*qfor[2]; qqor[2] = (i-cx)*qfor[1] - (j-cy)*qfor[0];
      for(int m=0;m<lbd;m++) {
        srfor[m]+=rfor[m];svfor[m]+=vfor[m];safor[m]+=afor[m];spfor[m]+=pfor[m];sqfor[m]+=qfor[m];
        srqor[m]+=rqor[m];svqor[m]+=vqor[m];saqor[m]+=aqor[m];spqor[m]+=pqor[m];sqqor[m]+=qqor[m];
      }
      }
} } }
tfor[0]=srfor[0]+svfor[0]+safor[0]+spfor[0]+sqfor[0];
tfor[1]=srfor[1]+svfor[1]+safor[1]+spfor[1]+sqfor[1];
tfor[2]=srfor[2]+svfor[2]+safor[2]+spfor[2]+sqfor[2];
tqor[0]=srqor[0]+svqor[0]+saqor[0]+spqor[0]+sqqor[0];
tqor[1]=srqor[1]+svqor[1]+saqor[1]+spqor[1]+sqqor[1];
tqor[2]=srqor[2]+svqor[2]+saqor[2]+spqor[2]+sqqor[2];
if(nz>1) {
fprintf(tptr,"%d %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f\n",tm,srfor[0],srfor[1],srfor[2],svfor[0],svfor[1],svfor[2],safor[0],safor[1],safor[2],spfor[0],spfor[1],spfor[2],sqfor[0],sqfor[1],sqfor[2],tfor[0],tfor[1],tfor[2],latw->forceb[0],latw->forceb[1],latw->forceb[2],dra);
fprintf(qptr,"%d %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f\n",tm,srqor[0],srqor[1],srqor[2],svqor[0],svqor[1],svqor[2],saqor[0],saqor[1],saqor[2],spqor[0],spqor[1],spqor[2],sqqor[0],sqqor[1],sqqor[2],tqor[0],tqor[1],tqor[2],latw->torque[0],latw->torque[1],latw->torque[2],tda);
}
else {
fprintf(tptr,"%d pr=%f %f vs=%f %f ac=%f %f ps=%f %f qs=%f %f to=%f %f ld=%f %f dg=%f\n",tm,srfor[0],srfor[1],svfor[0],svfor[1],safor[0],safor[1],spfor[0],spfor[1],sqfor[0],sqfor[1],tfor[0],tfor[1],latw->forceb[0],latw->forceb[1],dra);
//printf("%d pr=%f %f vs=%f %f ac=%f %f ps=%f %f qs=%f %f to=%f %f ld=%f %f dg=%f\n",tm,srfor[0],srfor[1],svfor[0],svfor[1],safor[0],safor[1],spfor[0],spfor[1],sqfor[0],sqfor[1],tfor[0],tfor[1],latw->forceb[0],latw->forceb[1],dra);
fprintf(qptr,"%d %f %f %f %f %f %f %f \n",tm,srqor[2],svqor[2],saqor[2],spqor[2],sqqor[2],tqor[2],latw->torque[2]);
//printf("%d pr=%f vs=%f ac=%f ps=%f qs=%f to=%f ld=%f dr=%f\n",tm,srqor[2],svqor[2],saqor[2],spqor[2],sqqor[2],tqor[2],latw->torque[2],tda);
}
fclose(tptr);
fclose(qptr);
}

/*Printing the forces*/
void sepforceprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *tatr;
char nname[500];
sprintf(nname,"%s/output/tforce%d.dat",DPATH,tm); tatr=fopen(nname,"w");
int lps[26];/*These are for normal and mixed CDs*/
double wls[3]={0.5, 0.5, 0.5};
int *lpv=&lps[0];/*These will be used if nowedge*/
double *wlp=&wls[0];
int lpt, lpx,lmx,lpy,lmy,lpz,lmz;
double force[3],tfor[3]={0.0,0.0,0.0};
viscousstress(latv,latc,latw);
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      lpt = (i*ny2+j)*nz2+k;
      if(isgeom) {
        lpv=&latw->lpv[lpt*2*lbd];
        wlp=&latw->wlp[lpt*lbd]; }
      else {
        derivativesN(i,j,k,&lpv[0]); }
      lpx = lpv[0]*lcq;//(((i+1)*ny2+j  )*nz2+k  )*lcq;/*for derivatives*/
      lmx = lpv[1]*lcq;//(((i-1)*ny2+j  )*nz2+k  )*lcq;
      lpy = lpv[2]*lcq;//(( i   *ny2+j+1)*nz2+k  )*lcq;
      lmy = lpv[3]*lcq;//(( i   *ny2+j-1)*nz2+k  )*lcq;
      lpz = lpv[4]*lcq;//(( i   *ny2+j  )*nz2+k+1)*lcq;
      lmz = lpv[5]*lcq;//(( i   *ny2+j  )*nz2+k-1)*lcq;
      fprintf(tatr,"%d %d %d ",i,j,k);
      tfor[0]=0;tfor[1]=0.0;tfor[2]=0.0;
      if((isgeom)&&(latw->w[lpt]<lwall)) {
        fprintf(tatr,"%g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g\n",0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.);
        continue;
        }
      /*Pressure forces*/
      force[0]=-wlp[0]*(latc->presure[lpv[0]]-latc->presure[lpv[1]]);
      force[1]=-wlp[1]*(latc->presure[lpv[2]]-latc->presure[lpv[3]]);
      force[2]=-wlp[2]*(latc->presure[lpv[4]]-latc->presure[lpv[5]]);
      tfor[0]+=force[0];tfor[1]+=force[1];tfor[2]+=force[2];
      fprintf(tatr,"%g %g %g ",force[0],force[1],force[2]);
      /*Viscous forces*/
      force[0]=wlp[0]*(latv->vstress[lpx  ]-latv->vstress[lmx  ])+wlp[1]*(latv->vstress[lpy+3]-latv->vstress[lmy+3])+wlp[2]*(latv->vstress[lpz+4]-latv->vstress[lmz+4]);
      force[1]=wlp[0]*(latv->vstress[lpx+3]-latv->vstress[lmx+3])+wlp[1]*(latv->vstress[lpy+1]-latv->vstress[lmy+1])+wlp[2]*(latv->vstress[lpz+5]-latv->vstress[lmz+5]);
      force[2]=wlp[0]*(latv->vstress[lpx+4]-latv->vstress[lmx+4])+wlp[1]*(latv->vstress[lpy+5]-latv->vstress[lmy+5])+wlp[2]*(latv->vstress[lpz+2]-latv->vstress[lmz+2]);
      tfor[0]+=force[0];tfor[1]+=force[1];tfor[2]+=force[2];
      fprintf(tatr,"%g %g %g ",force[0],force[1],force[2]);
      /*Active forces*/
      force[0]=-zetalc*(wlp[0]*(latc->q[lpx  ]-latc->q[lmx  ])+wlp[1]*(latc->q[lpy+3]-latc->q[lmy+3])+wlp[2]*(latc->q[lpz+4]-latc->q[lmz+4]));
      force[1]=-zetalc*(wlp[0]*(latc->q[lpx+3]-latc->q[lmx+3])+wlp[1]*(latc->q[lpy+1]-latc->q[lmy+1])+wlp[2]*(latc->q[lpz+5]-latc->q[lmz+5]));
      force[2]=-zetalc*(wlp[0]*(latc->q[lpx+4]-latc->q[lmx+4])+wlp[1]*(latc->q[lpy+5]-latc->q[lmy+5])+wlp[2]*(latc->q[lpz+2]-latc->q[lmz+2]));
      tfor[0]+=force[0];tfor[1]+=force[1];tfor[2]+=force[2];
      fprintf(tatr,"%g %g %g ",force[0],force[1],force[2]);
      /*Forces from passive symmetric stresses*//*-*//*Active stresses reduced*/
      force[0]=(wlp[0]*((latc->estress[lpx  ]+latc->presure[lpv[0]])-(latc->estress[lmx  ]+latc->presure[lpv[1]]))
               +wlp[1]*((latc->estress[lpy+3]                      )-(latc->estress[lmy+3]                      ))
               +wlp[2]*((latc->estress[lpz+4]                      )-(latc->estress[lmz+4]                      )))-force[0];
      force[1]=(wlp[0]*((latc->estress[lpx+3]                      )-(latc->estress[lmx+3]                      ))
               +wlp[1]*((latc->estress[lpy+1]+latc->presure[lpv[2]])-(latc->estress[lmy+1]+latc->presure[lpv[3]]))
               +wlp[2]*((latc->estress[lpz+5]                      )-(latc->estress[lmz+5]                      )))-force[1];
      force[2]=(wlp[0]*((latc->estress[lpx+4]                      )-(latc->estress[lmx+4]                      ))
               +wlp[1]*((latc->estress[lpy+5]                      )-(latc->estress[lmy+5]                      ))
               +wlp[2]*((latc->estress[lpz+2]+latc->presure[lpv[4]])-(latc->estress[lmz+2]+latc->presure[lpv[5]])))-force[2];
      tfor[0]+=force[0];tfor[1]+=force[1];tfor[2]+=force[2];
      fprintf(tatr,"%g %g %g ",force[0],force[1],force[2]);
      /*Forces from passive asymmetric stresses*/
      lpx = lpv[0]*lcd*lcd;//(((i+1)*ny2+j  )*nz2+k  )*lcd*lcd;/*for derivatives*/
      lmx = lpv[1]*lcd*lcd;//(((i-1)*ny2+j  )*nz2+k  )*lcd*lcd;
      lpy = lpv[2]*lcd*lcd;//(( i   *ny2+j+1)*nz2+k  )*lcd*lcd;
      lmy = lpv[3]*lcd*lcd;//(( i   *ny2+j-1)*nz2+k  )*lcd*lcd;
      lpz = lpv[4]*lcd*lcd;//(( i   *ny2+j  )*nz2+k+1)*lcd*lcd;
      lmz = lpv[5]*lcd*lcd;//(( i   *ny2+j  )*nz2+k-1)*lcd*lcd;
      force[0]=wlp[0]*(latc->bstress[lpx  ]-latc->bstress[lmx  ])+wlp[1]*(latc->bstress[lpy+3]-latc->bstress[lmy+3])+wlp[2]*(latc->bstress[lpz+4]-latc->bstress[lmz+4]);
      force[1]=wlp[0]*(latc->bstress[lpx+6]-latc->bstress[lmx+6])+wlp[1]*(latc->bstress[lpy+1]-latc->bstress[lmy+1])+wlp[2]*(latc->bstress[lpz+5]-latc->bstress[lmz+5]);
      force[2]=wlp[0]*(latc->bstress[lpx+7]-latc->bstress[lmx+7])+wlp[1]*(latc->bstress[lpy+8]-latc->bstress[lmy+8])+wlp[2]*(latc->bstress[lpz+2]-latc->bstress[lmz+2]);
      tfor[0]+=force[0];tfor[1]+=force[1];tfor[2]+=force[2];
      fprintf(tatr,"%g %g %g %g %g %g\n",force[0],force[1],force[2],tfor[0],tfor[1],tfor[2]);
} } }
fclose(tatr);
}
/*0-11, 1-22, 2-33, 3-12, 4-13, 5-23, 6-21, 7-31, 8-32*/

void markerprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *pptr;
char nname[500];
sprintf(nname,"%s/output/marker.dat",DPATH);
if(tm==tini) {pptr=fopen(nname,"w");}
  else {pptr=fopen(nname,"a");}
fprintf(pptr,"%d ",tm);
for(int i=0;i<numofpart;i++) {fprintf(pptr," %f %f %f",latw->markers[i*lcd+0],latw->markers[i*lcd+1],latw->markers[i*lcd+2]);}
fprintf(pptr,"\n");
fclose(pptr);
}

void angvelprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *fptr;
char nname[500];
sprintf(nname,"%s/output/angvel.dat",DPATH);
if(tm==tini) {fptr=fopen(nname,"w");}
  else {fptr=fopen(nname,"a");}
fprintf(fptr,"%d ",tm);
for(int i=0;i<numofpart;i++) {fprintf(fptr," %f %f %f",latw->bodyomega[i*lcd+0],latw->bodyomega[i*lcd+1],latw->bodyomega[i*lcd+2]);}
fprintf(fptr,"\n");
fclose(fptr);
}

void angvelcorrprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *pptr;
char nname[500];
sprintf(nname,"%s/output/angvelcorr.dat",DPATH);
pptr=fopen(nname,"w");
int tml=(tm-tminforang)/tgapforang;
for(int i=0;i<tml;i++) {
fprintf(pptr,"%d ",i*tgapforang);
for(int j=0;j<numofpart;j++) {fprintf(pptr," %g ",latw->corrang[j*tmlmax+i]/latw->corrangrealzn[j*tmlmax+i]);}
fprintf(pptr," \n");
}
fclose(pptr);
}
