/*Defect dynamics variables and function declarations*/
typedef struct deflattice {
    int ndefects;/*Number of defects actually tracked*/
    int nd0;/*Number of defects started with*/
    double *mcharge;/*charge from Q*/
    int *dcharge;/*charge from director stored as integers*/
    int *defexist;/*Presence of defect*/
    int *defect_tag; /*1-Tag*/
    double *defect_chg; /*2-charge*/
    double *defect_xlc; /*3-xloc*/
    double *defect_ylc; /*4-yloc*/
    int *defect_liv; /*7-live or dead*/
    int *defect_lif; /*8-life time*/
    int *defect_nop; /*9-no of points*/
    double *defect_dis; /*10-distance travelled*/
    double *defect_xbirth; /*birth-xloc*/
    double *defect_ybirth; /*birth-yloc*/
    double *defect_xanyt; /*anytime-xloc*/
    double *defect_yanyt; /*anytime-yloc*/
    int *dalpha; /*No of defects created*/
    int *dbeta; /*No of defects destroyed*/
    int *nrmsp; /*Number of by +ve defects analyzed*/
    int *nrmsn; /*Number of by -ve defects analyzed*/
    double *drmsp; /*Distance travelled by +ve defects*/
    double *drmsn; /*Distance travelled by -ve defects*/
    int *deftm; /*Tracking time of defects*/
    int *dcharge3Dxy;
    int *dcharge3Dyz;
    int *dcharge3Dzx;
    int *dchargeint3Dxy2;
    int *dchargeint3Dyz2;
    int *dchargeint3Dzx2;
    int *dchargeint3Dxy;
    int *dchargeint3Dyz;
    int *dchargeint3Dzx;
    double *dchargeangle3Dxy;
    double *dchargeangle3Dyz;
    double *dchargeangle3Dzx;
    int *dcharge3D;
    int *dchargemono3D;
    int *highest_label;
    int *dcharge3Dstart;
    int *dcharge3Dend;
    int *dcharge3Dnext;
    double *characteristicangle;
    /*pointers to functions*/
} deflattice;

deflattice *inddefsetting(deflattice *);
deflattice *defsetting(lclattice *);
void getdefects(lblattice *, lclattice *, wedge *, deflattice *);
void trackdefects(deflattice *, int );
void indtrackdefects(deflattice *, int );
void qton(lclattice *, wedge *);
void detectdefectsinxy(lclattice *, wedge *);
double smallestangle(double ,double , double , double );
void defectdynamics(lblattice *, lclattice *, wedge *, deflattice *, int );
void defectoint(lclattice *, deflattice *);
int deftagging(deflattice *,int );
int inddeftagging(deflattice *,int );
int deftagfollow(deflattice *);
int detectdefectbound(int, int , int , int *, int , int *, int *, int *, int *);
int lpoint(int , int ,int );
void pbc(int *, int *);
void defectstrackprinting(deflattice *, int );
void alldefectstrackprinting(deflattice *, int );
void printing(lblattice *, lclattice *, wedge *, deflattice *, int );
void viscousstress(lblattice *, lclattice *, wedge *);
void (*hydrodynamics)(lblattice *, lclattice *, wedge *, int);
void dryhydrodynamics(lblattice *, lclattice *, wedge *, int);
void nohydrodynamics(lblattice *, lclattice *, wedge *, int);
void free_energy_printing(lblattice *, lclattice *, wedge *, int);
void readdirectory(lblattice *, lclattice *, wedge *);
void run3Ddefect_Zapotocky1(lclattice *, deflattice *);
void run3Ddefect_Zapotocky1xy(lclattice *, deflattice *, int, int, int);
void run3Ddefect_Zapotocky1yz(lclattice *, deflattice *, int, int, int);
void run3Ddefect_Zapotocky1zx(lclattice *, deflattice *, int, int, int);
double distance(double, double, double, double, double, double);
void run3Ddefect_Zapotocky2(lclattice *, deflattice *);
double run3Ddefect_Zapotockyintegerdefectxy(lclattice *, deflattice *, int, int, int);
double run3Ddefect_Zapotockyintegerdefectyz(lclattice *, deflattice *, int, int, int);
double run3Ddefect_Zapotockyintegerdefectzx(lclattice *, deflattice *, int, int, int);
void run3Ddefect(lclattice *, deflattice *);
void run3Ddefect_monopoles(lclattice *, deflattice *);
double smallestangle3D(double, double, double, double, double, double);
double Spherical_triangle_surface(lclattice *, int, int, int, int, int, int, int, int, int);
void defect3dprinting(deflattice *);
void defect3dprintinglines(deflattice *);
void findcharacteristicangle(lclattice *,deflattice *);
void crossproduct(lclattice *, int, int, int, int, double *);
