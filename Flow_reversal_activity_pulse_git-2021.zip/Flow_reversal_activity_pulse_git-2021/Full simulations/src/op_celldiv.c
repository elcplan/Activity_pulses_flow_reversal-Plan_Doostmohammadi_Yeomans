/*This file contains functions related to taking into consideration
 * celldivision, emmanuel's version*/

void celldivision_init(lclattice *latc){
latc->locxcelldiv=(int *)malloc(numcelldiv*sizeof(int));
latc->locycelldiv=(int *)malloc(numcelldiv*sizeof(int));
//latc->timecelldiv=(int *)malloc(numcelldiv*sizeof(int));
latc->statuscelldiv=(double *)malloc(numcelldiv*sizeof(double));
double *statcelld=&latc->statuscelldiv[0];

for (int icell=0;icell<numcelldiv;icell++){newloc_celldiv(latc,icell);statcelld[icell]=0.0;}
//printf("Initialising cell div OK. Trial cell at %d,%d\n",locxcelld[0],locycelld[0]);
return;
}

void celldivision(lclattice *latc, int tm){
//Declarations of variables
double *phi=&latc->phi[0];
double *pflux=&latc->phiflux[0];
int *locxcelld=&latc->locxcelldiv[0];
int *locycelld=&latc->locycelldiv[0];
//int *tcelld=&latc->timecelldiv[0];
double *statcelld=&latc->statuscelldiv[0];
double cellgrowthlim=durcelldiv*(PI*radcelldiv*radcelldiv*ratecelldiv);	
//growth of each cell (before transferring to another site)

for(int icell=0;icell<numcelldiv;icell++) {
int ipt=locxcelld[icell];
int jpt=locycelld[icell];
int lpt=(ipt*ny2+jpt)*nz2+1;
if (phi[lpt]<phicrit) {newloc_celldiv(latc,icell); statcelld[icell]=0.0;
printf("New cell(out)!\n");
}
if (statcelld[icell]>cellgrowthlim) {newloc_celldiv(latc,icell); statcelld[icell]=0.0;
printf("New cell(div)!\n");
}
//printf("Growing cell at %d,%d. phi=%f\n",ipt,jpt,phi[lpt]);

//grow cells
        for(int ii=-radcelldiv;ii<=radcelldiv*2;ii++) {
	for(int jj=-radcelldiv;jj<=radcelldiv*2;jj++) {
	int idiv=ipt+ii; int jdiv=jpt+jj;
	if (ii*ii+jj*jj<=radcelldiv*radcelldiv){
		int ll=(idiv*ny2+jdiv)*nz2+1;
	if(phi[ll]>0.0){
        	pflux[ll]+=ratecelldiv*phi[ll];
		statcelld[icell]+=ratecelldiv*phi[ll];
		//active stress in the area
		double *qloc=&latc->q[ll*lcq];
		int lsy=ll*lcd*2;
		latc->estress[lsy]+=-zetalc*qloc[0]*phi[ll];
		latc->estress[lsy+1]+=-zetalc*qloc[1]*phi[ll];
		latc->estress[lsy+2]+=-zetalc*qloc[2]*phi[ll];
		latc->estress[lsy+3]+=-zetalc*qloc[3]*phi[ll];
		latc->estress[lsy+4]+=-zetalc*qloc[4]*phi[ll];
		latc->estress[lsy+5]+=-zetalc*qloc[5]*phi[ll];

	int las=ll*lcd*lcd;
	latc->actstress[las]=-zetalc*qloc[0]*phi[ll];
	latc->actstress[las+1]=-zetalc*qloc[1]*phi[ll];
	latc->actstress[las+2]=-zetalc*qloc[2]*phi[ll];
	latc->actstress[las+3]=-zetalc*qloc[3]*phi[ll];
	latc->actstress[las+4]=-zetalc*qloc[4]*phi[ll];
	latc->actstress[las+5]=-zetalc*qloc[5]*phi[ll];
	latc->actstress[las+6]=-zetalc*qloc[3]*phi[ll];
	latc->actstress[las+7]=-zetalc*qloc[4]*phi[ll];
	latc->actstress[las+8]=-zetalc*qloc[5]*phi[ll];
	}
	}//end if
	}}//end jk
//printf("Tm=%d.Statcelld[%d]=%f.\n",tm,icell,statcelld[icell]);
} //end for

return;
}

void newloc_celldiv(lclattice *latc, int icell){
double *phi=&latc->phi[0];
int *locxcelld=&latc->locxcelldiv[0];
int *locycelld=&latc->locycelldiv[0];
int ii,jj;
int x=0, count=0;

while(x==0){
ii=(int)(nx*ran2(&seed));
jj=(int)(ny*ran2(&seed));
int l=(ii*ny2+jj)*nz2+1;
if(phi[l]>phicrit) {x=1; 
//printf("Count(%d) is %d. ",icell,count); 
printf("Dividing cell at %d,%d. phi[l] is %f.\n",ii,jj,phi[l]);
}
if(count==nx*ny) x=1;
count+=1;
}
locxcelld[icell]=ii;
locycelld[icell]=jj;

return;
}


