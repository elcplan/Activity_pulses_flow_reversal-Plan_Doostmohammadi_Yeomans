/*Stress values for actcol analysis*/
void stresssplitprinting(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *iptr, *lptr, *vptr;
char nname[500];
sprintf(nname,"%s/output/isopas%d.dat",DPATH,tm); iptr=fopen(nname,"w");
sprintf(nname,"%s/output/lampas%d.dat",DPATH,tm); lptr=fopen(nname,"w");
sprintf(nname,"%s/output/varpas%d.dat",DPATH,tm); vptr=fopen(nname,"w");
int lps[26];/*These are for normal and mixed CDs*/
double wls[3]={0.5, 0.5, 0.5};
int *lpv=&lps[0];/*These will be used if nowedge*/
double *wlp=&wls[0];
double *q=&latc->q[0];
int lpt,lptcq;
double delu[9],strain[6],vortic[3];
double dqx[6],dqy[6],dqz[6];/*derivatives of q locally*/
double isosts[2],lamsts[6],varsts[6];
double *u=&latv->u[0];
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      lpt = (i*ny2+j)*nz2+k;
      lptcq=lpt*lcq;
      derivativesN(i,j,k,&lps[0]);
      derivativesQ(q,&dqx[0],&dqy[0],&dqz[0],&lps[0]);
      if(isgeom) {lpv=&latw->lpv[lpt*2*lbd];wlp=&latw->wlp[lpt*lbd];};
      derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);
      liqcstressessplit(latc,lpt,latv->rho[lpt],&dqx[0],&dqy[0],&dqz[0],&isosts[0],&lamsts[0],&varsts[0],&lps[0]);
      fprintf(iptr,"%f %f\n",isosts[0],isosts[1]);
      for (int m=0;m<lcq;m++) {
      fprintf(lptr,"%f ",lamsts[m]);
      fprintf(vptr,"%f ",varsts[m]);
      }
      fprintf(lptr,"\n ");
      fprintf(vptr,"\n ");
} } }
fclose(iptr);
fclose(lptr);
fclose(vptr);
}

/*Calculating all the liquid crystal stresses*/
void liqcstressessplit(lclattice *lat, int l,double rho, double *dqx, double *dqy, double *dqz, double *isosts, double *lamsts, double *varsts, int *lps) {
double *q=&(lat->q[l*lcq]);
double *h=&(lat->H[l*lcq]);
int lpx=lps[0],lmx=lps[1],lpy=lps[2],lmy=lps[3],lpz=lps[4],lmz=lps[5];
int llc=l*lcq, lpxq=lpx*lcq, lmxq=lmx*lcq, lpyq=lpy*lcq, lmyq=lmy*lcq, lpzq=lpz*lcq, lmzq=lmz*lcq;
double traceq2=q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+2*(q[3]*q[3]+q[4]*q[4]+q[5]*q[5]);
double bulk[6],H[6];
double lap;
bulk[0]=-Alc*q[0]-Blc*(q[0]*q[0]+q[3]*q[3]+q[4]*q[4]-traceq2/3.0)-Clc*q[0]*traceq2;
bulk[1]=-Alc*q[1]-Blc*(q[3]*q[3]+q[1]*q[1]+q[5]*q[5]-traceq2/3.0)-Clc*q[1]*traceq2;
bulk[2]=-Alc*q[2]-Blc*(q[4]*q[4]+q[5]*q[5]+q[2]*q[2]-traceq2/3.0)-Clc*q[2]*traceq2;
bulk[3]=-Alc*q[3]-Blc*(q[0]*q[3]+q[3]*q[1]+q[4]*q[5])-Clc*q[3]*traceq2;
bulk[4]=-Alc*q[4]-Blc*(q[0]*q[4]+q[3]*q[5]+q[4]*q[2])-Clc*q[4]*traceq2;
bulk[5]=-Alc*q[5]-Blc*(q[3]*q[4]+q[1]*q[5]+q[5]*q[2])-Clc*q[5]*traceq2;
for(int m=0; m<lcq; m++) {
  lap=q[lpxq+m]+q[lmxq+m]+q[lpyq+m]+q[lmyq+m]+q[lpzq+m]+q[lmzq+m]-6.0*q[llc+m];
    H[m]=bulk[m]+Klc*lap;}
double qh=q[0]*h[0]+q[1]*h[1]+q[2]*h[2]+2.0*(q[3]*h[3]+q[4]*h[4]+q[5]*h[5]);
double diff2=dqx[0]*dqx[0]+dqy[0]*dqy[0]+dqz[0]*dqz[0]+dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]+dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]
      +dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]+dqx[1]*dqx[1]+dqy[1]*dqy[1]+dqz[1]*dqz[1]+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]
            +dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]+dqx[2]*dqx[2]+dqy[2]*dqy[2]+dqz[2]*dqz[2];
isosts[0]=P0*rho;
isosts[1]=-0.5*Klc*diff2;
/*Symmetric part of the stress*/
double xi=xilc;
lamsts[0]=2*xi*(q[0]+1./3.)*qh-xi*(h[0]*(q[0]+1./3.)+h[3]*q[3]+h[4]*q[4]+(q[0]+1./3.)*h[0]+q[3]*h[3]+q[4]*h[4]);
lamsts[1]=2*xi*(q[1]+1./3.)*qh-xi*(h[3]*q[3]+h[1]*(q[1]+1./3.)+h[5]*q[5]+q[3]*h[3]+(q[1]+1./3.)*h[1]+q[5]*h[5]);
lamsts[2]=2*xi*(q[2]+1./3.)*qh-xi*(h[4]*q[4]+h[5]*q[5]+h[2]*(q[2]+1./3.)+q[4]*h[4]+q[5]*h[5]+(q[2]+1./3.)*h[2]);
lamsts[3]=2*xi*q[3]*qh        -xi*(h[0]*q[3]+h[3]*(q[1]+1./3.)+h[4]*q[5]+(q[0]+1./3.)*h[3]+q[3]*h[1]+q[4]*h[5]);
lamsts[4]=2*xi*q[4]*qh        -xi*(h[0]*q[4]+h[3]*q[5]+h[4]*(q[2]+1./3.)+(q[0]+1./3.)*h[4]+q[3]*h[5]+q[4]*h[2]);
lamsts[5]=2*xi*q[5]*qh        -xi*(h[3]*q[4]+h[1]*q[5]+h[5]*(q[2]+1./3.)+q[3]*h[4]+(q[1]+1./3.)*h[5]+q[5]*h[2]);
varsts[0]=-Klc*(dqx[0]*dqx[0]+dqx[1]*dqx[1]+dqx[2]*dqx[2]+2*(dqx[3]*dqx[3]+dqx[4]*dqx[4]+dqx[5]*dqx[5]));
varsts[1]=-Klc*(dqy[0]*dqy[0]+dqy[1]*dqy[1]+dqy[2]*dqy[2]+2*(dqy[3]*dqy[3]+dqy[4]*dqy[4]+dqy[5]*dqy[5]));
varsts[2]=-Klc*(dqz[0]*dqz[0]+dqz[1]*dqz[1]+dqz[2]*dqz[2]+2*(dqz[3]*dqz[3]+dqz[4]*dqz[4]+dqz[5]*dqz[5]));
varsts[3]=-Klc*(dqx[0]*dqy[0]+dqx[1]*dqy[1]+dqx[2]*dqy[2]+2*(dqx[3]*dqy[3]+dqx[4]*dqy[4]+dqx[5]*dqy[5]));
varsts[4]=-Klc*(dqx[0]*dqz[0]+dqx[1]*dqz[1]+dqx[2]*dqz[2]+2*(dqx[3]*dqz[3]+dqx[4]*dqz[4]+dqx[5]*dqz[5]));
varsts[5]=-Klc*(dqy[0]*dqz[0]+dqy[1]*dqz[1]+dqy[2]*dqz[2]+2*(dqy[3]*dqz[3]+dqy[4]*dqz[4]+dqy[5]*dqz[5]));
return;
}
