void stressgrad(lblattice *latv,  lclattice *latc, wedge *latw, int tm){
//Declarations of variables
double *phi=&latc->phi[0];
double *u=&latv->u[0];
int lps[26];

FILE *aacptr, *d_00ptr, *d_01ptr, *d_02ptr, *d_03ptr, *d_04ptr, *d_05ptr;
FILE *ener_00ptr, *ener_01ptr, *ener_02ptr, *ener_03ptr, *ener_04ptr, *ener_05ptr;
FILE *tseries_ptr, *ts_in_ptr, *ts_boun_ptr, *ts_out_ptr;
char nname[500];
sprintf(nname,"%s/output/aac%d.dat",DPATH,tm);
aacptr=fopen(nname,"w");
sprintf(nname,"%s/output/d_00.dat",DPATH);
d_00ptr=fopen(nname,"a");
sprintf(nname,"%s/output/d_01.dat",DPATH);
d_01ptr=fopen(nname,"a");
sprintf(nname,"%s/output/d_02.dat",DPATH);
d_02ptr=fopen(nname,"a");
sprintf(nname,"%s/output/d_03.dat",DPATH);
d_03ptr=fopen(nname,"a");
sprintf(nname,"%s/output/d_04.dat",DPATH);
d_04ptr=fopen(nname,"a");
sprintf(nname,"%s/output/d_05.dat",DPATH);
d_05ptr=fopen(nname,"a");
sprintf(nname,"%s/output/ener_00.dat",DPATH);
ener_00ptr=fopen(nname,"a");
sprintf(nname,"%s/output/ener_01.dat",DPATH);
ener_01ptr=fopen(nname,"a");
sprintf(nname,"%s/output/ener_02.dat",DPATH);
ener_02ptr=fopen(nname,"a");
sprintf(nname,"%s/output/ener_03.dat",DPATH);
ener_03ptr=fopen(nname,"a");
sprintf(nname,"%s/output/ener_04.dat",DPATH);
ener_04ptr=fopen(nname,"a");
sprintf(nname,"%s/output/ener_05.dat",DPATH);
ener_05ptr=fopen(nname,"a");
sprintf(nname,"%s/output/tseries.dat",DPATH);
tseries_ptr=fopen(nname,"a");
sprintf(nname,"%s/output/tseries_in.dat",DPATH);
ts_in_ptr=fopen(nname,"a");
sprintf(nname,"%s/output/tseries_boun.dat",DPATH);
ts_boun_ptr=fopen(nname,"a");
sprintf(nname,"%s/output/tseries_out.dat",DPATH);
ts_out_ptr=fopen(nname,"a");

//Extension to boundary
(*latc->bc_func)(latv,latc,latw,&latc->actstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->capstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->elasstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->viscstress[0],lcd*lcd);
//pbc_on_vars(latv,latc,latw,&latc->actstress[0],lcd*lcd); //emmanuel:working
double *totst= (double *)malloc(nx2*ny2*nz2*sizeof(double)*lcd);
double *tot= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *ast= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *cst= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *est= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *vst= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *total= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *pst, *Deb;
pst= (double *)malloc(nx2*ny2*nz2*sizeof(double));
Deb= (double *)malloc(nx2*ny2*nz2*sizeof(double));
if(iswithpoly){
(*latc->bc_func)(latv,latc,latw,&latc->polystress[0],lcd*lcd);
}

int dmin2,dist2;
int imin, jmin, kmin;
double maxd=sqrt(nx*nx+ny*ny);
int Nbin=(int)maxd+1;
double gap=1;//maxd/(double)Nbin;
float *bin_dist,*bin_a,*bin_c,*bin_e,*bin_v,*bin_p,*bin_tot,*bin_total;
float *bin_ener_a,*bin_ener_c,*bin_ener_e,*bin_ener_v,*bin_ener_p, *bin_ener;
float *bin_phi, *bin_Deb;
bin_dist=vector(1,Nbin);
bin_a=vector(1,Nbin);bin_c=vector(1,Nbin);bin_e=vector(1,Nbin);bin_v=vector(1,Nbin);bin_p=vector(1,Nbin);
bin_ener_a=vector(1,Nbin);bin_ener_c=vector(1,Nbin);bin_ener_e=vector(1,Nbin);bin_ener_v=vector(1,Nbin);bin_ener_p=vector(1,Nbin);
bin_ener=vector(1,Nbin);bin_phi=vector(1,Nbin);bin_Deb=vector(1,Nbin);bin_tot=vector(1,Nbin);bin_total=vector(1,Nbin);
for(int i=0;i<Nbin;i++){
bin_a[i]=0.0;bin_c[i]=0.0;bin_e[i]=0.0;bin_v[i]=0.0;bin_p[i]=0.0;
bin_dist[i]=0.0;bin_phi[i]=0.0;bin_Deb[i]=0.0;bin_tot[i]=0.0;bin_total[i]=0.0;
bin_ener_a[i]=0.0;bin_ener_c[i]=0.0;bin_ener_e[i]=0.0;bin_ener_v[i]=0.0;bin_ener_p[i]=0.0;bin_ener[i]=0.0;
};
int ibin;
double ast_ener, cst_ener, est_ener, vst_ener, pst_ener=0.0;
double ener=0.0, enertot=0.0,vrms=0.0;
double Deb_ave_in=0.0, Deb_ave_boun=0.0, Deb_ave_out=0.0;
double len_ave_in=0.0, len_ave_boun=0.0, len_ave_out=0.0;
double phi_ave_in=0.0, phi_ave_boun=0.0, phi_ave_out=0.0;
double ener_in=0.0, ener_boun=0.0, ener_out=0.0;
double n_in=0, n_boun=0, n_out=0;
double phi_in=1.00, phi_out=0.0;
double force_a_in=0.0,force_c_in=0.0,force_e_in=0.0,force_v_in=0.0,force_p_in=0.0;
double force_a_out=0.0,force_c_out=0.0,force_e_out=0.0,force_v_out=0.0,force_p_out=0.0;
double force_a_boun=0.0,force_c_boun=0.0,force_e_boun=0.0,force_v_boun=0.0,force_p_boun=0.0;
double ener_a_in=0.0,ener_c_in=0.0,ener_e_in=0.0,ener_v_in=0.0,ener_p_in=0.0;
double ener_a_out=0.0,ener_c_out=0.0,ener_e_out=0.0,ener_v_out=0.0,ener_p_out=0.0;
double ener_a_boun=0.0,ener_c_boun=0.0,ener_e_boun=0.0,ener_v_boun=0.0,ener_p_boun=0.0;
double force_total_in=0.0,force_total_out=0.0,force_total_boun=0.0;
double force_tot_in=0.0,force_tot_out=0.0,force_tot_boun=0.0;
double adv_u_temp=0.0,adv_u_tot=0.0,adv_u_in=0.0,adv_u_out=0.0,adv_u_boun=0.0;

double peri=0.0;
//if (shape==0) peri=perimeter_flat(latc,tm);
//if (shape==1) peri=perimeter_drop(latc,tm);
printf("WARNING: PERIMETER FUNCTION IS TURNED OFF.\n");
//does not work for phase sep because all phi not below critical phi.
//printf("The perimeter is %f.\n",peri);


//principal stresses as function of distance
float *bin_prinstress_a, *bin_prinstress_c, *bin_prinstress_e, *bin_prinstress_v, *bin_prinstress_p;
bin_prinstress_a=vector(1,Nbin); bin_prinstress_c=vector(1,Nbin); bin_prinstress_e=vector(1,Nbin); bin_prinstress_v=vector(1,Nbin); bin_prinstress_p=vector(1,Nbin);
for(int i=0;i<Nbin;i++){
bin_prinstress_a[i]=0.0;bin_prinstress_c[i]=0.0;bin_prinstress_e[i]=0.0;bin_prinstress_v[i]=0.0;bin_prinstress_p[i]=0.0;};
float **temp_mat, *temp_diag,*temp_offdiag;
float **tot_mat;
temp_mat = matrix(1,3,1,3);
tot_mat = matrix(1,3,1,3);
temp_diag=vector(1,3);
temp_offdiag=vector(1,3);
int temp_evmax;

//printf("here101.\n");
double uxave[3]={0.0,0.0,0.0};
double totave[3]={0.0,0.0,0.0};

//Getting the divergence for each point
for(int ipt=1;ipt<=nx;ipt++) {
for(int jpt=1;jpt<=ny;jpt++) {
for(int kpt=1;kpt<=nz;kpt++) {
//printf("%d,%d\n",ipt,jpt);
	int lpt = (ipt*ny2+jpt)*nz2+kpt;
	//int las = lpt*lcd*lcd;
	derivativesN(ipt,jpt,kpt,&lps[0]);
	double uloc[3];
	uloc[0]=u[lpt*lbd];
	uloc[1]=u[lpt*lbd+1];
	uloc[2]=u[lpt*lbd+2];
	ener=0.5*(uloc[0]*uloc[0]+uloc[1]*uloc[1]+uloc[2]*uloc[2]);
	enertot+=ener;
	vrms+=sqrt(2*ener);
	double length=0.0;
	if(iswithpoly){
	double *c=&latc->c[0];
	length=c[lpt*lcc]+c[lpt*lcc+1]+c[lpt*lcc+2];
	}

//Getting Deborah (need strain tensor only)
	double delu[9],strain[6],vortic[3];
	double wls[3]={0.5, 0.5, 0.5};
	int *lpv=&lps[0];
	double *wlp=&wls[0];
	derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);
	double DddD=strain[0]*strain[0]+strain[1]*strain[1]+strain[2]*strain[2]
		+2*(strain[3]*strain[3]+strain[4]*strain[4]+strain[5]*strain[5]);
	if(iswithpoly) Deb[lpt]=tau_poly*sqrt(0.5*DddD);
	double advterm[3];
	advterm[0]=uloc[0]*delu[0]+uloc[1]*delu[3]+uloc[2]*delu[4];
	advterm[1]=uloc[0]*delu[6]+uloc[1]*delu[1]+uloc[2]*delu[5];
	advterm[2]=uloc[0]*delu[7]+uloc[1]*delu[8]+uloc[2]*delu[2];
	adv_u_temp=uloc[0]*advterm[0]+uloc[1]*advterm[1]+uloc[2]*advterm[2];

//Getting magnitudes
	for(int ii=0;ii<26;ii++){lps[ii]=lps[ii]*lcd*lcd;}
	double div[3];
	double divtemp[3];


//activity
	div[0]=0.5*(latc->actstress[lps[0]]-latc->actstress[lps[1]]
		+latc->actstress[lps[2]+3]-latc->actstress[lps[3]+3]
		+latc->actstress[lps[4]+4]-latc->actstress[lps[5]+4]);
	div[1]=0.5*(latc->actstress[lps[0]+3]-latc->actstress[lps[1]+3]
		+latc->actstress[lps[2]+1]-latc->actstress[lps[3]+1]
		+latc->actstress[lps[4]+5]-latc->actstress[lps[5]+5]);
	div[2]=0.5*(latc->actstress[lps[0]+4]-latc->actstress[lps[1]+4]
		+latc->actstress[lps[2]+5]-latc->actstress[lps[3]+5]
		+latc->actstress[lps[4]+2]-latc->actstress[lps[5]+2]);
//if((jpt<18)&&(jpt>12)&&(ipt<9)&&(ipt>1)&&(tm>tini+0)&&(tm<tini+5000)){printf("At %d,%d, actstress is %f,%f,%f\n",ipt,jpt,div[0],div[1],div[2]);}
	ast[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
	total[lpt]=ast[lpt];
	totst[lpt]=div[0];
	totst[lpt+1]=div[1];
	totst[lpt+2]=div[2];
	ast_ener=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
//printf("act=%f:%f,%f,%f\n",ast[lpt],div[1],div[2],div[3]);

//capillary
	div[0]=0.5*(latc->capstress[lps[0]]-latc->capstress[lps[1]]
		+latc->capstress[lps[2]+3]-latc->capstress[lps[3]+3]
		+latc->capstress[lps[4]+4]-latc->capstress[lps[5]+4]);
	div[1]=0.5*(latc->capstress[lps[0]+3]-latc->capstress[lps[1]+3]
		+latc->capstress[lps[2]+1]-latc->capstress[lps[3]+1]
		+latc->capstress[lps[4]+5]-latc->capstress[lps[5]+5]);
	div[2]=0.5*(latc->capstress[lps[0]+4]-latc->capstress[lps[1]+4]
		+latc->capstress[lps[2]+5]-latc->capstress[lps[3]+5]
		+latc->capstress[lps[4]+2]-latc->capstress[lps[5]+2]);
//if((jpt<18)&&(jpt>12)&&(ipt<9)&&(ipt>1)&&(tm>tini+0)&&(tm<tini+5000)){printf("At %d,%d, .....capstress is %f,%f,%f\n",ipt,jpt,div[0],div[1],div[2]);}
	cst[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
	total[lpt]+=cst[lpt];
	totst[lpt]+=div[0];
	totst[lpt+1]+=div[1];
	totst[lpt+2]+=div[2];
	cst_ener=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
	divtemp[0]=div[0];
	divtemp[1]=div[1];
	divtemp[2]=div[2];
//printf("cap=%f:%f,%f,%f\n",cst[lpt],div[1],div[2],div[3]);

//elastic
	div[0]=0.5*(latc->elasstress[lps[0]]-latc->elasstress[lps[1]]
		+latc->elasstress[lps[2]+3]-latc->elasstress[lps[3]+3]
		+latc->elasstress[lps[4]+4]-latc->elasstress[lps[5]+4]);
	div[1]=0.5*(latc->elasstress[lps[0]+3]-latc->elasstress[lps[1]+3]
		+latc->elasstress[lps[2]+1]-latc->elasstress[lps[3]+1]
		+latc->elasstress[lps[4]+5]-latc->elasstress[lps[5]+5]);
	div[2]=0.5*(latc->elasstress[lps[0]+4]-latc->elasstress[lps[1]+4]
		+latc->elasstress[lps[2]+5]-latc->elasstress[lps[3]+5]
		+latc->elasstress[lps[4]+2]-latc->elasstress[lps[5]+2]);
	divtemp[0]+=div[0];
	divtemp[1]+=div[1];
	divtemp[2]+=div[2];
//if((jpt<18)&&(jpt>12)&&(ipt<9)&&(ipt>1)&&(tm>tini+0)&&(tm<tini+5000)){printf("At %d,%d, ...........elasstress is %f,%f,%f\n",ipt,jpt,div[0],div[1],div[2]);}
	est[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
//	est[lpt]=sqrt(divtemp[0]*divtemp[0]+divtemp[1]*divtemp[1]+divtemp[2]*divtemp[2]);
	total[lpt]+=est[lpt];
	totst[lpt]+=div[0];
	totst[lpt+1]+=div[1];
	totst[lpt+2]+=div[2];
	est_ener=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
//printf("elas=%f:%f,%f,%f\n",est[lpt],div[1],div[2],div[3]);

//viscous
	div[0]=0.5*(latc->viscstress[lps[0]]-latc->viscstress[lps[1]]
		+latc->viscstress[lps[2]+3]-latc->viscstress[lps[3]+3]
		+latc->viscstress[lps[4]+4]-latc->viscstress[lps[5]+4]);
	div[1]=0.5*(latc->viscstress[lps[0]+3]-latc->viscstress[lps[1]+3]
		+latc->viscstress[lps[2]+1]-latc->viscstress[lps[3]+1]
		+latc->viscstress[lps[4]+5]-latc->viscstress[lps[5]+5]);
	div[2]=0.5*(latc->viscstress[lps[0]+4]-latc->viscstress[lps[1]+4]
		+latc->viscstress[lps[2]+5]-latc->viscstress[lps[3]+5]
		+latc->viscstress[lps[4]+2]-latc->viscstress[lps[5]+2]);
	vst[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
	divtemp[0]=div[0];
	divtemp[1]=div[1];
	divtemp[2]=div[2];
//if((jpt<18)&&(jpt>12)&&(ipt<9)&&(ipt>1)&&(tm>tini+0)&&(tm<tini+5000)){printf("At %d,%d, ................viscstress is %f,%f,%f\n",ipt,jpt,div[0],div[1],div[2]);}
	total[lpt]+=vst[lpt];
	totst[lpt]+=div[0];
	totst[lpt+1]+=div[1];
	totst[lpt+2]+=div[2];
	vst_ener=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
//printf("visc=%f:%f,%f,%f\n",vst[lpt],div[1],div[2],div[3]);

//polymer
if(iswithpoly){
	div[0]=0.5*(latc->polystress[lps[0]]-latc->polystress[lps[1]]
		+latc->polystress[lps[2]+3]-latc->polystress[lps[3]+3]
		+latc->polystress[lps[4]+4]-latc->polystress[lps[5]+4]);
	div[1]=0.5*(latc->polystress[lps[0]+3]-latc->polystress[lps[1]+3]
		+latc->polystress[lps[2]+1]-latc->polystress[lps[3]+1]
		+latc->polystress[lps[4]+5]-latc->polystress[lps[5]+5]);
	div[2]=0.5*(latc->polystress[lps[0]+4]-latc->polystress[lps[1]+4]
		+latc->polystress[lps[2]+5]-latc->polystress[lps[3]+5]
		+latc->polystress[lps[4]+2]-latc->polystress[lps[5]+2]);
	divtemp[0]+=div[0];
	divtemp[1]+=div[1];
	divtemp[2]+=div[2];
if((jpt<18)&&(jpt>14)&&(ipt<10)&&(ipt>0)&&(tm>tini+0)&&(tm<tini+2000)){
	//printf("At %d,%d, ...................polystress is %f,%f,%f\n",ipt,jpt,div[0],div[1],div[2]);
	uxave[0]+=div[0];
	uxave[1]+=div[1];
	uxave[2]+=div[2];
	if(ipt==9) printf("Time %d:..........polystress is %f,%f,%f\n",tm,div[0],div[1],div[2]);
}
	pst[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
//	pst[lpt]=sqrt(divtemp[0]*divtemp[0]+divtemp[1]*divtemp[1]+divtemp[2]*divtemp[2]);
	total[lpt]+=pst[lpt];
	totst[lpt]+=div[0];
	totst[lpt+1]+=div[1];
	totst[lpt+2]+=div[2];
if((jpt<18)&&(jpt>14)&&(ipt<10)&&(ipt>0)&&(tm>tini+0)&&(tm<tini+2000)){
	totave[0]+=totst[lpt];
	totave[1]+=totst[lpt+1];
	totave[2]+=totst[lpt+2];
	if(ipt==9) printf("Totstress is %f,%f,%f\n",totave[0],totave[1],totave[2]);
}
	pst_ener=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
//printf("poly=%f:%f,%f,%f\n",pst[lpt],div[1],div[2],div[3]);
}

	div[0]=0.5*(latc->estress[lps[0]]-latc->estress[lps[1]]
		+latc->estress[lps[2]+3]-latc->estress[lps[3]+3]
		+latc->estress[lps[4]+4]-latc->estress[lps[5]+4]);
	div[1]=0.5*(latc->estress[lps[0]+3]-latc->estress[lps[1]+3]
		+latc->estress[lps[2]+1]-latc->estress[lps[3]+1]
		+latc->estress[lps[4]+5]-latc->estress[lps[5]+5]);
	div[2]=0.5*(latc->estress[lps[0]+4]-latc->estress[lps[1]+4]
		+latc->estress[lps[2]+5]-latc->estress[lps[3]+5]
		+latc->estress[lps[4]+2]-latc->estress[lps[5]+2]);
	divtemp[0]+=div[0];
	divtemp[1]+=div[1];
	divtemp[2]+=div[2];
//if((jpt<18)&&(jpt>12)&&(ipt<9)&&(ipt>1)&&(tm>tini+0)&&(tm<tini+5000)){printf("At %d,%d, ...................estress is %f,%f,%f\n",ipt,jpt,div[0],div[1],div[2]);}

tot[lpt]=sqrt(totst[lpt]*totst[lpt]+totst[lpt+1]*totst[lpt+1]+totst[lpt+2]*totst[lpt+2]);
adv_u_tot+=adv_u_temp;
	tot[lpt]=sqrt(uloc[0]*totst[lpt]+uloc[1]*totst[lpt+1]+uloc[2]*totst[lpt+2]);
	ast[lpt]=ast[lpt]/total[lpt];
	cst[lpt]=cst[lpt]/total[lpt];
	est[lpt]=est[lpt]/total[lpt];
	vst[lpt]=vst[lpt]/total[lpt];

	
//printf("%f:%f,%f,%f\n",tot[lpt],totst[lpt],totst[lpt+1],totst[lpt+2]);

//printf("here-bins.\n");
//Getting distance and preparing bins
	if(phi[lpt]<phi_in){
	dmin2=nx*ny;
	dist2=nx*ny;
	for(int i=1;i<=nx;i++) {
	for(int j=1;j<=ny;j++) {
	for(int k=1;k<=nz;k++) {
		int l = (i*ny2+j)*nz2+k;
		if(phi[l]>phi_in){
			dist2=((double)i-(double)ipt)*((double)i-(double)ipt)
				+((double)j-(double)jpt)*((double)j-(double)jpt)
				+((double)k-(double)kpt)*((double)k-(double)kpt);
			if(dist2<dmin2){
			dmin2=dist2;
			imin=i;
			jmin=j;
			kmin=k;
			} //end if
		}//end if phi[l]
	}}} //end i,j
	}//end phi[lpt]
	else{
	dmin2=0;
	imin=0;
	jmin=0;
	kmin=0;
	};


//tseries saving
if(phi[lpt]>phi_in){
//in cell
n_in+=1;
phi_ave_in+=phi[lpt];
len_ave_in+=length;
ener_in+=ener;
force_a_in+=ast[lpt];
force_c_in+=cst[lpt];
force_e_in+=est[lpt];
force_v_in+=vst[lpt];
ener_a_in+=ast_ener;
ener_c_in+=cst_ener;
ener_e_in+=est_ener;
ener_v_in+=vst_ener;
force_total_in+=total[lpt];
force_tot_in+=tot[lpt];
adv_u_in+=adv_u_temp;

if(iswithpoly){ Deb_ave_in+=Deb[lpt];
force_p_in+=pst[lpt];
ener_p_in+=pst_ener;
};
}
else{
if(phi[lpt]<phi_out){
//out of boundary
n_out+=1;
phi_ave_out+=phi[lpt];
len_ave_out+=length;
ener_out+=ener;
force_a_out+=ast[lpt];
force_c_out+=cst[lpt];
force_e_out+=est[lpt];
force_v_out+=vst[lpt];
ener_a_out+=ast_ener;
ener_c_out+=cst_ener;
ener_e_out+=est_ener;
ener_v_out+=vst_ener;
force_total_out+=total[lpt];
force_tot_out+=tot[lpt];
adv_u_out+=adv_u_temp;

if(iswithpoly){ Deb_ave_out+=Deb[lpt];
force_p_out+=pst[lpt];
ener_p_out+=pst_ener;
};
}
else{
//boundary
n_boun+=1;
phi_ave_boun+=phi[lpt];
len_ave_boun+=length;
ener_boun+=ener;
force_a_boun+=ast[lpt];
force_c_boun+=cst[lpt];
force_e_boun+=est[lpt];
force_v_boun+=vst[lpt];
ener_a_boun+=ast_ener;
ener_c_boun+=cst_ener;
ener_e_boun+=est_ener;
ener_v_boun+=vst_ener;
force_total_boun+=total[lpt];
force_tot_boun+=tot[lpt];
adv_u_boun+=adv_u_temp;

if(iswithpoly){ Deb_ave_boun+=Deb[lpt];
force_p_boun+=pst[lpt];
ener_p_boun+=pst_ener;
};
}};

//saving into bins
	ibin=sqrt(dmin2)/gap;
	bin_dist[ibin]=bin_dist[ibin]+1.0;
	bin_a[ibin]+=ast[lpt];
	bin_c[ibin]+=cst[lpt];
	bin_e[ibin]+=est[lpt];
	bin_v[ibin]+=vst[lpt];
	bin_ener_a[ibin]+=ast_ener;
	bin_ener_c[ibin]+=cst_ener;
	bin_ener_e[ibin]+=est_ener;
	bin_ener_v[ibin]+=vst_ener;
	bin_ener[ibin]+=ener;
	bin_phi[ibin]+=phi[lpt];
	if(iswithpoly) {
		bin_Deb[ibin]+=Deb[lpt];
		bin_p[ibin]+=pst[lpt];
		bin_ener_p[ibin]+=pst_ener;}
	bin_tot[ibin]+=tot[lpt];
	bin_total[ibin]+=total[lpt];
//printf("At %d,%d:ibin=%d,dmin2=%d\n",ipt,jpt,ibin,dmin2);


//principal stresses as function of distance
int las=lpt*lcd*lcd;
temp_mat[1][1]=fabs(latc->actstress[las]);
temp_mat[2][2]=fabs(latc->actstress[las+1]);
temp_mat[3][3]=fabs(latc->actstress[las+2]);
temp_mat[1][2]=fabs(latc->actstress[las+3]);
temp_mat[1][3]=fabs(latc->actstress[las+4]);
temp_mat[2][3]=fabs(latc->actstress[las+5]);
temp_mat[2][1]=fabs(latc->actstress[las+6]);
temp_mat[3][1]=fabs(latc->actstress[las+7]);
temp_mat[3][2]=fabs(latc->actstress[las+8]);
prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
bin_prinstress_a[ibin]+=temp_diag[temp_evmax];

temp_mat[1][1]=latc->capstress[las];
temp_mat[2][2]=latc->capstress[las+1];
temp_mat[3][3]=latc->capstress[las+2];
temp_mat[1][2]=latc->capstress[las+3];
temp_mat[1][3]=latc->capstress[las+4];
temp_mat[2][3]=latc->capstress[las+5];
temp_mat[2][1]=latc->capstress[las+6];
temp_mat[3][1]=latc->capstress[las+7];
temp_mat[3][2]=latc->capstress[las+8];
prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
bin_prinstress_c[ibin]+=temp_diag[temp_evmax];

temp_mat[1][1]=latc->elasstress[las];
temp_mat[2][2]=latc->elasstress[las+1];
temp_mat[3][3]=latc->elasstress[las+2];
temp_mat[1][2]=latc->elasstress[las+3];
temp_mat[1][3]=latc->elasstress[las+4];
temp_mat[2][3]=latc->elasstress[las+5];
temp_mat[2][1]=latc->elasstress[las+6];
temp_mat[3][1]=latc->elasstress[las+7];
temp_mat[3][2]=latc->elasstress[las+8];
prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
bin_prinstress_e[ibin]+=temp_diag[temp_evmax];

temp_mat[1][1]=latc->viscstress[las];
temp_mat[2][2]=latc->viscstress[las+1];
temp_mat[3][3]=latc->viscstress[las+2];
temp_mat[1][2]=latc->viscstress[las+3];
temp_mat[1][3]=latc->viscstress[las+4];
temp_mat[2][3]=latc->viscstress[las+5];
temp_mat[2][1]=latc->viscstress[las+6];
temp_mat[3][1]=latc->viscstress[las+7];
temp_mat[3][2]=latc->viscstress[las+8];
prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
bin_prinstress_v[ibin]+=temp_diag[temp_evmax];

if(iswithpoly){
//polytress
temp_mat[1][1]=latc->polystress[las];
temp_mat[2][2]=latc->polystress[las+1];
temp_mat[3][3]=latc->polystress[las+2];
temp_mat[1][2]=latc->polystress[las+3];
temp_mat[1][3]=latc->polystress[las+4];
temp_mat[2][3]=latc->polystress[las+5];
temp_mat[2][1]=latc->polystress[las+6];
temp_mat[3][1]=latc->polystress[las+7];
temp_mat[3][2]=latc->polystress[las+8];
prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
bin_prinstress_p[ibin]+=temp_diag[temp_evmax];
}

}}}//end ipt,jpt,kpt

//Saving as function of distance from cell
for (int i=0;i<Nbin;i++){
bin_a[i]=bin_a[i]/(bin_dist[i]);
bin_c[i]=bin_c[i]/(bin_dist[i]);
bin_e[i]=bin_e[i]/(bin_dist[i]);
bin_v[i]=bin_v[i]/(bin_dist[i]);
bin_p[i]=bin_p[i]/(bin_dist[i]);
bin_Deb[i]=bin_Deb[i]/(bin_dist[i]);
bin_phi[i]=bin_phi[i]/(bin_dist[i]);
bin_tot[i]=bin_tot[i]/(bin_dist[i]);
bin_total[i]=bin_total[i]/(bin_dist[i]);
bin_prinstress_a[i]=bin_prinstress_a[i]/(bin_dist[i]);
bin_prinstress_c[i]=bin_prinstress_c[i]/(bin_dist[i]);
bin_prinstress_e[i]=bin_prinstress_e[i]/(bin_dist[i]);
bin_prinstress_v[i]=bin_prinstress_v[i]/(bin_dist[i]);
bin_prinstress_p[i]=bin_prinstress_p[i]/(bin_dist[i]);
}//end for


phi_ave_in/=n_in;
Deb_ave_in/=n_in;
len_ave_in/=n_in;
phi_ave_out/=n_out;
Deb_ave_out/=n_out;
len_ave_out/=n_out;
phi_ave_boun/=n_boun;
Deb_ave_boun/=n_boun;
len_ave_boun/=n_boun;

force_a_in/=n_in;
force_c_in/=n_in;
force_e_in/=n_in;
force_v_in/=n_in;
force_p_in/=n_in;
force_total_in/=n_in;
force_tot_in/=n_in;
adv_u_in/=n_in;

force_a_out/=n_out;
force_c_out/=n_out;
force_e_out/=n_out;
force_v_out/=n_out;
force_p_out/=n_out;
force_total_out/=n_out;
force_tot_out/=n_out;
adv_u_out/=n_out;

force_a_boun/=n_boun;
force_c_boun/=n_boun;
force_e_boun/=n_boun;
force_v_boun/=n_boun;
force_p_boun/=n_boun;
force_total_boun/=n_boun;
force_tot_boun/=n_boun;
adv_u_boun/=n_boun;

//printf("here-saving.\n");
//Saving timeseries
fprintf(d_00ptr,"%d %f %f %f %f %f %f %f %f %f\n",tm,bin_a[0],bin_c[0],bin_e[0],bin_v[0],bin_p[0],bin_Deb[0],bin_phi[0],bin_tot[0],bin_total[0]);
fprintf(d_01ptr,"%d %f %f %f %f %f %f %f %f %f\n",tm,bin_a[1],bin_c[1],bin_e[1],bin_v[1],bin_p[1],bin_Deb[1],bin_phi[1],bin_tot[1],bin_total[1]);
fprintf(d_02ptr,"%d %f %f %f %f %f %f %f %f %f\n",tm,bin_a[2],bin_c[2],bin_e[2],bin_v[2],bin_p[2],bin_Deb[2],bin_phi[2],bin_tot[2],bin_total[2]);
fprintf(d_03ptr,"%d %f %f %f %f %f %f %f %f %f\n",tm,bin_a[3],bin_c[3],bin_e[3],bin_v[3],bin_p[3],bin_Deb[3],bin_phi[3],bin_tot[3],bin_total[3]);
fprintf(d_04ptr,"%d %f %f %f %f %f %f %f %f %f\n",tm,bin_a[4],bin_c[4],bin_e[4],bin_v[4],bin_p[4],bin_Deb[4],bin_phi[4],bin_tot[4],bin_total[4]);
fprintf(d_05ptr,"%d %f %f %f %f %f %f %f %f %f\n",tm,bin_a[5],bin_c[5],bin_e[5],bin_v[5],bin_p[5],bin_Deb[5],bin_phi[5],bin_tot[5],bin_total[5]);
fprintf(ener_00ptr,"%d %f %f %f %f %f %f\n",tm,bin_ener_a[0],bin_ener_c[0],bin_ener_e[0],bin_ener_v[0],bin_ener_p[0], bin_ener[0]);
fprintf(ener_01ptr,"%d %f %f %f %f %f %f\n",tm,bin_ener_a[1],bin_ener_c[1],bin_ener_e[1],bin_ener_v[1],bin_ener_p[1], bin_ener[1]);
fprintf(ener_02ptr,"%d %f %f %f %f %f %f\n",tm,bin_ener_a[2],bin_ener_c[2],bin_ener_e[2],bin_ener_v[2],bin_ener_p[2], bin_ener[2]);
fprintf(ener_03ptr,"%d %f %f %f %f %f %f\n",tm,bin_ener_a[3],bin_ener_c[3],bin_ener_e[3],bin_ener_v[3],bin_ener_p[3], bin_ener[3]);
fprintf(ener_04ptr,"%d %f %f %f %f %f %f\n",tm,bin_ener_a[4],bin_ener_c[4],bin_ener_e[4],bin_ener_v[4],bin_ener_p[4], bin_ener[4]);
fprintf(ener_05ptr,"%d %f %f %f %f %f %f\n",tm,bin_ener_a[5],bin_ener_c[5],bin_ener_e[5],bin_ener_v[5],bin_ener_p[5], bin_ener[5]);
fprintf(tseries_ptr,"%d %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f\n", 
tm,enertot,ener_in,ener_boun,ener_out,vrms, //1-6
phi_ave_in,phi_ave_boun,phi_ave_out,n_in,n_boun,n_out, //7-12
len_ave_in,len_ave_boun,len_ave_out,Deb_ave_in,Deb_ave_boun,Deb_ave_out,peri); //13-19


fprintf(ts_in_ptr,"%d %f %f %f %f %f %f %f %f %f %f %f %f %f\n",tm,
force_a_in,force_c_in,force_e_in,force_v_in,force_p_in,force_total_in,force_tot_in,//2-6,7-8
ener_a_in,ener_c_in,ener_e_in,ener_v_in,ener_p_in,adv_u_in);//9-13,14

fprintf(ts_out_ptr,"%d %f %f %f %f %f %f %f %f %f %f %f %f %f\n",tm,
force_a_out,force_c_out,force_e_out,force_v_out,force_p_out,force_total_out,force_tot_out,
ener_a_out,ener_c_out,ener_e_out,ener_v_out,ener_p_out,adv_u_out);

fprintf(ts_boun_ptr,"%d %f %f %f %f %f %f %f %f %f %f %f %f %f\n",tm,
force_a_boun,force_c_boun,force_e_boun,force_v_boun,force_p_boun,force_total_boun,force_tot_boun,
ener_a_boun,ener_c_boun,ener_e_boun,ener_v_boun,ener_p_boun,adv_u_boun);



if (tm%writ==0){
fprintf(aacptr,"0.000000 %f %f %f %f %f %f %f %f %f %f %f %f %f %f\n",bin_a[0],bin_c[0],bin_e[0],bin_v[0],bin_p[0],
bin_Deb[0],bin_phi[0],bin_tot[0],bin_total[0],
bin_prinstress_a[0],bin_prinstress_c[0],bin_prinstress_e[0],bin_prinstress_v[0],bin_prinstress_p[0]);
for (int i=1;i<Nbin;i++){
fprintf(aacptr,"%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f\n",((double)i)*gap,bin_a[i],bin_c[i],bin_e[i],bin_v[i],bin_p[i], //1-6
bin_Deb[i],bin_phi[i],bin_tot[i],bin_total[i], //7-10
bin_prinstress_a[i],bin_prinstress_c[i],bin_prinstress_e[i],bin_prinstress_v[i],bin_prinstress_p[i]); //11-15
}//end for
}//end if

fclose(aacptr);
fclose(d_00ptr);
fclose(d_01ptr);
fclose(d_02ptr);
fclose(d_03ptr);
fclose(d_04ptr);
fclose(d_05ptr);
fclose(ener_00ptr);
fclose(ener_01ptr);
fclose(ener_02ptr);
fclose(ener_03ptr);
fclose(ener_04ptr);
fclose(ener_05ptr);
fclose(tseries_ptr);
fclose(ts_in_ptr);
fclose(ts_boun_ptr);
fclose(ts_out_ptr);

	return;
}


/*
void stressgrad_old(lblattice *latv,  lclattice *latc, wedge *latw, int tm){
//Declarations of variables
double *phi=&latc->phi[0];
double *u=&latv->u[0];
int lps[26];

FILE *aacptr, *aptr, *cptr, *eptr, *vptr, *pptr, *totptr;
char nname[500];
sprintf(nname,"%s/output/aac%d.dat",DPATH,tm);
aacptr=fopen(nname,"w");
sprintf(nname,"%s/output/astr%d.dat",DPATH,tm);
aptr=fopen(nname,"w");
sprintf(nname,"%s/output/cstr%d.dat",DPATH,tm);
cptr=fopen(nname,"w");
sprintf(nname,"%s/output/estr%d.dat",DPATH,tm);
eptr=fopen(nname,"w");
sprintf(nname,"%s/output/vstr%d.dat",DPATH,tm);
vptr=fopen(nname,"w");
sprintf(nname,"%s/output/pstr%d.dat",DPATH,tm);
pptr=fopen(nname,"w");
sprintf(nname,"%s/output/totstr%d.dat",DPATH,tm);
totptr=fopen(nname,"w");

//Extension to boundary
(*latc->bc_func)(latv,latc,latw,&latc->actstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->capstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->elasstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->viscstress[0],lcd*lcd);
//pbc_on_vars(latv,latc,latw,&latc->actstress[0],lcd*lcd); //emmanuel:working
double *totst= (double *)malloc(nx2*ny2*nz2*sizeof(double)*lcd);
double *tot= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *ast= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *cst= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *est= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *vst= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *total= (double *)malloc(nx2*ny2*nz2*sizeof(double));
double *pst;
double *Deb;

float **temp_mat, *temp_diag,*temp_offdiag;
temp_mat = matrix(1,3,1,3);
temp_diag=vector(1,3);
temp_offdiag=vector(1,3);
int temp_evmax;

if(iswithpoly){
(*latc->bc_func)(latv,latc,latw,&latc->polystress[0],lcd*lcd);
pst= (double *)malloc(nx2*ny2*nz2*sizeof(double));
Deb= (double *)malloc(nx2*ny2*nz2*sizeof(double));
}

int dmin2,dist2;
int imin, jmin, kmin;
double maxd=sqrt(nx*nx+ny*ny);
int Nbin=(int)maxd+1;
double gap=1;//maxd/(double)Nbin;
float *bin_dist,*bin_a,*bin_c,*bin_e,*bin_v,*bin_p,*bin_tot,*bin_total;
float *bin_phi, *bin_Deb;
bin_dist=vector(1,Nbin);
bin_a=vector(1,Nbin);
bin_c=vector(1,Nbin);
bin_e=vector(1,Nbin);
bin_v=vector(1,Nbin);
bin_p=vector(1,Nbin);
bin_phi=vector(1,Nbin);
bin_Deb=vector(1,Nbin);
bin_tot=vector(1,Nbin);
bin_total=vector(1,Nbin);
for(int i;i<=Nbin;i++){
bin_dist[i]=0.0;
bin_a[i]=0.0;
bin_c[i]=0.0;
bin_e[i]=0.0;
bin_v[i]=0.0;
bin_p[i]=0.0;
bin_phi[i]=0.0;
bin_Deb[i]=0.0;
bin_tot[i]=0.0;
bin_total[i]=0.0;
};
int ibin;

//Getting the divergence for each point
for(int ipt=1;ipt<=nx;ipt++) {
for(int jpt=1;jpt<=ny;jpt++) {
for(int kpt=1;kpt<=nz;kpt++) {
//printf("%d,%d\n",ipt,jpt);
	int lpt = (ipt*ny2+jpt)*nz2+kpt;
	//int las = lpt*lcd*lcd;
	derivativesN(ipt,jpt,kpt,&lps[0]);
	double uloc[3];
	uloc[0]=u[lpt*lbd];
	uloc[1]=u[lpt*lbd+1];
	uloc[2]=u[lpt*lbd+2];

//Getting Deborah (need strain tensor only)
	double delu[9],strain[6],vortic[3];
	double wls[3]={0.5, 0.5, 0.5};
	int *lpv=&lps[0];
	double *wlp=&wls[0];
	derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);
	double DddD=strain[0]*strain[0]+strain[1]*strain[1]+strain[2]*strain[2]
		+2*(strain[3]*strain[3]+strain[4]*strain[4]+strain[5]*strain[5]);
	if(iswithpoly) Deb[lpt]=tau_poly*sqrt(0.5*DddD);

//Getting magnitudes
	for(int ii=0;ii<26;ii++){lps[ii]=lps[ii]*lcd*lcd;}
	double div[3];

//activity
	div[0]=0.5*(latc->actstress[lps[0]]-latc->actstress[lps[1]]
		+latc->actstress[lps[2]+3]-latc->actstress[lps[3]+3]
		+latc->actstress[lps[4]+4]-latc->actstress[lps[5]+4]);
	div[1]=0.5*(latc->actstress[lps[0]+3]-latc->actstress[lps[1]+3]
		+latc->actstress[lps[2]+1]-latc->actstress[lps[3]+1]
		+latc->actstress[lps[4]+5]-latc->actstress[lps[5]+5]);
	div[2]=0.5*(latc->actstress[lps[0]+4]-latc->actstress[lps[1]+4]
		+latc->actstress[lps[2]+5]-latc->actstress[lps[3]+5]
		+latc->actstress[lps[4]+2]-latc->actstress[lps[5]+2]);
	ast[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
//	ast[lpt]=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
	total[lpt]=ast[lpt];
	totst[lpt]=div[0];
	totst[lpt+1]=div[1];
	totst[lpt+2]=div[2];
//printf("act=%f:%f,%f,%f\n",ast[lpt],div[1],div[2],div[3]);

//capillary
	div[0]=0.5*(latc->capstress[lps[0]]-latc->capstress[lps[1]]
		+latc->capstress[lps[2]+3]-latc->capstress[lps[3]+3]
		+latc->capstress[lps[4]+4]-latc->capstress[lps[5]+4]);
	div[1]=0.5*(latc->capstress[lps[0]+3]-latc->capstress[lps[1]+3]
		+latc->capstress[lps[2]+1]-latc->capstress[lps[3]+1]
		+latc->capstress[lps[4]+5]-latc->capstress[lps[5]+5]);
	div[2]=0.5*(latc->capstress[lps[0]+4]-latc->capstress[lps[1]+4]
		+latc->capstress[lps[2]+5]-latc->capstress[lps[3]+5]
		+latc->capstress[lps[4]+2]-latc->capstress[lps[5]+2]);
	cst[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
//	cst[lpt]=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
	total[lpt]+=cst[lpt];
	totst[lpt]+=div[0];
	totst[lpt+1]+=div[1];
	totst[lpt+2]+=div[2];
//printf("cap=%f:%f,%f,%f\n",cst[lpt],div[1],div[2],div[3]);

//elastic
	div[0]=0.5*(latc->elasstress[lps[0]]-latc->elasstress[lps[1]]
		+latc->elasstress[lps[2]+3]-latc->elasstress[lps[3]+3]
		+latc->elasstress[lps[4]+4]-latc->elasstress[lps[5]+4]);
	div[1]=0.5*(latc->elasstress[lps[0]+3]-latc->elasstress[lps[1]+3]
		+latc->elasstress[lps[2]+1]-latc->elasstress[lps[3]+1]
		+latc->elasstress[lps[4]+5]-latc->elasstress[lps[5]+5]);
	div[2]=0.5*(latc->elasstress[lps[0]+4]-latc->elasstress[lps[1]+4]
		+latc->elasstress[lps[2]+5]-latc->elasstress[lps[3]+5]
		+latc->elasstress[lps[4]+2]-latc->elasstress[lps[5]+2]);
	est[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
//	est[lpt]=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
	total[lpt]+=est[lpt];
	totst[lpt]+=div[0];
	totst[lpt+1]+=div[1];
	totst[lpt+2]+=div[2];
//printf("elas=%f:%f,%f,%f\n",est[lpt],div[1],div[2],div[3]);

//viscous
	div[0]=0.5*(latc->viscstress[lps[0]]-latc->viscstress[lps[1]]
		+latc->viscstress[lps[2]+3]-latc->viscstress[lps[3]+3]
		+latc->viscstress[lps[4]+4]-latc->viscstress[lps[5]+4]);
	div[1]=0.5*(latc->viscstress[lps[0]+3]-latc->viscstress[lps[1]+3]
		+latc->viscstress[lps[2]+1]-latc->viscstress[lps[3]+1]
		+latc->viscstress[lps[4]+5]-latc->viscstress[lps[5]+5]);
	div[2]=0.5*(latc->viscstress[lps[0]+4]-latc->viscstress[lps[1]+4]
		+latc->viscstress[lps[2]+5]-latc->viscstress[lps[3]+5]
		+latc->viscstress[lps[4]+2]-latc->viscstress[lps[5]+2]);
	vst[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
//	vst[lpt]=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
	total[lpt]+=vst[lpt];
	totst[lpt]+=div[0];
	totst[lpt+1]+=div[1];
	totst[lpt+2]+=div[2];
//printf("visc=%f:%f,%f,%f\n",vst[lpt],div[1],div[2],div[3]);

//polymer
if(iswithpoly){
	div[0]=0.5*(latc->polystress[lps[0]]-latc->polystress[lps[1]]
		+latc->polystress[lps[2]+3]-latc->polystress[lps[3]+3]
		+latc->polystress[lps[4]+4]-latc->polystress[lps[5]+4]);
	div[1]=0.5*(latc->polystress[lps[0]+3]-latc->polystress[lps[1]+3]
		+latc->polystress[lps[2]+1]-latc->polystress[lps[3]+1]
		+latc->polystress[lps[4]+5]-latc->polystress[lps[5]+5]);
	div[2]=0.5*(latc->polystress[lps[0]+4]-latc->polystress[lps[1]+4]
		+latc->polystress[lps[2]+5]-latc->polystress[lps[3]+5]
		+latc->polystress[lps[4]+2]-latc->polystress[lps[5]+2]);
	pst[lpt]=sqrt(div[0]*div[0]+div[1]*div[1]+div[2]*div[2]);
//	pst[lpt]=uloc[0]*div[0]+uloc[1]*div[1]+uloc[2]*div[2];
	total[lpt]+=pst[lpt];
	totst[lpt]+=div[0];
	totst[lpt+1]+=div[1];
	totst[lpt+2]+=div[2];
	//pst[lpt]=pst[lpt]/total[lpt];
//printf("poly=%f:%f,%f,%f\n",pst[lpt],div[1],div[2],div[3]);
}

tot[lpt]=sqrt(totst[lpt]*totst[lpt]+totst[lpt+1]*totst[lpt+1]+totst[lpt+2]*totst[lpt+2]);
//	tot[lpt]=sqrt(uloc[0]*totst[lpt]+uloc[1]*totst[lpt+1]+uloc[2]*totst[lpt+2]);
	//ast[lpt]=ast[lpt]/total[lpt];
	//cst[lpt]=cst[lpt]/total[lpt];
	//est[lpt]=est[lpt]/total[lpt];
	//vst[lpt]=vst[lpt]/total[lpt];
	
//printf("%f:%f,%f,%f\n",tot[lpt],totst[lpt],totst[lpt+1],totst[lpt+2]);

//Getting distance and preparing bins
	if(phi[lpt]<0.95){
	dmin2=nx*ny;
	dist2=nx*ny;
	for(int i=1;i<=nx;i++) {
	for(int j=1;j<=ny;j++) {
	for(int k=1;k<=nz;k++) {
		int l = (i*ny2+j)*nz2+k;
		if(phi[l]>0.95){
			dist2=((double)i-(double)ipt)*((double)i-(double)ipt)
				+((double)j-(double)jpt)*((double)j-(double)jpt)
				+((double)k-(double)kpt)*((double)k-(double)kpt);
			if(dist2<dmin2){
			dmin2=dist2;
			imin=i;
			jmin=j;
			kmin=k;
			} //end if
		}//end if phi[l]
	}}} //end i,j


	}//end phi[lpt]
	else{
	dmin2=0;
	imin=0;
	jmin=0;
	kmin=0;
	};

//saving into bins
	ibin=sqrt(dmin2)/gap;
	bin_dist[ibin]=bin_dist[ibin]+1.0;
	bin_a[ibin]+=ast[lpt];
	bin_c[ibin]+=cst[lpt];
	bin_e[ibin]+=est[lpt];
	bin_v[ibin]+=vst[lpt];
	bin_phi[ibin]+=phi[lpt];
	if(iswithpoly) {
		bin_Deb[ibin]+=Deb[lpt];
		bin_p[ibin]+=pst[lpt];}
	bin_tot[ibin]+=tot[lpt];
	bin_total[ibin]+=total[lpt];
//printf("At %d,%d:ibin=%d,dmin2=%d\n",ipt,jpt,ibin,dmin2);

}}}//end ipt,jpt,kpt

//Saving into fields
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      int l=(i*ny2+j)*nz2+k;
      fprintf(aptr,"%f\n",ast[l]);
      fprintf(cptr,"%f\n",cst[l]);
      fprintf(eptr,"%f\n",est[l]);
      fprintf(vptr,"%f\n",vst[l]);
      fprintf(pptr,"%f\n",pst[l]);
      fprintf(totptr,"%f\n",totst[l]);
} } }

*/

/*
fwrite(&tm,sizeof(int),1,aptr);
fwrite(ast,sizeof(double),nx2*ny2*nz2,aptr);
fwrite(&tm,sizeof(int),1,cptr);
fwrite(cst,sizeof(double),nx2*ny2*nz2,cptr);
fwrite(&tm,sizeof(int),1,eptr);
fwrite(est,sizeof(double),nx2*ny2*nz2,eptr);
fwrite(&tm,sizeof(int),1,vptr);
fwrite(vst,sizeof(double),nx2*ny2*nz2,vptr);
	if(iswithpoly) {fwrite(&tm,sizeof(int),1,pptr);
	fwrite(pst,sizeof(double),nx2*ny2*nz2,pptr);};
fwrite(&tm,sizeof(int),1,totptr);
fwrite(tot,sizeof(double),nx2*ny2*nz2,totptr);
*/


