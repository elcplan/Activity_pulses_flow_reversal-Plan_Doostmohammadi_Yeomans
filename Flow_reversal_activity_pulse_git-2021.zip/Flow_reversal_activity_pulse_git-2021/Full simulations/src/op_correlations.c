calccorr *calccorrmemallocate() {
calccorr *calcc=(calccorr *)malloc(sizeof(calccorr));/*variable associated with all autocorr calculations*/
calcc->autoc=autocorrmemallocate();        /*Autocorr calculations setting if required*/
calcc->spatc=spatcorrmemallocate();        /*Spatcorr calculations setting if required*/
calcc->tracc=tracermemallocate();
return calcc;
}

autocorr *autocorrmemallocate() {
autocorr *autoc=(autocorr *)malloc(sizeof(autocorr));/*variable associated with all autocorr calculations*/
if(autocorrcalculations) {
  autoc->vstd = (double *)malloc(n2max*lbd*sizeof(double));/*at t=0*/
  autoc->vauto = (double *)malloc(tmaxforauto*sizeof(double));/*at anytime t*/
  autoc->vautotemp = (double *)malloc(tmaxforauto*sizeof(double));/*at anytime t*/
  autoc->qstd = (double *)malloc(n2max*lcq*sizeof(double));/*at t=0*/
  autoc->qauto = (double *)malloc(tmaxforauto*sizeof(double));/*at anytime t*/
  autoc->qautotemp = (double *)malloc(tmaxforauto*sizeof(double));/*at anytime t*/
  autoc->ostd = (double *)malloc(n2max*lcq*sizeof(double));/*at t=0*/
  autoc->oauto = (double *)malloc(tmaxforauto*sizeof(double));/*at anytime t*/
  autoc->oautotemp = (double *)malloc(tmaxforauto*sizeof(double));/*at anytime t*/
  for(int l=0;l<tmaxforauto;l++) {
    autoc->vauto[l]=0;
    autoc->qauto[l]=0;
    autoc->oauto[l]=0;
  }
autoc->realzn=0;
}
return autoc;
}

void autocorrcalcon(lblattice *latv,  lclattice *latc, wedge *latw, autocorr *autoc, int tm) {
if(tm%tmaxforauto==0) {
  autocorrmemory(latv,latc,autoc,tm);
}
autocorractualcalc(latv,latc,autoc,tm);
if((tm+1)%tmaxforauto==0) {
  autocorravg(autoc,tm);
  autocorrwrite(autoc,tm);
}
return;
}

void autocorrcalcoff(lblattice *latv,  lclattice *latc, wedge *latw, autocorr *autoc, int tm) {
/*Do nothing*/
return;
}

void autocorrmemory(lblattice *latv, lclattice *latc, autocorr *autoc, int tm) {
autoc->tstd=tm;
for(int l=0;l<n2max*lbd;l++) {autoc->vstd[l]=latv->u[l];}
for(int l=0;l<n2max*lcq;l++) {autoc->qstd[l]=latc->q[l];}
for(int l=0;l<n2max;l++)     {autoc->ostd[l]=latv->o[l];}
return;
}

void autocorractualcalc(lblattice *latv, lclattice *latc, autocorr *autoc,int tm) {
double sumv=0,sumq=0,sumo=0;
int lpt;
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      lpt = (i*ny2+j)*nz2+k;
      sumo+=autoc->ostd[lpt]*latv->o[lpt];
      for(int m=0;m<lbd;m++) {sumv+=autoc->vstd[lpt*lbd+m]*latv->u[lpt*lbd+m];}
      for(int m=0;m<lcq;m++) {sumq+=autoc->qstd[lpt*lcq+m]*latc->q[lpt*lcq+m];}
} } }
autoc->vautotemp[tm-autoc->tstd]=sumv/nmax;
autoc->qautotemp[tm-autoc->tstd]=sumq/nmax;
autoc->oautotemp[tm-autoc->tstd]=sumo/nmax;
return;
}

void autocorravg(autocorr *autoc, int tm) {
for(int l=0;l<tmaxforauto;l++) {
autoc->vauto[l]+=autoc->vautotemp[l];
autoc->qauto[l]+=autoc->qautotemp[l];
autoc->oauto[l]+=autoc->oautotemp[l];
}
autoc->realzn+=1;
}

void autocorrwrite(autocorr *autoc, int tm) {
FILE *vaptr,*qaptr,*oaptr;
char nname[500];
sprintf(nname,"%s/output/vautocorr.dat",DPATH);
vaptr=fopen(nname,"w");
sprintf(nname,"%s/output/qautocorr.dat",DPATH);
qaptr=fopen(nname,"w");
sprintf(nname,"%s/output/oautocorr.dat",DPATH);
oaptr=fopen(nname,"w");
fprintf(vaptr,"%d\n%d\n",autoc->realzn,tm);
fprintf(qaptr,"%d\n%d\n",autoc->realzn,tm);
fprintf(oaptr,"%d\n%d\n",autoc->realzn,tm);
for(int l=0;l<tmaxforauto;l++) {
  fprintf(vaptr,"%g \n",autoc->vauto[l]/autoc->realzn);
  fprintf(qaptr,"%f \n",autoc->qauto[l]/autoc->realzn);
  fprintf(oaptr,"%g \n",autoc->oauto[l]/autoc->realzn);}
fclose(vaptr);
fclose(qaptr);
fclose(oaptr);
return;
}


void vorticityon(lblattice *latv, lclattice *latc, wedge *latw) {
int lps[26];/*These are for normal and mixed CDs*/
double wls[3]={0.5, 0.5, 0.5};
int *lpv=&lps[0];/*These will be used if nowedge*/
double *wlp=&wls[0];
int lpt;
double delu[9],strain[6],vortic[3];
double *u=&latv->u[0];
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      lpt = (i*ny2+j)*nz2+k;
      if(latw->w[lpt]>=0) {
        if(isgeom) {
          lpv=&latw->lpv[lpt*2*lbd];
          wlp=&latw->wlp[lpt*lbd]; }
        else {
          derivativesN(i,j,k,&lpv[0]); }
      derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);
      latv->o[lpt]=-2*strain[0];
}; }; }; };
(*latc->bc_func)(latv,latc,latw,&latv->o[0],1);
return;
}

void vorticityoff(lblattice *latv, lclattice *latc, wedge *latw) {
/*Do nothing*/
return;
}

spatcorr *spatcorrmemallocate() {
spatcorr *spatc=(spatcorr *)malloc(sizeof(spatcorr));/*variable associated with all spatcorr calculations*/
if(spatcorrcalculations) {
  spatc->nspat = (int *)malloc(rxymax*sizeof(int));/*at anytime t*/
  spatc->vspat = (double *)malloc(rxymax*sizeof(double));/*at anytime t*/
  spatc->qspat = (double *)malloc(rxymax*sizeof(double));/*at anytime t*/
  spatc->ospat = (double *)malloc(rxymax*sizeof(double));/*at anytime t*/
  spatc->nspattemp = (int *)malloc(rxymax*sizeof(int));/*at anytime t*/
  spatc->vspattemp = (double *)malloc(rxymax*sizeof(double));/*at anytime t*/
  spatc->qspattemp = (double *)malloc(rxymax*sizeof(double));/*at anytime t*/
  spatc->ospattemp = (double *)malloc(rxymax*sizeof(double));/*at anytime t*/
  for(int l=0;l<rxymax;l++) {
    spatc->nspat[l]=0;
    spatc->vspat[l]=0;
    spatc->qspat[l]=0;
    spatc->ospat[l]=0;
  }
spatc->realzn=0;
int lpt,l,rad,k=1;
for(int ipt=1;ipt<=nx;ipt++) {
  for(int jpt=1;jpt<=ny;jpt++) {
    lpt = (ipt*ny2+jpt)*nz2+k;
    for(int i=1;i<=nx;i++) {
      for(int j=1;j<=ny;j++) {
      l = (i*ny2+j)*nz2+k;
      rad=(i-ipt)*(i-ipt)+(j-jpt)*(j-jpt);
      spatc->nspat[rad]++;
} } } }
}
return spatc;
}

void spatcorrcalcon(lblattice *latv,  lclattice *latc, wedge *latw, spatcorr *spatc, int tm) {
if((tm%tgapforspat==0)&&(tm>=tminforspat)) {
spatcorractualcalc(latv,latc,spatc,tm);
spatcorravg(spatc,tm);
spatcorrwrite(spatc,tm);
}
return;
}

void spatcorrcalcoff(lblattice *latv,  lclattice *latc, wedge *latw, spatcorr *spatc, int tm) {
/*Do nothing*/
return;
}

void spatcorractualcalc(lblattice *latv, lclattice *latc, spatcorr *spatc,int tm) {
int l,lpt,k=1,rad;
for(int l=0;l<rxymax;l++) {
  spatc->nspattemp[l]=0;
  spatc->vspattemp[l]=0;
  spatc->qspattemp[l]=0;
  spatc->ospattemp[l]=0;
}
for(int ipt=1;ipt<=nx;ipt++) {
  for(int jpt=1;jpt<=ny;jpt++) {
    lpt = (ipt*ny2+jpt)*nz2+k;
    for(int i=1;i<=nx;i++) {
      for(int j=1;j<=ny;j++) {
      l = (i*ny2+j)*nz2+k;
      rad=(i-ipt)*(i-ipt)+(j-jpt)*(j-jpt);
      spatc->nspattemp[rad]++;
      spatc->ospattemp[rad]+=latv->o[l]*latv->o[lpt];
      for(int m=0;m<lcq;m++) {spatc->qspattemp[rad]+=latc->q[l*lcq+m]*latc->q[lpt*lcq+m];}
      for(int m=0;m<lbd;m++) {spatc->vspattemp[rad]+=latv->u[l*lbd+m]*latv->u[lpt*lbd+m];}
} } } } 
return;
}

void spatcorravg(spatcorr *spatc, int tm) {
for(int l=0;l<rxymax;l++) {
if(spatc->nspattemp[l]>0) {
  spatc->vspat[l]+=spatc->vspattemp[l]/spatc->nspattemp[l];
  spatc->qspat[l]+=spatc->qspattemp[l]/spatc->nspattemp[l];
  spatc->ospat[l]+=spatc->ospattemp[l]/spatc->nspattemp[l];
} }
spatc->realzn+=1;
return;
}

void spatcorrwrite(spatcorr *spatc, int tm) {
FILE *vaptr,*qaptr,*oaptr,*vfaptr,*qfaptr,*ofaptr;
char nname[500];
double radl=0,rad=0.0,vv=0,qq=0,oo=0;
double tv,tq,to;
int nn=0;
sprintf(nname,"%s/output/vspatcorrf.dat",DPATH);
vfaptr=fopen(nname,"w");
sprintf(nname,"%s/output/qspatcorrf.dat",DPATH);
qfaptr=fopen(nname,"w");
sprintf(nname,"%s/output/ospatcorrf.dat",DPATH);
ofaptr=fopen(nname,"w");
sprintf(nname,"%s/output/vspatcorr.dat",DPATH);
vaptr=fopen(nname,"w");
sprintf(nname,"%s/output/qspatcorr.dat",DPATH);
qaptr=fopen(nname,"w");
sprintf(nname,"%s/output/ospatcorr.dat",DPATH);
oaptr=fopen(nname,"w");
fprintf(vaptr,"%d\n%d\n",spatc->realzn,tm);
fprintf(qaptr,"%d\n%d\n",spatc->realzn,tm);
fprintf(oaptr,"%d\n%d\n",spatc->realzn,tm);
for(int l=0;l<rxymax;l++) {
  radl=sqrt(l);
  if(spatc->nspat[l]>0) {
    tv=spatc->vspat[l]/spatc->realzn;
    tq=spatc->qspat[l]/spatc->realzn;
    to=spatc->ospat[l]/spatc->realzn;
    fprintf(vfaptr,"%f %g \n",radl,tv);
    fprintf(qfaptr,"%f %g \n",radl,tq);
    fprintf(ofaptr,"%f %g \n",radl,to);
    if(radl<=rad+0.5) {
      vv+=tv;
      qq+=tq;
      oo+=to;
      nn++;
    } 
    else{
    fprintf(vaptr,"%f %g \n",rad,vv/nn);
    fprintf(qaptr,"%f %g \n",rad,qq/nn);
    fprintf(oaptr,"%f %g \n",rad,oo/nn);
    vv=tv;
    qq=tq;
    oo=to;
    nn=1;
    rad=rad+1;
    }
  }
  if((rad>nx)||(rad>ny)) break;
}
fclose(vaptr);
fclose(qaptr);
fclose(oaptr);
return;
}

