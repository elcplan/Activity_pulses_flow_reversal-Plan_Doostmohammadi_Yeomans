/* functions associated with forces in lattice LB-LC simulation*/

/*Calculating the body forces*/
void bodyforcecalc(lblattice *lat) {
int inew,jnew,knew;
double *bforce=&lat->bforce[0];
for(int i=1;i<=nx;i++) {
  inew=i*ny2;
  for(int j=1;j<=ny;j++) {
    jnew=(inew+j)*nz2;
    for(int k=1;k<=nz;k++) {
      knew=(jnew+k)*lbd;
      lat->force[knew]=bforce[0];
      lat->force[knew+1]=bforce[1];
      lat->force[knew+2]=bforce[2];
}; }; };
return;
}

/*Calculating the passive forces*/
void liqcforcecalc(lblattice *latv, lclattice *latc, wedge *latw) {
double force[3];
double *bforce=&latv->bforce[0];
int lpt, l,lpx,lmx,lpy,lmy,lpz,lmz;
int lcd2=lcd*lcd;
double wls[3]={0.5, 0.5, 0.5};/*These will be used if no geometry*/
int lps[26];/*These are used when derivatives without recognizing walls*/
int *lpv=&lps[0];/*lpv is for, when walls present, lps is used instead if no such geometry*/
double *wlp=&wls[0];
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      lpt = (i*ny2+j)*nz2+k;
      if(latw->w[lpt]>=0) {
      if(isgeom) {
        lpv=&latw->lpv[lpt*2*lbd];
        wlp=&latw->wlp[lpt*lbd]; }
      else {
        derivativesN(i,j,k,&lpv[0]); }
      lpx = lpv[0]*lcd2;//(((i+1)*ny2+j  )*nz2+k  )*lcd2;/*for derivatives*/
      lmx = lpv[1]*lcd2;//(((i-1)*ny2+j  )*nz2+k  )*lcd2;
      lpy = lpv[2]*lcd2;//(( i   *ny2+j+1)*nz2+k  )*lcd2;
      lmy = lpv[3]*lcd2;//(( i   *ny2+j-1)*nz2+k  )*lcd2;
      lpz = lpv[4]*lcd2;//(( i   *ny2+j  )*nz2+k+1)*lcd2;
      lmz = lpv[5]*lcd2;//(( i   *ny2+j  )*nz2+k-1)*lcd2;
      l   = lpt*lcd;/*for forces*/
      force[0]=wlp[0]*(latc->bstress[lpx  ]-latc->bstress[lmx  ])+wlp[1]*(latc->bstress[lpy+3]
			-latc->bstress[lmy+3])+wlp[2]*(latc->bstress[lpz+4]-latc->bstress[lmz+4]);
      force[1]=wlp[0]*(latc->bstress[lpx+6]-latc->bstress[lmx+6])+wlp[1]*(latc->bstress[lpy+1]
			-latc->bstress[lmy+1])+wlp[2]*(latc->bstress[lpz+5]-latc->bstress[lmz+5]);
      force[2]=wlp[0]*(latc->bstress[lpx+7]-latc->bstress[lmx+7])+wlp[1]*(latc->bstress[lpy+8]
			-latc->bstress[lmy+8])+wlp[2]*(latc->bstress[lpz+2]-latc->bstress[lmz+2]);
      latv->force[l]  =bforce[0];
      latv->force[l+1]=bforce[1];
      latv->force[l+2]=bforce[2];
      if(!noliqc) {
      latv->force[l]  +=force[0];
      latv->force[l+1]+=force[1];
      latv->force[l+2]+=force[2];}
/*      if(inphase) {This is now taken care of in stress
double *phigradmu=&latc->phigmu[0]; from before for loop
      latv->force[l]  -=phigradmu[l];
      latv->force[l+1]-=phigradmu[l+1];
      latv->force[l+2]-=phigradmu[l+2];
      }*/
      if(drywetmat) {
      latv->force[l]  -=fcoef*latv->u[l];
      latv->force[l+1]-=fcoef*latv->u[l+1];
      latv->force[l+2]-=fcoef*latv->u[l+2];
      }
      if(nocollisions) {
      latv->force[l]  +=wlp[0]*(latc->estress[lpx  ]-latc->estress[lmx  ])+wlp[1]*(latc->estress[lpy+3]
			-latc->estress[lmy+3])+wlp[2]*(latc->estress[lpz+4]-latc->estress[lmz+4]);
      latv->force[l+1]+=wlp[0]*(latc->estress[lpx+3]-latc->estress[lmx+3])+wlp[1]*(latc->estress[lpy+1]
			-latc->estress[lmy+1])+wlp[2]*(latc->estress[lpz+5]-latc->estress[lmz+5]);
      latv->force[l+2]+=wlp[0]*(latc->estress[lpx+4]-latc->estress[lmx+4])+wlp[1]*(latc->estress[lpy+5]
			-latc->estress[lmy+5])+wlp[2]*(latc->estress[lpz+2]-latc->estress[lmz+2]);
      }
}; }; }; };
return;
}
/*0-11, 1-22, 2-33, 3-12, 4-13, 5-23, 6-21, 7-31, 8-32*/

/*Calculation of no forces*/
void nothingforce() {
return;
}

void viscousstress(lblattice *latv, lclattice *latc, wedge *latw) {
int lps[26];/*These are for normal and mixed CDs*/
double wls[3]={0.5, 0.5, 0.5};
int *lpv=&lps[0];/*These will be used if nowedge*/
double *wlp=&wls[0];
int lpt;
double delu[9],strain[6],vortic[3];
double mu=rho0*(taulb-0.5)/3;
double *u=&latv->u[0];
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      lpt = (i*ny2+j)*nz2+k;
      if(latw->w[lpt]>=0) {
        if(isgeom) {
          lpv=&latw->lpv[lpt*2*lbd];
          wlp=&latw->wlp[lpt*lbd]; }
        else {
          derivativesN(i,j,k,&lpv[0]); }
        derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);
        for(int m=0;m<lbd*2;m++) {latv->vstress[lpt*2*lbd+m]=2*mu*strain[m];}
}; }; }; };
(*latc->bc_func)(latv,latc,latw,&latv->vstress[0],lbd*2);
return;
}

/*Calculating total forces*/
void angvelcalc(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
int lpt;
//double force[3]={0.0,0.0,0.0};
//double torque[3]={0.0,0.0,0.0};
//double omega[3]={0.0,0.0,0.0};
double xc, yc, zc,cx,cy,cz;
int inew,jnew,knew,lnew,np;
//double Udotv,faut,fau[lbq*lbd],tuq[lbq*lbd];
//double partwallvel[3]={0.0,0.0,0.0};
//double addm;
double *num=latw->numforomega;
double *den=latw->denforomega;
for(int i=0;i<numofpart;i++) {num[i]=momofi*latw->bodyomega[i*lcd+2];den[i]=momofi;}
int jstart=2,jend=ny-1;
for(int k=1;k<=nz;k++) {
  for(int j=jstart;j<=jend;j++) {
      for(int i=1;i<=nx;i++) {
	lpt = (i*ny2+j)*nz2+k;
	if(latw->w[lpt]!=0) {continue;}
	for(int m=0;m<lbq;m++) {
	  inew=i+latv->xi[m*lbd];
	  jnew=j+latv->xi[m*lbd+1];
	  knew=k+latv->xi[m*lbd+2];
	  lnew=(inew*ny2+jnew)*nz2+knew;
          if(latw->w[lnew]==swall) {
	    np=latw->partmark[lnew];
	    xc=latw->partloc[(np-1)*lcd+0];
	    yc=latw->partloc[(np-1)*lcd+1];
	    zc=latw->partloc[(np-1)*lcd+2];
	    cx = i+0.5*latv->xi[m*lbd+0]-xc;
	    cy = j+0.5*latv->xi[m*lbd+1]-yc;
	    cz = k+0.5*latv->xi[m*lbd+2]-zc;
	    /*Ladd's method - next 17 lines, Frenkels method (Lowe, Frenkel, Masters JCP 103 (4) 1995) is implemented only for cylinder rotating which is the 18th and 19th line*/
/*	    partwallvel[0] = latw->bodyomega[1]*cz - latw->bodyomega[2]*cy;
	    partwallvel[1] = latw->bodyomega[2]*cx - latw->bodyomega[0]*cz;
	    partwallvel[2] = latw->bodyomega[0]*cy - latw->bodyomega[1]*cx;
	    Udotv=partwallvel[0]*latv->xi[m*lbd+0]+partwallvel[1]*latv->xi[m*lbd+1]+partwallvel[2]*latv->xi[m*lbd+2];
	    faut=latv->fnew[lpt*lbq+m]+latv->fnew[lnew*lbq+latv->complement[m]];*/
	    //addm=-6*latv->wt[m]*rho0*Udotv;///lat->cs2;
	    //faut=2*latv->fnew[lpt*lbq+m]+addm;
	    /*We are calculating the force on the wall using momentum exchange method suggested by Ladd. However, I don't understand his equation 3.12 (in 1994 JFM which considers fluid inside the particle), instead his modified equation 14 in Aidun's article, Vol 81, 1995, Journal of Statistical Physics page 49 can be used. If you look at the expression used right now, it is much more intutitve. We are calculating the momentum exchanged between the particle and fluid when the streaming step occurs. This is according to eqn 15, and the previous equation suggested by Mei et al, PRE, 65, 041203. This expression is actually by Ladd, but he finally used something more complicated. However the time stepping method has to be that suggested by the Ladd, meaning use of eqns: 3.18 for force smoothing and 3.21 for angular velocity evaluation are also needed to get a stable code.*/
	    /*fau[m*lbd+0]=faut*latv->xi[m*lbd+0];
	    fau[m*lbd+1]=faut*latv->xi[m*lbd+1];
	    fau[m*lbd+2]=faut*latv->xi[m*lbd+2];
	    tuq[m*lbd+0] = cy*fau[m*lbd+2] - cz*fau[m*lbd+1];
	    tuq[m*lbd+1] = cz*fau[m*lbd+0] - cx*fau[m*lbd+2];
	    tuq[m*lbd+2] = cx*fau[m*lbd+1] - cy*fau[m*lbd+0];
	    torque[0]+=tuq[m*lbd+0]; force[0]+=fau[m*lbd+0];
	    torque[1]+=tuq[m*lbd+1]; force[1]+=fau[m*lbd+1];
	    torque[2]+=tuq[m*lbd+2]; force[2]+=fau[m*lbd+2];*/
	    num[np-1]+=2*latv->fnew[lpt*lbq+m]*(cx*latv->xi[m*lbd+1] - cy*latv->xi[m*lbd+0]);
	    den[np-1]+=6*latv->wt[m]*rho0*(cx*latv->xi[m*lbd+1] - cy*latv->xi[m*lbd+0])*(cx*latv->xi[m*lbd+1] - cy*latv->xi[m*lbd+0]);
	}}
} } }
/*Ladd's method - next 12 lines, other method is implemented only for cylinder rotating which is the 13th line*/
/*Following is Ladd's eqn 3.18 to smoothen torques*/
//latw->torque[0]=0.5*(torque[0]+latw->torqueold[0]); latw->torqueold[0]=torque[0];
//latw->torque[1]=0.5*(torque[1]+latw->torqueold[1]); latw->torqueold[1]=torque[1];
//latw->torque[2]=0.5*(torque[2]+latw->torqueold[2]); latw->torqueold[2]=torque[2];
///*Following is Ladd's eqn 3.21 to calculate angular velocity*/
//if(isrotn==1) {
//omega[0]=latw->bodyomega[0]; omega[1]=latw->bodyomega[1]; omega[2]=latw->bodyomega[2];
//latw->bodyomega[0]=latw->bodyomegaold[0]+2.0*latw->torque[0]/momofi;
//latw->bodyomega[1]=latw->bodyomegaold[1]+2.0*latw->torque[1]/momofi;
//latw->bodyomega[2]=latw->bodyomegaold[2]+2.0*latw->torque[2]/momofi;
//latw->bodyomegaold[0]=omega[0];latw->bodyomegaold[1]=omega[1]; latw->bodyomegaold[2]=omega[2];
//};
if(isrotn==1) {
  for(int j=0;j<numofpart;j++) {
  latw->bodyomega[j*lcd+2]=num[j]/den[j];
  if((angvelcorr)&&(tm>=tminforang)) {
    int tml=(tm-tminforang)/tgapforang;
    latw->angseries[j*tmlmax+tml]=latw->bodyomega[j*lcd+2];
    for(int i=0;i<=tml;i++) {
      latw->corrang[j*tmlmax+i]+=latw->angseries[j*tmlmax+tml]*latw->angseries[j*tmlmax+tml-i];
      latw->corrangrealzn[j*tmlmax+i]=latw->corrangrealzn[j*tmlmax+i]+1;
    }
  }
}
}
}
/*0-11, 1-22, 2-33, 3-12, 4-13, 5-23, 6-21, 7-31, 8-32*/

/*Calculating total forces*/
void dragftcalc(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
int lpt;
double force[3]={0.0,0.0,0.0};
double torque[3]={0.0,0.0,0.0};
//double omega[3]={0.0,0.0,0.0};
double xc=nx/2.+0.5;
double yc=ny/2.+0.5;
double zc=nz/2.+0.5;
int inew,jnew,knew,lnew;
//double Udotv;
double faut,fau[lbq*lbd],tuq[lbq*lbd];
double cx,cy,cz;
//double partwallvel[3]={0.0,0.0,0.0};
//double addm;
int jstart=2,jend=ny-1;
if(isdragboun) {jstart=1;jend=ny-1;}/*Because we are calculating force only on one wall*/
for(int k=1;k<=nz;k++) {
  for(int j=jstart;j<=jend;j++) {
      for(int i=1;i<=nx;i++) {
	lpt = (i*ny2+j)*nz2+k;
	if(latw->w[lpt]!=0) {continue;}
	for(int m=0;m<lbq;m++) {
	  inew=i+latv->xi[m*lbd];
	  jnew=j+latv->xi[m*lbd+1];
	  knew=k+latv->xi[m*lbd+2];
	  lnew=(inew*ny2+jnew)*nz2+knew;
          if(latw->w[lnew]==swall) {
	    cx = i+0.5*latv->xi[m*lbd+0]-xc;
	    cy = j+0.5*latv->xi[m*lbd+1]-yc;
	    cz = k+0.5*latv->xi[m*lbd+2]-zc;
	    /*Ladd's method*/
//	    partwallvel[0] = latw->bodyomega[1]*cz - latw->bodyomega[2]*cy;
//	    partwallvel[1] = latw->bodyomega[2]*cx - latw->bodyomega[0]*cz;
//	    partwallvel[2] = latw->bodyomega[0]*cy - latw->bodyomega[1]*cx;
//	    Udotv=partwallvel[0]*latv->xi[m*lbd+0]+partwallvel[1]*latv->xi[m*lbd+1]+partwallvel[2]*latv->xi[m*lbd+2];
	    faut=latv->fnew[lpt*lbq+m]+latv->fnew[lnew*lbq+latv->complement[m]];
	    //addm=-6*latv->wt[m]*rho0*Udotv;///lat->cs2;
	    //faut=2*latv->fnew[lpt*lbq+m]+addm;
	    /*We are calculating the force on the wall using momentum exchange method suggested by Ladd. However, I don't understand his equation 3.12 (in 1994 JFM which considers fluid inside the particle), instead his modified equation 14 in Aidun's article, Vol 81, 1995, Journal of Statistical Physics page 49 can be used. If you look at the expression used right now, it is much more intutitve. We are calculating the momentum exchanged between the particle and fluid when the streaming step occurs. This is according to eqn 15, and the previous equation suggested by Mei et al, PRE, 65, 041203. This expression is actually by Ladd, but he finally used something more complicated. However the time stepping method has to be that suggested by the Ladd, meaning use of eqns: 3.18 for force smoothing and 3.21 for angular velocity evaluation are also needed to get a stable code.*/
	    fau[m*lbd+0]=faut*latv->xi[m*lbd+0];
	    fau[m*lbd+1]=faut*latv->xi[m*lbd+1];
	    fau[m*lbd+2]=faut*latv->xi[m*lbd+2];
	    tuq[m*lbd+0] = cy*fau[m*lbd+2] - cz*fau[m*lbd+1];
	    tuq[m*lbd+1] = cz*fau[m*lbd+0] - cx*fau[m*lbd+2];
	    tuq[m*lbd+2] = cx*fau[m*lbd+1] - cy*fau[m*lbd+0];
	    torque[0]+=tuq[m*lbd+0]; force[0]+=fau[m*lbd+0];
	    torque[1]+=tuq[m*lbd+1]; force[1]+=fau[m*lbd+1];
	    torque[2]+=tuq[m*lbd+2]; force[2]+=fau[m*lbd+2];
//	    num+=2*latv->fnew[lpt*lbq+m]*(cx*latv->xi[m*lbd+1] - cy*latv->xi[m*lbd+0]);
//	    den+=6*latv->wt[m]*rho0*(cx*latv->xi[m*lbd+1] - cy*latv->xi[m*lbd+0])*(cx*latv->xi[m*lbd+1] - cy*latv->xi[m*lbd+0]);
	}}
} } }
/*Ladd's method - next 12 lines, other method is implemented only for cylinder rotating which is the 13th line*/
/*Following is Ladd's eqn 3.18 to smoothen torques*/
latw->torque[0]=0.5*(torque[0]+latw->torqueold[0]); latw->torqueold[0]=torque[0];
latw->torque[1]=0.5*(torque[1]+latw->torqueold[1]); latw->torqueold[1]=torque[1];
latw->torque[2]=0.5*(torque[2]+latw->torqueold[2]); latw->torqueold[2]=torque[2];
latw->forceb[0]=0.5*(force[0]+latw->forcebold[0]); latw->forcebold[0]=force[0];
latw->forceb[1]=0.5*(force[1]+latw->forcebold[1]); latw->forcebold[1]=force[1];
latw->forceb[2]=0.5*(force[2]+latw->forcebold[2]); latw->forcebold[2]=force[2];
///*Following is Ladd's eqn 3.21 to calculate angular velocity*/
//if(isrotn==1) {
//omega[0]=latw->bodyomega[0]; omega[1]=latw->bodyomega[1]; omega[2]=latw->bodyomega[2];
//latw->bodyomega[0]=latw->bodyomegaold[0]+2.0*latw->torque[0]/momofi;
//latw->bodyomega[1]=latw->bodyomegaold[1]+2.0*latw->torque[1]/momofi;
//latw->bodyomega[2]=latw->bodyomegaold[2]+2.0*latw->torque[2]/momofi;
//latw->bodyomegaold[0]=omega[0];latw->bodyomegaold[1]=omega[1]; latw->bodyomegaold[2]=omega[2];
//};
}
