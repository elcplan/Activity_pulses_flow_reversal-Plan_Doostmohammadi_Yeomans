//This is the main file
//*This is a temporary working file - until verified, that restructures the code of Luuk*/
/////////////////////////////////// START of CODE /////////////////////////////////////////

//Includes all the files and libraries to be used
#include "include.c" 

int main() {
////////////////// Step 1: Initialisation ////////////////////////////////////////////////////

//*Lattice Boltzmann initialisation and setting parameters*/
//This function is defined in lb_d3q15.c. Currently no other LBM scheme written.
lblattice *mlat=lbsetting();

//*Liquid Crystal initialisation and setting parameters*/
//This function is defined in lc_func.c; qintmethod input in parameters.h
lclattice *qlat=lcsetting(qintmethod); 

//*Defects initialisation and setting if required*/
//This function is defined in op_defects.c
deflattice *dlat=defsetting(qlat);     

//*Autocorr calculations setting if required*/
//This function is defined in op_correlations.c
calccorr *calcc=calccorrmemallocate(); 

//*Initialising geometry if any (initially written for wedge)*/
//This function is defined in geom_wedge.c, and printing it in write.c
wedge *glat=wedge_initialise(mlat);
if(iswedgeprint) printing_geometry(glat);

//Initial and boundary conditions
//These functions are defined below.
printf("IC.\n");
initial_conditions(mlat,qlat,glat,finitcond,qinitcond,phiinitcond,cinitcond,ninitx,ninity,ninitz);
boundary_conditions(mlat,qlat,glat,fbouncond,qbouncond,phibouncond,nbounx,nbouny,nbounz,nbounref);

//Forcings:first argument for bodyforce, 2nd for passive stress, 3rd for active stress
//This function is define below.
forcings(mlat,qlat,forcecondb,forcecondp,forceconda);

///////////////// Step 2: Checking consistencies /////////////////////////////////////////////
//Checking consistency before running
//This function is defined below.
checkconds(mlat,qlat,glat,dlat,calcc);

///////////////// Step 3: Main program////////////////////////////////////////////////////////
//Functions defined below, mainfunctions defined in initialcalcs
initialcalcs(mlat,qlat,glat,dlat,calcc);
(*mainfunctions)(mlat,qlat,glat,dlat,calcc);
printf("Done.\n");
}

////////////////////////////////////////////////////////////////////////////////////////////////
///////////////// END OF MAIN FILE. Below are (some of) the functions used above ///////////////
////////////////////////////////////////////////////////////////////////////////////////////////

// Functions defined below are:
// 1. initial_conditions
// 2. boundary_conditions
// 3. forcings
// 4. checkconds
////////////////
// 5. initialcalcs and its supporting functions
// normalmain, indfollowmain, lbhydrodynamics, nohydrodynamics, liqcrdynamics, defectdynamics, dataanalysison/off

void initial_conditions(lblattice *latv, lclattice *latc, wedge *latw, int i, int j, int k, int l, double dirx, double diry, double dirz) {
if ( i != 10 ) {if((tini>0)&&(i!=0)) {printf("Initial f data will be read \n"); };};//i=0;};};
if ( j != 10 ) {if((tini>0)&&(j!=0)) {printf("Initial q data will be read \n"); };};//j=0;};};
if ( k != 10 ) {if((inphase)&&(tini>0)&&(k!=0)) {printf("Initial phi data will be read \n");};};// k=0;};};
int i_min=0,i_max=nx2;

initial_conditions_lc(latc,j,k,l,dirx,diry,dirz,&i_min,&i_max);	//see lc_init.c
initial_conditions_lb(latv,latc,i,i_min,i_max);			//see lb_init.c
if(isgeom) modify_initial_conditions_lc(latc,latw);
if(isgeom) find_for_anchoring_lc(latc,latw);
if(iswithcelldiv) celldivision_init(latc);
return;
}

void boundary_conditions(lblattice *latv, lclattice *latc, wedge *latw, int i, int j, int k, double dirx, double diry, double dirz, int r) {
boundary_conditions_lb(latv, i);
(*latv->bc_func)(latv,latc,latw,&latv->f[0],lbq,tini);
boundary_conditions_lc(latc, latw, i, j, k, dirx, diry, dirz, r);
(*latc->bc_func)(latv,latc,latw,&latc->q[0],lcq);
if(iswithpoly){(*latc->bc_func)(latv,latc,latw,&latc->c[0],lcc);};
(*latc->bc_funcphi)(latv,latc,latw,&latc->phi[0],1);
if(impflow==0) (*latc->bc_derv)(latv,latc,latw,&latv->u[0],lbd,tini);
return;
}

void forcings(lblattice *latv, lclattice *latc, int i, int j, int k) {
if(i==0) {latv->bforce[0]=0.0;latv->bforce[1]=0.0;latv->bforce[2]=0.0;}
if(j==0) {};
if(k==0) {};
switch (i+j+k) {
case 0:
  latv->force_func=&nothingforce;
break;
case 1:
  if(i==1) {
    bodyforcecalc(latv);
    latv->force_func=&nothingforce;}
  else if(j==1) {
    latv->force_func=&liqcforcecalc;}
  else {
    printf("Case not defined yet\n");
    system("pause");
    return;}
break;
case 2:
  if(i==0) {
    latv->force_func=&liqcforcecalc;}
  else if((i==1)&&(j==1)) {
    bodyforcecalc(latv);
    latv->force_func=&liqcforcecalc;}
  else {
    printf("Case not defined yet\n");
    system("pause");
    return;}
break;
case 3:
    if((i==1)&&(j==1)&&(k==1)) {
    bodyforcecalc(latv);
    latv->force_func=&liqcforcecalc;}
  else {
    printf("Case not defined yet\n");
    system("pause");
    return;}
break;
  }
latc->vstress=latv->vstress;/*Viscous stress accessible for latc variable as well*/
return;
}

void checkconds(lblattice *latv, lclattice *latc, wedge *latw, deflattice *latd, calccorr *calcc) {
int ret=0;
if(noflow) {printf("\nCalculations without any hydrodynamics\n");}
if(noliqc) {printf("Calculations without any liquid crystal dynamics\n\n");}
//if(qnoise) {if(qintmethod!=3) {ret=ret+1;printf("noise in q, is consistent integration method?\n");}}
if(inphase) {if(qbouncond!=phibouncond) {ret=ret+1;printf("Inconsistent boundary conditions for Q and phi\n");}}
if(inphase) {if((qinitcond!=phiinitcond)&&(!noliqc)) {ret=ret+1;printf("Inconsistent initial conditions for Q and phi\n");}}
if(iswithpoly) {if(qbouncond!=cbouncond) {ret=ret+1;printf("Inconsistent boundary conditions for Q and C\n");}}
if(isgeom)  {if(sconst!=0) {ret=ret+1;printf("Geometry not done yet, Need to expand lpv in wedge.c to 26 elements and corresponding modifications of lpv whereever needed.\n");}}
//if(isgeom)  {if(inphase) {ret=ret+1;printf("Geometry not done yet, Probably need to expand lpv in wedge.c to 26 elements and corresponding modifications of lpv whereever needed, for eg: in laplacian calculations.\n");}}
if(isbox)  {if(((int)(boxdim1)%2)==1) {ret=ret+1;printf("Inside box dimensions should be even number.\n");}}
if((fbouncond==4)&&(shearrate*ny/2>0.1)) {ret=ret+1;printf("\nShear rate is too large, boundary velocity > 0.1, Reduce shear rate or implement multiple LE planes\n");}
if((isbox==1)||(iscir==1)) {if((fbouncond<5)&&(qbouncond<5)){ret=ret+1;printf("\nInconsistent boundary conditions with geometry\n");}}
if((iscir==1)&&(numofpart>1)) {if((forcea)||(isdragbody)){ret=ret+1;printf("\nForce evaluation for multiple particles not implemented yet\n");}}
if(ret>0) {printf("\n"); exit(ret);}
return ;
}

//////////////////////////////////////////////////////////////////////////////////////////////////
void initialcalcs(lblattice *latv, lclattice *latc, wedge *latw, deflattice *latd,calccorr *calcc) {
isdrag=(isdragbody)||(isdragboun);
isbulk=(isnotbulk==0);
isvortalign=(isnotvortalign==0);
if(qnoise) {qnoise_flux=(nz==1)?&qnoise_fluxinxy:&qnoise_fluxin3d;} else {qnoise_flux=&qnoise_fluxnone;}
mainfunctions=&normalmain;
advective_flux=noflowadvect?&advective_fluxoff:&advective_fluxon;
corotatnl_flux=noflowcortan?&corotatnl_fluxoff:&corotatnl_fluxon;
diffusive_flux_phi=inphase?&diffusive_flux_phion:&diffusive_flux_phioff;
advective_flux_phi=inphase?&advective_flux_phion:&advective_flux_phioff;
phi_fluxcalc=inphase?&phi_fluxcalcon:&phi_fluxcalcoff;
if(nocollisions) {colliding=&nocolliding;}
else {colliding=&lbcolliding;}
if(noflow||(impflow==1)) {hydrodynamics=&nohydrodynamics;}
else if(drymat) {hydrodynamics=&dryhydrodynamics;}
  else {hydrodynamics=&lbhydrodynamics;}
hydrocalc(latv);
if(impflow==0) (*latc->bc_derv)(latv,latc,latw,&latv->u[0],lbd,tini);
veldirprinting(latv,latc,latw,tini);
freeenergyprinting(latv,latc,latw,tini);
stresscalc(latv,latc,latw,tini);
if(defects||trackdef||indtrack) {
  getdefects(latv, latc, latw, latd);
  defectsprinting(&latc->dcharge[0],tini);}
if(trackdef) {
  latd->nd0=deftagging(latd,tini);
  alldefectstrackprinting(latd,tini);}
if(indtrack) {
  mainfunctions=&indfollowmain;
  latd->nd0=inddeftagging(latd,tini);
  alldefectstrackprinting(latd,tini);}
if(autocorrcalculations||spatcorrcalculations) {
  vorticity=&vorticityon;
  dataanalysis=&dataanalysison;}
else{
  vorticity=&vorticityoff;
  dataanalysis=&dataanalysisoff;}
autocorrcalc=autocorrcalculations?&autocorrcalcon:autocorrcalcoff;
spatcorrcalc=spatcorrcalculations?&spatcorrcalcon:spatcorrcalcoff;
if(tracers) {
  tracerlocinitialise(calcc->tracc);
  dataanalysis=&dataanalysison;}
tracertrack=tracers?&tracertrackon:&tracertrackoff;
(*dataanalysis)(tini, latv, latc, latw, latd, calcc);
if((marker&&iscir)) markerprinting(latv, latc, latw, 0);
if((isrotn&&iscir)) angvelprinting(latv, latc, latw, 0);
if(issingcelld) initiate_celld(latv, latc, latw, 0);
return;
}

void normalmain(lblattice *mlat, lclattice *qlat, wedge *glat, deflattice *dlat, calccorr *calcc) {
for(int t=tini+1;t<=tmax;t++) {
  liqcrdynamics(mlat,qlat,glat,t);
  (*hydrodynamics)(mlat,qlat,glat,t);
  defectdynamics(mlat,qlat,glat,dlat,t);
  (*dataanalysis)(t,mlat,qlat,glat,dlat,calcc);
if (t%writ==0){printf(".....................The time now is........................t=%d.\n",t);
printing(mlat,qlat,glat,dlat,t);}
}
return;
}

void indfollowmain(lblattice *mlat, lclattice *qlat, wedge *glat, deflattice *dlat, calccorr *calcc) {
for(int t=tini+1;t<=tmax;t++) {
  liqcrdynamics(mlat,qlat,glat,t);
  if(indtrack) {/*This particular part is to do follow up without hydrodynamics*/
    if(t<deft) {(*hydrodynamics)(mlat,qlat,glat,t);}
    else if(t==deft) {init_stag(mlat);}
    else {}/*Do nothing*/
  }
  else {(*hydrodynamics)(mlat,qlat,glat,t);}
  defectdynamics(mlat,qlat,glat,dlat,t);
  printing(mlat,qlat,glat,dlat,t);
  if((t>deft)&&(*dlat->defect_liv==0)) break;
}
return;
}

void lbhydrodynamics(lblattice *latv, lclattice *latc, wedge *latw, int t)
{
(*latv->force_func)(latv, latc, latw);
(*colliding)(latv,latc,latw);
(*latv->bc_func)(latv,latc,latw,&latv->fnew[0],lbq,t);
geometryrotn(latv,latc,latw,t);/*It should be here as collided populations after bc application are needed to calculate torque*/
//geometryrotn is defined below
streaming(latv,latw);
hydrocalc(latv);
(*latc->bc_derv)(latv,latc,latw,&latv->u[0],lbd,t);
return;
}

void nohydrodynamics(lblattice *latv, lclattice *latc, wedge *latw, int t){
/*Do nothing*/
return;
}

void liqcrdynamics(lblattice *latv, lclattice *latc, wedge *latw,int t) {
(*latc->methodofintg)(latv, latc, latw, t, timestep,1);/*last argument is for stress calculation which wil be modified on course*/
(*latc->bc_derv)(latv,latc,latw,&latc->bstress[0],lcd*lcd,t);

////////////////////////////////////////////////// Emmanuel edit
/*
if (t%10==0 && inphase){
FILE *traceptr;
char nname[500];
sprintf(nname,"%s/output/poly.dat",DPATH);
int N_phi_in=0,N_phi_bound=0,N_phi_out=0;
double phi_in=0.0,phi_bound=0.0,phi_out=0.0;
double c_xx_in=0.0, c_xy_in=0.0, c_yy_in=0.0;
double c_xx_bound=0.0, c_xy_bound=0.0, c_yy_bound=0.0;
double c_xx_out=0.0, c_xy_out=0.0, c_yy_out=0.0;
double phi_crit_out=0.20,phi_crit_in=0.95;
double *phi=&latc->phi[0];
double *c;
if(iswithpoly) c=&latc->c[0];

for(int i=1;i<=nx;i++) {
for(int j=1;j<=ny;j++) {
for(int k=1;k<=nz;k++) {
int lpt = (i*ny2+j)*nz2+k;
int lptcc=lpt*lcc;
if(phi[lpt]<phi_crit_out)//out of the cell
{N_phi_out+=1;
phi_out+=phi[lpt];
if(iswithpoly){
c_xx_out+=c[lptcc];
c_yy_out+=c[lptcc+1];
c_xy_out+=c[lptcc+3];
}}
else if(phi[lpt]>phi_crit_in)//inside the cell
{N_phi_in+=1;
phi_in+=phi[lpt];
if(iswithpoly){
c_xx_in+=c[lptcc];
c_yy_in+=c[lptcc+1];
c_xy_in+=c[lptcc+3];
}}
else //in the boundary
{N_phi_bound+=1;
phi_bound+=phi[lpt];
if(iswithpoly){
c_xx_bound+=c[lptcc];
c_yy_bound+=c[lptcc+1];
c_xy_bound+=c[lptcc+3];
}};

}}}//end i,j,k

phi_in/=N_phi_in;
phi_out/=N_phi_out;
phi_bound/=N_phi_bound;

traceptr=fopen(nname,"a");
if(iswithpoly){
c_xx_in/=N_phi_in;
c_yy_in/=N_phi_in;
c_xy_in/=N_phi_in;
c_xx_bound/=N_phi_bound;
c_yy_bound/=N_phi_bound;
c_xy_bound/=N_phi_bound;
c_xx_out/=N_phi_out;
c_yy_out/=N_phi_out;
c_xy_out/=N_phi_out;

fprintf(traceptr,"%d %f %f %f %d %d %d %f %f %f %f %f %f %f %f %f \n",t,phi_in,phi_bound,phi_out,
N_phi_in,N_phi_bound,N_phi_out,
c_xx_in, c_xy_in, c_yy_in,
c_xx_bound, c_xy_bound, c_yy_bound,
c_xx_out, c_xy_out, c_yy_out);
}
else {
fprintf(traceptr,"%d %f %f %f %d %d %d\n",
t,phi_in,phi_bound,phi_out,
N_phi_in,N_phi_bound,N_phi_out);
}

fclose(traceptr);

}
*/
///////////////////////////////////////////////// end Emmanuel edit


if(stress||forcea||isdrag) {/*Not required usually*/
  (*latc->bc_func)(latv,latc,latw,&latc->presure[0],1);
  (*latc->bc_func)(latv,latc,latw,&latc->estress[0],lcd*2);
  (*latc->bc_func)(latv,latc,latw,&latc->vstress[0],lcd*2);}
if(isallcelld) {modify_celldlocs(latc, t);}
return;
}

void defectdynamics(lblattice *latv, lclattice *latc, wedge *latw, deflattice *latd, int tm) {
if((trackdef)||indtrack||((defects)&&(tm%writdefects==0))) {
  getdefects(latv, latc, latw, latd);}
if(trackdef) {
  trackdefects(latd,tm);
}
if(indtrack) {
  indtrackdefects(latd,tm);
}
}

void dataanalysison(int tm, lblattice *latv, lclattice *latc, wedge *latw, deflattice *latd, calccorr *calcc) {
(*vorticity)(latv, latc, latw);
(*autocorrcalc)(latv, latc, latw, calcc->autoc, tm);
(*spatcorrcalc)(latv, latc, latw, calcc->spatc, tm);
(*tracertrack)(latv, calcc->tracc, tm);
return;
}

void dataanalysisoff(int tm, lblattice *latv, lclattice *latc, wedge *latw, deflattice *latd, calccorr *calcc) {
/*Do nothing*/
return;
}

// This function needed in lbhydrodynamics
void geometryrotn(lblattice *mlat, lclattice *qlat, wedge *glat, int tm) {
if(isrotn) {angvelcalc(mlat,qlat,glat,tm);}                                
if(isdrag) {dragftcalc(mlat,qlat,glat,tm);}                                
return;                                                                    
}                                                                         

//END
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

// Following are comments of previous users of the code. Must be checked
/*
//To do list
//-2 change u calculation with force
 //-1 Change f initial conditions, now its random for testing
 * 0. finitialise with feq and not with f/15
 * 1. Multiple time steps for q integration
  Reduction of spurious velocities throgh cates method,need careful reading of paper, several things need to be changed
 . Use of predictor-corrector algorithm for timestepping
 */
