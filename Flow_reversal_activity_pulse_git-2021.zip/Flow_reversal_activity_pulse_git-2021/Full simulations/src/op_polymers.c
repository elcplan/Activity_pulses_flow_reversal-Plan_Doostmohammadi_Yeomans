/*This file contains functions related to taking into consideration
 * the presence of polymers in the system. Since this comes in as an option
 * rather than the rule, these functions will simply be called within the 
 * usual loops of the liquid crystal code.*/

// The variables must be defined in the header file defs_lblcwedge.h
// in the structure lclattice. Memory allocation is done elsewhere,
// generally when Q and phi are also allocated.


void poly_initialise(lclattice *latc){ // Located in lc_funcc.c. // Emmanuel: verified to run.
        latc->c = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));		//Polymer conformation tensor
        latc->cnew = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));		//updated polymer conformation tensor
	latc->cflux = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));		//change in c every timestep
        latc->l = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));		//Polymer conformation tensor
        latc->lnew = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));		//updated polymer conformation tensor
	latc->lflux = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));		//change in c every timestep
	latc->fe_poly = (double *)malloc(nx2*ny2*nz2*sizeof(double));		//free energy from polymer
	latc->fe_qc = (double *)malloc(nx2*ny2*nz2*sizeof(double));		//free energy from polymer
	latc->h_poly = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));	//molecular field due to polymer
	latc->polystress = (double *)malloc(nx2*ny2*nz2*lcc*lcc*sizeof(double));	/*stresses for polymer*/
		//Emmanuel: not symmetric
	//latc->phi_c = (double *)malloc(nx2*ny2*nz2*sizeof(double));		//concentration of polymers
	return;
}

////////////////////// for polymers
void derivatives_C(double *c,double *dcx, double *dcy, double *dcz, int *lps) {
// In the absence of a geometry, lpv is simply lps, giving the indices of the neighbouring points of 
// the point of interest (at i,j,k) wrt to all the points (see derivativesN)
// As can be inferred here, c is structured such that the lcc=6 consecutive components
// (starting from an index divisible by d) refer to the lcc=6 components(degrees of freedom) of c at the point (i,j,k).
// By default, I suppose that 0-5 refer to components 11,22,33,12,13,23. //Emmanuel: their default
// Here, dcx has 6 components, one for each component of c. Same for dcy and dcz.
    int lpxc=lps[0]*lcc, lmxc=lps[1]*lcc, lpyc=lps[2]*lcc, lmyc=lps[3]*lcc, lpzc=lps[4]*lcc, lmzc=lps[5]*lcc;
    for(int m=0; m<lcc; m++) {
        dcx[m]=0.5*(c[lpxc+m]-c[lmxc+m]);
        dcy[m]=0.5*(c[lpyc+m]-c[lmyc+m]);
        dcz[m]=0.5*(c[lpzc+m]-c[lmzc+m]);
    };
    return;
}

void stretching_flux_C(double *c, double *strflx, double *vor) {
//This function refers to C \Sigma-\Sigma C term in PRE 032702 (2016) in the equation for the polymer conformation C
//note vor at the diagonals is zero.
      	strflx[0]=2*(c[3]*vor[0]+c[4]*vor[1]);
    	strflx[1]=-2*(c[3]*vor[0]-c[5]*vor[2]);
    	strflx[2]=-2*(c[4]*vor[1]+c[5]*vor[2]);
    	strflx[3]=-(vor[0]*(c[0]-c[1])-c[4]*vor[2]-vor[1]*c[5]);
    	strflx[4]=-(vor[1]*(c[0]-c[2])+c[3]*vor[2]-vor[0]*c[5]);
    	strflx[5]=-(vor[2]*(c[1]-c[2])+c[3]*vor[1]+vor[0]*c[4]);
//printf("Here: %f.\n",strflx[3]);
    return;
}

void stretching2_flux_C(double *c, double *strflx, double *stn) {
//This function refers to polymer term with coefficient a in PRE 032702 (2016) in the equation for the polymer conformation C
      	strflx[0]+=2.0*a_poly*(c[0]*stn[0]+c[3]*stn[3]+c[4]*stn[4]);
    	strflx[1]+=2.0*a_poly*(c[3]*stn[3]+c[1]*stn[1]+c[5]*stn[5]);
    	strflx[2]+=2.0*a_poly*(c[4]*stn[4]+c[5]*stn[5]+c[2]*stn[2]);
    	strflx[3]+=a_poly*(c[0]*stn[3]+c[3]*stn[1]+c[4]*stn[5]+stn[0]*c[3]+stn[3]*c[1]+stn[4]*c[5]);
    	strflx[4]+=a_poly*(c[0]*stn[4]+c[3]*stn[5]+c[4]*stn[2]+stn[0]*c[4]+stn[3]*c[5]+stn[4]*c[2]);
    	strflx[5]+=a_poly*(c[3]*stn[4]+c[1]*stn[5]+c[5]*stn[2]+stn[3]*c[4]+stn[1]*c[5]+stn[5]*c[2]);
//printf("strain: %f, %f, %f.\n",stn[0],stn[3],stn[4]);
//printf("strain: %f, %f, %f.\n",stn[2],stn[1],stn[5]);
//printf("cloc: %f, %f, %f.\n",c[0],c[3],c[4]);	
//printf("cloc: %f, %f, %f.\n",c[2],c[1],c[5]);
//printf("There: %f.\n",strflx[3]);
    return;
}

void relaxation_flux_C(double *c, double *relflx, double *stn, double *h_c){
// This function calculates the relaxation term (with polymer time, but not the diffusion) in PRE 032702 (2016) in the equation for the polymer conformation C
/*	relflx[0]=2.0*(c[0]*h_c[0]+c[3]*h_c[3]+c[4]*h_c[4]);
	relflx[1]=2.0*(c[1]*h_c[1]+c[3]*h_c[3]+c[5]*h_c[5]);
	relflx[2]=2.0*(c[2]*h_c[2]+c[4]*h_c[4]+c[5]*h_c[5]);
	relflx[3]=c[3]*(h_c[0]+h_c[1])+h_c[3]*(c[0]+c[1])+c[5]*h_c[4]+c[4]*h_c[5];
	relflx[4]=c[4]*(h_c[0]+h_c[2])+h_c[4]*(c[0]+c[2])+c[5]*h_c[3]+c[3]*h_c[5];
	relflx[5]=c[5]*(h_c[1]+h_c[2])+h_c[5]*(c[1]+c[2])+c[3]*h_c[4]+c[4]*h_c[3];
*/
double A_c=1.0/tau_poly;
	relflx[0]=-A_c*(c[0]-1.0);
	relflx[1]=-A_c*(c[1]-1.0);
	relflx[2]=-A_c*(c[2]-1.0);
	relflx[3]=-A_c*(c[3]);
	relflx[4]=-A_c*(c[4]);
	relflx[5]=-A_c*(c[5]);

/*printf("%f,%f,%f,%f,%f,%f.\n",2.0*(c[0]*h_c[0]+c[3]*h_c[3]+c[4]*h_c[4])+A_c*(c[0]-1.0),
2.0*(c[1]*h_c[1]+c[3]*h_c[3]+c[5]*h_c[5])+A_c*(c[1]-1.0),
2.0*(c[2]*h_c[2]+c[4]*h_c[4]+c[5]*h_c[5])+A_c*(c[2]-1.0),
c[3]*(h_c[0]+h_c[1])+h_c[3]*(c[0]+c[1])+c[5]*h_c[4]+c[4]*h_c[5]+A_c*(c[3]),
c[4]*(h_c[0]+h_c[2])+h_c[4]*(c[0]+c[2])+c[5]*h_c[3]+c[3]*h_c[5]+A_c*(c[4]),
c[5]*(h_c[1]+h_c[2])+h_c[5]*(c[1]+c[2])+c[3]*h_c[4]+c[4]*h_c[3]+A_c*(c[5])
);
*/
}

void diffusion_flux_C(double *c, int l, int *lps, double *difflx){
// This function calculates the laplacian term in PRE 032702 (2016) in the equation for the polymer conformation C (ellsq/tau_c to be multiplied later)
for(int m=0; m<lcc; m++) {
	difflx[m]=c[lps[0]*lcc+m]+c[lps[1]*lcc+m]+c[lps[2]*lcc+m]
		+c[lps[3]*lcc+m]+c[lps[4]*lcc+m]+c[lps[5]*lcc+m]
		-6.0*c[l*lcc+m];
/*printf("lpt=%d:%f,%f,%f,.\n %f,%f,%f, ------%f.\n",
l,
c[lps[0]*lcc+m],c[lps[1]*lcc+m],c[lps[2]*lcc+m],
c[lps[3]*lcc+m],c[lps[4]*lcc+m],c[lps[5]*lcc+m],
		-6.0*c[l*lcc+m]);
*/
	}
}

double determinant_matrix(double *matrix){
//This gives the determinant of a symmetric matrix only, especially defined for a 3x3 matrix C
double determinant;

determinant=matrix[0]*(matrix[1]*matrix[2]-matrix[5]*matrix[5])
		-matrix[3]*(matrix[3]*matrix[2]-matrix[4]*matrix[5])
		+matrix[4]*(matrix[3]*matrix[5]-matrix[4]*matrix[1]);
if (determinant==0) printf("Warning, det==0.\n");
return (determinant);
}

void invert_matrix(double *matrix, double *newmatrix, int lpt){
//This inverts a symmetric matrix only, especially defined for a 3x3 matrix C
double determinant;

determinant=matrix[0]*(matrix[1]*matrix[2]-matrix[5]*matrix[5])
		-matrix[3]*(matrix[3]*matrix[2]-matrix[4]*matrix[5])
		+matrix[4]*(matrix[3]*matrix[5]-matrix[4]*matrix[1]);
//determinant_matrix(matrix);
//printf("determinant=%f.\n",determinant);
if (determinant==0) {
printf("ERROR at lpt=%d. Polymer conformation tensor C must be invertible.\n",lpt);
printf("Matrix is %f,%f,%f.\n",matrix[0],matrix[3],matrix[4]);
printf("Matrix is %f,%f,%f.\n",matrix[2],matrix[1],matrix[5]);
exit (EXIT_FAILURE);
};

determinant=1/determinant;
newmatrix[0]=(matrix[1]*matrix[2]-matrix[5]*matrix[5])*determinant;
newmatrix[1]=(matrix[0]*matrix[2]-matrix[4]*matrix[4])*determinant;
newmatrix[2]=(matrix[0]*matrix[1]-matrix[3]*matrix[3])*determinant;
newmatrix[3]=-(matrix[3]*matrix[2]-matrix[5]*matrix[4])*determinant;
newmatrix[4]=-(matrix[4]*matrix[1]-matrix[3]*matrix[5])*determinant;
newmatrix[5]=-(matrix[0]*matrix[5]-matrix[3]*matrix[4])*determinant;
//I know this is inefficient since we can swap the addresses, but I am not yet an expert.
}

void init_poly_eq(lclattice *lat) {//Emmanuel:checked
int l;
for(int i=0;i<=nx2;i++) {
   for(int j=0;j<=ny2;j++) {
      for(int k=0;k<=nz2;k++) {
        l = ((i*ny2+j)*nz2+k)*lcc;
	lat->c[l]  = 1.0;
        lat->c[l+1]= 1.0;
	lat->c[l+2]= 1.0;
        lat->c[l+3]= 0.0;
        lat->c[l+4]= 0.0;
        lat->c[l+5]= 0.0;
//printf("InitC is: %f,%f,%f,%f,%f,%f,\n",lat->c[l],lat->c[l+1],lat->c[l+2],lat->c[l+3],lat->c[l+4],lat->c[l+5]);

//log conformation
	lat->l[l]=sqrt(lat->c[l]);
	lat->l[l+3]=lat->l[l+3]/lat->l[l];
	lat->l[l+4]=lat->l[l+4]/lat->l[l];
	lat->l[l+1]=sqrt(lat->c[l+1]-lat->l[l+3]*lat->l[l+3]);
	lat->l[l+5]=(lat->c[l+5]-lat->l[l+3]*lat->l[l+4])/lat->l[l+1];
	lat->l[l+2]=sqrt(lat->c[l+2]-lat->l[l+4]*lat->l[l+4]-lat->l[l+5]*lat->l[l+5]);

lat->l[l]=log(lat->l[l]);
lat->l[l+1]=log(lat->l[l+1]);
lat->l[l+2]=log(lat->l[l+2]);
//printf("InitL is : %f,%f,%f,%f,%f,%f,\n",lat->l[l],lat->l[l+1],lat->l[l+2],lat->l[l+3],lat->l[l+4],lat->l[l+5]);
};};};
return;
}


void init_poly_stretch_ran(lclattice *lat){

double theta=M_PI/2.0,phi;
int l;
double mag=0.01, S,dirx,diry,dirz,ndir;
double xylen=polylen;//xylen=2 gives C of trace=3 (identity) in 3d

	double height=phidim1;
    int geo=shape;/*0-for flat,1-for circular*/
    int chk1=0;
    //double xc=nx2/2.+0.5;
    //double xc=nx2/2.+0.5;
    double yc=ny/2.+0.5;
    double yc1=ny/2.+0.5-distance_y*height,yc2=ny/2.+0.5+distance_y*height;
    double xc1=nx/2.+0.5-distance_x*height,xc2=nx/2.+0.5+distance_x*height;
    double zc1=nz/2.+0.5-distance_z*height,zc2=nz/2.+0.5*distance_z*height;

    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k)*lcc;

		if(geo==0) {chk1=(fabs(j-yc)<=height);}
                if(geo==1) {chk1=(sqrt((i-xc1)*(i-xc1)+(j-yc1)*(j-yc1)+(k-zc1)*(k-zc1))<=height)||(sqrt((i-xc2)*(i-xc2)+(j-yc2)*(j-yc2)+(k-zc2)*(k-zc2))<=(height));}
if(chk1) {/*Nematic phase*/
		lat->c[l]  = 1.0;
		lat->c[l+1]= 1.0;
		lat->c[l+2]= 1.0;
		lat->c[l+3]= 0.0;
		lat->c[l+4]= 0.0;
		lat->c[l+5]= 0.0;
}
else{
                S=ran2(&seed)*mag;
                phi=ran2(&seed)*M_PI*2;
                dirx=sin(theta)*cos(phi);
                diry=sin(theta)*sin(phi);
                dirz=cos(theta);

        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
//printf("dir %f,%f.\n",dirx,diry);
        lat->c[l]  = (dirx*dirx)*xylen;
        lat->c[l+1]= (diry*diry)*xylen;
        lat->c[l+2]= 1.0;
        lat->c[l+3]= 0.5*(3.*dirx*diry-0.0);
        lat->c[l+4]= 0.5*(3.*dirx*dirz-0.0);
        lat->c[l+5]= 0.5*(3.*diry*dirz-0.0);
        for(int m=0;m<lcc;m++) { lat->cnew[l+m]=lat->c[l+m]; }
//printf("%f,%f,%f,%f,%f,%f,%f.\n",lat->c[l*lcc],lat->c[l*lcc+1],lat->c[l*lcc+2],lat->c[l*lcc+3],lat->c[l*lcc+4],lat->c[l*lcc+5],lat->c[l*lcc]+lat->c[l*lcc+1]);
}


//log conformation
	lat->l[l]=sqrt(lat->c[l]);
	lat->l[l+3]=lat->l[l+3]/lat->l[l];
	lat->l[l+4]=lat->l[l+4]/lat->l[l];
	lat->l[l+1]=sqrt(lat->c[l+1]-lat->l[l+3]*lat->l[l+3]);
	lat->l[l+5]=(lat->c[l+5]-lat->l[l+3]*lat->l[l+4])/lat->l[l+1];
	lat->l[l+2]=sqrt(lat->c[l+2]-lat->l[l+4]*lat->l[l+4]-lat->l[l+5]*lat->l[l+5]);

lat->l[l]=log(lat->l[l]);
lat->l[l+1]=log(lat->l[l+1]);
lat->l[l+2]=log(lat->l[l+2]);
//printf("%f,%f,%f,%f,%f,%f,\n",lat->l[l],lat->l[l+1],lat->l[l+2],lat->l[l+3],lat->l[l+4],lat->l[l+5]);

}}}//end i,j,k


return;
}

void init_poly_ori_stretch_ran(lclattice *lat){

double theta=M_PI/2.0,phi;
int l;
double mag=0.1, S,dirx,diry,dirz,ndir;
double xylen=polylen;//xylen=2 gives C of trace=3 (identity) in 3d
double cdirx=cinitx;
double cdiry=cinity;
phi=atan2(cdiry,cdirx);

	double height=phidim1;
    int geo=shape;/*0-for flat,1-for circular*/
    int chk1=0;
    //double xc=nx2/2.+0.5;
    //double xc=nx2/2.+0.5;
    double yc=ny/2.+0.5;
    double yc1=ny/2.+0.5-distance_y*height,yc2=ny/2.+0.5+distance_y*height;
    double xc1=nx/2.+0.5-distance_x*height,xc2=nx/2.+0.5+distance_x*height;
    double zc1=nz/2.+0.5-distance_z*height,zc2=nz/2.+0.5*distance_z*height;

    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k)*lcc;
		if(geo==0) {chk1=(fabs(j-yc)<=height);}
                if(geo==1) {chk1=(sqrt((i-xc1)*(i-xc1)+(j-yc1)*(j-yc1)+(k-zc1)*(k-zc1))<=height)||(sqrt((i-xc2)*(i-xc2)+(j-yc2)*(j-yc2)+(k-zc2)*(k-zc2))<=(height));}
if(chk1) {/*Nematic phase*/
		lat->c[l]  = 1.0;
		lat->c[l+1]= 1.0;
		lat->c[l+2]= 1.0;
		lat->c[l+3]= 0.0;
		lat->c[l+4]= 0.0;
		lat->c[l+5]= 0.0;
}
else{
		double noisy=0.1;
	        double rann=phi+noisy*(2*ran2(&seed)-1);
                //S=ran2(&seed)*mag;
                dirx=cos(rann);
        	diry=sin(rann);
		dirz=0.0;
        	ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        	dirx=dirx/ndir;
        	diry=diry/ndir;

//printf("dir %f,%f.\n",dirx,diry);
        lat->c[l]  = (dirx*dirx)*xylen;
        lat->c[l+1]= (diry*diry)*xylen;
        lat->c[l+2]= 1.0;
        lat->c[l+3]= (dirx*diry-0.0);
        lat->c[l+4]= 0.0;//commentelc (dirx*dirz-0.0);
        lat->c[l+5]= 0.0;//commentelc (diry*dirz-0.0);
        for(int m=0;m<lcc;m++) { lat->cnew[l+m]=lat->c[l+m]; }
//printf("InitC is: %f,%f,%f,%f,%f,%f,%f.\n",lat->c[l*lcc],lat->c[l*lcc+1],lat->c[l*lcc+2],lat->c[l*lcc+3],lat->c[l*lcc+4],lat->c[l*lcc+5],lat->c[l*lcc]+lat->c[l*lcc+1]);
}
//log conformation
	lat->l[l]=sqrt(lat->c[l]);
	lat->l[l+3]=lat->l[l+3]/lat->l[l];
	lat->l[l+4]=lat->l[l+4]/lat->l[l];
	lat->l[l+1]=sqrt(lat->c[l+1]-lat->l[l+3]*lat->l[l+3]);
	lat->l[l+5]=(lat->c[l+5]-lat->l[l+3]*lat->l[l+4])/lat->l[l+1];
	lat->l[l+2]=sqrt(lat->c[l+2]-lat->l[l+4]*lat->l[l+4]-lat->l[l+5]*lat->l[l+5]);

lat->l[l]=log(lat->l[l]);
lat->l[l+1]=log(lat->l[l+1]);
lat->l[l+2]=log(lat->l[l+2]);

/*
double lloc[6];
lloc[0]=lat->l[l];
lloc[1]=lat->l[l+1];
lloc[2]=lat->l[l+2];
lloc[3]=lat->l[l+3];
lloc[4]=lat->l[l+4];
lloc[5]=lat->l[l+5];

	lat->c[l]=exp(2*lloc[0]);
	lat->c[l+1]=lloc[3]*lloc[3]+exp(2*lloc[1]);
	lat->c[l+2]=lloc[4]*lloc[4]+lloc[5]*lloc[5]+exp(2*lloc[2]);
	lat->c[l+3]=exp(lloc[0])*lloc[3];
	lat->c[l+4]=exp(lloc[0])*lloc[4];
	lat->c[l+5]=lloc[3]*lloc[4]+exp(lloc[1])*lloc[5];
*/

//printf("InitL is: %f,%f,%f,%f,%f,%f,\n",lat->l[l],lat->l[l+1],lat->l[l+2],lat->l[l+3],lat->l[l+4],lat->l[l+5]);
}}}//end i,j,k


return;
}


void init_poly_ori_stretch_bor(lclattice *lat){

double theta=M_PI/2.0,phi;
int l;
double mag=0.1, S,dirx,diry,dirz,ndir;
double xylen=polylen;//xylen=2 gives C of trace=3 (identity) in 3d
double cdirx=cinitx;
double cdiry=cinity;
phi=atan2(cdiry,cdirx);

	double height=phidim1;
    int geo=shape;/*0-for flat,1-for circular*/
    int chk1=0;
    //double xc=nx2/2.+0.5;
    //double xc=nx2/2.+0.5;
    double yc=ny/2.+0.5;
    double yc1=ny/2.+0.5-distance_y*height,yc2=ny/2.+0.5+distance_y*height;
    double xc1=nx/2.+0.5-distance_x*height,xc2=nx/2.+0.5+distance_x*height;
    double zc1=nz/2.+0.5-distance_z*height,zc2=nz/2.+0.5*distance_z*height;

    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k)*lcc;
		if(geo==0) {chk1=(fabs(j-yc)<=height);}
                if(geo==1) {chk1=(sqrt((i-xc1)*(i-xc1)+(j-yc1)*(j-yc1)+(k-zc1)*(k-zc1))<=height)||(sqrt((i-xc2)*(i-xc2)+(j-yc2)*(j-yc2)+(k-zc2)*(k-zc2))<=(height));}
if(chk1) {/*Nematic phase*/
		lat->c[l]  = 1.0;
		lat->c[l+1]= 1.0;
		lat->c[l+2]= 1.0;
		lat->c[l+3]= 0.0;
		lat->c[l+4]= 0.0;
		lat->c[l+5]= 0.0;
}
else{/*polymer part*/
	if(j<=height+2)
	{
			double noisy=0.1;
			double rann=phi+noisy*(2*ran2(&seed)-1);
		        //S=ran2(&seed)*mag;
		        dirx=cos(rann);
			diry=sin(rann);
			dirz=0.0;
			ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
			dirx=dirx/ndir;
			diry=diry/ndir;

	//printf("dir %f,%f.\n",dirx,diry);
		lat->c[l]  = (dirx*dirx)*xylen;
		lat->c[l+1]= (diry*diry)*xylen;
		lat->c[l+2]= 1.0;
		lat->c[l+3]= (dirx*diry-0.0);
		lat->c[l+4]= 0.0;//commentelc (dirx*dirz-0.0);
		lat->c[l+5]= 0.0;//commentelc (diry*dirz-0.0);
		for(int m=0;m<lcc;m++) { lat->cnew[l+m]=lat->c[l+m]; }
	//printf("InitC is: %f,%f,%f,%f,%f,%f,%f.\n",lat->c[l*lcc],lat->c[l*lcc+1],lat->c[l*lcc+2],lat->c[l*lcc+3],lat->c[l*lcc+4],lat->c[l*lcc+5],lat->c[l*lcc]+lat->c[l*lcc+1]);
	}
	else
	{
			lat->c[l]  = 1.0;
			lat->c[l+1]= 1.0;
			lat->c[l+2]= 1.0;
			lat->c[l+3]= 0.0;
			lat->c[l+4]= 0.0;
			lat->c[l+5]= 0.0;
	}
}
//log conformation
	lat->l[l]=sqrt(lat->c[l]);
	lat->l[l+3]=lat->l[l+3]/lat->l[l];
	lat->l[l+4]=lat->l[l+4]/lat->l[l];
	lat->l[l+1]=sqrt(lat->c[l+1]-lat->l[l+3]*lat->l[l+3]);
	lat->l[l+5]=(lat->c[l+5]-lat->l[l+3]*lat->l[l+4])/lat->l[l+1];
	lat->l[l+2]=sqrt(lat->c[l+2]-lat->l[l+4]*lat->l[l+4]-lat->l[l+5]*lat->l[l+5]);

lat->l[l]=log(lat->l[l]);
lat->l[l+1]=log(lat->l[l+1]);
lat->l[l+2]=log(lat->l[l+2]);

/*
double lloc[6];
lloc[0]=lat->l[l];
lloc[1]=lat->l[l+1];
lloc[2]=lat->l[l+2];
lloc[3]=lat->l[l+3];
lloc[4]=lat->l[l+4];
lloc[5]=lat->l[l+5];

	lat->c[l]=exp(2*lloc[0]);
	lat->c[l+1]=lloc[3]*lloc[3]+exp(2*lloc[1]);
	lat->c[l+2]=lloc[4]*lloc[4]+lloc[5]*lloc[5]+exp(2*lloc[2]);
	lat->c[l+3]=exp(lloc[0])*lloc[3];
	lat->c[l+4]=exp(lloc[0])*lloc[4];
	lat->c[l+5]=lloc[3]*lloc[4]+exp(lloc[1])*lloc[5];
*/

//printf("InitL is: %f,%f,%f,%f,%f,%f,\n",lat->l[l],lat->l[l+1],lat->l[l+2],lat->l[l+3],lat->l[l+4],lat->l[l+5]);
}}}//end i,j,k


return;
}


/*get the polymer length, adapted from sumof*/
double polylength(double *f, int num, int *w,int flag)
{
if(!flag) return 0;
double sum=0.0;
int l,lpt;
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
	    lpt=(i*ny2+j)*nz2+k;
      if(w[lpt]>=0) {
	    for(int m=0;m<3;m++) { //changed for poly length
	    l=lpt*num+m;
	    sum+=f[l];
      }; }; }; }; };
sum/=(nx*ny*nz);
return sum;
}

