/*This file contains all the parameters and constants used in the code */ 
//Emmanuel: Still need to verify all options/parameters, but should work for the intended purpose//
//Note: To simulate activity pulses, you can either run this code several times (change tini, tmax, and activity, and initial conditions) or write a script that automatically does this for you.

/*System size*/
// For the coalescence of equilibrated tactoids with initial lattice size n{x,y,z}_in, one must set nx=2*nx_in, ny=ny_in, nz=nz_in
#define nx 10	/*number of points in x-direction*/
#define ny 100	/*number of points in y-direction*/
#define nz 1    /*number of points in z-direction*/

/*Time information*/
#define tini 0		// Initial time. Generally set to 0 except when reading from previous files
#define tmax 100000		// Final time. Generally corresponds to number of LB timesteps also
#define writ 1000  	// Frequency of writing
#define writfq 10000	// Frequency of writing the fq tensors
const double timestep=1.0;// Do not change.

const int shape=2;	//0 if flat interface, 1 if drop, using mode 7 in qinit and phiinit
			//2 half of x with phi. see lc_init
const double phidim1=20.0; /*Relevant dimensions for option 0,6,7,8,9*/ 

/*Lattice Boltzmann model*/
#define lbd 3		// number of dimensions in LB. Do not change.
#define lbq 15		// number of directions. Do not change.
/*Q model*/
#define lcd 3 		/*Dimensions of domain*/ //Should match lbd
#define lcq 6 		/*Degrees of freedom of Q. Note that Q is symmetric*/ //

/*Time stepping for Q*/
const int nsteps=1;	

/*Random number seed*/
long seed=1000; //orig seed ic1=1000  //ic2=1500 //ic3=124;

/*LB parameters*/
const double taulb=2.5;	// Controls viscosity in the NSE
const double P0=0.25;		/*Do not change-Background pressure*/       

/*Bodyforces*/
const double gx=0.0;
const double gy=0.0;
const double gz=0.0;

/////////////////////////////////////*Liquid crystal parameters*////////////////

/*Free energy parameters for Q - Landau energy */
const double Alc=1.0;		// QQ term
const double Blc=0.0;		// QQQ term //useless since Blceff is redefined in qflux.
const double Clc=0.0;		// QQQQ term //useless since Clceff is redefined in qflux.
const double Klc=0.2;		// grad Q squared term
const double xilc=0.70;		/**Tumbling parameter*/
const double Gammalc=0.5;	/*Rotational Diffusivity*/
const double zetalc=0.015;	/*Activity*/ //Emmanuel lengthscale:sqrt(Klc/zetalc)
const double lambdalc=0.0;	/*Active term in Q evolution*/

/*Phase separation*/ //i.e. if we will use equation for concentration phi
const int inphase=1;		// 1 for phase separation, 0 if none
//if inphase=0, disable stressgrad and prinstress in write.c
//also note coupling of phi in lc_5func.c
const double phi0=1.0;		// ??
const double Aphi=0.1;		// A_phi coefficient concentration
const double Bphi=0.0;		// ??
const double Kphi=0.02;	// K_Phi coefficient
const double Gammaphi=0.005;	// Controlling diffusion in phi term
const double Dlcphi=0.0;	// ??
const double phicrit=0.9;	// Critical phi defines tactoid boundaries

/*Polymer conformation tensor C*/
int iswithpoly=0;		// 1 with polymer, 0 if none
const int polyphicoup=0;	//turns on coupling of C and phi (via 1-phi)
const int lcc=6;		// number of degrees of freedom of C (symmetric)
const double a_poly=1.0;	// relaxation parameter for model, a=1 means Oldroyd-B model, Do not randomly change       
const double tau_poly=10000;	// relaxation time of  polymers, this must never be 0.
//To be defined as a variable during each loop
//const double A_c=0.0010;	//1.0/tau_poly;	//Constant that turns on polymers in the free energy. Corresponds to Alc parameter. must not be 0.
//const double ellsq_poly=0.04*1000.0*0.25;	//Klc*tau_poly*Gammalc?;	
//const double tau_poly_2=5.0;
//const double A_c_2=0.02;
//const double ellsq_poly_2=0.04*5.0*0.25;
const double kappaqc=0.0;	//turns on coefficient of QC in free energy with polymers
const double chiqc=0.0;		//turns on coefficient of QC in free energy with poymers
	//f_QC=kappa Tr(C-I)Tr(Q^2)+2chi Tr(CQ)
	//Emmanuel: propose to have f_QC=kappa Tr(C-I)Tr(Q^2)+2chi Tr((C-I)Q) instead

/*Parameters for cell division //Emmanuel' s version*/
const int iswithcelldiv=0;	//1 if with cell division
const double ratecelldiv=0.0001;//rate of cell division (growth in phi)
const int numcelldiv=1;		//number of cells dividing at a time
const int radcelldiv=5;		//radius of cell in LBM lengths units
const double durcelldiv=1000.0;	//approximate duration of cell growth in LBM time units

/*Parameters for chirality*/
const int ischiral=0;		/*1 for chiral, 0 for non-chiral*/
const double KClc=0.04;		/*Chiral elasticity parameter*/
const double Cpit=2.*M_PI/20.;	/*Chiral pitch parameter*/

/*Some constants*/ 		//Emmanuel: to study what is l2h and l3h
const int sconst=0;		/*0 for single constant, 1 for triple elastic constant*/
const double K2lc=0.0;
const double K3lc=0.0;

/*Parameters for smectic*/
const int issmectic=0;		/*1 for smectic, 0 for non-smectic*/
const double CSme=0.0; 		/* Smectic alignment parameter */

/*Parameters for lyotropic */
const int Beq0=1;		/*0 if yes, otherwise 1 for lyotropic*/ //Emmanuel: Beq0=1 keeps the second coefficient
const double A0lcphi=-0.10;      // Emmanuel: I am not using this
const double eta0lcphi=2.7;    // Emmanuel: I am using this to determine eta/etaphi
const double etaslcphi=0.5;	// Emmanuel: I am not using this
const double phibar=0.5;     	// Emmanuel: I am not using this
const double Lw=0.05;		/*Cross-gradient coefficient for interface, appears in coupling term of concentration phi and Q in free energy*/


////////////////////////////////////////*Integration methods*/
const int qintmethod=1;
/*argument 	1- for euler update, 
 * 		2 -for rk2 update, 
 * 		3-for euler+rk2 update*/


////////////////////////////////////////*Initial conditions*/
double u0[3] = {0.0, 0.0, 0.0}; // initial flow
double rho0 = 1.0; 		// density

/*IC for velocity field u*/
const int finitcond=1;  /*This index for LB, 
		0-to read, 
		1-for stagnant, 
		2- for inlet intial conditions,
		3-for random initials,
		4-imposed bidirectional flow, 
		5-khwithfinitethick, 
		6-genkwhwithfinitethick, 
		7-imposed polynomial flow (adjust n in ac_lb_init.c)*/

/*IC for nematics Q*/    
const int qinitcond=7;
/*		0-to read, 
 *		1 for nematic equilibrium,*** set director below
 *		11 for nematic equilibrium with perturbations,*** set director below
 *		2 for random initial conditions, 
 *		21 for isotropic state, 
 *		3 for a tilt at the middle,*** set director below
 *		4 for the wedge,
 *		5 for bend deformation at the centre,
 *		6-for flat interface,
 *		7-for drop with random director inside,
 *		8-for a membrane floating in 3d space at nz/2,
 *		9-for single pitch,
 *		10-for two equilibrated tactoids
 *		12-see phiinitcond
 */
const double ninitx=1.0,ninity=0.0,ninitz=0.0;   /*set director if choosing option 1,11 or 3*/

/*IC for concentration phi*/ 
const int phiinitcond=7; /*
		0-to read, 
		2 for random initial conditions,
		6-for flat interface, height as dim1,
		7-for drop with random director, radius as phidim1,
		8-for a membrane floating in 3d space at nz/2 with radius phidim1,
		9-for single pitch,
		10-for two equilibrated tactoids
		12-phase separation*/

/*The following distances for options 6,7,8,9*/
const double distance_x=0; /*Distance from centre for two droplets in number of radii*/
const double distance_y=0; /*Distance from centre for multiple droplets in tandem*/
const double distance_z=0; /*Distance from centre for multiple droplets in 3D*/

/*IC for polymer conformation*/
const int cinitcond=1; 	//0=to read
			//1=equlibrium position
			//2=random orientation,stretched polymers
			//3=stretched polymers around a given orientation
			//4=stretched polymers near boundary
const double cinitx=0.5,cinity=0.5,cinitz=0.0;
const double polylen=28.0;

////////////////////////////////////*Boundary conditions*/
const double shearrate=0.0;	/*Imposed shear rate for lee-edwards boundary conditions*/
const int oscillatory=0;	/*0 for no-osciallatory shear, 1 for oscillatory shear*/
const double frequency=0.0;	/*Frequency of oscillatory shear*/
const double topwallvel[3]={0.0,0.0,0.0};	/*top wall velocity*/
const double botwallvel[3]={0.0,0.0,0.0};	/*bottom wall velocity*/
/*for hydro*/
const int fbouncond=2;   		/*1-for pbc, 
					2-for wall on xz plane, 
					3-for walls on xz and yz planes,
					4-for lee-edwards on xz, 
					5-for some geometry in xy, 
					6 for somegeometry in xy with lee-edwards,
					7-somegeometry in xy between plates*/
/*for Q*/    
const int qbouncond=2;   		/*0-for pbc, 
					1-for lc boundary conditions on the walls, 
					2-Neumann boundary conditions on xz, 
					4-for shear edwards bc, 
					5-for some geometry in xy,
					6 for some geometry in xy with lees-edwards,
					7 for some geometry in xy between plates*/

const double nbounx=1.0,nbouny=0.0,nbounz=0.0;   /*directions of director*/
const int nbounref=1; /*1 if reflective, 
			0 otherwise for the above director field on top bottom walls*/
const int homogentr=1; /*0 if homogeneous boundary conditions, 
			 1 if homeotropic boundary conditions for inside geometry*/

// For anchoring
const int weakanch=1;/*,0 for strong anchoring, 
			1 for weak anchoring boundary conditions on the particle*/
const double bWlc=0.0;/*strength of anchoring at the surface - only on the particle*/

// For phi    
const int phibouncond=2;   /*0-for pbc, 
			     1-for phi boundary conditions on walls
		 	     2- Neumann boundary conditions on xz*/

// For polymer conformation C
const int cbouncond=2;   // 0-for pbc
			//2- Neumann bouncary conditions on xz


////////////////////////*Other options*/

/*Forcings*/
const int forcecondb=1,forcecondp=1,forceconda=1;  /*first for bodyforce, 2nd for passive stress, 3rd for active stress*/

/*Electric field*/
const int iselectric = 0;
const int telecini = 5000;	// initial time to induce electricity
const int telecend = 20000;	// maximum time to induce electricity
const double fsperm=1.;		/*Free space permittivity*/
const double dielan=1.;		/*Dielectric anisotropy*/
const double elecf[3]={0.15,0.0,0.0};	// ?

/*Imposed flow*/
const int impflow=0;/*0 if no flow imposed, 1 if flow imposed*/

/*Dry activematter*/
const int drymat=0;/*0 if full NS*/
const int drywetmat=0;/*0 if full NS*/
const double fcoef=0.001;/*Friction coefficent for velocity*/

/*Noise*/
const int qnoise=0;
const int fnoise=0;
const double kbT=0.00001;

/*Numbers to distinguish domains*/
const int score=-2;	/*This is in solid bulk*/
const int swall=-1;	/*This is in solid but next grid is liquid*/
const int lwall=0;	/*This is in liquid but next grid is solid*/
const int lcore=1;	/*This is in liquid bulk*/

/*Wedge parameters*/
const int iswedge=0;
const int istwowedge=0;	/*Expanding contracting channels*/
const double hwwedge=15;
const double thetawedge=170;
const int iswedgeprint=0; //1 to print the geometry

/*Box circle parameters*/
const int isbox=0;
const int iscir=0;
const int numofpart=1;		//else will give a warning on division by 0
const double boxdim1=18;	/*Should be an even number*/
const double momofi=1000.0;
const int isrotn=0;		/*0 if the particle is fixed, 1 if alllowed to rotate but not translate*/
const int writangvel=100;	/*how oftern marker to be written*/
const int marker=0;		/*if marker to be written*/
const int writmarker=1000;	/*how often marker to be written*/

/*Cell division parameters*/
const int iscelld=0;	/*0 if no division, 1 if yes*/
const int issingcelld=0;/*whether we have cell division*/
const int isallcelld=0;	/*whether we have cell division*/
const int numofcelld=0;	/*Number of cell division events per ??*/
const int sizofcelld=0;	/*Size of cells*/
const int timofcelld=0;	/*Time for each cell division*/
const double ratecelld=0;/*rate of mass increase*/

/*Defect dynamics*/
const int defects=0;
const int writdefects=writ;
/*Track defects*/
const int trackdef=0;
const int writdeftrack=20;
const int defcoords=1;
const int scand=2;
const int darea=2;
const int ndefsmax=100000;/*Maximum number of defects to be tracked*/
const int timetrackmax=100000;/*Maximum time to be tracked*/
/*Track defects individually*/
const int indtrack=0;
const double defx=36.5;
const double defy=60.5;
const int deft=200397;
const int defc=-5;/*Give as + or - 5*/
const int writindtrack=10;
const int indtimetrackmax=10000;/*Maximum time to be tracked*/

/*Autocorrelation calculations*/
const int autocorrcalculations=0;/*0 if no calculations are needed*/
const int tmaxforauto=5000;/*Maximum time used*/
const int tminforauto=100000;/*Minimum time wait to start the calcs*/

/*Spatial correlation calculations*/
const int spatcorrcalculations=0;/*0 if no calculations are needed*/
const int tgapforspat=10000;/*Time gap used*/
const int tminforspat=100000;/*Minimum time wait to start the calcs*/

/*Angular velocity correlation calculation*/
const int angvelcorr=0;
const int tgapforang=10000;/*Time gap for ang vel correlation calculations*/
const int tminforang=1000;/*Minimum time wait to start the calcs*/
const int tgapforangwrite=1000;/*Time gap for ang vel correlations written*/

/*Tracer dynamics*/
const int tracers=0;
const int ntracers=64;
const int tminfortracers=200000;
const int writtracers=100;


///////////////////////////*Parameters for output/writing*/

/*Stress Data writing for analysis*/
const int stress=0;
const int writstress=200; //time interval to write stress
const int stresssplit=0;/*To split all parts of passive stress*/

/*Free energy writing for analysis*/
const int writenergy=0;

/*Writing the different parts of the stress*/
const int calcstress=0;

/*Force Data writing for analysis*/
const int forcea=0;/*Checking the force balance at every grid point in the domain*/
const int writforce=1000;//writ;
const int isdragbody=0;/*0 if you want to calculate drag force and drag torque on the particle*/
const int isdragboun=0;/*0 if you want to calculate drag force and drag torque on the solid boundary*/



//////////////////////////////*Switching off terms in the equations*/
/*Switch off liquid crystals*/
const int noliqc=0; /*Put this to 0 for normal situation, 
			       to 1 if no liquid crystal dynamics*/

/*Switch off flow*/
const int noflow=0; /*Put this to 0 for normal situation, 
			       to 1 if no hydrodynamics*/

/*Switch off collsions*/
const int nocollisions=0;/*Put this to 0 for normal situation, 
				    to 1 if no collisions*/

/*Switch off backflow*/
const int nobackflow=0;/*Put this to 0 for normal situation, 
				  to 1 if no back flow is desired*/

/*Switch off bulk terms for free energy*/
const int isnotbulk=0;/*Put this to 0 for normal situation, 
				 to 1 if no ABC terms in free energy desired*/

/*Switch off vorticity in corortational derivative*/
const int isnotvortalign=0;/*Put this to 0 for normal situation, 
			to 1 if no response to voriticity is desired in corortational derivative*/

/*Switch off advection of Q*/
const int noflowadvect=0;/*Put this to 0 for normal situation, 
				    to 1 if no advection of Q*/

/*Switch off corortation of Q*/
const int noflowcortan=0;/*Put this to 0 for normal situation, 
				    to 1 if no corotation of Q*/

/*Switch of normal stresses in passive stress*/
const int nopassnormstress=0;/*Put this to 0 for normal situation, 
					to 1 if no back flow is desired*/




