/* functions associated with boundary conditions */

void do_nothing(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
return;
}

void pbc_on_vars(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexz(q,lq);/*pbc on xz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_linez(q,lq);/*pbc on z line @ four edges*/
pbc_copying_linex(q,lq);/*pbc on x line @ four edges*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
pbc_copying_point(q,lq);/*pbc on corner points*/
return;
}

/*order xfrom, xto, yfrom, yto, zfrom, zto, number of elements*/
void pbc_copying_planeyz(double *q, int lq) {
/*Copying planes to the opposite ones*/
for(int j=1; j<=ny; j++) {
  for(int k=1; k<=nz; k++) {
    pbc_actual_copy(nx,0   ,j,j,k,k,q,lq);
    pbc_actual_copy(1 ,nx+1,j,j,k,k,q,lq);
}; };
return;
}

void pbc_copying_planexz(double *q, int lq) {
/*Copying planes to the opposite ones*/
for(int i=1; i<=nx; i++) {
  for(int k=1; k<=nz; k++) {
    pbc_actual_copy(i,i,ny,0   ,k,k,q,lq);
    pbc_actual_copy(i,i,1 ,ny+1,k,k,q,lq);
}; };
return;
}

void pbc_copying_planexy(double *q, int lq) {
/*Copying planes to the opposite ones*/
for(int i=1; i<=nx; i++) {
  for(int j=1; j<=ny; j++) {
    pbc_actual_copy(i,i,j,j,nz,0   ,q,lq);
    pbc_actual_copy(i,i,j,j,1 ,nz+1,q,lq);
}; };
return;
}

void pbc_copying_linez(double *q, int lq) {
/*Copying lines to the opposite ones*/
for(int k=1; k<=nz; k++) {
    pbc_actual_copy(1 ,nx+1,1 ,ny+1,k,k,q,lq);
    pbc_actual_copy(nx,0   ,1 ,ny+1,k,k,q,lq);
    pbc_actual_copy(1 ,nx+1,ny,0   ,k,k,q,lq);
    pbc_actual_copy(nx,0   ,ny,0   ,k,k,q,lq);
};
return;
}

void pbc_copying_liney(double *q, int lq) {
/*Copying lines to the opposite ones*/
for(int j=1; j<=ny; j++) {
    pbc_actual_copy(1 ,nx+1,j,j,1 ,nz+1,q,lq);
    pbc_actual_copy(nx,0   ,j,j,1 ,nz+1,q,lq);
    pbc_actual_copy(1 ,nx+1,j,j,nz,0   ,q,lq);
    pbc_actual_copy(nx,0   ,j,j,nz,0   ,q,lq);
};
return;
}

void pbc_copying_linex(double *q, int lq) {
/*Copying lines to the opposite ones*/
for(int i=1; i<=nx; i++) {
    pbc_actual_copy(i,i,1 ,ny+1,1 ,nz+1,q,lq);
    pbc_actual_copy(i,i,ny,0   ,1 ,nz+1,q,lq);
    pbc_actual_copy(i,i,1 ,ny+1,nz,0   ,q,lq);
    pbc_actual_copy(i,i,ny,0   ,nz,0   ,q,lq);
};
return;
}

void pbc_copying_point(double *q, int lq) {
/*Copying corners to the opposite ones*/
pbc_actual_copy(1 ,nx+1,1 ,ny+1,1 ,nz+1,q,lq);
pbc_actual_copy(1 ,nx+1,1 ,ny+1,nz,0   ,q,lq);
pbc_actual_copy(1 ,nx+1,ny,0   ,1 ,nz+1,q,lq);
pbc_actual_copy(1 ,nx+1,ny,0   ,nz,0   ,q,lq);
pbc_actual_copy(nx,0   ,1 ,ny+1,1 ,nz+1,q,lq);
pbc_actual_copy(nx,0   ,1 ,ny+1,nz,0   ,q,lq);
pbc_actual_copy(nx,0   ,ny,0   ,1 ,nz+1,q,lq);
pbc_actual_copy(nx,0   ,ny,0   ,nz,0   ,q,lq);
return;
}

void pbc_actual_copy(int ifr,int ito,int jfr,int jto,int kfr,int kto,double *q, int lq) {
int lto = ((ito*ny2+jto)*nz2+kto)*lq;
int lfr = ((ifr*ny2+jfr)*nz2+kfr)*lq;
for(int m=0; m<lq; m++) q[lto+m]=q[lfr+m];
//for(int m=0; m<lq; m++) printf("%d %d %f %f\n",lto,lfr,mlat->f[lto+m],q[lto+m]);
//for(int m=0; m<lcq; m++) printf("%d %d %f %f\n",lto,lfr,qlat->q[lto+m],q[lto+m]);
return;
}

void pbc_copying_planeyz_ofint(int *q, int lq) {
/*Copying planes to the opposite ones*/
for(int j=1; j<=ny; j++) {
  for(int k=1; k<=nz; k++) {
    pbc_actual_copy_ofint(nx,0   ,j,j,k,k,q,lq);
    pbc_actual_copy_ofint(1 ,nx+1,j,j,k,k,q,lq);
}; };
return;
}

void pbc_copying_planexy_ofint(int *q, int lq) {
/*Copying planes to the opposite ones*/
for(int i=1; i<=nx; i++) {
  for(int j=1; j<=ny; j++) {
    pbc_actual_copy_ofint(i,i,j,j,nz,0   ,q,lq);
    pbc_actual_copy_ofint(i,i,j,j,1 ,nz+1,q,lq);
}; };
return;
}


void pbc_copying_liney_ofint(int *q, int lq) {
/*Copying lines to the opposite ones*/
for(int j=1; j<=ny; j++) {
    pbc_actual_copy_ofint(1 ,nx+1,j,j,1 ,nz+1,q,lq);
    pbc_actual_copy_ofint(nx,0   ,j,j,1 ,nz+1,q,lq);
    pbc_actual_copy_ofint(1 ,nx+1,j,j,nz,0   ,q,lq);
    pbc_actual_copy_ofint(nx,0   ,j,j,nz,0   ,q,lq);
};
return;
}

void pbc_actual_copy_ofint(int ifr,int ito,int jfr,int jto,int kfr,int kto,int *q, int lq) {
int lto = ((ito*ny2+jto)*nz2+kto)*lq;
int lfr = ((ifr*ny2+jfr)*nz2+kfr)*lq;
for(int m=0; m<lq; m++) q[lto+m]=q[lfr+m];
return;
}

void reflnabouty_copying_linez(double *q, int lq) {
/*Copying lines to the reflection lines*/
for(int k=0; k<=nz+1; k++) {
    pbc_actual_copy(1 ,nx+1,ny+1 ,ny+1,k,k,q,lq);
    pbc_actual_copy(nx,0   ,ny+1 ,ny+1,k,k,q,lq);
    pbc_actual_copy(1 ,nx+1,0 ,0   ,k,k,q,lq);
    pbc_actual_copy(nx,0   ,0 ,0   ,k,k,q,lq);
};
return;
}

void reflnabouty_copying_linex(double *q, int lq) {
/*Copying lines to the reflection lines*/
for(int i=0; i<=nx+1; i++) {
    pbc_actual_copy(i,i,ny+1,ny+1,1 ,nz+1,q,lq);
    pbc_actual_copy(i,i,0   ,0   ,1 ,nz+1,q,lq);
    pbc_actual_copy(i,i,ny+1,ny+1,nz,0   ,q,lq);
    pbc_actual_copy(i,i,0   ,0   ,nz,0   ,q,lq);
};
return;
}

