/*
This is a draft to save the principal stresses (of different components)
as a vector field.
The values will be saved like the velocity fields.
*/

void prinstress(lblattice *latv,  lclattice *latc, wedge *latw, int tm){
//double *phi=&latc->phi[0];
//double *u=&latv->u[0];
//int lps[26];

FILE *aptr, *cptr, *eptr, *vptr, *pptr, *totptr;
char nname[500];
sprintf(nname,"%s/output/astrfld%d.dat",DPATH,tm);
aptr=fopen(nname,"w");
sprintf(nname,"%s/output/cstrfld%d.dat",DPATH,tm);
cptr=fopen(nname,"w");
sprintf(nname,"%s/output/estrfld%d.dat",DPATH,tm);
eptr=fopen(nname,"w");
sprintf(nname,"%s/output/vstrfld%d.dat",DPATH,tm);
vptr=fopen(nname,"w");
sprintf(nname,"%s/output/pstrfld%d.dat",DPATH,tm);
pptr=fopen(nname,"w");
sprintf(nname,"%s/output/totstrfld%d.dat",DPATH,tm);
totptr=fopen(nname,"w");

//Extension to boundary
(*latc->bc_func)(latv,latc,latw,&latc->actstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->capstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->elasstress[0],lcd*lcd);
(*latc->bc_func)(latv,latc,latw,&latc->viscstress[0],lcd*lcd);
if(iswithpoly){
(*latc->bc_func)(latv,latc,latw,&latc->polystress[0],lcd*lcd);
}
//pbc_on_vars //emmanuel:working

float **temp_mat, *temp_diag,*temp_offdiag;
float **tot_mat;
temp_mat = matrix(1,3,1,3);
tot_mat = matrix(1,3,1,3);
temp_diag=vector(1,3);
temp_offdiag=vector(1,3);
int temp_evmax;

for(int k=1;k<=nz;k++) {
for(int j=1;j<=ny;j++) {
for(int i=1;i<=nx;i++) {
	int l=(i*ny2+j)*nz2+k;
	int las=l*lcd*lcd;
//calculate stress field for the point
//and save the stresses in that point

//actstress
//we do not want the negative of Q because the eigenvalues become negative
temp_mat[1][1]=fabs(latc->actstress[las]);
temp_mat[2][2]=fabs(latc->actstress[las+1]);
temp_mat[3][3]=fabs(latc->actstress[las+2]);
temp_mat[1][2]=fabs(latc->actstress[las+3]);
temp_mat[1][3]=fabs(latc->actstress[las+4]);
temp_mat[2][3]=fabs(latc->actstress[las+5]);
temp_mat[2][1]=fabs(latc->actstress[las+6]);
temp_mat[3][1]=fabs(latc->actstress[las+7]);
temp_mat[3][2]=fabs(latc->actstress[las+8]);

tot_mat[1][1]=temp_mat[1][1];
tot_mat[2][2]=temp_mat[2][2];
tot_mat[3][3]=temp_mat[3][3];
tot_mat[1][2]=temp_mat[1][2];
tot_mat[1][3]=temp_mat[1][3];
tot_mat[2][3]=temp_mat[2][3];
tot_mat[2][1]=temp_mat[2][1];
tot_mat[3][1]=temp_mat[3][1];
tot_mat[3][2]=temp_mat[3][2];

prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
fprintf(aptr,"%f %f %f %f\n",temp_diag[temp_evmax],temp_mat[1][temp_evmax],temp_mat[2][temp_evmax],temp_mat[3][temp_evmax]);

//capstress
temp_mat[1][1]=latc->capstress[las];
temp_mat[2][2]=latc->capstress[las+1];
temp_mat[3][3]=latc->capstress[las+2];
temp_mat[1][2]=latc->capstress[las+3];
temp_mat[1][3]=latc->capstress[las+4];
temp_mat[2][3]=latc->capstress[las+5];
temp_mat[2][1]=latc->capstress[las+6];
temp_mat[3][1]=latc->capstress[las+7];
temp_mat[3][2]=latc->capstress[las+8];

tot_mat[1][1]+=temp_mat[1][1];
tot_mat[2][2]+=temp_mat[2][2];
tot_mat[3][3]+=temp_mat[3][3];
tot_mat[1][2]+=temp_mat[1][2];
tot_mat[1][3]+=temp_mat[1][3];
tot_mat[2][3]+=temp_mat[2][3];
tot_mat[2][1]+=temp_mat[2][1];
tot_mat[3][1]+=temp_mat[3][1];
tot_mat[3][2]+=temp_mat[3][2];

prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
fprintf(cptr,"%f %f %f %f\n",temp_diag[temp_evmax],temp_mat[1][temp_evmax],temp_mat[2][temp_evmax],temp_mat[3][temp_evmax]);

//elasstress
temp_mat[1][1]=latc->elasstress[las];
temp_mat[2][2]=latc->elasstress[las+1];
temp_mat[3][3]=latc->elasstress[las+2];
temp_mat[1][2]=latc->elasstress[las+3];
temp_mat[1][3]=latc->elasstress[las+4];
temp_mat[2][3]=latc->elasstress[las+5];
temp_mat[2][1]=latc->elasstress[las+6];
temp_mat[3][1]=latc->elasstress[las+7];
temp_mat[3][2]=latc->elasstress[las+8];

tot_mat[1][1]+=temp_mat[1][1];
tot_mat[2][2]+=temp_mat[2][2];
tot_mat[3][3]+=temp_mat[3][3];
tot_mat[1][2]+=temp_mat[1][2];
tot_mat[1][3]+=temp_mat[1][3];
tot_mat[2][3]+=temp_mat[2][3];
tot_mat[2][1]+=temp_mat[2][1];
tot_mat[3][1]+=temp_mat[3][1];
tot_mat[3][2]+=temp_mat[3][2];

prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
fprintf(eptr,"%f %f %f %f\n",temp_diag[temp_evmax],temp_mat[1][temp_evmax],temp_mat[2][temp_evmax],temp_mat[3][temp_evmax]);//Pressure added to remove inclusion in calculation

//visctress
temp_mat[1][1]=latc->viscstress[las];
temp_mat[2][2]=latc->viscstress[las+1];
temp_mat[3][3]=latc->viscstress[las+2];
temp_mat[1][2]=latc->viscstress[las+3];
temp_mat[1][3]=latc->viscstress[las+4];
temp_mat[2][3]=latc->viscstress[las+5];
temp_mat[2][1]=latc->viscstress[las+6];
temp_mat[3][1]=latc->viscstress[las+7];
temp_mat[3][2]=latc->viscstress[las+8];

tot_mat[1][1]+=temp_mat[1][1];
tot_mat[2][2]+=temp_mat[2][2];
tot_mat[3][3]+=temp_mat[3][3];
tot_mat[1][2]+=temp_mat[1][2];
tot_mat[1][3]+=temp_mat[1][3];
tot_mat[2][3]+=temp_mat[2][3];
tot_mat[2][1]+=temp_mat[2][1];
tot_mat[3][1]+=temp_mat[3][1];
tot_mat[3][2]+=temp_mat[3][2];

prin_eigen(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
fprintf(vptr,"%f %f %f %f\n",temp_diag[temp_evmax],temp_mat[1][temp_evmax],temp_mat[2][temp_evmax],temp_mat[3][temp_evmax]);

if(iswithpoly){
//polytress
temp_mat[1][1]=latc->polystress[las];
temp_mat[2][2]=latc->polystress[las+1];
temp_mat[3][3]=latc->polystress[las+2];
temp_mat[1][2]=latc->polystress[las+3];
temp_mat[1][3]=latc->polystress[las+4];
temp_mat[2][3]=latc->polystress[las+5];
temp_mat[2][1]=latc->polystress[las+6];
temp_mat[3][1]=latc->polystress[las+7];
temp_mat[3][2]=latc->polystress[las+8];

tot_mat[1][1]+=temp_mat[1][1];
tot_mat[2][2]+=temp_mat[2][2];
tot_mat[3][3]+=temp_mat[3][3];
tot_mat[1][2]+=temp_mat[1][2];
tot_mat[1][3]+=temp_mat[1][3];
tot_mat[2][3]+=temp_mat[2][3];
tot_mat[2][1]+=temp_mat[2][1];
tot_mat[3][1]+=temp_mat[3][1];
tot_mat[3][2]+=temp_mat[3][2];

prin_eigen_c(temp_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
fprintf(pptr,"%f %f %f %f\n",temp_diag[temp_evmax],temp_mat[1][temp_evmax],temp_mat[2][temp_evmax],temp_mat[3][temp_evmax]);
}

prin_eigen(tot_mat,lbd,temp_diag,temp_offdiag,&temp_evmax);
fprintf(totptr,"%f %f %f %f\n",temp_diag[temp_evmax],tot_mat[1][temp_evmax],tot_mat[2][temp_evmax],tot_mat[3][temp_evmax]);

}}} //end k,j,i

fclose(aptr);
fclose(cptr);
fclose(eptr);
fclose(vptr);
fclose(pptr);
fclose(totptr);

	return;
}


//Emmanuel
//temporary
void prin_eigen(float **mat, int dim, float d[], float offd[],int *evmx){
//printf("Q is: %f,%f,%f,%f,%f,%f\n",mat[1][1],mat[2][2],mat[3][3],mat[1][2],mat[1][3],mat[2][3]);
tred2(mat,dim,d,offd);
tqli(d,offd,dim,mat);
*evmx=1;
if(d[2]>d[*evmx]) *evmx=2;
if(d[3]>d[*evmx]) *evmx=3;

if(fabs(d[*evmx])<1e-10) {//printf("%f\n",d[*evmx]);
mat[1][*evmx]=0;mat[2][*evmx]=0;mat[3][*evmx]=0;}
if(d[*evmx]<-10) {//printf("(prinstressorstressgrad)neg eigen_q-%f\n",d[*evmx]);d[*evmx]=0;mat[1][*evmx]=0;mat[2][*evmx]=0;mat[3][*evmx]=0;
printf("Q is: %f,%f,%f,%f,%f,%f\n",mat[1][1],mat[2][2],mat[3][3],mat[1][2],mat[1][3],mat[2][3]);
}

	return;
}

void prin_eigen_c(float **mat, int dim, float d[], float offd[],int *evmx){
//printf("C is: %f,%f,%f,%f,%f,%f\n",mat[1][1],mat[2][2],mat[3][3],mat[1][2],mat[1][3],mat[2][3]);
tred2(mat,dim,d,offd);
tqli(d,offd,dim,mat);
*evmx=1;
if(d[2]>d[*evmx]) *evmx=2;
if(d[3]>d[*evmx]) *evmx=3;

if(fabs(d[*evmx])<1e-10) {//printf("%f\n",d[*evmx]);
mat[1][*evmx]=0;mat[2][*evmx]=0;mat[3][*evmx]=0;}
if(d[*evmx]<-10) {//printf("(prinstress)neg eigen_c-%f\n",d[*evmx]);d[*evmx]=0;mat[1][*evmx]=0;mat[2][*evmx]=0;mat[3][*evmx]=0;
printf("C is: %f,%f,%f,%f,%f,%f\n",mat[1][1],mat[2][2],mat[3][3],mat[1][2],mat[1][3],mat[2][3]);
}

	return;
}

