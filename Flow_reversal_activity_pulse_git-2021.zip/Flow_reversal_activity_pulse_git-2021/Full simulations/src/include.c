/*Files, functions and global variables to be included*/
#define _XOPEN_SOURCE 700

// Standard libraries
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stddef.h>
#include <sys/stat.h>
#include <time.h>
#include <complex.h>

// Defining variables and pointers (very useful in C++)
// N.B. Do not change the order of definitions //
// Header files roughly sorted into categories//
//#include "defs.h"
#include "defs_common1.h"	
#include "defs_lblcwedge.h"
#include "defs_common2.h"
#include "defs_defects.h"
#include "defs_correltracer.h"
#include "defs_common3.h"
//#include "defs_polymers.h"

// Setting parameters
#include "parameters.h"

// Some global variables. 

// //Emmanuel: Why here? Can these be defined in their individual files?
int nx2=nx+2,ny2=ny+2,nz2=nz+2;	// the indices 0 and nx+1, ny+1, and nz+1 correspond to auxiliary points in the border. may be necessary for BCs and gradients
int n2max=(nx+2)*(ny+2)*(nz+2);	//
int nmax=(nx)*(ny)*(nz);	//
int rxymax=nx*nx+ny*ny;		//
int wallflagxz=0;		//
int isgeom;			//
int isbulk;			//
int isvortalign;		//
int isdrag;			//
int tmlmax;			//
double phip0;			//
double phim0;			//
#define PI 3.14159265358979323846

//Useful functions (eg see numerical recipes online, or from Miha(?)
#include "util_nr_1.h" 
#include "util_nr_2.c" 
#include "util_3.c"   

// Other files
#include "freeenergy.c"
#include "write.c"
#include "read.c"

//Regarding Lattice Boltzmann (lb)
#include "lb_d3q15.c"
#include "lb_bc.c"
#include "lb_init.c"

//Regarding the Liquid Crystals (lc)
#include "lc_func.c"
#include "lc_init.c"
#include "lc_bc.c"

//Boundary Conditions, forces, geometry
#include "geom_bcs.c"
#include "geom_wedge.c" 

//Different options
#include "op_chiral.c"
#include "op_forces.c"
#include "op_defects.c"
#include "op_tracers.c"
#include "op_correlations.c"
#include "op_stresscalc.c" 	// important
#include "op_stresssplit.c" 	// important
#include "op_polymers.c"
#include "op_dist.c"
#include "op_stressgrad.c"
#include "op_prinstress.c"
#include "op_perimeter.c"
#include "op_celldiv.c"
#include "op_centreofmass.c"

////////////////////////// END OF FILE ////////////////////

