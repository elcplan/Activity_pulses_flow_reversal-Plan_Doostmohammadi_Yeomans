/* functions associated with initialisation of LC simulation*/

void initial_conditions_lc(lclattice *lat,int j,int k, int poly, double dirx, double diry, double dirz, int* imin, int* imax) {

if(iswithpoly){ // Initial conditions if with polymer
	switch (poly){
	case 0:
  		lat->ic_func_c=&init_readc;
		break;
	case 1: 
		printf("Initial conditions for the polymers: all at equilibrium\n");
  		lat->ic_func_c=&init_poly_eq;
  		break;
	case 2:
		printf("Initial conditions for the polymers: stretched, random dir\n");
  		lat->ic_func_c=&init_poly_stretch_ran;
  		break;
	case 3:
		printf("Initial conditions for the polymers: stretched, random dir\n");
  		lat->ic_func_c=&init_poly_ori_stretch_ran;
  		break;
	case 4:
		printf("Initial conditions for the polymers: stretched, random dir, near interface only\n");
  		lat->ic_func_c=&init_poly_ori_stretch_bor;
  		break;
	}//end switch
	lat->ic_func_c(lat);
}//end iswithpoly

// Initial conditions for order parameter Q
switch (j) {
case 0:
  lat->ic_func=&init_readq;
  break;
case 1:
  lat->ic_func=&init_nematic_equi;
  break;
case 11:
  lat->ic_func=&init_nematic_equi_withran;
  break;
case 2:
  lat->ic_func=&init_randomqs;
  break;
case 21:
  lat->ic_func=&init_isotropic;
  break;
case 3:
  lat->ic_func=&init_tiltmiddleqs;
  break;
case 4:
  lat->ic_func=&init_wedgeranplusnemqs;
  break;
case 5:
  lat->ic_func=&init_bendatmiddle;
  break;
case 6:
  lat->ic_func=&init_nothing;
case 7:
  lat->ic_func=&init_nothing;
case 8:
  lat->ic_func=&init_nothing;
case 9:
  lat->ic_func=&init_nothing;
case 10:
  lat->ic_func=&init_nothing;
case 12:
  lat->ic_func=&init_nothing;
}

	if ( j == 10 )
	{
		
		int nx2_in      = nx2/2+1;
		int ny2_in      = ny2;
		int nz2_in      = nz2;
		
		double* lat_q   = (double *)malloc(nx2_in*ny2_in*nz2_in*lcq*sizeof(double));
		double* lat_phi = (double *)malloc(nx2_in*ny2_in*nz2_in    *sizeof(double));
		
		init_read_eq_q  (lat_q,  nx2_in,ny2_in,nz2_in);
		init_read_eq_phi(lat_phi,nx2_in,ny2_in,nz2_in);

		int    i_max   = 0;
		int    i_min   = nx2_in;
		
		for(int i=0;i<nx2_in;i++)
		{
			for(int j=0;j<nx2_in;j++)
			{
				for(int k=0;k<nx2_in;k++)
				{
					int l = ((i*ny2_in+j)*nz2_in+k);
					
					if (lat_phi[l] > phicrit)
					{
						if (i < i_min) i_min=i;
						if (i > i_max) i_max=i;
					}
				}
			}
		}
		
		imin[0] = i_min;
		imax[0] = i_max;
		
		for(int i=0;i<nx2;i++)
		{
			for(int j=0;j<ny2;j++)
			{
				for(int k=0;k<nz2;k++)
				{
					int i_in;
					
					if ((i>0) && (i<nx2_in-1))
					{
						if (i-nx/2+i_max > 0) i_in = i-nx/2+i_max;
						else i_in = i+i_max;
					}
					
					else if ((i>0) && (i<nx2-1))
					{
						if (i-nx/2-1+i_min < nx/2+1) i_in = i-nx/2-1+i_min;
						else i_in = i+i_min-nx-1;
					}
					
					else if (i == 0) i_in = i_min-1;
					else i_in = i_max+1;
					
					int l    = (i   *ny2+j)*nz2+k;
					int l_in = (i_in*ny2+j)*nz2+k;

					for (int m=0; m<lcq; m++) lat->q[l*lcq+m] = lat_q[l_in*lcq+m];
					
					lat->phi[l] = lat_phi[l_in];
				}
			}
		}
	}
	
	else (*lat->ic_func)(lat,dirx,diry,dirz);


if(inphase) {
switch (k) {
case 0:
  init_readphi(lat,phidim1,dirx,diry,dirz);
  break;
case 2:
  init_randomforphi(lat);
  break;
case 6:
  init_isonemflat_interface(lat,phidim1,dirx,diry,dirz);
  break;
case 7:
  init_random_drop(lat,phidim1,dirx,diry,dirz);
  break;
case 8:
  init_membrane3d(lat,phidim1,dirx,diry,dirz);
  break;
case 9:
  init_single_pitch(lat,phidim1,Cpit);
  break;
case 12:
  init_phasesep(lat,phidim1,dirx,diry,dirz);
  break;
} }
return;

}

void init_nothing(lclattice *lat) {
/*Do nothing*/
}

/*To start from a bend in the middle*/
void init_bendatmiddle(lclattice *lat) {
double qe=qeq();
double dirx, diry, dirz, ndir;
int l;
double theta,phi;
int geo=4; /*0 for linear, 1 for in phase wave, 2 for anti phase wave,3 a diamond at the center, 4 kink */
double minthick=1;//ny/2-ampl;
double ampl=0, freq=1;
double dthick=1.0;
double nymid=ny/2+0.5;
double nxmid=nx/2+0.5;
for(int i=1;i<=nx;i++)
   for(int j=1;j<=ny;j++)
      for(int k=1;k<=nz;k++) {
        l = ((i*ny2+j)*nz2+k)*lcq;
      	theta=M_PI/1.0;
      	phi=0.0;
      	switch (geo) {
      	case 0:
         dthick=fabs(i-nxmid)/nxmid*ampl+minthick;
      	break;
      	case 1:
      	  nymid=ny/2+0.5+sin(2*M_PI*i*freq/nx)*ampl;
	        dthick=minthick;
      	break;
      	case 2:
          dthick=sin(2*M_PI*i*freq/nx)*ampl+minthick+ampl;
      	break;
      	}
        if(fabs(j-nymid)<=dthick) {
          if((geo==3)||(geo==4)) {
            if(i==nx/2) phi=M_PI/3.0;
            if(i==nx/2+1) phi=-M_PI/3.0;
          }
          else phi=M_PI/2-fabs(j-nymid)/dthick*M_PI/2.0;//+0.1*ran2(&seed);
	      if((geo==4)&&(j>nymid)) phi=0.0;
        else phi=j>nymid? phi:-phi;
      	}
      	dirx=sin(theta)*cos(phi);
        diry=sin(theta)*sin(phi);
      	dirz=cos(theta);
        if(nz==1) dirz=0.0;/*To avoid perturbations if arise*/
        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
        dirz=dirz/ndir;
        lat->q[l]  = 0.5*qe*(3.*dirx*dirx-1.0);
        lat->q[l+1]= 0.5*qe*(3.*diry*diry-1.0);
        lat->q[l+2]= 0.5*qe*(3.*dirz*dirz-1.0);
        lat->q[l+3]= 0.5*qe*(3.*dirx*diry-0.0);
        lat->q[l+4]= 0.5*qe*(3.*dirx*dirz-0.0);
        lat->q[l+5]= 0.5*qe*(3.*diry*dirz-0.0);
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }
      }
return;
}

/*To start from a tilt in the middle*/
void init_tiltmiddleqs(lclattice *lat, double dirx, double diry, double dirz) {
double ndir;
double qe=qeq();
int l;
double theta,phi;
double theta0=atan(sqrt(dirx*dirx+diry*diry)/dirz);
double phi0=atan(diry/dirx);
if(dirz==0.0) theta0=M_PI/2.0;
if(dirx==0.0) phi0=M_PI/2.0;
double theta1=M_PI/4.0;
double phi1=M_PI/2.0;
if(nz==1) {theta1=M_PI/2.0;phi1=M_PI/200.0; }
for(int i=1;i<=nx;i++)
   for(int j=1;j<=ny;j++)
      for(int k=1;k<=nz;k++) {
        l = ((i*ny2+j)*nz2+k)*lcq;
	theta=theta0;
	phi=phi0;
	if(j==ny/2) {
	//if((i==nx/2)&&(j==ny/2)) {
	//if(i==nx/2) {
	//if(j==1) {
	theta=theta1;
        phi=phi1;
	}
	dirx=sin(theta)*cos(phi);
        diry=sin(theta)*sin(phi);
	dirz=cos(theta);
        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
        dirz=dirz/ndir;
        lat->q[l]  = 0.5*qe*(3.*dirx*dirx-1.0);
        lat->q[l+1]= 0.5*qe*(3.*diry*diry-1.0);
        lat->q[l+2]= 0.5*qe*(3.*dirz*dirz-1.0);
        lat->q[l+3]= 0.5*qe*(3.*dirx*diry-0.0);
        lat->q[l+4]= 0.5*qe*(3.*dirx*dirz-0.0);
        lat->q[l+5]= 0.5*qe*(3.*diry*dirz-0.0);
	if(fabs(dirx)<=1e-16) {	lat->q[l+3]=0.0; lat->q[l+4]=0.0;}
	if(fabs(diry)<=1e-16) {	lat->q[l+3]=0.0; lat->q[l+5]=0.0;}
	if(fabs(dirz)<=1e-16) {	lat->q[l+4]=0.0; lat->q[l+5]=0.0;}
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }
      }
return;
}

/*To start from a equilibrium situation with slight perturbations*/
void init_nematic_equi_withran(lclattice *lat,double dirx,double diry,double dirz) {
double qe=qeq();
int l;
double rann, mag=0.25,ndir;
double phi=atan2(diry,dirx);
if(nz>1) {
  printf("Not designed for nz>1\n");
  };
for(int i=0;i<nx2;i++)
   for(int j=0;j<ny2;j++)
      for(int k=0;k<nz2;k++) {
        rann=phi+mag*(2*ran2(&seed)-1);
        dirx=cos(rann);
        diry=sin(rann);
        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
        l = ((i*ny2+j)*nz2+k)*lcq;
        lat->q[l]  = 0.5*qe*(3.*dirx*dirx-1.0);
        lat->q[l+1]= 0.5*qe*(3.*diry*diry-1.0);
        lat->q[l+2]= 0.5*qe*(3.*dirz*dirz-1.0);
        lat->q[l+3]= 0.5*qe*(3.*dirx*diry-0.0);
        lat->q[l+4]= 0.5*qe*(3.*dirx*dirz-0.0);
        lat->q[l+5]= 0.5*qe*(3.*diry*dirz-0.0);
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }
      }
return;
}

/*To start from a equilibrium situation*/
void init_nematic_equi(lclattice *lat,double dirx,double diry,double dirz) {
double qe=qeq();
int l;
for(int i=0;i<nx2;i++)
   for(int j=0;j<ny2;j++)
      for(int k=0;k<nz2;k++) {
        l = ((i*ny2+j)*nz2+k)*lcq;
        lat->q[l]  = 0.5*qe*(3.*dirx*dirx-1.0);
        lat->q[l+1]= 0.5*qe*(3.*diry*diry-1.0);
        lat->q[l+2]= 0.5*qe*(3.*dirz*dirz-1.0);
        lat->q[l+3]= 0.5*qe*(3.*dirx*diry-0.0);
        lat->q[l+4]= 0.5*qe*(3.*dirx*dirz-0.0);
        lat->q[l+5]= 0.5*qe*(3.*diry*dirz-0.0);
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }
        //for(int m=0;m<6;m++) printf("%d %.6f,",m,lat->q[l+m]); printf("\n");
        //for(int m=0;m<6;m++) printf("%d %d %.6f %.6f,",l/lcq,m,lat->q[l+m],qe); printf("\n");
      }
return;
}

/*To start from a isotropic situation*/
void init_isotropic(lclattice *lat,double dirx,double diry,double dirz) {
int l;
double mag=1.;//0000;
double S,ndir;
double theta=M_PI/2.0,phi;
for(int i=0;i<nx2;i++)
   for(int j=0;j<ny2;j++)
      for(int k=0;k<nz2;k++) {
        l = ((i*ny2+j)*nz2+k);
	phi=ran2(&seed)*M_PI*2;
        dirx=sin(theta)*cos(phi);
        diry=sin(theta)*sin(phi);
	dirz=cos(theta);
        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
        dirz=dirz/ndir;
	S=0;//ran2(&seed)/mag;
        lat->q[l*lcq]  = 0.5*S*(3.*dirx*dirx-1.0);
        lat->q[l*lcq+1]= 0.5*S*(3.*diry*diry-1.0);
        lat->q[l*lcq+2]= 0.5*S*(3.*dirz*dirz-1.0);
        lat->q[l*lcq+3]= 0.5*S*(3.*dirx*diry-0.0);
	if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
        lat->q[l*lcq+4]= 0.5*S*(3.*dirx*dirz-0.0);
        lat->q[l*lcq+5]= 0.5*S*(3.*diry*dirz-0.0);}
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }
      }
return;
}


void init_randomqs(lclattice *lat) {
double qe=qeq()*phi0;
double etaphi=eta0lcphi+etaslcphi*(phip0-phibar);
if(inphase){
//Emmanuel: changed to Alc
double Alceff=Alc*(phip0)*(phip0)*(1.0-etaphi/3.0);
double Blceff=-Alc*(phip0)*(phip0)*etaphi*Beq0;
double Clceff=Alc*(phip0)*(phip0)*etaphi;
qe=(-Blceff+sqrt(Blceff*Blceff-24.*Alceff*Clceff))/(6.*Clceff);
}
double dirx, diry, dirz, ndir;
int l;
double rann1=0;
double rann2=0;
double theta,phi;
int nn=((nx==1)||(ny==1)||(nz==1));
for(int i=0;i<nx2;i++)
   for(int j=0;j<ny2;j++)
      for(int k=0;k<nz2;k++) {
        l = ((i*ny2+j)*nz2+k)*lcq;
        rann1=ran2(&seed);
	if(~nn) rann2=ran2(&seed);
	theta=rann1*M_PI;
	phi=rann2*M_PI*2;
	//if(nx==1) phi=M_PI/2.;
	if(ny==1) phi=0.0;
	if(nz==1) theta=M_PI/2.0;
    	dirx=sin(theta)*cos(phi);
    	diry=sin(theta)*sin(phi);
	dirz=cos(theta);
	//if(nx==1) dirx=0.0;/*To avoid any perturbation in 3rd direction in 2D simulations*/
	if(ny==1) diry=0.0;
	if(nz==1) dirz=0.0;
	//printf("%d,%d,%d,%f,%f,%.16f\n",l,i,j,dirx,diry,dirz);
        //if((i==nx2/2)&&(j==ny2/2)) {dirx=1.; diry=1.;printf("reaached\n.");}
        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
        dirz=dirz/ndir;
	qe=0.5;
        lat->q[l]  = 0.5*qe*(3.*dirx*dirx-1.0);
        lat->q[l+1]= 0.5*qe*(3.*diry*diry-1.0);
        lat->q[l+2]= 0.5*qe*(3.*dirz*dirz-1.0);
        lat->q[l+3]= 0.5*qe*(3.*dirx*diry-0.0);
        lat->q[l+4]= 0.5*qe*(3.*dirx*dirz-0.0);
        lat->q[l+5]= 0.5*qe*(3.*diry*dirz-0.0);
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }
        //for(int m=0;m<6;m++) printf("%d %d %.12f %.12f,",l/lcq,m,lat->q[l+m],qe); printf("\n");
//printf("%d,%d,%d,%f,%f,%f,%f,%f,%f\n",l,i,j,lat->q[l],lat->q[l+1],lat->q[l+2],lat->q[l+3],lat->q[l+4],lat->q[l+5]);
//printf("%f,%f,%f.\n",qe,dirx,diry);
      }
return;
}

/*To start from a random + nematic situation in a wedge*/
void init_wedgeranplusnemqs(lclattice *lat) {
double qe=qeq();
double dirx, diry, dirz, ndir;
int l;
double rann1=0;
double rann2=0;
double theta,phi;
int nn=((nx==1)||(ny==1)||(nz==1));
for(int i=0;i<nx2;i++)
   for(int j=0;j<ny2;j++)
      for(int k=0;k<nz2;k++) {
        l = ((i*ny2+j)*nz2+k)*lcq;
        rann1=ran2(&seed);
	if(~nn) rann2=ran2(&seed);
	theta=rann1*M_PI;
	phi=rann2*M_PI*2;
	if(nx==1) phi=M_PI/2.;
	if(ny==1) phi=0.0;
	if(nz==1) theta=M_PI/2.0;
        dirx=sin(theta)*cos(phi);
        diry=sin(theta)*sin(phi);
	dirz=cos(theta);
	if(nx==1) dirx=0.0;/*To avoid any perturbation in 3rd direction in 2D simulations*/
	if(ny==1) diry=0.0;
	if(nz==1) dirz=0.0;
	//printf("%d,%d,%d,%f,%f,%.16f\n",l,i,j,dirx,diry,dirz);
        //if((i==nx2/2)&&(j==ny2/2)) {dirx=1.; diry=1.;printf("reaached\n.");}
        if(j>hwwedge) {dirx=1.0+dirx*0.1; diry=0.1*diry;};
        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
        dirz=dirz/ndir;
        lat->q[l]  = 0.5*qe*(3.*dirx*dirx-1.0);
        lat->q[l+1]= 0.5*qe*(3.*diry*diry-1.0);
        lat->q[l+2]= 0.5*qe*(3.*dirz*dirz-1.0);
        lat->q[l+3]= 0.5*qe*(3.*dirx*diry-0.0);
        lat->q[l+4]= 0.5*qe*(3.*dirx*dirz-0.0);
        lat->q[l+5]= 0.5*qe*(3.*diry*dirz-0.0);
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }
        //for(int m=0;m<6;m++) printf("%d %d %.12f %.12f,",l/lcq,m,lat->q[l+m],qe); printf("\n");
	//printf("%d,%d,%d,%f,%f,%f,%f,%f,%f\n",l,i,j,lat->q[l],lat->q[l+1],lat->q[l+2],lat->q[l+3],lat->q[l+4],lat->q[l+5]);
      }
return;
}

/*To start from a flat interface for isotropic-nematic phase*/
void init_isonemflat_interface(lclattice *lat,double height,double dinx, double diny, double dinz) {
    double qe=0.0;//=(-Blc+sqrt(Blc*Blc-24.*Alc*Clc))/(6.*Clc);
    double etaphi=eta0lcphi+etaslcphi*(phip0-phibar);
    if(inphase){//Emmanue: changed A0lcphi to Alc, assume phip0=1
        double Alceff=Alc*(phip0)*(phip0)*(1.0-etaphi/3.0);
        double Blceff=-Alc*(phip0)*(phip0)*etaphi*Beq0;
        double Clceff=Alc*(phip0)*(phip0)*etaphi;
	double det=Blceff*Blceff-24.*Alceff*Clceff;
	qe=(-Blceff+sqrt(Blceff*Blceff-24.*Alceff*Clceff))/(6.*Clceff);
	printf("determinant=%f, qe=%f\n",det,qe);
	//qe=det>0?:(-Blceff+sqrt(Blceff*Blceff-24.*Alceff*Clceff))/(6.*Clceff),0.0;
    }
    int l;
    double theta=M_PI/2.0,phi;
    double mag=100.,S,dirx,diry,dirz,ndir;
    int geo=0;/*0-for flat,1-for circular*/
    int noiven=0;
    int chk1;
    //double xc=nx2/2.+0.5;
    double yc=ny/2.+0.5;
    double yc1=ny2/2.+0.5-distance_y*height,yc2=ny2/2.+0.5+distance_y*height;
    double xc1=nx2/2.+0.5-distance_x*height,xc2=nx2/2.+0.5+distance_x*height;
    double zc1=nz2/2.+0.5-distance_z*height,zc2=nz2/2.+0.5*distance_z*height;
    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k);
                S=noiven*ran2(&seed)/mag;
                phi=ran2(&seed)*M_PI*2;
                dirx=sin(theta)*cos(phi);
                diry=sin(theta)*sin(phi);
                dirz=cos(theta);
                if(geo==0) {chk1=(fabs(j-yc)<=height);}
                //if(geo==1) {chk=(sqrt((i-xc)*(i-xc)+(j-yc)*(j-yc))<=height);}
                if(geo==1) {chk1=(sqrt((i-xc1)*(i-xc1)+(j-yc1)*(j-yc1)+(k-zc1)*(k-zc1))<=height)||(sqrt((i-xc2)*(i-xc2)+(j-yc2)*(j-yc2)+(k-zc2)*(k-zc2))<=(height));}
                //    chk3=(sqrt((i-xc1)*(i-xc1)+(j-yc2)*(j-yc2))<=height);
                //    chk4=(sqrt((i-xc2)*(i-xc2)+(j-yc1)*(j-yc1))<=height);
                if(chk1) {/*Nematic phase*/
                    dirx=dinx+noiven*dirx/mag;
		    diry=diny+noiven*diry/mag;
                    dirz=dinz+noiven*dirz/mag;
                    ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
                    dirx=dirx/ndir;
                    diry=diry/ndir;
                    dirz=dirz/ndir;
                    lat->q[l*lcq]  = 0.5*(qe+S)*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*(qe+S)*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*(qe+S)*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*(qe+S)*(3.*dirx*diry-0.0);
                    if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
                        lat->q[l*lcq+4]= 0.5*(qe+S)*(3.*dirx*dirz-0.0);
                        lat->q[l*lcq+5]= 0.5*(qe+S)*(3.*diry*dirz-0.0);}
                    lat->phi[l]=phip0;
		//printf("%d,%d--Q:%f,%f,%f,%f,phi=%f.\n",i,j,lat->q[l*lcq],lat->q[l*lcq+1],lat->q[l*lcq+2],lat->q[l*lcq+3],phi);
		}
                else {/*Isotropic phase*/
                    lat->q[l*lcq]  = 0.5*S*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*S*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*S*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*S*(3.*dirx*diry-0.0);
                    if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
                        lat->q[l*lcq+4]= 0.5*S*(3.*dirx*dirz-0.0);
                        lat->q[l*lcq+5]= 0.5*S*(3.*diry*dirz-0.0);}
                    lat->phi[l]=phim0;
                }
                lat->phinew[l]=lat->phi[l];
                for(int m=0;m<lcq;m++) { lat->qnew[l*lcq+m]=lat->q[l*lcq+m]; }
            } } }
    return;
}


/*To start from a flat interface for isotropic-nematic phase*/
void init_random_drop(lclattice *lat,double height,double dinx, double diny, double dinz) {
    double qe=(-Blc+sqrt(Blc*Blc-24.*Alc*Clc))/(6.*Clc);
    double etaphi=eta0lcphi+etaslcphi*(phip0-phibar);
    if(inphase){
	//Emmanuel: changed to Alc
        double Alceff=Alc*(phip0)*(phip0)*(1.0-etaphi/3.0);
        double Blceff=-Alc*(phip0)*(phip0)*etaphi*Beq0;
        double Clceff=Alc*(phip0)*(phip0)*etaphi;
        qe=(-Blceff+sqrt(Blceff*Blceff-24.*Alceff*Clceff))/(6.*Clceff);
    }
    double rann1=0;
    double rann2=0;
    int nn=((nx==1)||(ny==1)||(nz==1));
    int l;
    double theta=M_PI/2.0,phi;
    double mag=100.,S,dirx,diry,dirz,ndir;
    int geo=shape;/*0-for flat,1-for circular*/
    int noiven=0;
    int chk1=0;
    //double xc=nx2/2.+0.5;
    //double xc=nx2/2.+0.5;
    double yc=ny/2.+0.5;
    double yc1=ny/2.+0.5-distance_y*height,yc2=ny/2.+0.5+distance_y*height;
    double xc1=nx/2.+0.5-distance_x*height,xc2=nx/2.+0.5+distance_x*height;
    double zc1=nz/2.+0.5-distance_z*height,zc2=nz/2.+0.5*distance_z*height;

//elc //ringstat
	int *ringstat=&lat->ringstat;
	if (shape==1) {*ringstat=1;}
	else {*ringstat=0;}
/*	int rstat=*ringstat;
	printf("Ringstat=%d.\n",*ringstat);
	printf("Ringstat=%d.\n",rstat);
	rstat=2;
	*ringstat=3;
	printf("Ringstat=%d.\n",*ringstat);
	printf("Ringstat=%d.\n",rstat);
*/
    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k);
                S=noiven*ran2(&seed)/mag;
                phi=ran2(&seed)*M_PI*2;
                dirx=sin(theta)*cos(phi);
                diry=sin(theta)*sin(phi);
                dirz=cos(theta);
                if(geo==0) {chk1=(fabs(j-yc)<=height);}
                if(geo==1) {chk1=(sqrt((i-xc1)*(i-xc1)+(j-yc1)*(j-yc1)+(k-zc1)*(k-zc1))<=height)||(sqrt((i-xc2)*(i-xc2)+(j-yc2)*(j-yc2)+(k-zc2)*(k-zc2))<=(height));}
		if(geo==2) {chk1=j<(phidim1/ny)*(ny+1);}
                if(chk1) {/*Nematic phase*/
                    rann1=ran2(&seed);
                    if(~nn) rann2=ran2(&seed);
                    theta=rann1*M_PI;
                    phi=rann2*M_PI*2;
                    //if(nx==1) phi=M_PI/2.;
                    if(ny==1) phi=0.0;
                    if(nz==1) theta=M_PI/2.0;
                    dirx=sin(theta)*cos(phi);
                    diry=sin(theta)*sin(phi);
                    dirz=cos(theta);
                    //if(nx==1) dirx=0.0;/*To avoid any perturbation in 3rd direction in 2D simulations*/
                    if(ny==1) diry=0.0;
                    if(nz==1) dirz=0.0;
/*                   
                    ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
                    dirx=dirx/ndir;
                    diry=diry/ndir;
                    dirz=dirz/ndir;

                    lat->q[l*lcq]  = 0.5*qe*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*qe*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*qe*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*qe*(3.*dirx*diry-0.0);
                    lat->q[l*lcq+4]= 0.5*qe*(3.*dirx*dirz-0.0);
                    lat->q[l*lcq+5]= 0.5*qe*(3.*diry*dirz-0.0);  
*/
		lat->phi[l]=1.0;//phip0; //Emmanuel 18/09

//////Emmanuel //ELC


// changed to have random perturbations from an equilibrium (given) director
	double phi=atan2(diny,dinx);
	double noisy=0.0;
	//printf("Initial Condition is with noise of mag:%f",noisy);
        double rann=phi+0.1*(2*ran2(&seed)-1); //phi-0.007*(j-ny2/2);//
	//j-ny/2 gives a croissant shape
        dirx=cos(rann);
        diry=sin(rann);
        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
//printf("dir %f,%f.\n",dirx,diry);
        lat->q[l*lcq]  = 0.5*qe*(3.*dirx*dirx-1.0);
        lat->q[l*lcq+1]= 0.5*qe*(3.*diry*diry-1.0);
        lat->q[l*lcq+2]= 0.5*qe*(3.*dirz*dirz-1.0);
        lat->q[l*lcq+3]= 0.5*qe*(3.*dirx*diry-0.0);
        lat->q[l*lcq+4]= 0.5*qe*(3.*dirx*dirz-0.0);
        lat->q[l*lcq+5]= 0.5*qe*(3.*diry*dirz-0.0);
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }
//printf("%f",qe);
//printf("%f,%f,%f,%f.\n",lat->q[l*lcq],lat->q[l*lcq+1],lat->q[l*lcq+1],lat->q[l*lcq+3]);


                }
                else {//Isotropic phase
                    lat->q[l*lcq]  = 0.5*S*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*S*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*S*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*S*(3.*dirx*diry-0.0);
                    if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
                        lat->q[l*lcq+4]= 0.5*S*(3.*dirx*dirz-0.0);
                        lat->q[l*lcq+5]= 0.5*S*(3.*diry*dirz-0.0);}
                    lat->phi[l]=0.0;//phim0; //Emmanuel 18/09
			//printf("phim0=%f.\n",phim0);
                }

                lat->phinew[l]=lat->phi[l];
                for(int m=0;m<lcq;m++) { lat->qnew[l*lcq+m]=lat->q[l*lcq+m]; }
            }}}
return;
}

void init_phasesep(lclattice *lat,double height,double dinx, double diny, double dinz) {
    double qe=(-Blc+sqrt(Blc*Blc-24.*Alc*Clc))/(6.*Clc);
    double etaphi=eta0lcphi+etaslcphi*(phip0-phibar);
    if(inphase){
	//Emmanuel: changed to Alc
        double Alceff=Alc*(phip0)*(phip0)*(1.0-etaphi/3.0);
        double Blceff=-Alc*(phip0)*(phip0)*etaphi*Beq0;
        double Clceff=Alc*(phip0)*(phip0)*etaphi;
        qe=(-Blceff+sqrt(Blceff*Blceff-24.*Alceff*Clceff))/(6.*Clceff);
    }
    double rann1=0;
    double rann2=0;
    int nn=((nx==1)||(ny==1)||(nz==1));
    int l;
    double theta=M_PI/2.0,phi;
    double mag=100.,S,dirx,diry,dirz,ndir;
    int geo=shape;/*0-for flat,1-for circular*/
    int noiven=0;
    int chk1=0;
    //double xc=nx2/2.+0.5;
    //double xc=nx2/2.+0.5;
    double yc=ny/2.+0.5;
    double yc1=ny/2.+0.5-distance_y*height,yc2=ny/2.+0.5+distance_y*height;
    double xc1=nx/2.+0.5-distance_x*height,xc2=nx/2.+0.5+distance_x*height;
    double zc1=nz/2.+0.5-distance_z*height,zc2=nz/2.+0.5*distance_z*height;

//elc //ringstat
	int *ringstat=&lat->ringstat;
	if (shape==1) {*ringstat=1;}
	else {*ringstat=0;}
/*	int rstat=*ringstat;
	printf("Ringstat=%d.\n",*ringstat);
	printf("Ringstat=%d.\n",rstat);
	rstat=2;
	*ringstat=3;
	printf("Ringstat=%d.\n",*ringstat);
	printf("Ringstat=%d.\n",rstat);
*/
    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k);
                S=noiven*ran2(&seed)/mag;
                phi=ran2(&seed)*M_PI*2;
                dirx=sin(theta)*cos(phi);
                diry=sin(theta)*sin(phi);
                dirz=cos(theta);
//                if(geo==0) {chk1=(fabs(j-yc)<=height);}
//                if(geo==1) {chk1=(sqrt((i-xc1)*(i-xc1)+(j-yc1)*(j-yc1)+(k-zc1)*(k-zc1))<=height)||(sqrt((i-xc2)*(i-xc2)+(j-yc2)*(j-yc2)+(k-zc2)*(k-zc2))<=(height));}
//                if(chk1) {/*Nematic phase*/
/*                    rann1=ran2(&seed);
                    if(~nn) rann2=ran2(&seed);
                    theta=rann1*M_PI;
                    phi=rann2*M_PI*2;
                    //if(nx==1) phi=M_PI/2.;
                    if(ny==1) phi=0.0;
                    if(nz==1) theta=M_PI/2.0;
                    dirx=sin(theta)*cos(phi);
                    diry=sin(theta)*sin(phi);
                    dirz=cos(theta);
*/
                    //if(nx==1) dirx=0.0;/*To avoid any perturbation in 3rd direction in 2D simulations*/
                    if(ny==1) diry=0.0;
                    if(nz==1) dirz=0.0;
/*                   
                    ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
                    dirx=dirx/ndir;
                    diry=diry/ndir;
                    dirz=dirz/ndir;

                    lat->q[l*lcq]  = 0.5*qe*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*qe*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*qe*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*qe*(3.*dirx*diry-0.0);
                    lat->q[l*lcq+4]= 0.5*qe*(3.*dirx*dirz-0.0);
                    lat->q[l*lcq+5]= 0.5*qe*(3.*diry*dirz-0.0);  
*/
		lat->phi[l]=0.5+0.01*(ran2(&seed)-1);//phip0; //Emmanuel 18/09

//////Emmanuel //ELC


// random direction OR random perturbations from an equilibrium (given) director
//change phi
	double rann=ran2(&seed)*M_PI*2;//atan2(diny,dinx);
	double noisy=0.0;
	//printf("Initial Condition is with noise of mag:%f",noisy);
        //double rann=phi+0.1*(2*ran2(&seed)-1); //phi-0.007*(j-ny2/2);//
	//j-ny/2 gives a croissant shape
        dirx=cos(rann);
        diry=sin(rann);
        ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
        dirx=dirx/ndir;
        diry=diry/ndir;
//printf("dir %f,%f.\n",dirx,diry);
        lat->q[l*lcq]  = 0.5*qe*(3.*dirx*dirx-1.0);
        lat->q[l*lcq+1]= 0.5*qe*(3.*diry*diry-1.0);
        lat->q[l*lcq+2]= 0.5*qe*(3.*dirz*dirz-1.0);
        lat->q[l*lcq+3]= 0.5*qe*(3.*dirx*diry-0.0);
        lat->q[l*lcq+4]= 0.5*qe*(3.*dirx*dirz-0.0);
        lat->q[l*lcq+5]= 0.5*qe*(3.*diry*dirz-0.0);
        for(int m=0;m<lcq;m++) { lat->qnew[l+m]=lat->q[l+m]; }


//printf("%f",qe);
//printf("%f,%f,%f,%f.\n",lat->q[l*lcq],lat->q[l*lcq+1],lat->q[l*lcq+1],lat->q[l*lcq+3]);

//                }
/*                else {//Isotropic phase
                    lat->q[l*lcq]  = 0.5*S*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*S*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*S*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*S*(3.*dirx*diry-0.0);
                    if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
                        lat->q[l*lcq+4]= 0.5*S*(3.*dirx*dirz-0.0);
                        lat->q[l*lcq+5]= 0.5*S*(3.*diry*dirz-0.0);}
                    lat->phi[l]=0.0;//phim0; //Emmanuel 18/09
			//printf("phim0=%f.\n",phim0);
                }
*/
                lat->phinew[l]=lat->phi[l];
                for(int m=0;m<lcq;m++) { lat->qnew[l*lcq+m]=lat->q[l*lcq+m]; }
            }}}
return;
}

/*To start from a flat membrane floating in a 3d space*/
void init_membrane3d(lclattice *lat,double height,double dinx, double diny, double dinz) {
    double qe=(-Blc+sqrt(Blc*Blc-24.*Alc*Clc))/(6.*Clc);
    double etaphi=eta0lcphi+etaslcphi*(phip0-phibar);
    if(inphase){
        double Alceff=A0lcphi*(phip0)*(phip0)*(1.0-etaphi/3.0);
        double Blceff=-A0lcphi*(phip0)*(phip0)*etaphi*Beq0;
        double Clceff=A0lcphi*(phip0)*(phip0)*etaphi;
        qe=(-Blceff+sqrt(Blceff*Blceff-24.*Alceff*Clceff))/(6.*Clceff);
    }
    int l;
    double theta=M_PI/2.0,phi;
    double mag=100.,S,dirx,diry,dirz,ndir;
    int geo=1;/*0-for flat,1-for circular*/
    int noiven=0;
    int chk1=0,chk2=0;
    //double xc=nx2/2.+0.5;
    double yc=ny/2.+0.5;
    double yc1=ny2/2.+0.5-distance_y*height,yc2=ny2/2.+0.5+distance_y*height;
    double xc1=nx2/2.+0.5-distance_x*height,xc2=nx2/2.+0.5+distance_x*height;
    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k);
                S=noiven*ran2(&seed)/mag;
                phi=ran2(&seed)*M_PI*2;
                dirx=sin(theta)*cos(phi);
                diry=sin(theta)*sin(phi);
                dirz=cos(theta);
                if(geo==0) {chk1=(fabs(j-yc)<=height);}
                //if(geo==1) {chk=(sqrt((i-xc)*(i-xc)+(j-yc)*(j-yc))<=height);}
                if(geo==1) {chk1=(sqrt((i-xc1)*(i-xc1)+(j-yc1)*(j-yc1))<=height)||(sqrt((i-xc2)*(i-xc2)+(j-yc2)*(j-yc2))<=(height));}
                //chk2 = (k-nz/2==1)||(k-nz/2==-1)||k==nz/2;
                chk2 = (k-nz/2==1)||k==nz/2;
                //    chk3=(sqrt((i-xc1)*(i-xc1)+(j-yc2)*(j-yc2))<=height);
                //    chk4=(sqrt((i-xc2)*(i-xc2)+(j-yc1)*(j-yc1))<=height);
                if(chk1&&chk2) {/*Nematic phase*/
                    dirx=dinx+noiven*dirx/mag;diry=diny+noiven*diry/mag;dirz=dinz+noiven*dirz/mag;
                    ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
                    dirx=dirx/ndir;
                    diry=diry/ndir;
                    dirz=dirz/ndir;
                    lat->q[l*lcq]  = 0.5*(qe+S)*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*(qe+S)*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*(qe+S)*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*(qe+S)*(3.*dirx*diry-0.0);
                    if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
                        lat->q[l*lcq+4]= 0.5*(qe+S)*(3.*dirx*dirz-0.0);
                        lat->q[l*lcq+5]= 0.5*(qe+S)*(3.*diry*dirz-0.0);}
                    lat->phi[l]=phip0;
                }
                else {/*Isotropic phase*/
                    lat->q[l*lcq]  = 0.5*S*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*S*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*S*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*S*(3.*dirx*diry-0.0);
                    if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
                        lat->q[l*lcq+4]= 0.5*S*(3.*dirx*dirz-0.0);
                        lat->q[l*lcq+5]= 0.5*S*(3.*diry*dirz-0.0);}
                    lat->phi[l]=phim0;
                }
                lat->phinew[l]=lat->phi[l];
                for(int m=0;m<lcq;m++) { lat->qnew[l*lcq+m]=lat->q[l*lcq+m]; }
            } } }
    return;
}

/*To start from a single pitch in 2D*/
void init_single_pitch(lclattice *lat,double height,double pitch) {
    double qe=(-Blc+sqrt(Blc*Blc-24.*Alc*Clc))/(6.*Clc);
    double etaphi=eta0lcphi+etaslcphi*(phip0-phibar);
    if(inphase){
        double Alceff=A0lcphi*(phip0)*(phip0)*(1.0-etaphi/3.0);
        double Blceff=-A0lcphi*(phip0)*(phip0)*etaphi*Beq0;
        double Clceff=A0lcphi*(phip0)*(phip0)*etaphi;
        qe=(-Blceff+sqrt(Blceff*Blceff-24.*Alceff*Clceff))/(6.*Clceff);
    }
    int l;
    double theta=M_PI/2.0,phi;
    double mag=100.,S,dirx,diry,dirz,ndir;
    int geo=1;/*0-for flat,1-for circular*/
    int noiven=0;
    int chk1=0;
    double yc=ny/2.+0.5;
    double yc1=ny2/2.+0.5-distance_y*height,yc2=ny2/2.+0.5+distance_y*height;
    double xc1=nx2/2.+0.5-distance_x*height,xc2=nx2/2.+0.5+distance_x*height;
    double zc1=nz2/2.+0.5-distance_z*height,zc2=nz2/2.+0.5*distance_z*height;
    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k);
                S=noiven*ran2(&seed)/mag;
                phi=ran2(&seed)*M_PI*2;
                dirx=sin(theta)*cos(phi);
                diry=sin(theta)*sin(phi);
                dirz=cos(theta);
                if(geo==0) {chk1=(fabs(j-yc)<=height);}
                //if(geo==1) {chk=(sqrt((i-xc)*(i-xc)+(j-yc)*(j-yc))<=height);}
                if(geo==1) {chk1=(sqrt((i-xc1)*(i-xc1)+(j-yc1)*(j-yc1)+(k-zc1)*(k-zc1))<=height)||(sqrt((i-xc2)*(i-xc2)+(j-yc2)*(j-yc2)+(k-zc2)*(k-zc2))<=(height));}
                //    chk3=(sqrt((i-xc1)*(i-xc1)+(j-yc2)*(j-yc2))<=height);
                //    chk4=(sqrt((i-xc2)*(i-xc2)+(j-yc1)*(j-yc1))<=height);
                if(chk1) {/*Nematic phase*/
		    //dirx=cos(pitch*j/2);
		    //diry=0.0;
		    //dirz=-sin(pitch*j/2);
                    ndir=sqrt(dirx*dirx+diry*diry+dirz*dirz);
                    dirx=dirx/ndir;
                    diry=diry/ndir;
                    dirz=dirz/ndir;
                    lat->q[l*lcq]  = 0.5*(qe+S)*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*(qe+S)*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*(qe+S)*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*(qe+S)*(3.*dirx*diry-0.0);
                    if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
                        lat->q[l*lcq+4]= 0.5*(qe+S)*(3.*dirx*dirz-0.0);
                        lat->q[l*lcq+5]= 0.5*(qe+S)*(3.*diry*dirz-0.0);}
                    lat->phi[l]=phip0;
                }
                else {/*Isotropic phase*/
                    lat->q[l*lcq]  = 0.5*S*(3.*dirx*dirx-1.0);
                    lat->q[l*lcq+1]= 0.5*S*(3.*diry*diry-1.0);
                    lat->q[l*lcq+2]= 0.5*S*(3.*dirz*dirz-1.0);
                    lat->q[l*lcq+3]= 0.5*S*(3.*dirx*diry-0.0);
                    if(nz==1) {lat->q[l*lcq+4]=0.0;lat->q[l*lcq+5]=0.0;} else {
                        lat->q[l*lcq+4]= 0.5*S*(3.*dirx*dirz-0.0);
                        lat->q[l*lcq+5]= 0.5*S*(3.*diry*dirz-0.0);}
                    lat->phi[l]=phim0;
                }
                lat->phinew[l]=lat->phi[l];
                for(int m=0;m<lcq;m++) { lat->qnew[l*lcq+m]=lat->q[l*lcq+m]; }
            } } }
    return;
}

/*To start from random configuration*/
void init_randomforphi(lclattice *lat) {
int l;
// double abyb=sqrt(-Aphi/Bphi);
for(int i=0;i<nx2;i++) {
   for(int j=0;j<ny2;j++) {
      for(int k=0;k<nz2;k++) {
        l = ((i*ny2+j)*nz2+k);
        lat->phi[l] = phi0+0.01*(2*ran2(&seed)-1);//+abyb*(2*ran2(&seed)-1);
        lat->phinew[l]=lat->phi[l];
} } }
return;
}

void modify_initial_conditions_lc(lclattice *latc, wedge *latw) {
int l;
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]<swall) {
        for(int m=0;m<lcq;m++) {latc->q[l*lcq+m]=0; latc->qnew[l*lcq+m]=0; }
};};};};
return;
}

void find_for_anchoring_lc(lclattice *latc, wedge *latw) {
int l,lin=0,lon=0;
double qe=qeq();
double xc,yc,vx,vy,mag,ux,uy,uz=0.0,xdiffb,xdifft,ydiff,qxb,qxt,qx;
int rx,ry,leftbx,leftby,lleftb,rigtbx,rigtby,lrigtb,lefttx,leftty,lleftt,rigttx,rigtty,lrigtt;
int swallcnt=0;
int lwallcnt=0;
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      if(latw->w[(i*ny2+j)*nz2+k]==swall) {swallcnt++;}
      if(latw->w[(i*ny2+j)*nz2+k]==lwall) {lwallcnt++;}
}}}
latw->swallcnt=swallcnt;
latw->neighswall= (int *)malloc(swallcnt*5*sizeof(int));/*l,left_bottom,right_bottom,left_top,right_top,are the 5 ls*/
latw->diffneigh= (double *)malloc(swallcnt*3*sizeof(double));/*xdiff_bottom,xdiff_top,ydiff are the 3*/
latw->qeonswall= (double *)malloc(swallcnt*lcq*sizeof(double));/*Q on the surface of the particle/swalls*/
latw->lwallcnt=lwallcnt;
latw->lwallloc= (int *)malloc(lwallcnt*sizeof(int));/*l of lwalls*/
latw->qeonlwall= (double *)malloc(lwallcnt*lcq*sizeof(double));/*Q on the surface of the particle/lwalls*/
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]==swall) {
        xc = latw->partloc[(latw->partmark[l]-1)*lcd+0];
	yc = latw->partloc[(latw->partmark[l]-1)*lcd+1];
	vx=i-xc;
	vy=j-yc;
	mag=sqrt(vx*vx+vy*vy);
	rx=(0<vx)-(vx<0);
	ry=(0<vy)-(vy<0);
	ux= vx/mag;
	uy= vy/mag;
	leftbx=(int) (xc+vx+ux);
	leftby=(int) (yc+vy+uy);
        lleftb=(leftbx*ny2+leftby)*nz2+k;
	rigtbx=leftbx+1;
	rigtby=leftby;
        lrigtb=(rigtbx*ny2+rigtby)*nz2+k;
	lefttx=leftbx;
	leftty=leftby+1;
        lleftt=(lefttx*ny2+leftty)*nz2+k;
	rigttx=leftbx+1;
	rigtty=leftby+1;
        lrigtt=(rigttx*ny2+rigtty)*nz2+k;
	latw->neighswall[lin*5+0]=l;
	latw->neighswall[lin*5+1]=lleftb;
	latw->neighswall[lin*5+2]=lrigtb;
	latw->neighswall[lin*5+3]=lleftt;
	latw->neighswall[lin*5+4]=lrigtt;
	xdiffb=xc+vx+ux-leftbx;
	if(latw->w[lleftb]<lwall) xdiffb=0;
	if(latw->w[lrigtb]<lwall) xdiffb=1;
	xdifft=xc+vx+ux-lefttx;
	if(latw->w[lleftt]<lwall) xdifft=0;
	if(latw->w[lrigtt]<lwall) xdifft=1;
	ydiff=yc+vy+uy-leftby;
	if((latw->w[lleftb]<lwall)&&(latw->w[lrigtb]<lwall)) ydiff=0;
	if((latw->w[lleftt]<lwall)&&(latw->w[lrigtt]<lwall)) ydiff=1;
	if((latw->w[lleftb]<lwall)&&(latw->w[lrigtb]<lwall)&&(latw->w[lleftt]<lwall)&&(latw->w[lrigtt]<lwall)) {exit(1);};
	latw->diffneigh[lin*3+0]=xdiffb;
	latw->diffneigh[lin*3+1]=xdifft;
	latw->diffneigh[lin*3+2]=ydiff;
	latw->qeonswall[lin*lcq+0]= 0.5*qe*(3.*ux*ux-1.0);
	latw->qeonswall[lin*lcq+1]= 0.5*qe*(3.*uy*uy-1.0);
	latw->qeonswall[lin*lcq+2]= 0.5*qe*(3.*uz*uz-1.0);
	latw->qeonswall[lin*lcq+3]= 0.5*qe*(3.*ux*uy-0.0);
	latw->qeonswall[lin*lcq+4]= 0.5*qe*(3.*ux*uz-0.0);
	latw->qeonswall[lin*lcq+5]= 0.5*qe*(3.*uy*uz-0.0);
	lin++;
	for(int m=0;m<lcq;m++) {
	qxb=latc->q[lleftb*lcq+m]*xdiffb+latc->q[lrigtb*lcq+m]*(1.0-xdiffb);
	qxt=latc->q[lleftt*lcq+m]*xdifft+latc->q[lrigtt*lcq+m]*(1.0-xdifft);
	qx=qxb*ydiff+qxt*(1.0-ydiff);
	latc->q[l*lcq+m]=qx-(qx-qe)*2*bWlc/Klc;
	latc->qnew[l*lcq+m]=latc->q[l*lcq+m];
	}
      }
      if(latw->w[l]==lwall) {
        xc = latw->partloc[(latw->partmark[l]-1)*lcd+0];
	yc = latw->partloc[(latw->partmark[l]-1)*lcd+1];
	vx=i-xc;
	vy=j-yc;
	mag=sqrt(vx*vx+vy*vy);
	ux= vx/mag;
	uy= vy/mag;
	latw->lwallloc[lon]=l;
	latw->qeonlwall[lon*lcq+0]= 0.5*qe*(3.*ux*ux-1.0);
	latw->qeonlwall[lon*lcq+1]= 0.5*qe*(3.*uy*uy-1.0);
	latw->qeonlwall[lon*lcq+2]= 0.5*qe*(3.*uz*uz-1.0);
	latw->qeonlwall[lon*lcq+3]= 0.5*qe*(3.*ux*uy-0.0);
	latw->qeonlwall[lon*lcq+4]= 0.5*qe*(3.*ux*uz-0.0);
	latw->qeonlwall[lon*lcq+5]= 0.5*qe*(3.*uy*uz-0.0);
	lon++;
    }
};};};
return;
}

void initiate_celld(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
int m,xc,yc;
for(int i=0;i<numofcelld;i++) {
if(numofcelld==1) {
xc=nx/2;
yc=ny/2;}
else {
xc=(int)((nx-sizofcelld)*ran2(&seed));
yc=(int)((nx-sizofcelld)*ran2(&seed));}
if(numofcelld==1) {
latc->tmcelld[i]=0;}
else {
latc->tmcelld[i]=(int)((timofcelld-1)*ran2(&seed)+1);}
m=0;
for(int j=0;j<sizofcelld;j++) {
  for(int k=0;k<sizofcelld;k++) {
  latc->locelld[i*sizofcelld*sizofcelld+m]=((xc+j)*ny2+(yc+k))*nz2+1;
//  printf("%d %d %d %d %d %d %d\n",tm,i,m,i*sizofcelld*sizofcelld+m,xc+j,yc+k,latc->tmcelld[i]);
  m++;
 }  }
}
return;
}

/*Calculation of qeq*/
double qeq() {
	//Emmanuel: check qeq everywhere!!!
//    double res=Blc*Blc-24.*Alc*Clc;
//   res=res>0?(-Blc+sqrt(res))/(6.*Clc):1e-16;//Emmanuel: Why 6 and not 4?
	double etaphi=eta0lcphi-etaslcphi;
	double res=3.0*(etaphi)-8.0;
	res=res>0?(1.0+sqrt(res/(3.0*etaphi)))/18.0*Alc:1e-16;
	//printf("res:%f.\n",res);
	return (res);
}
