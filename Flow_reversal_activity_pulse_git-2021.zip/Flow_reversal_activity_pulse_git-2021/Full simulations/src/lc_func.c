/* functions associated with liquid crystal simulation*/

/*LC initialisation and setting parameters*/
lclattice *lcsetting(int i) {
    
    /*structure qlat describes all parameters associated with lc*/
    lclattice *lat = liqcry_initialise(i);    /*initialises a LC lattice, allocates sufficient memories*/
    if(sconst==0) {
        if(K2lc!=0) system("pause");
        if(K3lc!=0) system("pause");
    };
    return lat;
}

/*Lattice initialisation*/
lclattice *liqcry_initialise(int i) {
    lclattice *lat=(lclattice *)malloc(sizeof(lclattice));/*variable associated with all lattice parameters*/
    
    lat->q = (double *)malloc(nx2*ny2*nz2*lcq*sizeof(double));/*distribution functions*/
    lat->qnew = (double *)malloc(nx2*ny2*nz2*lcq*sizeof(double));/*distribution functions*/
    lat->qflux = (double *)malloc(nx2*ny2*nz2*lcq*sizeof(double));/*distribution functions*/
    lat->H = (double *)malloc(nx2*ny2*nz2*lcq*sizeof(double));/*molecular filed*/
    lat->estress = (double *)malloc(nx2*ny2*nz2*lcd*2*sizeof(double));/*stresses for equilibrium in LB*/
    lat->bstress = (double *)malloc(nx2*ny2*nz2*lcd*lcd*sizeof(double));/*stresses for body force in LB*/
	lat->viscstress = (double *)malloc(nx2*ny2*nz2*lcd*lcd*sizeof(double));	
	lat->elasstress = (double *)malloc(nx2*ny2*nz2*lcd*lcd*sizeof(double));
	lat->actstress = (double *)malloc(nx2*ny2*nz2*lcd*lcd*sizeof(double));
	lat->capstress = (double *)malloc(nx2*ny2*nz2*lcd*lcd*sizeof(double));
	lat->totstress = (double *)malloc(nx2*ny2*nz2*lcd*lcd*sizeof(double));
	if(inphase) lat->fe_phi = (double *)malloc(nx2*ny2*nz2*sizeof(double));
    lat->presure = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*pressure if required*/
    lat->fe_nematics = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*fe_Q*/	
    //lat->mcharge = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*charge from Q*/
    lat->dcharge = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*charge from director*/
    lat->dir = (double *)malloc(nx2*ny2*nz2*(lcd+1)*sizeof(double));/*S and d from Q*/
    if(isdragbody||isdragboun) lat->tforce = (double *)malloc(nx2*ny2*nz2*lcd*sizeof(double));
			/*total force if required*/
    lat->tbwall=0;/*information about top-bottom wall bc, by default it is zero meaning no wall*/
		// Emmanuel: This is also found in lb_d3q15 (file to evolve u via LB)
    lat->Dt=timestep;
    for(int l=0; l<n2max; l++) {lat->qflux[l]=0.0;} /*filling with zeros*/
    
    switch (i) {
        case 1:
            lat->methodofintg=&euler_update;
            break;
        case 2:
            lat->methodofintg=&rk2_update;
            lat->qkep = (double *)malloc(nx2*ny2*nz2*lcq*sizeof(double));/*distribution functions*/
            break;
        case 3:
            lat->methodofintg=&eulerrk2_update;
            lat->qkep = (double *)malloc(nx2*ny2*nz2*lcq*sizeof(double));/*distribution functions*/
            break;
    }
    /*Basis vectors for Q tensor in 3 dimensions*/
    	T1[0][0] = -1.0/sqrt(6);	T1[1][1] = -1.0/sqrt(6);	T1[2][2] = 2.0/sqrt(6);
    	T2[0][0] = 1.0/sqrt(2);		T2[1][1] = -1.0/sqrt(2);
    	T3[0][1] = 1.0/sqrt(2);		T3[1][0] = 1.0/sqrt(2);
    	T4[0][2] = 1.0/sqrt(2);		T4[2][0] = 1.0/sqrt(2);
 	T5[1][2] = 1.0/sqrt(2);		T5[2][1] = 1.0/sqrt(2);
    if(inphase) {
        lat->phi = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*concentration*/
        //lat->dphidx = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*phi-gradient x*/
        //lat->dphidy = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*phi-gradient y*/
        //lat->dphidz = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*phi-gradient z*/
        lat->phinew = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*concentration*/
        lat->mu = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*concentration*/
        lat->phiflux = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*concentration*/
        if((i==2)||(i==3))
            lat->phikep = (double *)malloc(nx2*ny2*nz2*sizeof(double));/*concentration*/
        phip0=1.0;//phi0+sqrt(-Aphi/Bphi);
        phim0=0.0;//phi0-sqrt(-Aphi/Bphi);
    }
    if(issingcelld) {
        lat->locelld=(int *)malloc(numofcelld*sizofcelld*sizofcelld*sizeof(int));
        lat->tmcelld=(int *)malloc(numofcelld*sizeof(int));
    }

    if(iswithpoly) {// Allocate memory for polymers, initialise
	//if (inphase==0) printf("WARNING. NOT INPHASE. PHI_C MAY BE UNDEFINED. C must be defined with phi?\n");
	poly_initialise(lat);
	for(int l=0; l<n2max; l++) {lat->cflux[l]=0.0;} /*filling with zeros*/// 
	for(int l=0; l<n2max; l++) {lat->lflux[l]=0.0;} /*filling with zeros*/// 
        if((i==2)||(i==3))    lat->ckep = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));/*if using RK2*/
	if((i==2)||(i==3))    lat->lkep = (double *)malloc(nx2*ny2*nz2*lcc*sizeof(double));/*if using RK2*/
	}
    if(iswithcelldiv) celldivision_init(lat);
    
    return lat;
}

void eulerrk2_update(lblattice *latv, lclattice *latc, wedge *latw, int t, double Dt,int itern) {
    double dt=Dt/nsteps;
    for(int iter=1;iter<=nsteps;iter++) {
        itern = (iter==nsteps) ? 1 : 0;
        rk2_update(latv, latc, latw,t,dt,itern);}
    return;
}

void rk2_update(lblattice *latv, lclattice *latc, wedge *latw, int t, double Dt,int itern) {
    copyffs(latc->q,latc->qkep,lcq);
    //if(iswithpoly) copyffs(latc->c,latc->ckep,lcc);; 
    //copyffs(latc->c,latc->ckep,lcc);; 
    copyffs(latc->l,latc->lkep,lcc);; 
    if(latc->phi!=NULL) copyffs(latc->phi,latc->phikep,inphase);
	/*inphase instead of 1 to prevent loop execution in case null-pointer does not work*/
    euler_update_onestep(latv,latc,latw,t,Dt/2,0,latc->q,latc->qnew,latc->c,latc->cnew,latc->l,latc->lnew,latc->phi,latc->phinew);
    swapffs(&latc->q,&latc->qnew);
    //if(iswithpoly) swapffs(&latc->c,&latc->cnew); 
    //swapffs(&latc->c,&latc->cnew); 
    swapffs(&latc->l,&latc->lnew); 
    swapffs(&latc->phi,&latc->phinew);
    (*latc->bc_func)(latv,latc,latw,&latc->q[0],lcq);
    //if(iswithpoly) (*latc->bc_func_c)(latv,latc,latw,&latc->c[0],lcc); 
    //(*latc->bc_func_c)(latv,latc,latw,&latc->c[0],lcc); 
    (*latc->bc_func_c)(latv,latc,latw,&latc->l[0],lcc); 
    (*latc->bc_funcphi)(latv,latc,latw,&latc->phi[0],1);
	
    euler_update_onestep(latv,latc,latw,t,Dt,itern,latc->qkep,latc->qnew,latc->ckep,latc->cnew,latc->l,latc->lnew,latc->phikep,latc->phinew);
    swapffs(&latc->q,&latc->qnew);
    //if(iswithpoly) swapffs(&latc->c,&latc->cnew);
    //swapffs(&latc->c,&latc->cnew); 
    swapffs(&latc->l,&latc->lnew); 
    swapffs(&latc->phi,&latc->phinew);
    (*latc->bc_func)(latv,latc,latw,&latc->q[0],lcq);
    //if(iswithpoly) (*latc->bc_func_c)(latv,latc,latw,&latc->c[0],lcc); 
    //(*latc->bc_func_c)(latv,latc,latw,&latc->c[0],lcc); 
    (*latc->bc_func_c)(latv,latc,latw,&latc->l[0],lcc); 
    (*latc->bc_funcphi)(latv,latc,latw,&latc->phi[0],1);
    return;
}

void euler_update(lblattice *latv, lclattice *latc, wedge *latw, int t, double Dt, int itern) {
    double dt=latc->Dt/nsteps;
    for(int iter=1;iter<=nsteps;iter++) {
        itern = (iter==nsteps) ? 1 : 0;
        euler_update_onestep(latv,latc,latw,t,dt,itern,latc->q,latc->qnew,latc->c,latc->cnew,latc->l,latc->lnew,latc->phi,latc->phinew);
        swapffs(&latc->q,&latc->qnew);
	//if(iswithpoly) {swapffs(&latc->c,&latc->cnew);}
	//swapffs(&latc->c,&latc->cnew); //commentelc-logconformation
	swapffs(&latc->l,&latc->lnew);
        swapffs(&latc->phi,&latc->phinew);
	(*latc->bc_func)(latv,latc,latw,&latc->q[0],lcq,t);
        //if(iswithpoly) (*latc->bc_func_c)(latv,latc,latw,&latc->c[0],lcc);
	//(*latc->bc_func_c)(latv,latc,latw,&latc->c[0],lcc);
	(*latc->bc_func_c)(latv,latc,latw,&latc->l[0],lcc);
	(*latc->bc_funcphi)(latv,latc,latw,&latc->phi[0],1);

//save C tensor after writing L=log C
if(iswithpoly){
double *l=&latc->l[0];
for(int i=1;i<=nx;i++) {
for(int j=1;j<=ny;j++) {
for(int k=1;k<=nz;k++) {
    	int lpt = (i*ny2+j)*nz2+k;
	int lptcc=lpt*lcc;
double *lloc=&l[lptcc];
	latc->c[lptcc]=exp(2*lloc[0]);
	latc->c[lptcc+1]=lloc[3]*lloc[3]+exp(2*lloc[1]);
	latc->c[lptcc+2]=lloc[4]*lloc[4]+lloc[5]*lloc[5]+exp(2*lloc[2]);
	latc->c[lptcc+3]=exp(lloc[0])*lloc[3];
	latc->c[lptcc+4]=exp(lloc[0])*lloc[4];
	latc->c[lptcc+5]=lloc[3]*lloc[4]+exp(lloc[1])*lloc[5];	
}}}// end ijk
}//end iswithpoly
    };
    return;
}

void euler_update_onestep(lblattice *latv, lclattice *latc, wedge *latw,int t, double dt,int iter, double *qold, double *qnew, double *cold, double *cnew, double *lold, double *lnew, double *phiold, double *phinew) {
    double *qflux=&latc->qflux[0];
    //double *cflux=&latc->cflux[0];//commentelc-logconformation
    double *lflux=&latc->lflux[0];
    double *pflux=&latc->phiflux[0];
    int *w=&latw->w[0];
    qflux_calc(latv,latc,latw,t,iter);
    if(iswithcelldiv) celldivision(latc,t);
//if(t%50==0) printf("The time is %d.\n",t);

    for(int i=1;i<=nx;i++) {
    for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
          int lpt = (i*ny2+j)*nz2+k;
          if(w[lpt]>=0) {
              if(inphase) phinew[lpt]=phiold[lpt]+0.0*dt*pflux[lpt];
              if(!noliqc) {
                  int lptcq = lpt*lcq;
                  for(int m=0; m<lcq;m++) {qnew[lptcq+m]=qold[lptcq+m]+dt*qflux[lptcq+m];};
                  double traceqnew=(qnew[lptcq]+qnew[lptcq+1]+qnew[lptcq+2])/3.0;
		  /*Forcing the trace of q to zero. By trial, error was less than 10^-5.*/
                  qnew[lptcq]-=traceqnew;
		  qnew[lptcq+1]-=traceqnew;
		  qnew[lptcq+2]-=traceqnew;
			  }
                  //latc->mcharge[lpt]=chargecalc(&dqx[0],&dqy[0],&dqz[0]);
	      if(iswithpoly) {int lptcc = lpt*lcc;
	      //for(int m=0; m<lcc;m++) {cnew[lptcc+m]=cold[lptcc+m]+dt*cflux[lptcc+m];}; //commentelc-logconformation
	      for(int m=0; m<lcc;m++) {lnew[lptcc+m]=lold[lptcc+m]+dt*lflux[lptcc+m];};
	      if(inphase){if (phinew[lpt]>=0.99999999999){//if(j>12){printf("At time t=%d, at (%d,%d): %f,%f.\n",t,i,j,lold[lptcc],lold[lptcc+1]);}
		for(int m=0; m<lcc;m++) {lnew[lptcc+m]=0.0;};
		};};//endinphase again
	      }//end iswithpoly
           };//for if w[lpt]>=0
    }; }; }; // for i,j,k
	
    return;
}

void qflux_calc(lblattice *latv, lclattice *latc, wedge *latw, int tm, int iter) {

//declaration for order parameter Q
	double *u=&latv->u[0];
	double *q=&latc->q[0];
	double *qflux=&latc->qflux[0];
	double *H=&latc->H[0];
	int *w=&latw->w[0];
	int *ringstat=&latc->ringstat;

//declaration for general variables
	//double order=0.0,elasticity=0.0,concen=0.0,surftens=0.0,anchor=0.0;
	//Emmanuel: not needed for now
	int lps[26];	/*lps is for normal CD (without wall, for eg in lap calc), 
			26 are for normal and mixed CDs for 3 elastic constants*/
	double wls[3]={0.5, 0.5, 0.5};
	int *lpv=&lps[0];	/*This is same as lps if no solid geometry, 
				otherwise this will be modified to recognize walls f(for eg in delu calc)*/
	double *wlp=&wls[0];
	double sigma=sqrt(2*kbT*Gammalc);
	double visc=(taulb-0.5)/3.0;

//declaration of variables diffusive_flux_q
    	double coup_Q[6]={0.0,0.0,0.0,0.0,0.0,0.0};
    	double Alceff=Alc,Blceff=-Blc,Clceff=Clc;

//declaration for concentration phi
	double *phi=&latc->phi[0];
	double *mu=&latc->mu[0];

//declaration for polymers                  //Emmanuel: check
	double *c=&latc->c[0];
	double *cflux=&latc->cflux[0];
	double *l=&latc->l[0];
	double *lflux=&latc->lflux[0];
	double A_c=1.0/tau_poly;
	double ellsq_poly=Klc*tau_poly*Gammalc;
	double Alceff_poly=0.5*A_c;


double cm_x=0.0, cm_y=0.0;
int rstat=*ringstat;
//printf("Time is %d \n",tm);

////////////////////////////////////////////////////////////// Main loops
for(int i=1;i<=nx;i++) {
for(int j=1;j<=ny;j++) {
for(int k=1;k<=nz;k++) {

    	int lpt = (i*ny2+j)*nz2+k;
    	if(w[lpt]>=0) {		//Emmanuel: check w[lpt].
//printf("Level 0.\n");
	double delu[9],strain[6],vortic[3];
	double bstress[9]={0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};//bstress for saving
	double estress[6]={0.0,0.0,0.0,0.0,0.0,0.0};//estress for saving
	double pstress[6]={0.0,0.0,0.0,0.0,0.0,0.0};//polystress
	double astress[6]={0.0,0.0,0.0,0.0,0.0,0.0};//actstress
	double elstress[6]={0.0,0.0,0.0,0.0,0.0,0.0};//elasstress
	double cstress[6]={0.0,0.0,0.0,0.0,0.0,0.0};//capstress
	double totalfree=0.0;
	double dqx[6],dqy[6],dqz[6];		/*derivatives of q*/
	
///// Preparatory calculations for point lpt = (i*ny2+j)*nz2+k;
	int lptlw=(w[lpt]==lwall);	//Emmanuel: for now, using pbc. all are 0.
        int lptcq=lpt*lcq;
	int lptcc=lpt*lcc;
	derivativesN(i,j,k,&lps[0]);
	double *qloc=&q[lptcq];
	double *cloc=&c[lptcc];
	double *lloc=&l[lptcc];
	double *uloc = &u[lpt*lbd];
	double philoc=0.0;//randomnumbernotimpt
	if(inphase) philoc=phi[lpt];
	double etaphi=eta0lcphi+etaslcphi*(philoc-phibar);
	Alceff=Alc*(1.0-etaphi/3.0);
        Blceff=-Alc*etaphi*Beq0;
        Clceff=Alc*etaphi;

	//reconstruct cloc from l //commentelc-logconformation 
if(iswithpoly){
	cloc[0]=exp(2*lloc[0]);
	cloc[1]=lloc[3]*lloc[3]+exp(2*lloc[1]);
	cloc[2]=lloc[4]*lloc[4]+lloc[5]*lloc[5]+exp(2*lloc[2]);
	cloc[3]=exp(lloc[0])*lloc[3];
	cloc[4]=exp(lloc[0])*lloc[4];
	cloc[5]=lloc[3]*lloc[4]+exp(lloc[1])*lloc[5];	
	if((tm>tini+1000)&&(tm<tini+1500)&&(j>15)&&(j<20)){
	if(tm=241000) printf("Time%d: C at %d,%d is %f %f %f\n",tm,i,j,cloc[0],cloc[1],cloc[3]);
	}
}


	double tr_lndet=0.0;
	if(iswithpoly) tr_lndet=cloc[0]+cloc[1]+cloc[2]-log(determinant_matrix(cloc))-3.0;
	//See op_polymers.c for determinant //Emmanuel: inserted -3.0 to make fe_phi have min near 0
        derivativesQ(q,&dqx[0],&dqy[0],&dqz[0],&lps[0]);
	/*For Q, actual lps as anchoring conditions on wall always specified*/
        //if(isgeom) {lpv=&latw->lpv[lpt*2*lbd]; wlp=&latw->wlp[lpt*lbd];};
	/*Need to change 2*lbd to 26 if all derivatives are to be included*/
	derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);

	//powers of Q	
	double traceq2=qloc[0]*qloc[0]+qloc[1]*qloc[1]+qloc[2]*qloc[2]
			+2*(qloc[3]*qloc[3]+qloc[4]*qloc[4]+qloc[5]*qloc[5]);
	double traceq3=qloc[0]*qloc[0]*qloc[0]+qloc[1]*qloc[1]*qloc[1]
			+qloc[2]*qloc[2]*qloc[2]+6*qloc[3]*qloc[4]*qloc[5]
                	+3*qloc[0]*(qloc[3]*qloc[3]+qloc[4]*qloc[4])
                	+3*qloc[1]*(qloc[3]*qloc[3]+qloc[5]*qloc[5])
                	+3*qloc[2]*(qloc[4]*qloc[4]+qloc[5]*qloc[5]);

	//derivatives of phi
	double dphidx,dphidy,dphidz;
	int las=lpt*lcd*lcd;


// Level 1: Phi: concentration
//printf("Level 1.\n");
	if(inphase) {
        double etaphi=eta0lcphi+etaslcphi*(philoc-phibar);
        Alceff=Alc*(1.0-etaphi/3.0); //EDITFE //*philoc*philoc
        Blceff=-Alc*etaphi*Beq0; //EDITFE //*philoc*philoc
        Clceff=Alc*etaphi; //EDITFE //*philoc*philoc

	//more derivatives of phi
	dphidx=0.5*(latc->phi[lps[0]]-latc->phi[lps[1]]);
        dphidy=0.5*(latc->phi[lps[2]]-latc->phi[lps[3]]);
        dphidz=0.5*(latc->phi[lps[4]]-latc->phi[lps[5]]);	
	double dphidspace2=dphidx*dphidx+dphidy*dphidy+dphidz*dphidz;

	//anchoring
	coup_Q[0]=-Lw*(dphidx*dphidx-dphidspace2/3.0);
        coup_Q[1]=-Lw*(dphidy*dphidy-dphidspace2/3.0);
        coup_Q[2]=-Lw*(dphidz*dphidz-dphidspace2/3.0);
        coup_Q[3]=-Lw*dphidx*dphidy;
        coup_Q[4]=-Lw*dphidx*dphidz;
        coup_Q[5]=-Lw*dphidy*dphidz;

	//Calculating free energy
	latc->fe_phi[lpt]=0.5*Aphi*philoc*philoc*(1-philoc)*(1-philoc) 
		+0.5*Kphi*dphidspace2
		+Lw*(dphidx*dphidx*qloc[0]+2.0*dphidx*dphidy*qloc[3]
		+2.0*dphidx*dphidz*qloc[4]+dphidy*dphidy*qloc[1]
		+2.0*dphidy*dphidz*qloc[5]+dphidz*dphidz*qloc[2]);


	//Calculating potential for phi
	double lap_phi = lap_oonopuri(latc->phi,&lps[0],lpt);
	double Qcontribution=0.0;// Alc*(0.5*(1.0-etaphi/3.0)*traceq2  //EDITFE //*philoc 2.0*
			//-Beq0*etaphi*traceq3/3.0+0.25*etaphi*traceq2*traceq2);
	double Ccontribution=-0.5*A_c*(1.0-philoc)*tr_lndet;//0.0;
			//-A_c*(1.0-philoc)*tr_lndet*(polyphicoup); //EDITFE
	double freegrad=Alc*(-0.5*etaslcphi*traceq2/3.0  //EDITFE //*philoc*philoc
		-Beq0*etaslcphi*traceq3/3.0+0.25*etaslcphi*traceq2*traceq2);
	double ddphidxdx = latc->phi[lps[0]]+latc->phi[lps[1]]-2*philoc;
        double ddphidydy = latc->phi[lps[2]]+latc->phi[lps[3]]-2*philoc;
        double ddphidzdz = latc->phi[lps[4]]+latc->phi[lps[5]]-2*philoc;
        double ddphidxdy = 0.25*(latc->phi[lps[14]]-latc->phi[lps[16]]
			-latc->phi[lps[15]]+latc->phi[lps[17]]);
        double ddphidxdz = 0.25*(latc->phi[lps[18]]-latc->phi[lps[20]]
			-latc->phi[lps[19]]+latc->phi[lps[21]]);
        double ddphidydz = 0.25*(latc->phi[lps[22]]-latc->phi[lps[24]]
			-latc->phi[lps[23]]+latc->phi[lps[25]]);
	double dphidq=dphidx*dqx[0]+dphidx*dqy[3]+dphidx*dqz[4]+dphidy*dqx[3]
	+dphidy*dqy[1]+dphidy*dqz[5]+dphidz*dqx[4]+dphidz*dqy[5]+dphidz*dqz[2];
        double ddphiq=ddphidxdx*qloc[0]+2*ddphidxdy*qloc[3]+2*ddphidxdz*qloc[4]
			+ddphidydy*qloc[1]+2*ddphidydz*qloc[5]+ddphidzdz*qloc[2];
//	if (polyphicoup==0) Ccontribution=0.0;
	latc->mu[lpt]= Qcontribution+Ccontribution*(iswithpoly)
		+Aphi*philoc*(1.0-philoc)*(1.0-2.0*philoc)
		+freegrad
		-Kphi*lap_phi
		-2.0*Lw*(dphidq+ddphiq);
        };//end inphase

// Level 2: C: Polymers
//printf("Level 2.\n");
	if(iswithpoly){
	double *h_poly_loc=&latc->h_poly[lptcc];
	double cinverse[6];
	double trace_CmI=cloc[0]+cloc[1]+cloc[2]-3.0;
	double poly_difflx[6];		/*diffusive flux:(term with no laplacian)*/ 
	double poly_advflx[6];		/*advective term locally: u dot grad C*/
	double poly_strflx[6];		/*stretching term locally: C*Vort-Vort*C*/
	double poly_relflx[6];		/*relaxation term locally: 2a[C*Strn]^sym*/
	//double dcx[6],dcy[6],dcz[6];	/*derivatives of C locally*/ //commentelc-logconformation
	double dlx[6],dly[6],dlz[6];	/*derivatives of L locally*/
	double l_advflx[6];
	double l_rhsflx[6];

	// coupling with Q
	coup_Q[0]+=-2.0*kappaqc*trace_CmI*qloc[0]-2.0*chiqc*(cloc[0]-1.0);
	coup_Q[1]+=-2.0*kappaqc*trace_CmI*qloc[1]-2.0*chiqc*(cloc[1]-1.0);
	coup_Q[2]+=-2.0*kappaqc*trace_CmI*qloc[2]-2.0*chiqc*(cloc[2]-1.0);
	coup_Q[3]+=-2.0*kappaqc*trace_CmI*qloc[3]-2.0*chiqc*(cloc[3]);
	coup_Q[4]+=-2.0*kappaqc*trace_CmI*qloc[4]-2.0*chiqc*(cloc[4]);
	coup_Q[5]+=-2.0*kappaqc*trace_CmI*qloc[5]-2.0*chiqc*(cloc[5]);

	//Potential H_c for the polymers
//2020 04 06 //	invert_matrix(&cloc[0],&cinverse[0],lpt); //defined in op_polymers.c
	if(inphase) Alceff_poly=-0.5*A_c; //EDITFE *(1.0-(philoc))*(1.0-(philoc))

	if(polyphicoup==0) Alceff_poly=-0.5*A_c;


	//free energies with C terms
	latc->fe_poly[lpt]=-Alceff_poly*(tr_lndet)*(1-philoc);  //EDITFE
	latc->fe_qc[lpt]=kappaqc*trace_CmI*traceq2
		+2.0*chiqc*((cloc[0]-1.0)*qloc[0]+(cloc[1]-1.0)*qloc[1]+(cloc[2]-1.0)*qloc[2]
		+2.0*(cloc[3]*qloc[3]+cloc[4]*qloc[4]+cloc[5]*qloc[5]));

	// fluxes for C
	relaxation_flux_C(&cloc[0],&poly_relflx[0],&strain[0],&h_poly_loc[0]); //commentelc-logconformation do not delete



/*Evolve l, where the diagonals 0-1-2 are in logarithm andthe offdiag terms 3-4-5 are not*/ //commentelc-logconformation
	derivatives_C(l,&dlx[0],&dly[0],&dlz[0],&lps[0]);// Calculate derivatives of L/
	for(int m=0; m<lcc; m++) 
	{l_advflx[m]=uloc[0]*dlx[m]+uloc[1]*dly[m]+uloc[2]*dlz[m];}; //advective flux
	l_rhsflx[0]=delu[0]+exp(-lloc[0])*(lloc[3]*delu[3]+lloc[4]*delu[4])+0.5/tau_poly*(exp(-2*lloc[0])-1.0);
	l_rhsflx[1]=delu[1]+exp(-lloc[1])*lloc[5]*delu[5]-exp(-lloc[0])*lloc[3]*delu[3]-exp(-lloc[0]-lloc[1])*lloc[5]*lloc[3]*delu[4]
			+0.5/tau_poly*(exp(-2*lloc[0]-2*lloc[1])*lloc[3]*lloc[3]-1+exp(-2*lloc[1]));
	l_rhsflx[2]=delu[2]-exp(-lloc[0])*lloc[4]*delu[4]-exp(-lloc[1])*lloc[5]*delu[5]+exp(-lloc[0]-lloc[1])*lloc[5]*lloc[3]*delu[4]
			+0.5/tau_poly*(-1.0+exp(-2*lloc[2])+exp(-2*lloc[0]-2*lloc[2])*lloc[4]*lloc[4]
				+exp(-2*lloc[0]-2*lloc[1]-2*lloc[2])*lloc[3]*lloc[3]*lloc[5]*lloc[5]
				+exp(-2*lloc[1]-2*lloc[2])*lloc[5]*lloc[5]
				-2.0*exp(-2*lloc[0]-2*lloc[1]-2*lloc[2])*lloc[3]*lloc[4]*lloc[5]);
	l_rhsflx[3]=exp(lloc[0])*delu[6]+lloc[3]*delu[1]+lloc[4]*delu[5]+exp(2*lloc[1]-lloc[0])*delu[3]+lloc[5]*exp(lloc[1]-lloc[0])*delu[4]-0.5/tau_poly*lloc[3]*(1+exp(-2*lloc[0]));
	l_rhsflx[4]=exp(lloc[0])*delu[7]+lloc[3]*delu[8]+lloc[4]*delu[2]+exp(lloc[1]-lloc[0])*lloc[5]*delu[3]+(exp(2*lloc[2])+lloc[5]*lloc[5])*exp(-lloc[0])*delu[4]-0.5/tau_poly*lloc[4]*(1+exp(-2*lloc[0]));;
	l_rhsflx[5]=exp(lloc[1])*delu[8]+lloc[5]*delu[2]-exp(lloc[1]-lloc[0])*lloc[4]*delu[3]-exp(-lloc[0])*lloc[4]*lloc[5]*delu[4]
			+exp(2*lloc[2]-lloc[1])*delu[5]-exp(2*lloc[2]-lloc[1]-lloc[0])*lloc[3]*delu[4]
			+0.5/tau_poly*(-lloc[5]-lloc[5]*exp(-2*lloc[1])+2.0*lloc[3]*lloc[4]*exp(-2*lloc[0]-lloc[1])
				-lloc[3]*lloc[3]*lloc[5]*exp(-2*lloc[0]-2*lloc[1]));

	//total cflux 

	for(int m=0; m<lcc; m++) {
	//cflux[lptcc+m]=-poly_advflx[m]+poly_strflx[m]
	//	+poly_relflx[m]/(tau_poly*A_c)+ellsq_poly*poly_difflx[m]/tau_poly; //commentelc-logconformation
	lflux[lptcc+m]=-l_advflx[m]+l_rhsflx[m];
	}// end m loop 


if(philoc>1.00) //commentelc-logconformation
	{//instantaneous relaxation by removing /tau_poly in each term
	l_rhsflx[0]=delu[0]+exp(-lloc[0])*(lloc[3]*delu[3]+lloc[4]*delu[4])+0.5*(exp(-2*lloc[0])-1.0);
	l_rhsflx[1]=delu[1]+exp(-lloc[1])*lloc[5]*delu[5]-exp(-lloc[0])*lloc[3]*delu[3]-exp(-lloc[0]-lloc[1])*lloc[5]*lloc[3]*delu[4]
			+0.5*(exp(-2*lloc[0]-2*lloc[1])*lloc[3]*lloc[3]-1+exp(-2*lloc[1]));
	l_rhsflx[2]=delu[2]-exp(-lloc[0])*lloc[4]*delu[4]-exp(-lloc[1])*lloc[5]*delu[5]+exp(-lloc[0]-lloc[1])*lloc[5]*lloc[3]*delu[4]
			+0.5*(-1.0+exp(-2*lloc[2])+exp(-2*lloc[0]-2*lloc[2])*lloc[4]*lloc[4]
				+exp(-2*lloc[0]-2*lloc[1]-2*lloc[2])*lloc[3]*lloc[3]*lloc[5]*lloc[5]
				+exp(-2*lloc[1]-2*lloc[2])*lloc[5]*lloc[5]
				-2.0*exp(-2*lloc[0]-2*lloc[1]-2*lloc[2])*lloc[3]*lloc[4]*lloc[5]);
	l_rhsflx[3]=exp(lloc[0])*delu[6]+lloc[3]*delu[1]+lloc[4]*delu[5]+exp(2*lloc[1]-lloc[0])*delu[3]+lloc[5]*exp(lloc[1]-lloc[0])*delu[4]-0.5*lloc[3]*(1+exp(-2*lloc[0]));
	l_rhsflx[4]=exp(lloc[0])*delu[7]+lloc[3]*delu[8]+lloc[4]*delu[2]+exp(lloc[1]-lloc[0])*lloc[5]*delu[3]+(exp(2*lloc[2])+lloc[5]*lloc[5])*exp(-lloc[0])*delu[4]-0.5*lloc[4]*(1+exp(-2*lloc[0]));;
	l_rhsflx[5]=exp(lloc[1])*delu[8]+lloc[5]*delu[2]-exp(lloc[1]-lloc[0])*lloc[4]*delu[3]-exp(-lloc[0])*lloc[4]*lloc[5]*delu[4]
			+exp(2*lloc[2]-lloc[1])*delu[5]-exp(2*lloc[2]-lloc[1]-lloc[0])*lloc[3]*delu[4]
			+0.5*(-lloc[5]-lloc[5]*exp(-2*lloc[1])+2.0*lloc[3]*lloc[4]*exp(-2*lloc[0]-lloc[1])
				-lloc[3]*lloc[3]*lloc[5]*exp(-2*lloc[0]-2*lloc[1]));

	for(int m=0; m<lcc; m++) {
	//cflux[lptcc+m]=-poly_advflx[m]+poly_relflx[m]/A_c; 
		//commentelc-logconformation How do I implement this?
		//i.e. instantaneous relaxation
	lflux[lptcc+m]=-l_advflx[m]+l_rhsflx[m];
	//+0*(poly_strflx[m]+ellsq_poly*poly_difflx[m]/tau_poly)
	//single tau_poly used //do not remove above carelessly
	};// end m loop
};//end if


	//get polymer stress -a(CH+HC)+CH-HC   Matrix:034/615/783
	//Emmanuel: removed parts that go to the body stress. see next part. //commentelc-logconformation do not delete
	pstress[0]=-a_poly*poly_relflx[0]*(1-philoc); //EDITFE
	pstress[1]=-a_poly*poly_relflx[1]*(1-philoc); //EDITFE
	pstress[2]=-a_poly*poly_relflx[2]*(1-philoc); //EDITFE
	pstress[3]=-a_poly*poly_relflx[3]*(1-philoc); //EDITFE
	pstress[4]=-a_poly*poly_relflx[4]*(1-philoc); //EDITFE
	pstress[5]=-a_poly*poly_relflx[5]*(1-philoc); //EDITFE

	//polymer stress contribution to bstress (antisymmetric part)
	//bstress[0]=0.0;
	//bstress[1]=0.0;
	//bstress[2]=0.0;
/*	bstress[3]+=(cloc[3]*(h_poly_loc[1]-h_poly_loc[0])
		+(cloc[0]-cloc[1])*h_poly_loc[3]+cloc[4]*h_poly_loc[5]-cloc[5]*h_poly_loc[4])*(1-philoc);
	bstress[4]+=(cloc[4]*(h_poly_loc[2]-h_poly_loc[0])
		+(cloc[0]-cloc[2])*h_poly_loc[4]+cloc[3]*h_poly_loc[5]-cloc[5]*h_poly_loc[3])*(1-philoc);
	bstress[5]+=(cloc[5]*(h_poly_loc[2]-h_poly_loc[1])
		+(cloc[1]-cloc[2])*h_poly_loc[5]+cloc[3]*h_poly_loc[4]-cloc[4]*h_poly_loc[3])*(1-philoc);
*/	//2020 02 06 these 3 terms are zero anyway when using oldroyd b model.-Emmanuel


if(iter==1){
for(int s=0;s<6;s++){estress[s]+=pstress[s];}
totalfree+=latc->fe_poly[lpt]+latc->fe_qc[lpt];

if(tm%writ==0){
latc->polystress[las]=pstress[0];
latc->polystress[las+1]=pstress[1];
latc->polystress[las+2]=pstress[2];
latc->polystress[las+3]=pstress[3];
latc->polystress[las+4]=pstress[4];
latc->polystress[las+5]=pstress[5];
latc->polystress[las+6]=pstress[3];
latc->polystress[las+7]=pstress[4];
latc->polystress[las+8]=pstress[5];

}// end tm%writ
}//end iter
	}; //end iswithpoly


/*if((i==1)&&(j==50)){
clock_gettime(CLOCK_MONOTONIC, &finish);
time2=(finish.tv_sec - start.tv_sec)+(finish.tv_nsec - start.tv_nsec) / 1000000000.0;
printf("Finished C:%f\n",time2*1000);}*/

// Level 3: Q: nematics
//printf("Level 3.\n");

//declaration of variables diffusive_flux_q
	double l2h[6]={0,0,0,0,0,0};
    	double l3h[6]={0,0,0,0,0,0};
    	double lap[6]={0,0,0,0,0,0};
    	double lCh[6]={0,0,0,0,0,0};
    	double l1hchiral[6]={0,0,0,0,0,0};
    	double bulk[6];
    	double elech[6]={0,0,0,0,0,0};
    	double chiral[6]={0,0,0,0,0,0};

	double difflx[6],advflx[6];	//local flux:diffusive,advective
	double actflx[6],corflx[6];	//local flux:active, corotational
	double noiflx[6]={0.0,0.0,0.0,0.0,0.0,0.0};	/*noise flux locally*/

	// Calculating potential H for point lpt
	//A(term w Q+term w Q^2+term w Q^3 -I/3 Tr[Q2]) Emmanuel: check terms
	bulk[0]=-Alceff*qloc[0]-Blceff*(qloc[0]*qloc[0]+qloc[3]*qloc[3]
		+qloc[4]*qloc[4]-traceq2/3.0)-Clceff*qloc[0]*traceq2;
    	bulk[1]=-Alceff*qloc[1]-Blceff*(qloc[3]*qloc[3]+qloc[1]*qloc[1]
		+qloc[5]*qloc[5]-traceq2/3.0)-Clceff*qloc[1]*traceq2;
    	bulk[2]=-Alceff*qloc[2]-Blceff*(qloc[4]*qloc[4]+qloc[5]*qloc[5]
		+qloc[2]*qloc[2]-traceq2/3.0)-Clceff*qloc[2]*traceq2;
    	bulk[3]=-Alceff*qloc[3]-Blceff*(qloc[0]*qloc[3]+qloc[3]*qloc[1]
		+qloc[4]*qloc[5])-Clceff*qloc[3]*traceq2;
    	bulk[4]=-Alceff*qloc[4]-Blceff*(qloc[0]*qloc[4]+qloc[3]*qloc[5]
		+qloc[4]*qloc[2])-Clceff*qloc[4]*traceq2;
    	bulk[5]=-Alceff*qloc[5]-Blceff*(qloc[3]*qloc[4]+qloc[1]*qloc[5]
		+qloc[5]*qloc[2])-Clceff*qloc[5]*traceq2;

	//Laplacian of Q
	for(int m=0; m<lcq; m++) {lap[m]=lap_cd(q,lpt,lps,m);}

	//total potential
	for(int m=0; m<lcq; m++) {
        H[lptcq+m]=isbulk*bulk[m]
		+Klc*lap[m]*(1-ischiral)
		+0.5*Klc*l1hchiral[m]*ischiral
		+0.5*K2lc*l2h[m]*sconst+K3lc*l3h[m]*sconst
		+weakanch*lptlw*H[lptcq+m]
		+coup_Q[m] //from anchoring and polymers
		+iselectric*elech[m]*(philoc)
		+ischiral*KClc*lCh[m]
		+2.*CSme*chiral[m];
        difflx[m]=Gammalc*H[lptcq+m];
	};

	//free energy of Q	
	//Emmanuel: not yet adapted for more than 1 elastic constant
	latc->fe_nematics[lpt]=0.5*Alceff*traceq2+Blceff/3.0*traceq3
			+0.25*Clceff*traceq2*traceq2
			+0.5*Klc*(dqx[0]*dqx[0]+dqy[0]*dqy[0]+dqz[0]*dqz[0]
			+dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]
			+dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]
      			+dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]
			+dqx[1]*dqx[1]+dqy[1]*dqy[1]+dqz[1]*dqz[1]
			+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]
			+dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]
			+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]
			+dqx[2]*dqx[2]+dqy[2]*dqy[2]+dqz[2]*dqz[2]);
	
	// fluxes for Q (note:difflx above)
        (*advective_flux)(u,lpt,&advflx[0],&dqx[0],&dqy[0],&dqz[0]);
        (*corotatnl_flux)(q,lpt,&corflx[0],&delu[0],&strain[0],&vortic[0]);
        active_flux(q, lpt,&actflx[0]);
        (*qnoise_flux)(&noiflx[0],sigma);

	//Total fluxes of Q
	for(int m=0; m<lcq;m++){qflux[lptcq+m]=difflx[m]-advflx[m]+corflx[m]+actflx[m]+noiflx[m];
};

//printf("Level 4.\n");
	// Calculating stresses
	if(iter){
    	double l1s[6]={0,0,0,0,0,0};
    	double l2s[6]={0,0,0,0,0,0};
    	double l3s[6]={0,0,0,0,0,0};
    	double lCs[9]={0,0,0,0,0,0,0,0,0}; /* First 6 symmetric; next 3 antisymmetric*/
    	//double l2p=0.0;
    	//double l3p=0.0;
	double qh=qloc[0]*H[lptcq]+qloc[1]*H[lptcq+1]+qloc[2]*H[lptcq+2]
		+2.0*(qloc[3]*H[lptcq+3]+qloc[4]*H[lptcq+4]+qloc[5]*H[lptcq+5]);
	double rho=latv->rho[lpt];
	totalfree+=latc->fe_nematics[lpt];
	if(inphase) {
	totalfree+=latc->fe_phi[lpt];
	//capillary stress //must wait for the end because of totalfree
	cstress[0]=(!noliqc)*totalfree-philoc*mu[lpt]-Kphi*dphidx*dphidx
		-2.0*Lw*(qloc[0]*dphidx*dphidx+qloc[3]*dphidx*dphidy+qloc[4]*dphidx*dphidz);
	cstress[1]=(!noliqc)*totalfree-philoc*mu[lpt]-Kphi*dphidy*dphidy
		-2.0*Lw*(qloc[3]*dphidx*dphidy+qloc[1]*dphidy*dphidy+qloc[5]*dphidy*dphidz);
	cstress[2]=(!noliqc)*totalfree-philoc*mu[lpt]-Kphi*dphidz*dphidz
		-2.0*Lw*(qloc[4]*dphidx*dphidz+qloc[5]*dphidy*dphidz+qloc[2]*dphidz*dphidz);
	cstress[3]=-Kphi*dphidx*dphidy
		-2.0*Lw*(qloc[3]*dphidx*dphidx+qloc[1]*dphidx*dphidy+qloc[5]*dphidx*dphidz);
	cstress[4]=-Kphi*dphidx*dphidz
		-2.0*Lw*(qloc[4]*dphidx*dphidx+qloc[5]*dphidx*dphidy+qloc[2]*dphidx*dphidz);
	cstress[5]=-Kphi*dphidy*dphidz
		-2.0*Lw*(qloc[4]*dphidx*dphidy+qloc[5]*dphidy*dphidy+qloc[2]*dphidy*dphidz);

	};//end inphase    
	
	//viscous stress

	//active stress
	//if((philoc>0.0)&&(philoc<1.0)){ //activity limited on the boundary
	astress[0]=-zetalc*qloc[0]*philoc;
	astress[1]=-zetalc*qloc[1]*philoc;
	astress[2]=-zetalc*qloc[2]*philoc;
	astress[3]=-zetalc*qloc[3]*philoc;
	astress[4]=-zetalc*qloc[4]*philoc;
	astress[5]=-zetalc*qloc[5]*philoc;
	//};

	//elastic stress
	elstress[0]=2*xilc*(qloc[0]+1./3.)*qh
		-xilc*(H[lptcq+0]*(qloc[0]+1./3.)+H[lptcq+3]*qloc[3]+H[lptcq+4]*qloc[4]
		+(qloc[0]+1./3.)*H[lptcq+0]+qloc[3]*H[lptcq+3]+qloc[4]*H[lptcq+4])
		-Klc*(dqx[0]*dqx[0]+dqx[1]*dqx[1]+dqx[2]*dqx[2]
		+2.0*(dqx[3]*dqx[3]+dqx[4]*dqx[4]+dqx[5]*dqx[5]))*(1-ischiral)
		-Klc*l1s[0]-K2lc*l2s[0]-K3lc*l3s[0]-0.5*KClc*lCs[0];
    	elstress[1]=2*xilc*(qloc[1]+1./3.)*qh
		-xilc*(H[lptcq+3]*qloc[3]+H[lptcq+1]*(qloc[1]+1./3.)+H[lptcq+5]*qloc[5]
		+qloc[3]*H[lptcq+3]+(qloc[1]+1./3.)*H[lptcq+1]+qloc[5]*H[lptcq+5])
		-Klc*(dqy[0]*dqy[0]+dqy[1]*dqy[1]+dqy[2]*dqy[2]
		+2.0*(dqy[3]*dqy[3]+dqy[4]*dqy[4]+dqy[5]*dqy[5]))*(1-ischiral)
		-Klc*l1s[1]-K2lc*l2s[1]-K3lc*l3s[1]-0.5*KClc*lCs[1];
    	elstress[2]=2*xilc*(qloc[2]+1./3.)*qh
		-xilc*(H[lptcq+4]*qloc[4]+H[lptcq+5]*qloc[5]+H[lptcq+2]*(qloc[2]+1./3.)
		+qloc[4]*H[lptcq+4]+qloc[5]*H[lptcq+5]+(qloc[2]+1./3.)*H[lptcq+2])
		-Klc*(dqz[0]*dqz[0]+dqz[1]*dqz[1]+dqz[2]*dqz[2]
		+2.0*(dqz[3]*dqz[3]+dqz[4]*dqz[4]+dqz[5]*dqz[5]))*(1-ischiral)
		-Klc*l1s[2]-K2lc*l2s[2]-K3lc*l3s[2]-0.5*KClc*lCs[2];
    	elstress[3]=    2*xilc*qloc[3]*qh
		-xilc*(H[lptcq+0]*qloc[3]+H[lptcq+3]*(qloc[1]+1./3.)+H[lptcq+4]*qloc[5]
		+(qloc[0]+1./3.)*H[lptcq+3]+qloc[3]*H[lptcq+1]+qloc[4]*H[lptcq+5])	
		-Klc*(dqx[0]*dqy[0]+dqx[1]*dqy[1]+dqx[2]*dqy[2]
		+2.0*(dqx[3]*dqy[3]+dqx[4]*dqy[4]+dqx[5]*dqy[5]))*(1-ischiral)
		-Klc*l1s[3]-K2lc*l2s[3]-K3lc*l3s[3]-0.5*KClc*lCs[3];
    	elstress[4]=    2*xilc*qloc[4]*qh          
		-xilc*(H[lptcq+0]*qloc[4]+H[lptcq+3]*qloc[5]+H[lptcq+4]*(qloc[2]+1./3.)
		+(qloc[0]+1./3.)*H[lptcq+4]+qloc[3]*H[lptcq+5]+qloc[4]*H[lptcq+2])
		-Klc*(dqx[0]*dqz[0]+dqx[1]*dqz[1]+dqx[2]*dqz[2]
		+2.0*(dqx[3]*dqz[3]+dqx[4]*dqz[4]+dqx[5]*dqz[5]))*(1-ischiral)
		-Klc*l1s[4]-K2lc*l2s[4]-K3lc*l3s[4]-0.5*KClc*lCs[4];
    	elstress[5]=    2*xilc*qloc[5]*qh          
		-xilc*(H[lptcq+3]*qloc[4]+H[lptcq+1]*qloc[5]+H[lptcq+5]*(qloc[2]+1./3.)
		+qloc[3]*H[lptcq+4]+(qloc[1]+1./3.)*H[lptcq+5]+qloc[5]*H[lptcq+2])
		-Klc*(dqy[0]*dqz[0]+dqy[1]*dqz[1]+dqy[2]*dqz[2]
		+2.0*(dqy[3]*dqz[3]+dqy[4]*dqz[4]+dqy[5]*dqz[5]))*(1-ischiral)
		-Klc*l1s[5]-K2lc*l2s[5]-K3lc*l3s[5]-0.5*KClc*lCs[5];

if(tm%writ==0){
	//just check if inphase is not on; working if it is on
	latc->capstress[las]=cstress[0];
	latc->capstress[las+1]=cstress[1];
	latc->capstress[las+2]=cstress[2];
	latc->capstress[las+3]=cstress[3];
	latc->capstress[las+4]=cstress[4];
	latc->capstress[las+5]=cstress[5];
	latc->capstress[las+6]=cstress[3];
	latc->capstress[las+7]=cstress[4];
	latc->capstress[las+8]=cstress[5];

	latc->viscstress[las]=2.0*visc*strain[0];
	latc->viscstress[las+1]=2.0*visc*strain[1];
	latc->viscstress[las+2]=2.0*visc*strain[2];
	latc->viscstress[las+3]=2.0*visc*strain[3];
	latc->viscstress[las+4]=2.0*visc*strain[4];
	latc->viscstress[las+5]=2.0*visc*strain[5];
	latc->viscstress[las+6]=2.0*visc*strain[3];
	latc->viscstress[las+7]=2.0*visc*strain[4];
	latc->viscstress[las+8]=2.0*visc*strain[5];
if((j<18)&&(j>12)&&(i<9)&&(i>1)&&(tm>tini+0)&&(tm<tini+500)){
printf("Strain tensor is %f %f %f %f %f %f\n",strain[0],strain[1],strain[2],strain[3],strain[4],strain[5]);
}

	latc->elasstress[las]=elstress[0];
	latc->elasstress[las+1]=elstress[1];
	latc->elasstress[las+2]=elstress[2];
	latc->elasstress[las+3]=elstress[3]+qloc[0]*H[lptcq+3]+qloc[3]*H[lptcq+1]+qloc[4]*H[lptcq+5]
		-H[lptcq]*qloc[3]-H[lptcq+3]*qloc[1]-H[lptcq+4]*qloc[5];
	latc->elasstress[las+4]=elstress[4]+qloc[0]*H[lptcq+4]+qloc[3]*H[lptcq+5]+qloc[4]*H[lptcq+2]
		-H[lptcq+0]*qloc[4]-H[lptcq+3]*qloc[5]-H[lptcq+4]*qloc[2];
	latc->elasstress[las+5]=elstress[5]+qloc[3]*H[lptcq+4]+qloc[1]*H[lptcq+5]+qloc[5]*H[lptcq+2]
		-H[lptcq+3]*qloc[4]-H[lptcq+1]*qloc[5]-H[lptcq+5]*qloc[2];
	latc->elasstress[las+6]=elstress[3]-(qloc[0]*H[lptcq+3]+qloc[3]*H[lptcq+1]+qloc[4]*H[lptcq+5]
		-H[lptcq]*qloc[3]-H[lptcq+3]*qloc[1]-H[lptcq+4]*qloc[5]);
	latc->elasstress[las+7]=elstress[4]-(qloc[0]*H[lptcq+4]+qloc[3]*H[lptcq+5]+qloc[4]*H[lptcq+2]
		-H[lptcq+0]*qloc[4]-H[lptcq+3]*qloc[5]-H[lptcq+4]*qloc[2]);
	latc->elasstress[las+8]=elstress[5]-(qloc[3]*H[lptcq+4]+qloc[1]*H[lptcq+5]+qloc[5]*H[lptcq+2]
		-H[lptcq+3]*qloc[4]-H[lptcq+1]*qloc[5]-H[lptcq+5]*qloc[2]);

	latc->actstress[las]=astress[0];
	latc->actstress[las+1]=astress[1];
	latc->actstress[las+2]=astress[2];
	latc->actstress[las+3]=astress[3];
	latc->actstress[las+4]=astress[4];
	latc->actstress[las+5]=astress[5];
	latc->actstress[las+6]=astress[3];
	latc->actstress[las+7]=astress[4];
	latc->actstress[las+8]=astress[5];
}


///// Calculating stresses for point lpt
	for (int s=0;s<6;s++){estress[s]+=elstress[s]+astress[s];}
	if(inphase) {for(int s=0;s<6;s++){estress[s]+=cstress[s];}}
	double Pr=P0*rho;
	estress[0]+=-Pr;
	estress[1]+=-Pr;
	estress[2]+=-Pr;

	bstress[3]+=qloc[0]*H[lptcq+3]+qloc[3]*H[lptcq+1]+qloc[4]*H[lptcq+5]
		-H[lptcq]*qloc[3]-H[lptcq+3]*qloc[1]-H[lptcq+4]*qloc[5];/*12*/
	bstress[4]+=qloc[0]*H[lptcq+4]+qloc[3]*H[lptcq+5]+qloc[4]*H[lptcq+2]
		-H[lptcq+0]*qloc[4]-H[lptcq+3]*qloc[5]-H[lptcq+4]*qloc[2];/*13*/
	bstress[5]+=qloc[3]*H[lptcq+4]+qloc[1]*H[lptcq+5]+qloc[5]*H[lptcq+2]
		-H[lptcq+3]*qloc[4]-H[lptcq+1]*qloc[5]-H[lptcq+5]*qloc[2];/*23*/

//saving for evolution
	latc->bstress[las]=bstress[0];
	latc->bstress[las+1]=bstress[1];
	latc->bstress[las+2]=bstress[2];
	latc->bstress[las+3]=bstress[3];
	latc->bstress[las+4]=bstress[4];
	latc->bstress[las+5]=bstress[5];
	latc->bstress[las+6]=-bstress[3];
	latc->bstress[las+7]=-bstress[4];
	latc->bstress[las+8]=-bstress[5];

	int lsy=lpt*lcd*2;
	latc->estress[lsy]=estress[0];
	latc->estress[lsy+1]=estress[1];
	latc->estress[lsy+2]=estress[2];
	latc->estress[lsy+3]=estress[3];
	latc->estress[lsy+4]=estress[4];
	latc->estress[lsy+5]=estress[5];
	};//end iter
	};// end if w[lpt]

/*if((i==1)&&(j==50)){
clock_gettime(CLOCK_MONOTONIC, &finish);
time4=(finish.tv_sec - start.tv_sec)+(finish.tv_nsec - start.tv_nsec) / 1000000000.0;
printf("Finished stresses:%f\n",time4*1000);}*/
    }; }; };	// end i,j,k loop


//printf("Level 5.\n");
    if (inphase) {
    double *pflux=&latc->phiflux[0];
    double *phi=&latc->phi[0];
    double *mu=&latc->mu[0];
    double *u=&latv->u[0]; 
    (*latc->bc_funcmu)(latv,latc,latw,&latc->mu[0],1);   
    for(int i=1;i<=nx;i++) {
    for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
    	int lpt = (i*ny2+j)*nz2+k;
	derivativesN(i,j,k,&lps[0]);
	(*phi_fluxcalc)(pflux, phi, u, mu, &lps[0], lpt,i,j,k,iter);
	//Emmanuel: this requires the whole mu to be solved before using.
	//because lap_oonopuri is defined using neighbors
    }; }; };
    }//end inphase Level 5

    return;
}

/////////////////////////////////////////// END OF QFLUX ////////////////////////////////////////////////
//"Sub"functions below

double lap_cd(double *q, int l, int *lps, int m) {
    return q[lps[0]*lcq+m]+q[lps[1]*lcq+m]+q[lps[2]*lcq+m]+q[lps[3]*lcq+m]+q[lps[4]*lcq+m]+q[lps[5]*lcq+m]-6.0*q[l*lcq+m];
}

double lap_d3q15(double *q, int l, int *lps, int m) {
    return ((q[lps[0]*lcq+m]+q[lps[1]*lcq+m]+q[lps[2]*lcq+m]+q[lps[3]*lcq+m]+q[lps[4]*lcq+m]+q[lps[5]*lcq+m])*8.0
            +(q[lps[6]*lcq+m]+q[lps[7]*lcq+m]+q[lps[8]*lcq+m]+q[lps[9]*lcq+m]+q[lps[10]*lcq+m]+q[lps[11]*lcq+m]+q[lps[12]*lcq+m]+q[lps[13]*lcq+m])
            -56.0*q[l*lcq+m])/12.0;
}


void advective_fluxon(double *u, int l, double *advflx, double *dqx, double *dqy, double *dqz) {
    double *uloc = &u[l*lbd];
    for(int m=0; m<lcq; m++) advflx[m]=uloc[0]*dqx[m]+uloc[1]*dqy[m]+uloc[2]*dqz[m];
    return;
}
void advective_fluxoff(double *u, int l, double *advflx, double *dqx, double *dqy, double *dqz) {
    for(int m=0; m<lcq; m++) advflx[m]=0.0;
    return;
}

void derivativesN(int i, int j, int k, int *lps) {
// All points in the lattice are enumerated from 1 to nx2*ny2*nz2.
// This function locates the "index" or enumeration of the points neighbouring the point at (i*ny2+j)*nz2+k
// i,j,k refers to the x,y,z position of the point in the lattice.
// This function will be used to calculate the derivatives, hence the name. Emmanuel: I don't agree with the naming though.
// 0-5 give points next to the point in the x, y and z directions
    lps[0] = ((i+1)*ny2+j  )*nz2+k  ;
    lps[1] = ((i-1)*ny2+j  )*nz2+k  ;
    lps[2] = ( i   *ny2+j+1)*nz2+k  ;
    lps[3] = ( i   *ny2+j-1)*nz2+k  ;
    lps[4] = ( i   *ny2+j  )*nz2+k+1;
    lps[5] = ( i   *ny2+j  )*nz2+k-1;
    lps[6] = ((i+1)*ny2+j+1)*nz2+k+1;
    lps[7] = ((i+1)*ny2+j+1)*nz2+k-1;
    lps[8] = ((i+1)*ny2+j-1)*nz2+k+1;
    lps[9] = ((i+1)*ny2+j-1)*nz2+k-1;
    lps[10]= ((i-1)*ny2+j+1)*nz2+k+1;
    lps[11]= ((i-1)*ny2+j+1)*nz2+k-1;
    lps[12]= ((i-1)*ny2+j-1)*nz2+k+1;
    lps[13]= ((i-1)*ny2+j-1)*nz2+k-1;
    lps[14]= ((i+1)*ny2+j+1)*nz2+k  ;
    lps[15]= ((i-1)*ny2+j+1)*nz2+k  ;
    lps[16]= ((i+1)*ny2+j-1)*nz2+k  ;
    lps[17]= ((i-1)*ny2+j-1)*nz2+k  ;
    lps[18]= ((i+1)*ny2+j  )*nz2+k+1;
    lps[19]= ((i-1)*ny2+j  )*nz2+k+1;
    lps[20]= ((i+1)*ny2+j  )*nz2+k-1;
    lps[21]= ((i-1)*ny2+j  )*nz2+k-1;
    lps[22]= ((i  )*ny2+j+1)*nz2+k+1;
    lps[23]= ((i  )*ny2+j-1)*nz2+k+1;
    lps[24]= ((i  )*ny2+j+1)*nz2+k-1;
    lps[25]= ((i  )*ny2+j-1)*nz2+k-1;
    return;
}

void derivativesQ(double *q,double *dqx, double *dqy, double *dqz, int *lps) {
// In the absence of a geometry, lpv is simply lps, giving the indices of the neighbouring points of 
// the point of interest (at i,j,k) wrt to all the points (see derivativesN)
// As can be inferred here, q is structured such that the lcq=6 consecutive components
// (starting from an index divisible by d) refer to the lcq=6 components(degrees of freedom) of q at the point (i,j,k).
// By default, I suppose that 0-5 refer to components 11,22,33,12,13,23. //Emmanuel: their default
// Here, dqx has 6 components, one for each component of q. Same for dqy and dqz.
// p and m refer to plus and minus respectively.
    int lpxq=lps[0]*lcq, lmxq=lps[1]*lcq, lpyq=lps[2]*lcq, lmyq=lps[3]*lcq, lpzq=lps[4]*lcq, lmzq=lps[5]*lcq;
    for(int m=0; m<lcq; m++) {
        dqx[m]=0.5*(q[lpxq+m]-q[lmxq+m]);
        dqy[m]=0.5*(q[lpyq+m]-q[lmyq+m]);
        dqz[m]=0.5*(q[lpzq+m]-q[lmzq+m]);
    };
    return;
}

void derivativesU(double *u,double *delu, double *strain, double *vortic, int *lpv, double *wlp) {
// In the absence of a geometry, lpv is simply lps, giving the indices of the neighbouring points of 
// the point of interest (at i,j,k) wrt to all the points
// Here we calculate the derivatives of the velocity u.
// As can be inferred here, u is structured such that the d=lbd=3 consecutive components
// (starting from an index divisible by d) refer to the x,y,z,... components of u at the point (i,j,k).
// wlp is simply a weighting factor = [0.5,0.5,0.5] and must be changed if d changes.
// note that delu is written in this order:
// [dxux=0, dxuy=3, dxuz=4, dyux=6, dyuy=1, dyuz=5, dzux=7, dzuy=8, dzuz=2]
// (du)_ij= du_i/dx_j = d_j u_i
// strain E: E_11=0, E_22=1, E_33=2, E12=3, E_13=4, E_23=5
// note that the diagonals of the vorticity is always zero.
// Vort_12=0 Vort_13=1, Vort_23=2, vort= 1/2(du' - du) where ' means transpose
    int lpx=lpv[0],lmx=lpv[1],lpy=lpv[2],lmy=lpv[3],lpz=lpv[4],lmz=lpv[5];
//printf("lpx=%d,lmx=%d,lpy=%d,lmy=%d,lpz=%d,lmz=%d.\n",lpx,lmx,lpy,lmy,lpz,lmz);
    delu[0]=wlp[0]*(u[lpx*lbd]-u[lmx*lbd]);
//  if(delu[0]>0.1) printf("IN..................%d,lpt,%d:.... %f---%f.\n",lmx,lpx, u[lmx*lbd],u[lpx*lbd]);
//  if(delu[0]>0.1) printf("delu[0] at l=%d: %f-%f=%f.\n",lmx, u[lpx*lbd],u[lmx*lbd],u[lpx*lbd]-u[lmx*lbd]);
//  if(delu[0]<-0.1) printf("delu[0]at l=%d: %f-%f=%f.\n",lmx, u[lpx*lbd],u[lmx*lbd],u[lpx*lbd]-u[lmx*lbd]);
//printf("delu[0]=%f-%f=%f.\n",u[lpx*lbd],u[lmx*lbd],u[lpx*lbd]-u[lmx*lbd]);
    delu[3]=wlp[1]*(u[lpy*lbd]-u[lmy*lbd]);
    delu[4]=wlp[2]*(u[lpz*lbd]-u[lmz*lbd]);
    delu[6]=wlp[0]*(u[lpx*lbd+1]-u[lmx*lbd+1]);
    delu[1]=wlp[1]*(u[lpy*lbd+1]-u[lmy*lbd+1]);
    delu[5]=wlp[2]*(u[lpz*lbd+1]-u[lmz*lbd+1]);
    delu[7]=wlp[0]*(u[lpx*lbd+2]-u[lmx*lbd+2]);
    delu[8]=wlp[1]*(u[lpy*lbd+2]-u[lmy*lbd+2]);
    delu[2]=wlp[2]*(u[lpz*lbd+2]-u[lmz*lbd+2]);
    strain[0]=delu[0];
    strain[1]=delu[1];
    strain[2]=delu[2];
    strain[3]=0.5*(delu[3]+delu[6]);
    strain[4]=0.5*(delu[4]+delu[7]);
    strain[5]=0.5*(delu[5]+delu[8]);
    vortic[0]=0.5*(delu[3]-delu[6])*isvortalign;/*12th element*/
    vortic[1]=0.5*(delu[4]-delu[7])*isvortalign;/*13th element*/
    vortic[2]=0.5*(delu[5]-delu[8])*isvortalign;/*23th element*/
    return;
}

void corotatnl_fluxon(double *qall, int l, double *corflx, double *delu, double *stn, double *vor) {
    double *q=&qall[l*lcq];
    double qdu=(q[0]*delu[0]+q[3]*delu[3]+q[4]*delu[4]+q[3]*delu[6]+q[1]*delu[1]
		+q[5]*delu[5]+q[4]*delu[7]+q[5]*delu[8]+q[2]*delu[2]);
    
    corflx[0]=xilc*stn[0]*(q[0]+1./3.)+(xilc*stn[3]+vor[0])*q[3]+(xilc*stn[4]+vor[1])*q[4] 
		+ (q[0]+1./3.)*xilc*stn[0]+q[3]*(xilc*stn[3]+vor[0])+q[4]*(xilc*stn[4]+vor[1]) 
		- 2.*xilc*(q[0]+1./3.)*qdu;
    corflx[1]=(xilc*stn[3]-vor[0])*q[3]+xilc*stn[1]*(q[1]+1./3.)+(xilc*stn[5]+vor[2])*q[5] 
		+ q[3]*(xilc*stn[3]-vor[0])+(q[1]+1./3.)*xilc*stn[1]+q[5]*(xilc*stn[5]+vor[2]) 
		- 2.*xilc*(q[1]+1./3.)*qdu;
    corflx[2]=(xilc*stn[4]-vor[1])*q[4]+(xilc*stn[5]-vor[2])*q[5]+xilc*stn[2]*(q[2]+1./3.) 
		+ q[4]*(xilc*stn[4]-vor[1])+q[5]*(xilc*stn[5]-vor[2])+(q[2]+1./3.)*xilc*stn[2] 
		- 2.*xilc*(q[2]+1./3.)*qdu;
    corflx[3]=xilc*stn[0]*q[3]+(xilc*stn[3]+vor[0])*(q[1]+1./3.)+(xilc*stn[4]+vor[1])*q[5] 
		+ (q[0]+1./3.)*(xilc*stn[3]-vor[0])+q[3]*xilc*stn[1]+q[4]*(xilc*stn[5]+vor[2]) 
		- 2.*xilc*(q[3])*qdu;
    corflx[4]=xilc*stn[0]*q[4]+(xilc*stn[3]+vor[0])*q[5]+(xilc*stn[4]+vor[1])*(q[2]+1./3.) 
		+ (q[0]+1./3.)*(xilc*stn[4]-vor[1])+q[3]*(xilc*stn[5]-vor[2])+q[4]*xilc*stn[2] 
		- 2.*xilc*(q[4])*qdu;
    corflx[5]=(xilc*stn[3]-vor[0])*q[4]+xilc*stn[1]*q[5]+(xilc*stn[5]+vor[2])*(q[2]+1./3.) 
		+ q[3]*(xilc*stn[4]-vor[1])+(q[1]+1./3.)*(xilc*stn[5]-vor[2])+q[5]*xilc*stn[2] 
		- 2.*xilc*(q[5])*qdu;
    return;
}


void corotatnl_fluxoff(double *qall, int l, double *corflx, double *delu, double *stn, double *vor) {
    for(int m=0; m<lcq; m++) corflx[m]=0.0;
    return;
}

void active_flux(double *q, int l, double *actflx) {
    l=l*lcq;
    for(int m=0; m<lcq;m++) actflx[m]=lambdalc*q[l+m];
    return;
}

void qnoise_fluxnone(double *noiseflx, double sigma) {
    /*Do nothing;*/
    return;
}

void qnoise_fluxinxy(double *noiseflx, double sigma) {
    double alpha1=gasdev(&seed)*sigma;
    double alpha2=gasdev(&seed)*sigma;
    double alpha3=gasdev(&seed)*sigma;
    noiseflx[0]=alpha1*T1[0][0]+alpha2*T2[0][0]+alpha3*T3[0][0];
    noiseflx[1]=alpha1*T1[1][1]+alpha2*T2[1][1]+alpha3*T3[1][1];
    noiseflx[2]=alpha1*T1[2][2]+alpha2*T2[2][2]+alpha3*T3[2][2];
    noiseflx[3]=alpha1*T1[0][1]+alpha2*T2[0][1]+alpha3*T3[0][1];
    return;
}

void qnoise_fluxin3d(double *noiseflx, double sigma) {
    double alpha1=gasdev(&seed)*sigma;
    double alpha2=gasdev(&seed)*sigma;
    double alpha3=gasdev(&seed)*sigma;
    double alpha4=gasdev(&seed)*sigma;
    double alpha5=gasdev(&seed)*sigma;
    noiseflx[0]=alpha1*T1[0][0]+alpha2*T2[0][0]+alpha3*T3[0][0]+alpha4*T4[0][0]+alpha5*T5[0][0];
    noiseflx[1]=alpha1*T1[1][1]+alpha2*T2[1][1]+alpha3*T3[1][1]+alpha4*T4[1][1]+alpha5*T5[1][1];
    noiseflx[2]=alpha1*T1[2][2]+alpha2*T2[2][2]+alpha3*T3[2][2]+alpha4*T4[2][2]+alpha5*T5[2][2];
    noiseflx[3]=alpha1*T1[0][1]+alpha2*T2[0][1]+alpha3*T3[0][1]+alpha4*T4[0][1]+alpha5*T5[0][1];
    noiseflx[4]=alpha1*T1[0][2]+alpha2*T2[0][2]+alpha3*T3[0][2]+alpha4*T4[0][2]+alpha5*T5[0][2];
    noiseflx[5]=alpha1*T1[1][2]+alpha2*T2[1][2]+alpha3*T3[1][2]+alpha4*T4[1][2]+alpha5*T5[1][2];
    return;
}

void phi_fluxcalcon(double *pflux, double *phi, double *u, double *mu, int *lps, int lpt, int i, int j, int k,int iter) {
    double phidifflx=(*diffusive_flux_phi)(mu,lps,lpt);
    double phiadvflx=(*advective_flux_phi)(u,phi,lps,lpt,j);
    pflux[lpt]=Gammaphi*phidifflx-phiadvflx;

//if(iswithcelldiv&&iter){
//pflux[lpt]+=phi[lpt]*ratecelldiv;
//};


if(fabs(pflux[lpt])>0.1){
printf("phiflux at i=%d,j=%d,k=%d (lpt=%d):diff=%f, adv=%f, mu=%f.\n",
i,j,k,lpt,Gammaphi*phidifflx,phiadvflx,mu[lpt]);
};
//if(pflux[lpt]<-0.1){
//printf("-phiflux at i=%d,j=%d,k=%d (lpt=%d):diff=%f, adv=%f, mu=%f.\n",
//i,j,k,lpt,Gammaphi*phidifflx,phiadvflx,mu[lpt]);
//};


/*commented out by Emmanuel
    if(isallcelld) {
	if(phi[lpt]>phi0) {pflux[lpt]+=phi[lpt]*ratecelld;}};
*/
    return;
}
void phi_fluxcalcoff(double *pflux, double *phi, double *u, double *mu, int *lps, int lpt, int i, int j, int k,int iter) {
    return;
}

double diffusive_flux_phioff(double *mu, int *lps, int lpt) {
    return 0;
}
double diffusive_flux_phion(double *mu, int *lps, int lpt) {
    double ret_val = lap_oonopuri(mu,lps,lpt);
    return(ret_val);
}

double advective_flux_phioff(double *u, double *phi, int *lps,int lpt, int j) {
    return 0;
}
double advective_flux_phion(double *u, double *phi, int *lps,int lpt, int j) {
    int lpy=lps[2];
    int lmy=lps[3];
    int spy=1;
    int smy=1;
    if(wallflagxz) {
        if(j==1) {lmy=lpt;smy=-1;}
        else if(j==ny) {lpy=lpt;spy=-1;}
    }
    return(0.5*(u[lps[0]*lbd+0]*phi[lps[0]]-u[lps[1]*lbd+0]*phi[lps[1]])
           +0.5*(spy*u[lpy*lbd+1]*phi[lpy]-smy*u[lmy*lbd+1]*phi[lmy])
           +0.5*(u[lps[4]*lbd+2]*phi[lps[4]]-u[lps[5]*lbd+2]*phi[lps[5]]));
}


void modify_celldlocs(lclattice *latc, int tm) {
    int m,xc,yc;
    for(int i=0;i<numofcelld;i++) {
        if(latc->tmcelld[i]>timofcelld) {
            xc=(int)((nx-sizofcelld)*ran2(&seed));
            yc=(int)((nx-sizofcelld)*ran2(&seed));
            m=0;
            for(int j=0;j<sizofcelld;j++) {
                for(int k=0;k<sizofcelld;k++) {
                    latc->locelld[i*sizofcelld*sizofcelld+m]=((xc+j)*ny2+(yc+k))*nz2+1;
                    printf("%d %d %d %d %d %d %d\n",tm,i,m,i*sizofcelld*sizofcelld+m,xc+j,yc+k,latc->tmcelld[i]);
                    m++;
                }  }
            latc->tmcelld[i]=1;
        }
    }
    return;
}



double chargecalc(double *dqx, double *dqy, double *dqz) {
    return (dqx[0]*dqy[3] + dqx[3]*dqy[1] + dqx[4]*dqy[5] - dqx[3]*dqy[0] - dqx[1]*dqy[3] - dqx[5]*dqy[4])*4.0*3.14159265359;
}



