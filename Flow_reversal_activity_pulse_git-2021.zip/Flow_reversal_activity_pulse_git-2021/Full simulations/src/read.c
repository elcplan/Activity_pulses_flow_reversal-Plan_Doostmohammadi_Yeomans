/*Input and output functions for actcol*/
void init_readc(lclattice *latc, double temp1, double temp2, double temp3) {
FILE *cptr;
char nname[500];
int tm;
sprintf(nname,"%s/output/ctensor%d.bin",DPATH,tini);
struct stat buffer;
if(stat(nname,&buffer)) {
  printf("ctensor%d.bin does not exist \n",tini);
  exit(1);
}
cptr=fopen(nname,"r");
fread(&tm,sizeof(int),1,cptr);
if(tm!=tini) {
  printf("initial time = %d and read time = %d do not match \n",tm,tini);
  system("pause");
  return;}
fread(latc->l,sizeof(double),nx2*ny2*nz2*lcc,cptr);

/*
int l;
    for(int i=0;i<nx2;i++) {
        for(int j=0;j<ny2;j++) {
            for(int k=0;k<nz2;k++) {
                l = ((i*ny2+j)*nz2+k)*lcc;

//log conformation
	latc->l[l]=sqrt(latc->c[l]);
	latc->l[l+3]=latc->l[l+3]/latc->l[l];
	latc->l[l+4]=latc->l[l+4]/latc->l[l];
	latc->l[l+1]=sqrt(latc->c[l+1]-latc->l[l+3]*latc->l[l+3]);
	latc->l[l+5]=(latc->c[l+5]-latc->l[l+3]*latc->l[l+4])/latc->l[l+1];
	latc->l[l+2]=sqrt(latc->c[l+2]-latc->l[l+4]*latc->l[l+4]-latc->l[l+5]*latc->l[l+5]);

latc->l[l]=log(latc->l[l]);
latc->l[l+1]=log(latc->l[l+1]);
latc->l[l+2]=log(latc->l[l+2]);

}}}//end i,j,k
*/


fclose(cptr);
}

void init_readq(lclattice *latc, double temp1, double temp2, double temp3) {
FILE *qptr;
char nname[500];
int tm;
sprintf(nname,"%s/output/qtensor%d.bin",DPATH,tini);
struct stat buffer;
if(stat(nname,&buffer)) {
  printf("qtensor%d.bin does not exist \n",tini);
  exit(1);
}
qptr=fopen(nname,"r");
fread(&tm,sizeof(int),1,qptr);
if(tm!=tini) {
  printf("initial time = %d and read time = %d do not match \n",tm,tini);
  system("pause");
  return;}
fread(latc->q,sizeof(double),nx2*ny2*nz2*lcq,qptr);
/*int l,llc; for(int k=1;k<=nz;k++) { for(int j=1;j<=ny;j++) { for(int i=1;i<=nx;i++) { l=(i*ny2+j)*nz2+k; for (int m=0;m<lcq;m++) { llc=l*lcq+m; fscanf(qptr,"%lf",&ff); latc->q[llc]=ff;} } } }*/
fclose(qptr);
}

void init_readf(lblattice *latv) {
FILE *fptr;
char nname[500];
int tm;
sprintf(nname,"%s/output/ftensor%d.bin",DPATH,tini);
struct stat buffer;
if(stat(nname,&buffer)) {
  printf("ftensor%d.bin does not exist \n",tini);
  exit(1);
}
fptr=fopen(nname,"r");
fread(&tm,sizeof(int),1,fptr);
if(tm!=tini) {
  printf("initial time = %d and read time = %d do not match \n",tm,tini);
  system("pause");
  return;}
fread(latv->f,sizeof(double),nx2*ny2*nz2*lbq,fptr);
/*fscanf(fptr,"%d",&tm); int l,llf; for(int k=1;k<=nz;k++) { for(int j=1;j<=ny;j++) { for(int i=1;i<=nx;i++) { l=(i*ny2+j)*nz2+k; for (int m=0;m<lbq;m++) { llf=l*lbq+m; fscanf(fptr,"%lf",&ff); latv->f[llf]=ff;} } } }*/
fclose(fptr);
}

void init_readg(wedge *latw) {
printf("Emmanuel: reading geometry OFF!");
/*
FILE *wptr;
char nname[500];
sprintf(nname,"%s/geometry.bin",DPATH);
struct stat buffer;
if(stat(nname,&buffer)) {
  printf("data/geometry.bin does not exist \n");
  exit(1);
}
wptr=fopen(nname,"r");
fread(latw->w,sizeof(int),nx2*ny2*nz2,wptr);
fclose(wptr);
*/
}

void init_readphi(lclattice *latc, double temp1, double temp2, double temp3, double temp4) {
FILE *pptr;
char nname[500];
int tm;
sprintf(nname,"%s/output/phinsor%d.bin",DPATH,tini);
struct stat buffer;
if(stat(nname,&buffer)) {
  printf("phinsor%d.bin does not exist \n",tini);
  exit(1);
}
pptr=fopen(nname,"r");
fread(&tm,sizeof(int),1,pptr);
if(tm!=tini) {
  printf("initial time = %d and read time = %d do not match \n",tm,tini);
  system("pause");
  return;}
fread(latc->phi,sizeof(double),nx2*ny2*nz2,pptr);
/*int l,llc; for(int k=1;k<=nz;k++) { for(int j=1;j<=ny;j++) { for(int i=1;i<=nx;i++) { l=(i*ny2+j)*nz2+k; for (int m=0;m<lcq;m++) { llc=l*lcq+m; fscanf(qptr,"%lf",&ff); latc->q[llc]=ff;} } } }*/
fclose(pptr);
}

void init_read_eq_f(double* lat_f, int nx2_, int ny2_, int nz2_)
{
	FILE *fptr;
	
	char nname[500];
	int tm;
	
	sprintf(nname,"%s/output/ftensor%d.bin",DPATH,tini);
	
	struct stat buffer;
	
	if(stat(nname,&buffer))
	{
		printf("ftensor%d.bin does not exist \n",tini);
		exit(1);
	}
	
	fptr=fopen(nname,"r");
	fread(&tm,sizeof(int),1,fptr);
	
	if(tm!=tini)
	{
		printf("initial time = %d and read time = %d do not match \n",tm,tini);
		system("pause");
		
		return;
	}
	
	fread(lat_f,sizeof(double),nx2_*ny2_*nz2_*lbq,fptr);
	fclose(fptr);
}

void init_read_eq_q(double* lat_q, int nx2_, int ny2_, int nz2_)
{
	FILE *qptr;
	
	char nname[500];
	int tm;
	
	sprintf(nname,"%s/output/qtensor%d.bin",DPATH,tini);
	
	struct stat buffer;
	
	if(stat(nname,&buffer))
	{
		printf("qtensor%d.bin does not exist \n",tini);
		exit(1);
	}
	
	qptr=fopen(nname,"r");
	fread(&tm,sizeof(int),1,qptr);
	
	if (tm!=tini)
	{
		printf("initial time = %d and read time = %d do not match \n",tm,tini);
		system("pause");
		
		return;
	}
	
	fread(lat_q,sizeof(double),nx2_*ny2_*nz2_*lcq,qptr);
	fclose(qptr);
}

void init_read_eq_phi(double* lat_phi, int nx2_, int ny2_, int nz2_)
{
	FILE *pptr;
	
	char nname[500];
	int tm;
	
	sprintf(nname,"%s/output/phinsor%d.bin",DPATH,tini);
	
	struct stat buffer;
	
	if (stat(nname,&buffer))
	{
		printf("phinsor%d.bin does not exist \n",tini);
		exit(1);
	}
	
	pptr=fopen(nname,"r");
	fread(&tm,sizeof(int),1,pptr);
	
	if(tm!=tini)
	{
		printf("initial time = %d and read time = %d do not match \n",tm,tini);
		system("pause");
		
		return;
	}
	
	fread(lat_phi,sizeof(double),nx2_*ny2_*nz2_,pptr);
	fclose(pptr);
}
