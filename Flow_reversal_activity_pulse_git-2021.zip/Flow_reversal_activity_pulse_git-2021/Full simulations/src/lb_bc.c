/* Boundary conditions associated with d3q15 lattice LB simulation*/
void boundary_conditions_lb(lblattice *lat, int i) {
switch (i) {
case 1:
lat->bc_func=&pbc_on_vars;
break ;
case 2:
lat->bc_func=&lbwalls_xz;
break ;
case 3:
lat->bc_func=&lbwalls_xzandyz;
break;
case 4:
lbleeed_initialise(lat);
lat->bc_func=&lbleeed_xz;
break;
case 5:
  if(iswedge||istwowedge) {lat->bc_func=&lbwedge_inxy;}
  else if(isbox||iscir) {lat->bc_func=&lbgeominside_inxy;}
  else {return;} 
break;
case 6:
lbleeed_initialise(lat);
if(isbox||iscir) {lat->bc_func=&lbgeominxyleeedinxz;}
else {return;}
break;
case 7:
if(isbox||iscir) {lat->bc_func=&lbgeominxyplatesinxz;}
else {return;}
break;
}
if(impflow>0) {lat->bc_func=&do_nothing;}
return;
}

void lbgeominxyplatesinxz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq,int t) {
lbwalls_xz(latv, latc, latw, q, lq);
lbwedgeindomain(latv,latw); 
return;
}

void lbgeominxyleeedinxz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq,int t) {
lbleeed_topbottom(latv,t);/*le on xz plane*/
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
reflnabouty_copying_linez(q,lq);/*reflection copy of z line @ four edges*/
reflnabouty_copying_linex(q,lq);/*reflection copy of x line @ four edges*/
lbwedgeindomain(latv,latw); 
return;
}

void lbgeominside_inxy(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
pbc_on_vars(latv, latc, latw, q, lq);
lbwedgeindomain(latv,latw); 
return;
}

void lbwedge_inxy(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
lbwedgeindomain(latv,latw); /*wedge will take care of top wall as well*/
return;
}

void lbwalls_xz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
lbwalls_topbottom(latv);
return;
}

void lbwalls_xzandyz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
lbwalls_leftright(latv);
lbwalls_topbottom(latv);
return;
}

void lbwalls_leftright(lblattice *lat) {
for(int j=1;j<=ny;j++) {
  for(int k=1;k<=nz;k++) {
    /*left wall, i=1/2*/
    tobounceapply(lat,1,j,k,2,0);
    tobounceapply(lat,1,j,k,11,0);
    tobounceapply(lat,1,j,k,12,0);
    tobounceapply(lat,1,j,k,13,0);
    tobounceapply(lat,1,j,k,14,0);
    /*right wall, i=nx+1/2*/
    tobounceapply(lat,nx,j,k,1,0);
    tobounceapply(lat,nx,j,k,7,0);
    tobounceapply(lat,nx,j,k,8,0);
    tobounceapply(lat,nx,j,k,9,0);
    tobounceapply(lat,nx,j,k,10,0);
  };};
return;
}

void lbwalls_topbottom(lblattice *lat) {
int twal=(fabs(topwallvel[0])>=0.0);
int bwal=-(fabs(botwallvel[0])>=0.0);
for(int i=1;i<=nx;i++) {
  for(int k=1;k<=nz;k++) {
    /*bottom wall, j=1/2*/
    tobounceapply(lat,i,1,k,4,bwal);
    tobounceapply(lat,i,1,k,9,bwal);
    tobounceapply(lat,i,1,k,10,bwal);
    tobounceapply(lat,i,1,k,13,bwal);
    tobounceapply(lat,i,1,k,14,bwal);
    /*top wall, j=ny+1/2*/
    tobounceapply(lat,i,ny,k,3,twal);
    tobounceapply(lat,i,ny,k,7,twal);
    tobounceapply(lat,i,ny,k,8,twal);
    tobounceapply(lat,i,ny,k,11,twal);
    tobounceapply(lat,i,ny,k,12,twal);
  };};
return;
}

void lbwalls_frontback(lblattice *lat) {
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    /*back wall, k=1/2*/
    tobounceapply(lat,i,j,1,6,0);
    tobounceapply(lat,i,j,1,8,0);
    tobounceapply(lat,i,j,1,10,0);
    tobounceapply(lat,i,j,1,12,0);
    tobounceapply(lat,i,j,1,14,0);
    /*front wall, k=nz+1/2*/
    tobounceapply(lat,i,j,nz,5,0);
    tobounceapply(lat,i,j,nz,7,0);
    tobounceapply(lat,i,j,nz,9,0);
    tobounceapply(lat,i,j,nz,11,0);
    tobounceapply(lat,i,j,nz,13,0);
  };};
return;
}

void tobounceapply(lblattice *lat, int i, int j, int k, int m,int wal) {
int lpt=(i*ny2+j)*nz2+k;
int l=lpt*lbq+m;
double *xi=&lat->xi[m*lbd];
int inew=i+xi[0];//lat->xi[m*lbd];
int jnew=j+xi[1];//lat->xi[m*lbd+1];
int knew=k+xi[2];//lat->xi[m*lbd+2];
int lnew=((inew*ny2+jnew)*nz2+knew)*lbq+lat->complement[m];
/*Imposing wall velocity based on Alexander J Wagner's write up - A practical introduction to the lattice boltzmann method - ftp://ftp.math.tu-berlin.de/pub/numerik/baerwolf/seminar1112/lbm_book.pdf - However note that I add a negative sign and remove the factor of lat->cs2 to get the correct answer - hopefully this should be to do with various defnintions we are using - Remember, the start up couette flow obtained with this calculation exactly matches with the analytical expressions given in White's book on viscous fluid flow.*/
double Udotv;
switch (wal) {
case 0:
  Udotv=0.0;
  break;
case 1:
  Udotv=topwallvel[0]*xi[0]+topwallvel[1]*xi[1]+topwallvel[2]*xi[2];
  break;
case -1:
  Udotv=botwallvel[0]*xi[0]+botwallvel[1]*xi[1]+botwallvel[2]*xi[2];
  break;
}
double addm=-6*lat->wt[m]*lat->rho[lpt]*Udotv;///lat->cs2;
lat->fnew[lnew]=lat->fnew[l]+addm;
return;
}

/*wall boundary conditions*/
void wallbc(lblattice *lat) {
/*bottom wall, j=1/2, and top wall, j=ny+1/2 bounce back boundary condition*/
for(int i=1;i<=nx;i++)
  for(int k=1;k<=nz;k++) {
    wallbcapply(lat,i,0,k,4,1);
    wallbcapply(lat,i,0,k,9,1);
    wallbcapply(lat,i,0,k,10,1);
    wallbcapply(lat,i,0,k,13,1);
    wallbcapply(lat,i,0,k,14,1);
    wallbcapply(lat,i,ny+1,k,3,ny);
    wallbcapply(lat,i,ny+1,k,7,ny);
    wallbcapply(lat,i,ny+1,k,8,ny);
    wallbcapply(lat,i,ny+1,k,11,ny);
    wallbcapply(lat,i,ny+1,k,12,ny);
   }
}

void wallbcapply(lblattice *lat, int i, int j, int k, int m, int jnew) {
int l=((i*ny2+j)*nz2+k)*lbq+m;
int lnew=((i*ny2+jnew)*nz2+k)*lbq+lat->complement[m];
lat->fnew[lnew]=lat->fnew[l];
}

void lbwedgeindomain(lblattice *latv, wedge *latw) {
int l,inew,jnew,knew,lnew;
double Udotv=0.0;
double addm=0.0;
double xc=nx/2.+0.5, yc=ny/2.+0.5,zc=1.0;
double wallvel[3]={0.0,0.0,0.0};
double cx,cy,cz;
int np;
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]==lwall) {
        for(int m=0;m<lbq;m++) {
          inew=i+latv->xi[m*lbd];
          jnew=j+latv->xi[m*lbd+1];
          knew=k+latv->xi[m*lbd+2];
          lnew=(inew*ny2+jnew)*nz2+knew;
          if(latw->w[lnew]==swall) {
	    if(isrotn==1) {
	      np=latw->partmark[l];
	      xc=latw->partloc[(np-1)*lcd+0];
	      yc=latw->partloc[(np-1)*lcd+1];
	      zc=latw->partloc[(np-1)*lcd+2];
	      cx = i+0.5*latv->xi[m*lbd+0]-xc;
	      cy = j+0.5*latv->xi[m*lbd+1]-yc;
	      cz = k+0.5*latv->xi[m*lbd+2]-zc;
	      wallvel[0] = latw->bodyomega[(np-1)*lcd+1]*cz - latw->bodyomega[(np-1)*lcd+2]*cy;
	      wallvel[1] = latw->bodyomega[(np-1)*lcd+2]*cx - latw->bodyomega[(np-1)*lcd+0]*cz;
	      wallvel[2] = latw->bodyomega[(np-1)*lcd+0]*cy - latw->bodyomega[(np-1)*lcd+1]*cx;
	      Udotv=wallvel[0]*latv->xi[latv->complement[m]*lbd+0]+wallvel[1]*latv->xi[latv->complement[m]*lbd+1]+wallvel[2]*latv->xi[latv->complement[m]*lbd+2];
	      addm=6*latv->wt[m]*rho0*Udotv;///lat->cs2;
	      //addm=6*latv->wt[m]*latv->rho[l]*Udotv;///lat->cs2;
	    }
            latv->fnew[lnew*lbq+latv->complement[m]]=latv->fnew[l*lbq+m]+addm;/*We use the same boundary condition as suggested by Wagner in his LBM pdf which is same as what Ladd also suggested in his 1994 jfms. We have to be only careful in doing the torque calculation correctly.*/
}; }; };
}; }; };

for(int i=0;i<numofpart;i++) {
xc=latw->partloc[i*lcd+0];
yc=latw->partloc[i*lcd+1];
zc=latw->partloc[i*lcd+2];
cx = latw->markers[i*lcd+0] - xc;
cy = latw->markers[i*lcd+1] - yc;
cz = latw->markers[i*lcd+2] - zc;
wallvel[0] = latw->bodyomega[i*lcd+1]*cz - latw->bodyomega[i*lcd+2]*cy;
wallvel[1] = latw->bodyomega[i*lcd+2]*cx - latw->bodyomega[i*lcd+0]*cz;
wallvel[2] = latw->bodyomega[i*lcd+0]*cy - latw->bodyomega[i*lcd+1]*cx;
latw->markers[i*lcd+0]+=wallvel[0]*latv->Dt;
latw->markers[i*lcd+1]+=wallvel[1]*latv->Dt;
latw->markers[i*lcd+2]+=wallvel[2]*latv->Dt;
}
return;
}

void lbleeed_xz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq,int t) {
lbleeed_topbottom(latv,t);/*le on xz plane*/
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
reflnabouty_copying_linez(q,lq);/*reflection copy of z line @ four edges*/
reflnabouty_copying_linex(q,lq);/*reflection copy of x line @ four edges*/
return;
}

void lbleeed_initialise(lblattice *lat) {
lat->leef = (double *)malloc(nx2*2*nz2*lbq*sizeof(double));/*proxy distribution functions for top and bottom*/
return;
}

void lbleeed_calculate(lblattice *lat, int t) {
int j,l,lp;
double fdq[lbq];
double Utop[lbd],Ubot[lbd];
Utop[0]=(oscillatory==1)? shearrate*ny*sin(frequency*t): shearrate*ny;Utop[1]=0;Utop[2]=0;
Ubot[0]=(oscillatory==1)?-shearrate*ny*sin(frequency*t):-shearrate*ny;Ubot[1]=0;Ubot[2]=0;
for(int i=1;i<=nx;i++) {
  for(int k=1;k<=nz;k++) {
    j=ny;
    lp=(i*2+0)*nz2+k;/*for bottom*/
    l =(i*ny2+j)*nz2+k;/*frm top*/
    fdqcal(lat,i,j,k,fdq,Ubot);
    for(int m=0;m<lbq;m++) {
    	lat->leef[lp*lbq+m] = lat->fnew[l*lbq+m]+fdq[m];
    	lat->fnew[((i*ny2+0)*nz2+k)*lbq+m] = 0.0;/*bottom elements to zero so that it can be used later during interpolation*/
    }
    j=1;
    lp=(i*2+1)*nz2+k;/*for top*/
    l =(i*ny2+j)*nz2+k;/*frm bottom*/
    fdqcal(lat,i,j,k,fdq,Utop);
    for(int m=0;m<lbq;m++) {
    	lat->leef[lp*lbq+m] = lat->fnew[l*lbq+m]+fdq[m];
    	lat->fnew[((i*ny2+ny+1)*nz2+k)*lbq+m] = 0.0;/*so that it can be used later during interpolation*/
    }
  }
}
return;
}

void fdqcal(lblattice *lat, int i, int j, int k,double *fdiff,double *Us) {
double *xi=&lat->xi[0];
double *u=lat->u+(((i*ny2+j)*nz2+k)*lbd);
double rho=*(lat->rho+((i*ny2+j)*nz2+k));

double B2 = rho/24.;
double B1 = 8.*B2;

double C2 =-B2;
double C1 = 2.*C2;
double C0 = -2.*rho/3.;

double D2 = rho/16.;
double D1 = 8.*D2;

double Uu2 = Us[0]*Us[0]+Us[1]*Us[1]+Us[2]*Us[2]+2*(Us[0]*u[0]+Us[1]*u[1]+Us[2]*u[2]);
double tem1,tem2;
fdiff[0] = C0*Uu2;
for(int m=1;m<=6;m++) {
  tem1 = Us[0]*xi[3*m+0]+Us[1]*xi[3*m+1]+Us[2]*xi[3*m+2];
  tem2 = 0;
  for(int p=0;p<3;p++)
    for(int q=0;q<3;q++) tem2=tem2+(Us[p]*Us[q]+Us[p]*u[q]+u[p]*Us[q])*xi[3*m+p]*xi[3*m+q];
  fdiff[m] = B1*tem1+C1*Uu2+D1*tem2;
}

for(int m=7;m<=14;m++) {
  tem1 = Us[0]*xi[3*m+0]+Us[1]*xi[3*m+1]+Us[2]*xi[3*m+2];
  tem2 = 0;
  for(int p=0;p<3;p++)
    for(int q=0;q<3;q++) tem2=tem2+(Us[p]*Us[q]+Us[p]*u[q]+u[p]*Us[q])*xi[3*m+p]*xi[3*m+q];
  fdiff[m] = B2*tem1+C2*Uu2+D2*tem2;
}
return;
}

void lbleeed_interpolate(lblattice *lat, int t) {
int ll,lr,lp,il,ir;
double distx;
distx=(oscillatory==1)?shearrate*ny*(1.0-cos(frequency*t))/frequency:t*shearrate*ny;
int idistx=(int) distx;
double rdistx=distx-idistx;
idistx=idistx%nx;
for(int i=1;i<=nx;i++) {
  for(int k=1;k<=nz;k++) {
    lp=(i*2+1)*nz2+k;/*top*/
    il=(i+idistx)%nx;
    il=il==0?nx:il;
    ir=(i+idistx+1)%nx;
    ir=ir==0?nx:ir;
    ll=(il*ny2+ny+1)*nz2+k;/*top*/
    lr=(ir*ny2+ny+1)*nz2+k;/*top*/
    for(int m=0;m<lbq;m++) {
    	lat->fnew[ll*lbq+m]+=(1.0-rdistx)*lat->leef[lp*lbq+m];
    	lat->fnew[lr*lbq+m]+=rdistx*lat->leef[lp*lbq+m];
    }
    lp=(i*2+0)*nz2+k;/*bottom*/
    il=(i+nx-idistx)%nx;/*Moving nx distance to avoid -ve values*/
    il=il==0?nx:il;
    ir=(i+nx-1-idistx)%nx;
    ir=ir==0?nx:ir;
    ll=(il*ny2+0)*nz2+k;/*bottom*/
    lr=(ir*ny2+0)*nz2+k;/*bottom*/
    for(int m=0;m<lbq;m++) {
    	lat->fnew[ll*lbq+m]+=(1.0-rdistx)*lat->leef[lp*lbq+m];
    	lat->fnew[lr*lbq+m]+=rdistx*lat->leef[lp*lbq+m];
    }
  }
}
return;
}

void lbleeed_topbottom(lblattice *lat, int t) {
lbleeed_calculate(lat,t);
lbleeed_interpolate(lat,t);
return;
}
