void centreofmass(lclattice *latc, wedge *latw, int tm, double *cm_x, double *cm_y){
//Declarations of variables
double *phi=&latc->phi[0];
//double *u=&latv->u[0];
//int lps[26];
double complex xcm=0.0, ycm=0.0;
double realxcm=0.0, realycm=0.0;
double philoc;
int ncount=0;
int i,j,k;
	
for(i=1;i<=nx;i++) {
  for(j=1;j<=ny;j++) {
    for(k=1;k<=nz;k++) {
	int lpt = (i*ny2+j)*nz2+k;
	philoc=phi[lpt];
	if(philoc>phicrit){
	//printf("Reading %d,%d.\n",i,j);
	xcm+=cexp((double)i*2*PI*I/nx)*(complex)philoc;
	ycm+=cexp((double)j*2*PI*I/ny)*(complex)philoc;
	ncount+=1;
	};
} } }
	xcm/=ncount;
	ycm/=ncount;
	realxcm=(carg(xcm))*nx/(2*PI);
	realycm=(carg(ycm))*ny/(2*PI);
	if(realxcm<=0) realxcm=(carg(xcm)+2*PI)*nx/(2*PI);
	if(realycm<=0) realycm=(carg(ycm)+2*PI)*ny/(2*PI);
//printf("The centre of mass is %f,%f.\n",realxcm,realycm);

*cm_x=realxcm;
*cm_y=realycm;
	return;
}


