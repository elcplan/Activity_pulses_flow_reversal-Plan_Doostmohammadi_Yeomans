typedef struct tracedyn {
    double *locsini; /*Tracers locations initially*/
    double *locs; /*Tracers locations in the domain anytime*/
    double *locsanyt; /*Tracers locations actual anytime*/
    double *displm; /*Tracers displacements anytime*/
} tracedyn;

typedef struct autocorr {
    double *vstd;/*Velocity field in the memory*/
    double *qstd;/*director field in the memory*/
    double *ostd;/*vorticity field in the memory*/
    double *vauto;/*v autocorrelation as a function of time*/
    double *qauto;/*q autocorrelation as a function of time*/
    double *oauto;/*omega autocorrelation as a function of time*/
    double *vautotemp;/*autocorrelation as a function of time - temporarily*/
    double *qautotemp;/*autocorrelation as a function of time - temporarily*/
    double *oautotemp;/*autocorrelation as a function of time - temporarily*/
    int realzn;/*Number of realizations*/
    int tstd;/*Time where it starts*/
} autocorr;

autocorr *autocorrmemallocate();
void (*autocorrcalc)(lblattice *, lclattice *, wedge *, autocorr *, int );
void autocorrcalcon(lblattice *, lclattice *, wedge *, autocorr *, int );
void autocorrcalcoff(lblattice *, lclattice *, wedge *, autocorr *, int );
void autocorrmemory(lblattice *, lclattice *, autocorr *, int tm);
void autocorractualcalc(lblattice *,lclattice *, autocorr *,int );
void autocorravg(autocorr *, int );
void autocorrwrite(autocorr *, int );

typedef struct spatcorr {
    int *nspat;/*v spatcorrelation as a function of dist*/
    double *vspat;/*v spatcorrelation as a function of dist*/
    double *qspat;/*q spatcorrelation as a function of dist*/
    double *ospat;/*omega spatcorrelation as a function of dist*/
    int *nspattemp;/*spatcorrelation as a function of dist - temporarily*/
    double *vspattemp;/*spatcorrelation as a function of dist - temporarily*/
    double *qspattemp;/*spatcorrelation as a function of dist - temporarily*/
    double *ospattemp;/*spatcorrelation as a function of dist - temporarily*/
    int realzn;/*Number of realizations*/
} spatcorr;

typedef struct calccorr{
    autocorr *autoc;
    spatcorr *spatc;
    tracedyn *tracc;
} calccorr;

calccorr *calccorrmemallocate();
spatcorr *spatcorrmemallocate();
tracedyn *tracermemallocate();
void tracerlocinitialise(tracedyn *);
void (*tracertrack)(lblattice *, tracedyn *, int );
void tracertrackon(lblattice *, tracedyn *, int);
void tracertrackoff(lblattice *, tracedyn *, int);
void tracertrackactual(lblattice *, tracedyn *, int);
void writetracers(tracedyn *, int );
void (*spatcorrcalc)(lblattice *, lclattice *, wedge *, spatcorr *, int );
void spatcorrcalcon(lblattice *, lclattice *, wedge *, spatcorr *, int );
void spatcorrcalcoff(lblattice *, lclattice *, wedge *, spatcorr *, int );
void spatcorractualcalc(lblattice *,lclattice *, spatcorr *,int );
void spatcorravg(spatcorr *, int );
void spatcorrwrite(spatcorr *, int );






