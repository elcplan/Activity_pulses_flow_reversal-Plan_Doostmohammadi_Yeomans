// This file starts the series of header files//

/*kronecker delta in 3 dimensions*/          
int kdelta[3][3] = {{1,0,0},{0,1,0},{0,0,1}};

/*Numerical recipes definitions*/
float ran2(long *);
float gasdev(long *);
void tqli(float diag[], float offdiag[], int , float ** );
void tred2(float ** , int , float diag[], float offdiag[]);

/*Basis vectors for Q tensor in 3 dimensions*/
double T1[3][3] = {{0,0,0},{0,0,0},{0,0,0}};
double T2[3][3] = {{0,0,0},{0,0,0},{0,0,0}};
double T3[3][3] = {{0,0,0},{0,0,0},{0,0,0}};
double T4[3][3] = {{0,0,0},{0,0,0},{0,0,0}};
double T5[3][3] = {{0,0,0},{0,0,0},{0,0,0}};





