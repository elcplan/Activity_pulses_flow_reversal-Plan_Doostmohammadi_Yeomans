/*There are three functions on calculating stress, one of which is simply to write. 
But there is too much re-calculating going on. We must optimize a bit.*/

/*
void diffusive_flux_q(lclattice *latc, double *q, double *H, int l,double *difflx, int *lps, double *dqx, double *dqy, double *dqz,double phi,int lptlw,int tm) {
    double l2h[6]={0,0,0,0,0,0};
    double l3h[6]={0,0,0,0,0,0};
    double lap[6]={0,0,0,0,0,0};
    double lCh[6]={0,0,0,0,0,0};
    double l1hchiral[6]={0,0,0,0,0,0};
    int lpx=lps[0],lmx=lps[1],lpy=lps[2],lmy=lps[3],lpz=lps[4],lmz=lps[5];
    int llc=l*lcq;
    double *qloc=&(q[llc]);
    double traceq2=qloc[0]*qloc[0]+qloc[1]*qloc[1]+qloc[2]*qloc[2]+2*(qloc[3]*qloc[3]+qloc[4]*qloc[4]+qloc[5]*qloc[5]);
    double bulk[6];
    double coup[6]={0,0,0,0,0,0};
    double elech[6]={0,0,0,0,0,0};
    double chiral[6]={0,0,0,0,0,0};
    double Alceff=Alc,Blceff=Blc,Clceff=Clc;
    
    if(inphase) {
        double etaphi=eta0lcphi-etaslcphi*(phi-phibar)*(phi-phibar);
        Alceff=A0lcphi*phi*phi*(1.0-etaphi/3.0);
        Blceff=-A0lcphi*phi*phi*etaphi*Beq0;
        Clceff=A0lcphi*phi*phi*etaphi;
        
        double dphidx=0.5*(latc->phi[lpx]-latc->phi[lmx]);
        double dphidy=0.5*(latc->phi[lpy]-latc->phi[lmy]);
        double dphidz=0.5*(latc->phi[lpz]-latc->phi[lmz]);

        coup[0]=-Lw*(dphidx*dphidx-1.0/3.0*(dphidx*dphidx+dphidy*dphidy+dphidz*dphidz));
        coup[1]=-Lw*(dphidy*dphidy-1.0/3.0*(dphidx*dphidx+dphidy*dphidy+dphidz*dphidz));
        coup[2]=-Lw*(dphidz*dphidz-1.0/3.0*(dphidx*dphidx+dphidy*dphidy+dphidz*dphidz));
        coup[3]=-Lw*dphidx*dphidy;
        coup[4]=-Lw*dphidx*dphidz;
        coup[5]=-Lw*dphidy*dphidz;
    }
    
    bulk[0]=-Alceff*qloc[0]-Blceff*(qloc[0]*qloc[0]+qloc[3]*qloc[3]+qloc[4]*qloc[4]-traceq2/3.0)-Clceff*qloc[0]*traceq2;
    bulk[1]=-Alceff*qloc[1]-Blceff*(qloc[3]*qloc[3]+qloc[1]*qloc[1]+qloc[5]*qloc[5]-traceq2/3.0)-Clceff*qloc[1]*traceq2;
    bulk[2]=-Alceff*qloc[2]-Blceff*(qloc[4]*qloc[4]+qloc[5]*qloc[5]+qloc[2]*qloc[2]-traceq2/3.0)-Clceff*qloc[2]*traceq2;
    bulk[3]=-Alceff*qloc[3]-Blceff*(qloc[0]*qloc[3]+qloc[3]*qloc[1]+qloc[4]*qloc[5])-Clceff*qloc[3]*traceq2;
    bulk[4]=-Alceff*qloc[4]-Blceff*(qloc[0]*qloc[4]+qloc[3]*qloc[5]+qloc[4]*qloc[2])-Clceff*qloc[4]*traceq2;
    bulk[5]=-Alceff*qloc[5]-Blceff*(qloc[3]*qloc[4]+qloc[1]*qloc[5]+qloc[5]*qloc[2])-Clceff*qloc[5]*traceq2;
    
    for(int m=0; m<lcq; m++) {lap[m]=lap_cd(q,l,lps,m);}
    
    if(sconst>0) { l2l3derivforh(q,l,lps,&l2h[0],&l3h[0],&lap[0],dqx,dqy,dqz); };
    if(ischiral) { l1forchiral(q,l,lps,&l1hchiral[0],&lCh[0],&lap[0],dqx,dqy,dqz); };
    if(iselectric&&(tm>telecini)&&(tm<telecend)) {
        double elecmag=elecf[0]*elecf[0]+elecf[1]*elecf[1]+elecf[2]*elecf[2];
        elech[0]=fsperm*dielan*(elecf[0]*elecf[0]-elecmag/3.)/3.;
        elech[1]=fsperm*dielan*(elecf[1]*elecf[1]-elecmag/3.)/3.;
        elech[2]=fsperm*dielan*(elecf[2]*elecf[2]-elecmag/3.)/3.;
        elech[3]=fsperm*dielan*(elecf[0]*elecf[1])/3.;
        elech[4]=fsperm*dielan*(elecf[0]*elecf[2])/3.;
        elech[5]=fsperm*dielan*(elecf[1]*elecf[2])/3.;
    }
    
    if(issmectic) {
        float **dq;
        float *diag,*offdiag;
        
        dq = matrix(1,3,1,3);
        diag=vector(1,3);
        offdiag=vector(1,3);
        
        dq[1][1]=q[0];dq[1][2]=q[3];dq[1][3]=q[4];
        dq[2][1]=q[3];dq[2][2]=q[1];dq[2][3]=q[5];
        dq[3][1]=q[4];dq[3][2]=q[5];dq[3][3]=q[2];
        
        tred2(dq,lbd,diag,offdiag);
        tqli(diag,offdiag,lbd,dq);
        int evmax=1;
        
        if(diag[2]>diag[evmax]) evmax=2;
        if(diag[3]>diag[evmax]) evmax=3;
        
        if(abs(diag[evmax]<1e-10)) {dq[1][evmax]=0;dq[2][evmax]=0;dq[3][evmax]=0;}
        if(diag[evmax]<-100) {dq[1][evmax]=0;dq[2][evmax]=0;dq[3][evmax]=0;}
        
        if(evmax==1){
            chiral[4]=dq[3][1];}
        else if(evmax==2){
            chiral[5]=dq[3][2];}
        else if(evmax==3){
            chiral[0]=-1/3.*dq[3][3];
            chiral[1]=-1/3.*dq[3][3];
            chiral[2]=2/3.*dq[3][3];
        };
        
        free_matrix(dq, 1,3,1,3);
        free_vector(diag, 1,3);
        free_vector(offdiag, 1,3);
    };
    
    for(int m=0; m<lcq; m++) {
        H[llc+m]=isbulk*bulk[m]
		+Klc*lap[m]*(1-ischiral)
		+0.5*Klc*l1hchiral[m]*ischiral
		+0.5*K2lc*l2h[m]*sconst+K3lc*l3h[m]*sconst
		+weakanch*lptlw*H[llc+m]
		+coup[m]
		+iselectric*elech[m]*phi
		+ischiral*KClc*lCh[m]
		+2.*CSme*chiral[m];
        difflx[m]=Gammalc*H[llc+m];};
    return;
}
*/

/*Calculating all the liquid crystal stresses*/ //used for evolution
void liqcstresses(lclattice *lat, int l,double rho, double *dqx, double *dqy, double *dqz, double visc, double *strain,int *lps, double *order, double *elasticity, double *concen, double *surftens, double *anchor, int tm) {
    double l1s[6]={0,0,0,0,0,0};
    double l2s[6]={0,0,0,0,0,0};
    double l3s[6]={0,0,0,0,0,0};
    double lCs[9]={0,0,0,0,0,0,0,0,0}; /* First 6 symmetric; next 3 antisymmetric*/
    double l2p=0.0;
    double l3p=0.0;
    double smecticFE = 0.0;
    double *q=&(lat->q[l*lcq]);
    double *h=&(lat->H[l*lcq]);
    double phi,mu;
    if(sconst>0) { l2l3forstress(q,l,dqx,dqy,dqz,&l2s[0],&l3s[0],&l2p,&l3p); };
    if(ischiral) { lchiralforstress(q,l,dqx,dqy,dqz,&lCs[0],&l1s[0]); };
    double qh=q[0]*h[0]+q[1]*h[1]+q[2]*h[2]+2.0*(q[3]*h[3]+q[4]*h[4]+q[5]*h[5]);	//Q:H=sum_ij[(Q_ij)(H_ij)]
    double diff2=dqx[0]*dqx[0]+dqy[0]*dqy[0]+dqz[0]*dqz[0]
		+dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]
		+dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]
		+dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]
		+dqx[1]*dqx[1]+dqy[1]*dqy[1]+dqz[1]*dqz[1]
		+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]
		+dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]
		+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]
		+dqx[2]*dqx[2]+dqy[2]*dqy[2]+dqz[2]*dqz[2];	//(gradQ)^2
    double Q2=q[0]*q[0]+q[1]*q[1]+q[2]*q[2]
		+2.0*(q[3]*q[3]+q[4]*q[4]+q[5]*q[5]);
    double Q3=q[0]*q[0]*q[0]+q[1]*q[1]*q[1]+q[2]*q[2]*q[2]	//Tr[Q^2]
		+3*q[0]*q[3]*q[3]+3*q[0]*q[4]*q[4]
		+3*q[1]*q[3]*q[3]+3*q[1]*q[5]*q[5]
		+3*q[2]*q[4]*q[4]+3*q[2]*q[5]*q[5]
		+6*q[3]*q[5]*q[4];				//Tr[Q^3]
    double Alceff=Alc,Blceff=Blc,Clceff=Clc;
    
    if(inphase) {
        phi=lat->phi[l];
        double etaphi=eta0lcphi-etaslcphi*(phi-phibar)*(phi-phibar);
        Alceff=A0lcphi*phi*phi*(1.0-etaphi/3.0);
        Blceff=-A0lcphi*phi*phi*etaphi*Beq0;
        Clceff=A0lcphi*phi*phi*etaphi;
    }
    
    if(issmectic) {
        float **dq;
        float *diag,*offdiag;
        
        dq = matrix(1,3,1,3);
        diag=vector(1,3);
        offdiag=vector(1,3);
        
        dq[1][1]=q[0];dq[1][2]=q[3];dq[1][3]=q[4];
        dq[2][1]=q[3];dq[2][2]=q[1];dq[2][3]=q[5];
        dq[3][1]=q[4];dq[3][2]=q[5];dq[3][3]=q[2];
        
        tred2(dq,lbd,diag,offdiag);
        tqli(diag,offdiag,lbd,dq);
        int evmax=1;
        
        if(diag[2]>diag[evmax]) evmax=2;
        if(diag[3]>diag[evmax]) evmax=3;
        
        if(abs(diag[evmax]<1e-10)) {dq[1][evmax]=0;dq[2][evmax]=0;dq[3][evmax]=0;}
        if(diag[evmax]<-100) {dq[1][evmax]=0;dq[2][evmax]=0;dq[3][evmax]=0;}
        
        smecticFE = -CSme*SQR(dq[3][evmax]);
        
        free_matrix(dq, 1,3,1,3);
        free_vector(diag, 1,3);
        free_vector(offdiag, 1,3);
    }
    
    double chiralFE=0.5*KClc*((dqy[4]-dqz[3]+2*Cpit*q[0])*(dqy[4]-dqz[3]+2*Cpit*q[0])
                              +(dqy[5]-dqz[1]+2*Cpit*q[3])*(dqy[5]-dqz[1]+2*Cpit*q[3])
                              +(dqy[2]-dqz[5]+2*Cpit*q[4])*(dqy[2]-dqz[5]+2*Cpit*q[4])
                              +(dqz[0]-dqx[4]+2*Cpit*q[3])*(dqz[0]-dqx[4]+2*Cpit*q[3])
                              +(dqz[3]-dqx[5]+2*Cpit*q[1])*(dqz[3]-dqx[5]+2*Cpit*q[1])
                              +(dqz[4]-dqx[2]+2*Cpit*q[5])*(dqz[4]-dqx[2]+2*Cpit*q[5])
                              +(dqx[3]-dqy[0]+2*Cpit*q[4])*(dqx[3]-dqy[0]+2*Cpit*q[4])
                              +(dqx[1]-dqy[3]+2*Cpit*q[5])*(dqx[1]-dqy[3]+2*Cpit*q[5])
                              +(dqx[5]-dqy[4]+2*Cpit*q[2])*(dqx[5]-dqy[4]+2*Cpit*q[2]))
    			+0.5*Klc*(dqx[0]*dqx[0]+dqy[3]*dqy[3]+dqz[4]*dqz[4]
			+dqx[3]*dqx[3]+dqy[1]*dqy[1]+dqz[5]*dqz[5]
			+dqx[4]*dqx[4]+dqy[5]*dqy[5]+dqz[2]*dqz[2]);
    
    //double chiralFE=0.5*KClc*2*Cpit*((q[0]*dqy[4]+q[3]*dqy[5]+q[4]*dqy[2])
    //                                 -(q[0]*dqz[3]+q[3]*dqz[1]+q[4]*dqz[5])
    //                                 -(q[3]*dqx[4]+q[1]*dqx[5]+q[5]*dqx[2])
    //                                 +(q[3]*dqz[0]+q[1]*dqz[3]+q[5]*dqz[4])
    //                                 +(q[4]*dqx[3]+q[5]*dqx[1]+q[2]*dqx[5])
    //                                 -(q[4]*dqy[0]+q[5]*dqy[3]+q[2]*dqy[4]));
    double freeenergy=0.5*Alceff*Q2
			+Blceff/3*Q3
			+0.25*Clceff*Q2*Q2
			+0.5*Klc*diff2*(1-ischiral)
			+chiralFE*ischiral
			+smecticFE*issmectic
			+0.5*K2lc*l2p
			+0.5*K3lc*l3p;/*Are the last two terms correct, please double check*/
    order[0] = 0.5*Alceff*Q2+Blceff/3*Q3+0.25*Clceff*Q2*Q2;
    elasticity[0] = 0.5*Klc*diff2*(1-ischiral)+0.5*K2lc*l2p+0.5*K3lc*l3p;
    if(inphase){
        if(iselectric&&(tm>telecini)&&(tm<telecend)) {
            freeenergy-=fsperm*dielan*phi*(elecf[0]*elecf[0]*q[0]
			+elecf[1]*elecf[1]*q[1]
			+elecf[2]*elecf[2]*q[2]
			+2*elecf[0]*elecf[1]*q[3]
			+2*elecf[0]*elecf[2]*q[4]
			+2*elecf[1]*elecf[2]*q[5]);
        }
    }
    double Pr=P0*rho-(!noliqc)*freeenergy;//0.5*Klc*diff2-0.5*K2lc*l2p-0.5*K3lc*l3p;
    lat->presure[l]=Pr;
    
    /*Symmetric part of the stress*/
    int lsy=l*lcd*2;
    double *es=&lat->estress[lsy];
    double xi=xilc;
    es[0]=-Pr+2*xi*(q[0]+1./3.)*qh
		-xi*(h[0]*(q[0]+1./3.)+h[3]*q[3]+h[4]*q[4]
		+(q[0]+1./3.)*h[0]+q[3]*h[3]+q[4]*h[4])
		-Klc*(dqx[0]*dqx[0]+dqx[1]*dqx[1]+dqx[2]*dqx[2]
		+2*(dqx[3]*dqx[3]+dqx[4]*dqx[4]+dqx[5]*dqx[5]))*(1-ischiral)
		-Klc*l1s[0]-K2lc*l2s[0]-K3lc*l3s[0]-0.5*KClc*lCs[0];/*1/2 not required for K2*/
    es[1]=-Pr+2*xi*(q[1]+1./3.)*qh-xi*(h[3]*q[3]+h[1]*(q[1]+1./3.)+h[5]*q[5]+q[3]*h[3]+(q[1]+1./3.)*h[1]+q[5]*h[5])
		-Klc*(dqy[0]*dqy[0]+dqy[1]*dqy[1]+dqy[2]*dqy[2]
		+2*(dqy[3]*dqy[3]+dqy[4]*dqy[4]+dqy[5]*dqy[5]))*(1-ischiral)
		-Klc*l1s[1]-K2lc*l2s[1]-K3lc*l3s[1]-0.5*KClc*lCs[1];
    es[2]=-Pr+2*xi*(q[2]+1./3.)*qh-xi*(h[4]*q[4]+h[5]*q[5]+h[2]*(q[2]+1./3.)+q[4]*h[4]+q[5]*h[5]+(q[2]+1./3.)*h[2])
		-Klc*(dqz[0]*dqz[0]+dqz[1]*dqz[1]+dqz[2]*dqz[2]
		+2*(dqz[3]*dqz[3]+dqz[4]*dqz[4]+dqz[5]*dqz[5]))*(1-ischiral)
		-Klc*l1s[2]-K2lc*l2s[2]-K3lc*l3s[2]-0.5*KClc*lCs[2];
    es[3]=    2*xi*q[3]*qh-xi*(h[0]*q[3]+h[3]*(q[1]+1./3.)+h[4]*q[5]+(q[0]+1./3.)*h[3]+q[3]*h[1]+q[4]*h[5])	
		-Klc*(dqx[0]*dqy[0]+dqx[1]*dqy[1]+dqx[2]*dqy[2]
		+2*(dqx[3]*dqy[3]+dqx[4]*dqy[4]+dqx[5]*dqy[5]))*(1-ischiral)
		-Klc*l1s[3]-K2lc*l2s[3]-K3lc*l3s[3]-0.5*KClc*lCs[3];
    es[4]=    2*xi*q[4]*qh          -xi*(h[0]*q[4]+h[3]*q[5]+h[4]*(q[2]+1./3.)
		+(q[0]+1./3.)*h[4]+q[3]*h[5]+q[4]*h[2])
		-Klc*(dqx[0]*dqz[0]+dqx[1]*dqz[1]+dqx[2]*dqz[2]+2*(dqx[3]*dqz[3]+dqx[4]*dqz[4]
		+dqx[5]*dqz[5]))*(1-ischiral)
		-Klc*l1s[4]-K2lc*l2s[4]-K3lc*l3s[4]-0.5*KClc*lCs[4];
    es[5]=    2*xi*q[5]*qh          -xi*(h[3]*q[4]+h[1]*q[5]+h[5]*(q[2]+1./3.)
		+q[3]*h[4]+(q[1]+1./3.)*h[5]+q[5]*h[2])
		-Klc*(dqy[0]*dqz[0]+dqy[1]*dqz[1]+dqy[2]*dqz[2]
		+2*(dqy[3]*dqz[3]+dqy[4]*dqz[4]+dqy[5]*dqz[5]))*(1-ischiral)
		-Klc*l1s[5]-K2lc*l2s[5]-K3lc*l3s[5]-0.5*KClc*lCs[5];
//Emmanuel
//printf("lsy=%d. es[0]=%f. *es=%f. estress[lsy]=%f.\n",lsy,es[0],*es,lat->estress[lsy]);
//printf("lsy=%d. es[1]=%f. *es=%f. estress[lsy]=%f.\n",lsy,es[1],*es,lat->estress[lsy+1]);
    
    /*Addition of active stress*/
    if((phi>0.1)&&(phi<0.9)){
    es[0]-=zetalc*q[0];
    es[1]-=zetalc*q[1];
    es[2]-=zetalc*q[2];
    es[3]-=zetalc*q[3];
    es[4]-=zetalc*q[4];
    es[5]-=zetalc*q[5];
    }
    
    /*Part of the stress that will go as body force*/
    int las=l*lcd*lcd;
    lat->bstress[las  ]=0;/*11*/
    lat->bstress[las+1]=0;/*22*/
    lat->bstress[las+2]=0;/*33*/
    lat->bstress[las+3]=q[0]*h[3]+q[3]*h[1]+q[4]*h[5]-h[0]*q[3]-h[3]*q[1]-h[4]*q[5];/*12*/
    lat->bstress[las+4]=q[0]*h[4]+q[3]*h[5]+q[4]*h[2]-h[0]*q[4]-h[3]*q[5]-h[4]*q[2];/*13*/
    lat->bstress[las+5]=q[3]*h[4]+q[1]*h[5]+q[5]*h[2]-h[3]*q[4]-h[1]*q[5]-h[5]*q[2];/*23*/
    lat->bstress[las+6]=-lat->bstress[las+3];/*21*/
    lat->bstress[las+7]=-lat->bstress[las+4];/*31*/
    lat->bstress[las+8]=-lat->bstress[las+5];/*32*/
    
    /*Addition of surface tension stress*/
    if(inphase) {
        mu=lat->mu[l];
        double dphidx=0.5*(lat->phi[lps[0]]-lat->phi[lps[1]]);
        double dphidy=0.5*(lat->phi[lps[2]]-lat->phi[lps[3]]);
        double dphidz=0.5*(lat->phi[lps[4]]-lat->phi[lps[5]]);
        double fw=Lw*(dphidx*dphidx*q[0]+2*dphidx*dphidy*q[3]+2*dphidx*dphidz*q[4]
			+dphidy*dphidy*q[1]+2*dphidy*dphidz*q[5]+dphidz*dphidz*q[2]);
        freeenergy+=0.5*Aphi*phi*phi*(1.0-phi)*(1.0-phi)+0.5*Kphi*(dphidx*dphidx+dphidy*dphidy+dphidz*dphidz)+fw;
        //freeenergy+=0.5*Aphi*pow((phi-phi0),2)+0.25*Bphi*pow((phi-phi0),4)+0.5*Kphi*(dphidx*dphidx+dphidy*dphidy+dphidz*dphidz)+fw;
        concen[0] = 0.5*Aphi*phi*phi*(1.0-phi)*(1.0-phi);
        //concen[0] = 0.5*Aphi*(phi-phi0)*(phi-phi0)+0.25*Bphi*(phi-phi0)*(phi-phi0)*(phi-phi0)*(phi-phi0);
        surftens[0] = 0.5*Kphi*(dphidx*dphidx+dphidy*dphidy+dphidz*dphidz);
        anchor[0] = fw;
        
        /*Addition of Isotropic part*/
        es[0]-=mu*phi-freeenergy;
        es[1]-=mu*phi-freeenergy;
        es[2]-=mu*phi-freeenergy;
        
        /*Addition of Anisotropic part*/
        es[0]-=Kphi*dphidx*dphidx+2*Lw*(q[0]*dphidx*dphidx+q[3]*dphidx*dphidy+q[4]*dphidx*dphidz);
        es[1]-=Kphi*dphidy*dphidy+2*Lw*(q[3]*dphidx*dphidy+q[1]*dphidy*dphidy+q[5]*dphidy*dphidz);
        es[2]-=Kphi*dphidz*dphidz+2*Lw*(q[4]*dphidx*dphidz+q[5]*dphidy*dphidz+q[2]*dphidz*dphidz);
        es[3]-=Kphi*dphidx*dphidy+2*Lw*(q[3]*dphidx*dphidx+q[1]*dphidx*dphidy+q[5]*dphidx*dphidz);
        es[4]-=Kphi*dphidx*dphidz+2*Lw*(q[4]*dphidx*dphidx+q[5]*dphidx*dphidy+q[2]*dphidx*dphidz);
        es[5]-=Kphi*dphidy*dphidz+2*Lw*(q[4]*dphidx*dphidy+q[5]*dphidy*dphidy+q[2]*dphidy*dphidz);
    }
    
    /*A provision to calculate viscous stresses if required*/
    if(forcea||isdrag) {
        lat->vstress[lsy+0]=2*visc*strain[0];
        lat->vstress[lsy+1]=2*visc*strain[1];
        lat->vstress[lsy+2]=2*visc*strain[2];
        lat->vstress[lsy+3]=2*visc*strain[3];
        lat->vstress[lsy+4]=2*visc*strain[4];
        lat->vstress[lsy+5]=2*visc*strain[5];}
    
    /*A provision to switch off back flow & active stress*/
    if(noliqc) {
        for(int m=0;m<lcq;m++) {
            es[m]=-P0*(m<lbd)*rho;/*P)*rho is important, without rho its found to result in -ve fs and -ve rhos*/
            lat->bstress[las+3+m]=0;/*Asymmetric part to zero*/
        }};
    /*A provision to switch off back flow*/
    if(nobackflow) {
        for(int m=0;m<lcq;m++) {
            es[m]=-P0*(m<lbd)*rho-zetalc*q[m];/*Only active part*//*P)*rho is important, without rho its found to result in -ve fs and -ve rhos*/
            lat->bstress[las+3+m]=0;/*Asymmetric part to zero*/
        }};
    /*A provision to switch off normal stresess in passive stress*/
    if(nopassnormstress) {
        for(int m=0;m<lbd;m++) {
            es[m]=-P0*rho-zetalc*q[m];/*Only active part*//*P)*rho is important, without rho its found to result in -ve fs and -ve rhos*/
        }};
    return;
}


/*Stress values for actcol analysis*/ //???
void stresscalc(lblattice *latv, lclattice *latc, wedge *latw, int tm) {
FILE *isptr, *anptr, *elptr, *siptr, *taptr;
char nname[500];
sprintf(nname,"%s/output/isos%d.dat",DPATH,tm); isptr=fopen(nname,"w");
sprintf(nname,"%s/output/anisos%d.dat",DPATH,tm); anptr=fopen(nname,"w");
sprintf(nname,"%s/output/elast%d.dat",DPATH,tm); elptr=fopen(nname,"w");
sprintf(nname,"%s/output/sigma%d.dat",DPATH,tm); siptr=fopen(nname,"w");
sprintf(nname,"%s/output/tau%d.dat",DPATH,tm); taptr=fopen(nname,"w");
int lps[26];/*These are for normal and mixed CDs*/
double wls[3]={0.5, 0.5, 0.5};
int *lpv=&lps[0];/*These will be used if nowedge*/
double *wlp=&wls[0];
double *q=&latc->q[0];
int lpt,lptcq;
double delu[9],strain[6],vortic[3];
double dqx[6],dqy[6],dqz[6];/*derivatives of q locally*/
double isos[3],anisos[6],elast[6],sigma[6],tau[9];
double *u=&latv->u[0];
for(int k=1;k<=nz;k++) {
    for(int j=1;j<=ny;j++) {
        for(int i=1;i<=nx;i++) {
            lpt = (i*ny2+j)*nz2+k;
            lptcq=lpt*lcq;
            derivativesN(i,j,k,&lps[0]);
            derivativesQ(q,&dqx[0],&dqy[0],&dqz[0],&lps[0]);
            if(isgeom) {lpv=&latw->lpv[lpt*2*lbd];wlp=&latw->wlp[lpt*lbd];};
            derivativesU(u,&delu[0],&strain[0],&vortic[0],lpv,wlp);
            liqcstresscalc(latc,lpt,latv->rho[lpt],&dqx[0],&dqy[0],&dqz[0],&isos[0],&anisos[0],&elast[0],&sigma[0],&tau[0],&lps[0]);
            fprintf(isptr,"%f %f %f\n",isos[0],isos[1],isos[2]);
            fprintf(anptr,"%f %f %f %f %f %f\n",anisos[0],anisos[1],anisos[2],anisos[3],anisos[4],anisos[5]);
            fprintf(elptr,"%f %f %f %f %f %f\n",elast[0],elast[1],elast[2],elast[3],elast[4],elast[5]);
            fprintf(siptr,"%f %f %f %f %f %f\n",sigma[0],sigma[1],sigma[2],sigma[3],sigma[4],sigma[5]);
            fprintf(taptr,"%f %f %f %f %f %f %f %f %f\n",tau[0],tau[1],tau[2],tau[3],tau[4],tau[5],tau[6],tau[7],tau[8]);
} } }
fclose(isptr);
fclose(anptr);
fclose(elptr);
fclose(siptr);
fclose(taptr);
}

/*Calculating all the liquid crystal stresses*/
void liqcstresscalc(lclattice *lat, int l, double rho, double *dqx, double *dqy, double *dqz, 
			double *isos, double *anisos, double *elast, double *sigma, double *tau, int *lps) {
double l2s[6]={0,0,0,0,0,0};
double l3s[6]={0,0,0,0,0,0};
double l2p=0.0;
double l3p=0.0;
double *q=&(lat->q[l*lcq]);
double *h=&(lat->H[l*lcq]);
if(sconst>0) { l2l3forstress(q,l,dqx,dqy,dqz,&l2s[0],&l3s[0],&l2p,&l3p); };
double Q2=q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+2*(q[3]*q[3]+q[4]*q[4]+q[5]*q[5]);
double Q3=q[0]*q[0]*q[0]+q[1]*q[1]*q[1]+q[2]*q[2]*q[2]
		+3*q[0]*q[3]*q[3]+3*q[0]*q[4]*q[4]+3*q[1]*q[3]*q[3]
		+3*q[1]*q[5]*q[5]+3*q[2]*q[4]*q[4]+3*q[2]*q[5]*q[5]
		+6*q[3]*q[5]*q[4];
double phi,mu;
double dphidx, dphidy,dphidz;
double qh=q[0]*h[0]+q[1]*h[1]+q[2]*h[2]+2.0*(q[3]*h[3]+q[4]*h[4]+q[5]*h[5]);
double diff2=dqx[0]*dqx[0]+dqy[0]*dqy[0]+dqz[0]*dqz[0]+dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]+dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]
      +dqx[3]*dqx[3]+dqy[3]*dqy[3]+dqz[3]*dqz[3]+dqx[1]*dqx[1]+dqy[1]*dqy[1]+dqz[1]*dqz[1]+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]
            +dqx[4]*dqx[4]+dqy[4]*dqy[4]+dqz[4]*dqz[4]+dqx[5]*dqx[5]+dqy[5]*dqy[5]+dqz[5]*dqz[5]+dqx[2]*dqx[2]+dqy[2]*dqy[2]+dqz[2]*dqz[2];
double Alceff=Alc,Blceff=Blc,Clceff=Clc;
if(inphase) {
        phi=lat->phi[l];
        double etaphi=eta0lcphi-etaslcphi*(phi-phibar)*(phi-phibar);
        Alceff=A0lcphi*phi*phi*(1.0-etaphi/3.0);
        Blceff=-A0lcphi*phi*phi*etaphi*Beq0;
        Clceff=A0lcphi*phi*phi*etaphi;
}
double freeenergy=0.5*Alceff*Q2+Blceff/3*Q3+0.25*Clceff*Q2*Q2+0.5*Klc*diff2+0.5*K2lc*l2p+0.5*K3lc*l3p;
if(inphase) {
    mu=lat->mu[l];
    dphidx=0.5*(lat->phi[lps[0]]-lat->phi[lps[1]]);
    dphidy=0.5*(lat->phi[lps[2]]-lat->phi[lps[3]]);
    dphidz=0.5*(lat->phi[lps[4]]-lat->phi[lps[5]]);
    double fw=Lw*(dphidx*dphidx*q[0]+2*dphidx*dphidy*q[3]+2*dphidx*dphidz*q[4]+dphidy*dphidy*q[1]+2*dphidy*dphidz*q[5]+dphidz*dphidz*q[2]);
    freeenergy+=0.5*Aphi*phi*phi*(1.0-phi)*(1.0-phi)+0.5*Kphi*(dphidx*dphidx+dphidy*dphidy+dphidz*dphidz)+fw;
}
/*Thermodynamic contribution to the pressure tensor*/
    /*Pi in Sulaiman et al., 2006*/
    isos[0]=-mu*phi+freeenergy;
    isos[1]=-mu*phi+freeenergy;
    isos[2]=-mu*phi+freeenergy;
    anisos[0]=-Kphi*dphidx*dphidx-2*Lw*(q[0]*dphidx*dphidx+q[3]*dphidx*dphidy+q[4]*dphidx*dphidz);
    anisos[1]=-Kphi*dphidy*dphidy-2*Lw*(q[3]*dphidx*dphidy+q[1]*dphidy*dphidy+q[5]*dphidy*dphidz);
    anisos[2]=-Kphi*dphidz*dphidz-2*Lw*(q[4]*dphidx*dphidz+q[5]*dphidy*dphidz+q[2]*dphidz*dphidz);
    anisos[3]=-Kphi*dphidx*dphidy-2*Lw*(q[3]*dphidx*dphidx+q[1]*dphidx*dphidy+q[5]*dphidx*dphidz);
    anisos[4]=-Kphi*dphidx*dphidz-2*Lw*(q[4]*dphidx*dphidx+q[5]*dphidx*dphidy+q[2]*dphidx*dphidz);
    anisos[5]=-Kphi*dphidy*dphidz-2*Lw*(q[4]*dphidx*dphidy+q[5]*dphidy*dphidy+q[2]*dphidy*dphidz);
    elast[0]=-Klc*(dqx[0]*dqx[0]+dqx[1]*dqx[1]+dqx[2]*dqx[2]+2*(dqx[3]*dqx[3]+dqx[4]*dqx[4]+dqx[5]*dqx[5]))-K2lc*l2s[0]-K3lc*l3s[0];
    elast[1]=-Klc*(dqy[0]*dqy[0]+dqy[1]*dqy[1]+dqy[2]*dqy[2]+2*(dqy[3]*dqy[3]+dqy[4]*dqy[4]+dqy[5]*dqy[5]))-K2lc*l2s[1]-K3lc*l3s[1];
    elast[2]=-Klc*(dqz[0]*dqz[0]+dqz[1]*dqz[1]+dqz[2]*dqz[2]+2*(dqz[3]*dqz[3]+dqz[4]*dqz[4]+dqz[5]*dqz[5]))-K2lc*l2s[2]-K3lc*l3s[2];
    elast[3]=-Klc*(dqx[0]*dqy[0]+dqx[1]*dqy[1]+dqx[2]*dqy[2]+2*(dqx[3]*dqy[3]+dqx[4]*dqy[4]+dqx[5]*dqy[5]))-K2lc*l2s[3]-K3lc*l3s[3];
    elast[4]=-Klc*(dqx[0]*dqz[0]+dqx[1]*dqz[1]+dqx[2]*dqz[2]+2*(dqx[3]*dqz[3]+dqx[4]*dqz[4]+dqx[5]*dqz[5]))-K2lc*l2s[4]-K3lc*l3s[4];
    elast[5]=-Klc*(dqy[0]*dqz[0]+dqy[1]*dqz[1]+dqy[2]*dqz[2]+2*(dqy[3]*dqz[3]+dqy[4]*dqz[4]+dqy[5]*dqz[5]))-K2lc*l2s[5]-K3lc*l3s[5];
    /*Sigma in Sulaiman et al., 2006*/
    double xi=xilc;
    sigma[0]=-P0*rho+2*xi*(q[0]+1./3.)*qh-xi*(h[0]*(q[0]+1./3.)+h[3]*q[3]+h[4]*q[4]+(q[0]+1./3.)*h[0]+q[3]*h[3]+q[4]*h[4]);
    sigma[1]=-P0*rho+2*xi*(q[1]+1./3.)*qh-xi*(h[3]*q[3]+h[1]*(q[1]+1./3.)+h[5]*q[5]+q[3]*h[3]+(q[1]+1./3.)*h[1]+q[5]*h[5]);
    sigma[2]=-P0*rho+2*xi*(q[2]+1./3.)*qh-xi*(h[4]*q[4]+h[5]*q[5]+h[2]*(q[2]+1./3.)+q[4]*h[4]+q[5]*h[5]+(q[2]+1./3.)*h[2]);
    sigma[3]=2*xi*q[3]*qh        	-xi*(h[0]*q[3]+h[3]*(q[1]+1./3.)+h[4]*q[5]+(q[0]+1./3.)*h[3]+q[3]*h[1]+q[4]*h[5]);
    sigma[4]=2*xi*q[4]*qh        	-xi*(h[0]*q[4]+h[3]*q[5]+h[4]*(q[2]+1./3.)+(q[0]+1./3.)*h[4]+q[3]*h[5]+q[4]*h[2]);
    sigma[5]=2*xi*q[5]*qh        	-xi*(h[3]*q[4]+h[1]*q[5]+h[5]*(q[2]+1./3.)+q[3]*h[4]+(q[1]+1./3.)*h[5]+q[5]*h[2]);
    /*Tau in Sulaiman et al., 2006*/
    tau[0]=0;
    tau[1]=0;
    tau[2]=0;
    tau[3]=q[0]*h[3]+q[3]*h[1]+q[4]*h[5]-h[0]*q[3]-h[3]*q[1]-h[4]*q[5];
    tau[4]=q[0]*h[4]+q[3]*h[5]+q[4]*h[2]-h[0]*q[4]-h[3]*q[5]-h[4]*q[2];
    tau[5]=q[3]*h[4]+q[1]*h[5]+q[5]*h[2]-h[3]*q[4]-h[1]*q[5]-h[5]*q[2];
    tau[6]=-tau[3];
    tau[7]=-tau[4];
    tau[8]=-tau[5];
return;
}


