/* functions associated with boundary conditions of LC simulation*/

void boundary_conditions_lc(lclattice *latq, wedge *latw, int i, int j, int k, double dirx, double diry, double dirz, int r) { 
latq->bc_funcphi=&do_nothing; //Emmanuel: is this to make sure that it is well defined?
latq->bc_func_c=&do_nothing;
//printf("i is %d, j is %d.\n",i,j);
    
switch (i) {
 case 1:
   if(j==2) {
    latq->bc_func=&lcwalls_nofluxxz;
    latq->bc_derv=&lcwalls_nofluxxz;
   }
   else if(j>0) {
   printf("Inconsistent boundary conditions !!! \n");
   exit(0); }
   else {
   latq->bc_func=&pbc_on_vars;
   latq->bc_derv=&pbc_on_vars;}
   if(inphase) {
     latq->bc_funcphi=&pbc_on_vars;
     latq->bc_funcmu=&pbc_on_vars;
   }
   if(iswithpoly) {
     latq->bc_func_c=&pbc_on_vars;
     latq->bc_derv_c=&pbc_on_vars;
     //printf("Fix me-- boundary conditions for C !!! \n");
   }
   break;
 case 2:
   wallflagxz=1;
   if(dirx+diry+dirz<=0.0) { 
   printf("Please specify a boundary conditions for Q !!! \n");
   exit(0); }
   if(j==0) {
   printf("Please specify a boundary conditions for Q !!! \n");
   exit(0); }
   else if(j==1) {
   lcwalls_xz_initialise(latq, dirx, diry, dirz, r);
   latq->bc_derv=&lcwalls_dervsxz;
   latq->bc_func=&lcwalls_xz; }
   else if(j==2) {
    latq->bc_func=&lcwalls_nofluxxz;
    latq->bc_derv=&lcwalls_nofluxxz;
   }
   if(inphase) {
     latq->bc_funcphi=&lcwalls_nofluxxz;
     latq->bc_funcmu=&lcwalls_nofluxxz;
   }
   if(iswithpoly) {
	if(cbouncond==2){
     latq->bc_func_c=&lcwalls_nofluxxz;
     latq->bc_derv_c=&lcwalls_nofluxxz;
   printf("BC set for C: both fund and derv lcwalls_nofluxxz.\n");}
   }
   break;
 case 3:
   if(dirx+diry+dirz<=0.0) { 
   printf("Please specify a boundary conditions for Q !!! \n");
   exit(0); }
   if(j==0) {
   printf("Please specify a boundary conditions for Q !!! \n");
   exit(0); }
   else if(j==1) {
   lcwalls_xzandyz_initialise(latq, dirx, diry, dirz,r);
   latq->bc_derv=&lcwalls_dervsxzandyz;
   latq->bc_func=&lcwalls_xzandyz; }
        if(inphase) {
            latq->bc_funcphi=&lcwalls_nofluxxzandyz;
            latq->bc_funcmu=&lcwalls_nofluxxzandyz;
        }
   if(iswithpoly) {
   printf("C BC=2: walls in xz.\n");
   }
   break;
 case 4:
   if(j==0) {
   printf("Please specify a boundary conditions for Q !!! \n");
   exit(0); }
   else if(j==4) {
   lcleeed_xz_initialise(latq, dirx, diry, dirz, r);
   latq->bc_derv=&lcleeed_xz;
   latq->bc_func=&lcleeed_xz; }
   if(inphase) {
   printf("Lee edwards for phi not implemented yet !!! \n");
   exit(0); }
   if(iswithpoly) {
   printf("Please specify a boundary conditions for C !!! \n");
   }
   break;
 case 5:
   if(iswedge) {lcwedgebcinitialise(latq, latw);}
   else if(istwowedge) {lctwowedgebcinitialise(latq, latw);}
   else if(isbox) {lcboxbcinitialise(latq, latw);}
   else if(iscir) {lccirbcinitialise(latq, latw);}
   else {return;}
   if(iswithpoly) {
   printf("Please specify a boundary conditions for C !!! \n");
   }
   break;
 case 6:
   if(j==0) {
   printf("Please specify a boundary conditions for Q !!! \n");
   exit(0); }
   else if(j==6) {
   lcleeed_xz_initialise(latq, dirx, diry, dirz, r);
   latq->bc_derv=&lcleeed_xz;
   latq->bc_func=&lcleeed_xz; }
   if(isbox) {lcboxwalls_initialise(latq, latw);}
   else if(iscir) {lccirwalls_initialise(latq, latw);}
   else {return;}
   if(inphase) {
   printf("Lee edwards for phi not implemented yet !!! \n");
   exit(0); }
   if(iswithpoly) {
   printf("Please specify a boundary conditions for C !!! \n");
   }
   break;
 case 7:
   wallflagxz=1;
   if(dirx+diry+dirz<=0.0) { 
   printf("Please specify a boundary conditions for Q !!! \n");
   exit(0); }
   if(j==0) {
   printf("Please specify a boundary conditions for Q !!! \n");
   exit(0); }
   else if(j==7) {
   lcwalls_xz_initialise(latq, dirx, diry, dirz, r);
   latq->bc_derv=&lcwalls_dervsxz;
   latq->bc_func=&lcwalls_xz; }
   if(isbox) {lcboxwalls_initialise(latq, latw);}
   else if(iscir) {lccirwalls_initialise(latq, latw);}
   else {return;}
   if(inphase) {
   printf("Walls for phi not implemented yet !!! \n");
   exit(0); }
   if(iswithpoly) {
   printf("Please specify a boundary conditions for C !!! \n");
   }
   break;
   }
return;
}

void lccirbcinitialise(lclattice *latq, wedge *latw) {
lccirwalls_initialise(latq, latw);
latq->bc_func=&lccircbc;
latq->bc_derv=&pbc_on_vars;/*Read - &lcwalls_dervsonbox;*/
return;
}

void lccircbc(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq, int t) {
if(lq!=lcq) {printf("Why?\n");exit(1);}
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexz(q,lq);/*pbc on xz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_linez(q,lq);/*pbc on z line @ four edges*/
pbc_copying_linex(q,lq);/*pbc on x line @ four edges*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
pbc_copying_point(q,lq);/*pbc on corner points*/
if(weakanch) {lcwalls_circ(latc,latw);}
return;
}

void lcwalls_circ(lclattice *latc, wedge *latw) {
int swallcnt=latw->swallcnt;
int l,lleftb,lrigtb,lleftt,lrigtt;
double xdiffb,xdifft,ydiff,qxb,qxt,qx;
for (int i=0;i<swallcnt;i++) {
  l     =latw->neighswall[i*5+0];
  lleftb=latw->neighswall[i*5+1];
  lrigtb=latw->neighswall[i*5+2];
  lleftt=latw->neighswall[i*5+3];
  lrigtt=latw->neighswall[i*5+4];
  xdiffb=latw->diffneigh[i*3+0];
  xdifft=latw->diffneigh[i*3+1];
  ydiff =latw->diffneigh[i*3+2];
  for(int m=0;m<lcq;m++) {
    qxb=latc->q[lleftb*lcq+m]*xdiffb+latc->q[lrigtb*lcq+m]*(1.0-xdiffb);
    qxt=latc->q[lleftt*lcq+m]*xdifft+latc->q[lrigtt*lcq+m]*(1.0-xdifft);
    qx=qxb*ydiff+qxt*(1.0-ydiff);
    latc->q[l*lcq+m]=qx-(qx-latw->qeonswall[i*lcq+m])*2*bWlc/Klc;
  //  printf("%d %f %f %f %f %f \n",l,qxb,qxt,qx,qwall[m],latc->q[l*lcq+m]);
  }
}
return;
}

void lcwalls_xzq(lclattice *latc, wedge *latw) {
int l0,l1,lny,lny1;
double q1,qny;
for (int i=0;i<(nx+1);i++) {
 for (int k=0;k<(nz+1);k++) {
  l0 = (i*ny2+0)*nz2+k;
  l1 = (i*ny2+1)*nz2+k;
  lny = (i*ny2+ny)*nz2+k;
  lny1 = (i*ny2+ny+1)*nz2+k;
  for(int m=0;m<lcq;m++) {
    q1=latc->q[l1*lcq+m];
    qny=latc->q[lny*lcq+m];
    //latc->q[l0*lcq+m]=q1-(q1-latw->qeonswall[i*lcq+m])*2*bWlc/Klc;
    latc->q[l0*lcq+m]=q1;
    //latc->q[lny1*lcq+m]=qny-(qny-latw->qeonswall[i*lcq+m])*2*bWlc/Klc;
    latc->q[lny1*lcq+m]=qny; //as long as the anchoring is 0 this is fine
     }
    }
  }
return;
}

void lcwalls_yzq(lclattice *latc, wedge *latw) {
    int l0,l1,lny,lny1;
    double q1,qny;
    for (int j=0;j<(ny+1);j++) {
        for (int k=0;k<(nz+1);k++) {
            l0 = (0*ny2+j)*nz2+k;
            l1 = (1*ny2+j)*nz2+k;
            lny = (nx*ny2+j)*nz2+k;
            lny1 = ((nx+1)*ny2+j)*nz2+k;
            for(int m=0;m<lcq;m++) {
                q1=latc->q[l1*lcq+m];
                qny=latc->q[lny*lcq+m];
                //latc->q[l0*lcq+m]=q1-(q1-latw->qeonswall[j*lcq+m])*2*bWlc/Klc;
                latc->q[l0*lcq+m]=q1;
                //latc->q[lny1*lcq+m]=qny-(qny-latw->qeonswall[j*lcq+m])*2*bWlc/Klc;
                latc->q[lny1*lcq+m]=qny;
            }
        }
    }
    return;
}

void lcboxbcinitialise(lclattice *latq, wedge *latw) {
lcboxwalls_initialise(latq, latw);
latq->bc_func=&pbc_on_vars;
latq->bc_derv=&pbc_on_vars;/*Read - &lcwalls_dervsonbox;*/
return;
}

void lcwedgebcinitialise(lclattice *latq, wedge *latw) {
lcwedgewalls_initialise(latq, latw);
latq->bc_derv=&lcwalls_dervsonwedge;
latq->bc_func=&lcwalls_wedge;
return;
}

void lctwowedgebcinitialise(lclattice *latq, wedge *latw) {
lctwowedgewalls_initialise(latq, latw);
latq->bc_derv=&lcwalls_dervsonwedge;
latq->bc_func=&lcwalls_wedge;
return;
}

void lcwalls_nofluxxz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
lcwalls_nofluxxz_u(q, lq);/*q copied to ensure no flux*/
return;
}

void lcwalls_nofluxxzandyz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
    pbc_copying_planexy(q,lq);/*pbc on xy plane*/
    lcwalls_nofluxxz_u(q, lq);/*q copied to ensure no flux*/
    lcwalls_nofluxyz_u(q, lq);
    return;
}

void lcwalls_xz_initialise(lclattice *lat, double dirx, double diry, double dirz, int r) {
double qe=qeq();
lcwalls_topbottom_initial(lat,dirx,diry,dirz,qe,r);
return;
}

void lcwalls_xz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
if(weakanch) {lcwalls_xzq(latc,latw);}
/*Do nothing on walls*/
return;
}

void lcwalls_dervsxz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
double c1, c2;
if(lq==lbd) { c1=2.0; c2=1.0; }
//if(lq==lbd) { c1=0.0; c2=3.0; }
else if(lq==lbd*lbd) {c1=2.0; c2=1.0;}
else { printf("How come?\n"); exit(0);}
lcwalls_dervstopbottom(q, lq, c1, c2);
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
return;
}

void lcwalls_xzandyz_initialise(lclattice *lat, double dirx, double diry, double dirz,int r) {
double qe=qeq();
lcwalls_leftright_initial(lat,dirx,diry,dirz,qe);
lcwalls_topbottom_initial(lat,dirx,diry,dirz,qe,r);
return;
}

void lcwalls_xzandyz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
if(weakanch) {lcwalls_xzq(latc,latw);
    lcwalls_yzq(latc,latw);
}

/*Do nothing on walls*/
return;
}

void lcwalls_dervsxzandyz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq) {
double c1, c2;
if(lq==lbd) { c1=0.0; c2=3.0; }
else if(lq==lbd*lbd) {c1=2.0; c2=1.0;}
else { printf("How come?\n"); exit(0);}
lcwalls_dervsleftright(q, lq, c1, c2);
lcwalls_dervstopbottom(q, lq, c1, c2);
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
return;
}

void lcwalls_dervsleftright(double *u, int lq, double c1, double c2) {
int l0,l1,l2;
for(int j=1;j<=ny;j++) {
  for(int k=1;k<=nz;k++) {
    l0=((0*ny2+j)*nz2+k)*lq; l1=((1*ny2+j)*nz2+k)*lq; l2=((2*ny2+j)*nz2+k)*lq;
    swapusforbc(u,l0 ,l1 ,l2 ,lq,c1,c2);
    l0=(((nx+1)*ny2+j)*nz2+k)*lq; l1=(((nx)*ny2+j)*nz2+k)*lq; l2=(((nx-1)*ny2+j)*nz2+k)*lq;
    swapusforbc(u,l0 ,l1 ,l2 ,lq,c1,c2);
    }; };
return;
}

void lcwalls_dervstopbottom(double *u, int lq, double c1, double c2) {
int l0,l1,l2;
for(int i=1;i<=nx;i++) {
  for(int k=1;k<=nz;k++) {
    l0=((i*ny2+0)*nz2+k)*lq; l1=((i*ny2+1)*nz2+k)*lq; l2=((i*ny2+2)*nz2+k)*lq;
    swapusforbc(u,l0 ,l1 ,l2 ,lq,c1,c2);
    l0=((i*ny2+(ny+1))*nz2+k)*lq; l1=((i*ny2+(ny))*nz2+k)*lq; l2=((i*ny2+(ny-1))*nz2+k)*lq;
    swapusforbc(u,l0 ,l1 ,l2 ,lq,c1,c2);
    }; };
return;
}

void lcwalls_dervsfrontback(double *u, int lq, double c1, double c2) {
int l0,l1,l2;
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    l0=((i*ny2+j)*nz2+0)*lq; l1=((i*ny2+j)*nz2+1)*lq; l2=((i*ny2+j)*nz2+2)*lq;
    swapusforbc(u,l0 ,l1 ,l2 ,lq,c1,c2);
    l0=((i*ny2+j)*nz2+(nz+1))*lq; l1=((i*ny2+j)*nz2+(nz))*lq; l2=((i*ny2+j)*nz2+(nz-1))*lq;
    swapusforbc(u,l0 ,l1 ,l2 ,lq,c1,c2);
    }; };
return;
}

void swapusforbc(double *u, int l0, int l1, int l2, int lq, double c1, double c2) {
for(int m=0;m<lq;m++) {
u[l0+m] =c1*u[l1+m]-u[l2+m]/c2; };
return;
}

void lcwalls_nofluxxz_u(double *u, int lq) {
for(int i=0;i<=nx+1;i++) {
  for(int k=0;k<=nz+1;k++) {
    for(int m=0; m<lq; m++) {
     u[((i*ny2+0)*nz2+k)*lq+m]=u[((i*ny2+1)*nz2+k)*lq+m];
     u[((i*ny2+(ny+1))*nz2+k)*lq+m]=u[((i*ny2+(ny))*nz2+k)*lq+m];
    }; }; };
return;
}

void lcwalls_nofluxyz_u(double *u, int lq) {
    for(int j=0;j<=ny+1;j++) {
        for(int k=0;k<=nz+1;k++) {
            for(int m=0; m<lq; m++) {
                u[((0+j)*nz2+k)*lq+m]=u[((1*ny2+j)*nz2+k)*lq+m];
                u[(((nx+1)*ny2+j)*nz2+k)*lq+m]=u[((nx*ny2+j)*nz2+k)*lq+m];
            }; }; };
    return;
}

void lcwalls_leftright_initial(lclattice *lat, double dirx, double diry, double dirz, double qe) {
for(int j=0;j<ny2;j++) {
  for(int k=0;k<nz2;k++) {
    qassign(&lat->q[((0*ny2+j)*nz2+k)*lcq], qe, dirx, diry, dirz);
    qassign(&lat->q[(((nx+1)*ny2+j)*nz2+k)*lcq], qe, dirx, diry, dirz);
    qassign(&lat->qnew[((0*ny2+j)*nz2+k)*lcq], qe, dirx, diry, dirz);
    qassign(&lat->qnew[(((nx+1)*ny2+j)*nz2+k)*lcq], qe, dirx, diry, dirz);
    }; };
return;
}

void lcwalls_topbottom_initial(lclattice *lat, double dirx, double diry, double dirz, double qe,int r) {
r=-2*r+1;/*r=0 gives 1 and r=1 gives -1*/
for(int i=0;i<nx2;i++) {
  for(int k=0;k<nz2;k++) {
	printf("--------r value is %d.\n",r);
    qassign(&lat->q[((i*ny2+0)*nz2+k)*lcq], qe, dirx, r*diry, dirz);
    qassign(&lat->q[((i*ny2+(ny+1))*nz2+k)*lcq], qe, dirx, diry, dirz);
    qassign(&lat->qnew[((i*ny2+0)*nz2+k)*lcq], qe, dirx, r*diry, dirz);
    qassign(&lat->qnew[((i*ny2+(ny+1))*nz2+k)*lcq], qe, dirx, diry, dirz);
    }; };
return;
}

void lcwalls_frontback_initial(lclattice *lat, double dirx, double diry, double dirz, double qe) {
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    qassign(&lat->q[((i*ny2+j)*nz2+0)*lcq], qe, dirx, diry, dirz);
    qassign(&lat->q[((i*ny2+j)*nz2+(nz+1))*lcq], qe, dirx, diry, dirz);
    qassign(&lat->qnew[((i*ny2+j)*nz2+0)*lcq], qe, dirx, diry, dirz);
    qassign(&lat->qnew[((i*ny2+j)*nz2+(nz+1))*lcq], qe, dirx, diry, dirz);
    }; };
return;
}

void qassign(double *q, double qe, double dirx, double diry, double dirz) {
double dsum=dirx*dirx+diry*diry+dirz*dirz;
dirx=dirx/dsum;
diry=diry/dsum;
dirz=dirz/dsum;
q[0]= 0.5*qe*(3.*dirx*dirx-1.0);
q[1]= 0.5*qe*(3.*diry*diry-1.0);
q[2]= 0.5*qe*(3.*dirz*dirz-1.0);
q[3]= 0.5*qe*(3.*dirx*diry-0.0);
q[4]= 0.5*qe*(3.*dirx*dirz-0.0);
q[5]= 0.5*qe*(3.*diry*dirz-0.0);
return;
}

void lcwedgewalls_initialise(lclattice *latq, wedge *latw) {
int l;
double phi=(90.0-thetawedge/2.0)/180.0*3.14159265359;
double theta=90.0/180.0*3.14159265359;
double stheta=sin(theta);
double ctheta=cos(theta);
stheta=1.0;
ctheta=0.0;
double unity=1.0,zero=0.0;
if(homogentr==1) {
  phi=phi+3.14159265359/2.0;
  zero=1.0;unity=0.0;}
double dirx=stheta*cos(phi);
double diry=stheta*sin(phi);
double dirz=ctheta;
double qe=qeq();
double xc=nx/2+0.5;
for(int i=1;i<=nx;i++) {
  for(int j=0;j<ny2;j++) { //To include the wedge bottom and top wall
    for(int k=1;k<=nz;k++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]==swall) {
        //printf("%d %d %d %d %d\n",i,j,k,l,latw->w[l]);
        if(j==0) {
          qassign(&latq->q[l*lcq], qe, zero, unity, dirz);
          qassign(&latq->qnew[l*lcq], qe, zero, unity, dirz);}
        else if(j>=hwwedge) {
          qassign(&latq->q[l*lcq], qe, unity, zero, dirz);
          qassign(&latq->qnew[l*lcq], qe, unity, zero, dirz);}
        else {
          if(i<xc) {
            qassign(&latq->q[l*lcq], qe,-dirx, diry, dirz);
            qassign(&latq->qnew[l*lcq], qe,-dirx, diry, dirz);}
          else {
            qassign(&latq->q[l*lcq], qe, dirx, diry, dirz); 
            qassign(&latq->qnew[l*lcq], qe, dirx, diry, dirz);} }
}; }; }; };
return;
}

void lctwowedgewalls_initialise(lclattice *latq, wedge *latw) {
int l;
double phi=(90.0-thetawedge/2.0)/180.0*3.14159265359;
double theta=90.0/180.0*3.14159265359;
double stheta=sin(theta);
double ctheta=cos(theta);
stheta=1.0;
ctheta=0.0;
double unity=1.0,zero=0.0;
if(homogentr==1) {
  phi=phi+3.14159265359/2.0;
  zero=1.0;unity=0.0;}
double dirx=stheta*cos(phi);
double diry=stheta*sin(phi);
double dirz=ctheta;
double qe=qeq();
double xc=nx/2+0.5;
double yc=ny/2+0.5;
for(int i=1;i<=nx;i++) {
  for(int j=0;j<ny2;j++) { //To include the wedge bottom and top wall
    for(int k=1;k<=nz;k++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]==swall) {
        //printf("%d %d %d %d %d\n",i,j,k,l,latw->w[l]);
        if((j==0)||(j>ny)) {
          qassign(&latq->q[l*lcq], qe, zero, unity, dirz);
          qassign(&latq->qnew[l*lcq], qe, zero, unity, dirz);}
        else {
          if(((i<xc)&&(j<yc))||((i>xc)&&(j>yc))) {
            qassign(&latq->q[l*lcq], qe,-dirx, diry, dirz);
            qassign(&latq->qnew[l*lcq], qe,-dirx, diry, dirz);}
          else {
            qassign(&latq->q[l*lcq], qe, dirx, diry, dirz); 
            qassign(&latq->qnew[l*lcq], qe, dirx, diry, dirz);} }
}; }; }; };
return;
}

void lcwalls_dervsonwedge(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq, int t) {
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
/*Nothing else done here as this should be taken careof inside the program*/
return;
}

void lcwalls_wedge(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq, int t) {
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
/*Do nothing on walls*/
return;
}

void lccirwalls_initialise(lclattice *latq, wedge *latw) {
int l;
double phi;
double theta=90.0/180.0*3.14159265359;
double stheta=sin(theta); 
double ctheta=cos(theta); 
double dirx;//stheta*cos(phi);
double diry;//=stheta*sin(phi);
double dirz;//=ctheta;
stheta=1.0; ctheta=0.0;
dirz=0.0;
double qe=qeq();
double xl,yl;
if(weakanch) {
lcwalls_circ(latq,latw);
}
else{
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]==swall) {
        xl = i - latw->partloc[(latw->partmark[l]-1)*lcd+0];
	yl = j - latw->partloc[(latw->partmark[l]-1)*lcd+1];
//        printf("%d %d %f %f\n",i,j,latw->partloc[(latw->partmark[l]-1)*numofpart+0],latw->partloc[(latw->partmark[l]-1)*numofpart+1]);
        phi=atan(yl/xl);
	if(!homogentr) {phi=phi+3.14159265359/2.0;}
	dirx=stheta*cos(phi);
	diry=stheta*sin(phi);
	dirz=ctheta;
        qassign(&latq->q[l*lcq], qe, dirx, diry, dirz);
        qassign(&latq->qnew[l*lcq], qe, dirx, diry, dirz);
}; }; }; };
};
return;
}


void lcboxwalls_initialise(lclattice *latq, wedge *latw) {
int l;
//double phi=(90.0-thetawedge/2.0)/180.0*3.14159265359; double theta=90.0/180.0*3.14159265359;
//double stheta=sin(theta); double ctheta=cos(theta); stheta=1.0; ctheta=0.0;
//double dirx;=stheta*cos(phi);double diry;=stheta*sin(phi);double dirz;=ctheta;
double dirz=0.0;
double qe=qeq();
int xl=(nx/2.+0.5-boxdim1/2.+1);
int xh=(nx/2.+0.5+boxdim1/2.);
int yl=(ny/2.+0.5-boxdim1/2.+1);
int yh=(ny/2.+0.5+boxdim1/2.);
double unity=1.0,zero=0.0,root2=1.0/sqrt(2.0), yroot=root2;
if(!homogentr) {zero=1.0; unity = 0.0; yroot = -yroot;}
for(int i=1;i<=nx;i++) {
  for(int j=1;j<=ny;j++) {
    for(int k=1;k<=nz;k++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]==swall) {
        if(((i==xl)&&(j==yl))||((i==xh)&&(j==yh))) {
          qassign(&latq->q[l*lcq], qe, root2, yroot, dirz);
          qassign(&latq->qnew[l*lcq], qe, root2, yroot, dirz);}
        else if(((i==xh)&&(j==yl))||((i==xl)&&(j==yh))) {
          qassign(&latq->q[l*lcq], qe, root2, -yroot, dirz);
          qassign(&latq->qnew[l*lcq], qe, root2, -yroot, dirz);}
        else if((i==xl)||(i==xh)) {
          qassign(&latq->q[l*lcq], qe, unity, zero, dirz);
          qassign(&latq->qnew[l*lcq], qe, unity, zero, dirz);}
        else if((j==yl)||(j==yh)) {
          qassign(&latq->q[l*lcq], qe, zero, unity, dirz);
          qassign(&latq->qnew[l*lcq], qe, zero, unity, dirz);}
}; }; }; };
return;
}

void lcwalls_dervsonbox(lblattice *latv, lclattice *latq, double *q, int lq) {
//pbc_on_vars();/*for the domain boundaries which is directly assigned*/
/*Nothing else done here as walls inside should be taken careof inside the program*/
return;
}

void lcleeed_xz_initialise(lclattice *lat, double dirx, double diry, double dirz, int r) {
/*Nothing to do*/
return;
}

void lcleeed_xz(lblattice *latv, lclattice *latc, wedge *latw, double *q, int lq, int t) {
double leU[lq];
for(int m=0;m<lq;m++) leU[m]=0.0;
if(lq==3) {/*Assuming that only variable which comes here with dimensionality 3 is velocity. Since velocity needs addition of U the size is considered as a criteria. If a new variable comes up with dimenisonality 3, then code should be modified to distinguish velocity*/
  leU[0]=(oscillatory==1)?shearrate*ny*(noflow==0)*sin(frequency*t):shearrate*ny*(noflow==0);
  //printf("%f %f %d \n",leU[0],sin(frequency*t),t);
}
lcleeed_topbottom(q,lq,t,leU);/*le on xz plane*/
pbc_copying_planeyz(q,lq);/*pbc on yz plane*/
pbc_copying_planexy(q,lq);/*pbc on xy plane*/
pbc_copying_liney(q,lq);/*pbc on y line @ four edges*/
reflnabouty_copying_linez(q,lq);/*reflection copy of z line @ four edges*/
reflnabouty_copying_linex(q,lq);/*reflection copy of x line @ four edges*/
/*Do nothing on walls*/
return;
}

void lcleeed_topbottom(double *q, int lq, int t,double *leU) {
lcleeed_calculate(q,lq,leU);
lcleeed_interpolate(q,lq,t);
return;
}

void lcleeed_calculate(double *q, int lq, double *leU) {
for(int i=1;i<=nx;i++) {
  for(int k=1;k<=nz;k++) {
    for(int m=0;m<lq;m++) {
     q[((i*ny2+0)*nz2+k)*lq+m] = -leU[m];/*bottom elements to zero so that it can be used later during interpolation*/
     q[((i*ny2+ny+1)*nz2+k)*lq+m] = leU[m];/*so that it can be used later during interpolation*/
    }
  }
}
return;
}

void lcleeed_interpolate(double *q, int lq, int t) {
int ll,lr,lp,il,ir;
double distx;
distx=(oscillatory==1)?shearrate*ny*(1.0-cos(frequency*t))/frequency:t*shearrate*ny;
//printf("%f %d %d\n",distx,t,lq);
int idistx=(int) distx;
double rdistx=distx-idistx;
idistx=idistx%nx;
for(int i=1;i<=nx;i++) {
  for(int k=1;k<=nz;k++) {
    lp=(i*ny2+1)*nz2+k;/*taking from j=1*/
    il=(i+idistx)%nx;
    il=il==0?nx:il;
    ir=(i+idistx+1)%nx;
    ir=ir==0?nx:ir;
    ll=(il*ny2+ny+1)*nz2+k;/*giving at j=ny+1*/
    lr=(ir*ny2+ny+1)*nz2+k;/*giving at j=ny+1*/
    for(int m=0;m<lq;m++) {
      q[ll*lq+m]+=(1.0-rdistx)*q[lp*lq+m];
      q[lr*lq+m]+=rdistx*q[lp*lq+m];
    }
    lp=(i*ny2+ny)*nz2+k;/*taking from j=ny*/
    il=(i+nx-idistx)%nx;/*Moving nx distance to avoid -ve values*/
    il=il==0?nx:il;
    ir=(i+nx-1-idistx)%nx;
    ir=ir==0?nx:ir;
    ll=(il*ny2+0)*nz2+k;/*giving at j=0*/
    lr=(ir*ny2+0)*nz2+k;/*giving at j=0*/
    for(int m=0;m<lq;m++) {
      q[ll*lq+m]+=(1.0-rdistx)*q[lp*lq+m];
      q[lr*lq+m]+=rdistx*q[lp*lq+m];
   }
 }
}
return;
}
