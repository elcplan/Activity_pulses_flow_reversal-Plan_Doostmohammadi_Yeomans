/*This calculates the perimeter of a flat strip with no detached surface, pbc*/
double perimeter_flat(lclattice *latc,int tm){
//Declarations of variables
double *phi=&latc->phi[0];
int kptsample=1;

//TOP PART
//Look for starting point (will be written for a flat region
//for which a point on each x exists inside the region. We pick the highest one.
int i_curr, j_curr;
int itemp=1, jtemp=100;
int lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
double phicrit_peri=0.9;
while (phi[lpt_temp]<phicrit_peri) {
jtemp=jtemp-1; lpt_temp= (itemp*ny2+jtemp)*nz2+kptsample;
}//end while
i_curr=itemp;j_curr=jtemp;

//Loop to get the perimeter
int xdir[8] = {0,1,1,1,0,-1,-1,-1}; //directions
int ydir[8] = {1,1,0,-1,-1,-1,0,1};
double perimeter=0.0, peri_tot=0.0;
int i_cand, j_cand, lpt_cand;
int dir_curr, checkdir, dir;
dir_curr=2;
int endloop=0;

while(endloop==0){ //perimeter condition to avoid infinite loops
//candidates as next points are chosen starting from the north-west direction of the point
//relative to the current direction, and checked in a clockwise manner.
checkdir=1;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;

if(phi[lpt_cand]>phicrit_peri){//checkdir=1
	//printf("checkdir=\n",);
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+6)%8;
} else {//else-1
checkdir=2;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=2
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;	//dir_curr=dir_curr; //dir_curr the same
} else {//else-2
checkdir=3;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=3
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);  //dir_curr=dir_curr; //dir_curr the same
} else {//else-3
checkdir=4;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=4
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;
	dir_curr=(dir_curr+2)%8;
} else {//else-4
checkdir=5;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=5
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+2)%8;
} else {//else-5
checkdir=6;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=6
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;
	dir_curr=(dir_curr+4)%8;
} else {//else-6
checkdir=7;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=7
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+4)%8;
	printf("Warning: singular point may evolve.\n");
} //end if
}}}}}} //end else 1,2,3,4,5,6
//printf("Cand: phi[%d,%d]=%f at dir:%d\n",i_cand,j_cand,phi[lpt_cand],dir_curr);

if (i_curr>nx){i_curr=i_curr%nx;}
if (j_curr>ny){j_curr=j_curr%ny;}
if ((i_curr==itemp)&&(j_curr==jtemp)) {endloop=1;}// printf("The total perimeter (above) is %f.\n",perimeter);}
if (perimeter>nx*4){endloop=1; printf("Warning, perimeter limit1!-Emman");}
}//end while
peri_tot+=perimeter;


//LOWER PART
itemp=100, jtemp=1;
lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
while (phi[lpt_temp]<phicrit_peri) {
jtemp=jtemp+1; lpt_temp= (itemp*ny2+jtemp)*nz2+kptsample;
}//end while
i_curr=itemp;j_curr=jtemp;
endloop=0;dir_curr=6;perimeter=0;

while(endloop==0){
checkdir=1;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;

if(phi[lpt_cand]>phicrit_peri){//checkdir=1
	//printf("checkdir=\n",);
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+6)%8;
} else {//else-1
checkdir=2;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=2
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;	//dir_curr=dir_curr; //dir_curr the same
} else {//else-2
checkdir=3;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=3
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);  //dir_curr=dir_curr; //dir_curr the same
} else {//else-3
checkdir=4;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=4
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;
	dir_curr=(dir_curr+2)%8;
} else {//else-4
checkdir=5;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=5
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+2)%8;
} else {//else-5
checkdir=6;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=6
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;
	dir_curr=(dir_curr+4)%8;
} else {//else-6
checkdir=7;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=7
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+4)%8;
	printf("Warning: singular point may evolve.\n");
} //end if
}}}}}} //end else 1,2,3,4,5,6

if (i_curr<1){i_curr=i_curr+nx;}
if (j_curr<1){j_curr=j_curr+ny;}
if ((i_curr==itemp)&&(j_curr==jtemp)) {endloop=1;}
if (perimeter>nx*4){endloop=1; printf("Warning, perimeter limit2!-Emman");}
}//end while

peri_tot+=perimeter;
return peri_tot;
}

///////////////////////////////////////////////////////////////////////////////////////
/*This calculates the perimeter of a single drop, pbc*/
double perimeter_drop(lclattice *latc,int tm){
//Declarations of variables
double *phi=&latc->phi[0];
int kptsample=1;

FILE *crescent_ptr;
char nname[500];
sprintf(nname,"%s/output/crescent.dat",DPATH);
crescent_ptr=fopen(nname,"a");
int lx,ly,tx,ty,rx,ry,bx,by;

//Look for starting point (highest left-most point)
int i_curr, j_curr;
int itemp=1, jtemp=ny;
int lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
double phicrit_peri=0.2;

if (phi[lpt_temp]>phicrit_peri) {printf("Pick another point to start."); system("pause");}
while (phi[lpt_temp]<phicrit_peri) {
jtemp=jtemp-1;
if (jtemp==0) {jtemp=100; itemp+=1;}
lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
}//end while
i_curr=itemp;j_curr=jtemp;
//printf("Here %d,%d.\n",itemp,jtemp);

//Loop to get the perimeter
int xdir[8] = {0,1,1,1,0,-1,-1,-1}; //directions
int ydir[8] = {1,1,0,-1,-1,-1,0,1};
double perimeter=0.0, peri_tot=0.0;
int i_cand, j_cand, lpt_cand;
int dir_curr, checkdir, dir;
if(itemp==1) {dir_curr=2;} else {dir_curr=0;}
int endloop=0;

while(endloop==0){ //perimeter condition to avoid infinite loops
//candidates as next points are chosen starting from the north-west direction of the point
//relative to the current direction, and checked in a clockwise manner.
checkdir=1;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;

if(phi[lpt_cand]>phicrit_peri){//checkdir=1
	//printf("checkdir=\n",);
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+6)%8;
} else {//else-1
checkdir=2;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=2
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;	//dir_curr=dir_curr; //dir_curr the same
} else {//else-2
checkdir=3;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=3
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);  //dir_curr=dir_curr; //dir_curr the same
} else {//else-3
checkdir=4;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=4
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;
	dir_curr=(dir_curr+2)%8;
} else {//else-4
checkdir=5;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=5
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+2)%8;
} else {//else-5
checkdir=6;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=6
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=1;
	dir_curr=(dir_curr+4)%8;
} else {//else-6
checkdir=7;
dir=(dir_curr+checkdir+6)%8;
i_cand=i_curr+xdir[dir];j_cand=j_curr+ydir[dir];
lpt_cand=(i_cand*ny2+j_cand)*nz2+kptsample;
if(phi[lpt_cand]>phicrit_peri){//checkdir=7
	i_curr=i_cand;	j_curr=j_cand;
	perimeter+=sqrt(2);
	dir_curr=(dir_curr+4)%8;
	printf("Warning: singular point may evolve.\n");
} //end if
}}}}}} //end else 1,2,3,4,5,6
//printf("Cand: phi[%d,%d]=%f at dir:%d\n",i_cand,j_cand,phi[lpt_cand],dir_curr);

if (i_curr>nx){i_curr=i_curr%nx;}
if (j_curr>ny){j_curr=j_curr%ny;}
if ((i_curr==itemp)&&(j_curr==jtemp)) {endloop=1;}// printf("The total perimeter (above) is %f.\n",perimeter);}
if (perimeter>nx*4){endloop=1; printf("Warning, perimeter limit!-Emman");}
}//end while
peri_tot+=perimeter;

//Getting extreme points
//lx,ly
lx=itemp;ly=jtemp;

//rx,ry (top, right-most point)
itemp=nx, jtemp=ny;
lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
if (phi[lpt_temp]>phicrit_peri) {printf("Pick another point to start."); system("pause");}
while (phi[lpt_temp]<phicrit_peri) {
jtemp=jtemp-1;
if (jtemp==0) {jtemp=100; itemp-=1;}
lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
}//end while
rx=itemp;ry=jtemp;

//tx,ty (right, top-most point)
itemp=1, jtemp=ny;
lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
if (phi[lpt_temp]>phicrit_peri) {printf("Pick another point to start."); system("pause");}
while (phi[lpt_temp]<phicrit_peri) {
itemp=itemp+1;
if (itemp==nx) {itemp=1; jtemp-=1;}
lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
}//end while
tx=itemp;ty=jtemp;

//bx,by (right, bottom-most point)
itemp=1, jtemp=1;
lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
if (phi[lpt_temp]>phicrit_peri) {printf("Pick another point to start."); system("pause");}
while (phi[lpt_temp]<phicrit_peri) {
itemp=itemp+1;
if (itemp==nx) {itemp=1; jtemp+=1;}
lpt_temp=(itemp*ny2+jtemp)*nz2+kptsample;
}//end while
bx=itemp;by=jtemp;

fprintf(crescent_ptr,"%d %d %d %d %d %d %d %d %d %f\n",tm,lx,ly,rx,ry,tx,ty,bx,by,perimeter);
fclose(crescent_ptr);

return peri_tot;
}
