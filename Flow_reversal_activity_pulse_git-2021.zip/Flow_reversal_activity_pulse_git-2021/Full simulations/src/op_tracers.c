tracedyn *tracermemallocate() {
tracedyn *tracc=(tracedyn *)malloc(sizeof(tracedyn));/*variable associated with all tracer tracking calculations*/
if(tracers) {
tracc->locsini = (double *)malloc(ntracers*lbd*sizeof(double));/*at t=0*/
tracc->locs = (double *)malloc(ntracers*lbd*sizeof(double));/*at any time t*/
tracc->locsanyt = (double *)malloc(ntracers*lbd*sizeof(double));/*at any time t*/
tracc->displm = (double *)malloc(ntracers*sizeof(double));/*at any time t*/
}
return tracc;
}

void tracertrackon(lblattice *latv, tracedyn *tracc, int tm) {
if(tm>=tminfortracers) {
  tracertrackactual(latv,tracc,tm);
  if((tm+1)%writtracers==0) {
    writetracers(tracc, tm+1); }
}
return;
}

void tracertrackoff(lblattice *latv, tracedyn *tracc, int tm) {
/*Do nothing*/
return;
}

void tracerlocinitialise(tracedyn *tracc) {
int nrow=sqrt(ntracers);
int nxtr=nx/nrow;
int nytr=ny/nrow;
for(int i=0;i<nrow;i++) {
  for(int j=0;j<nrow;j++) {
   tracc->locsini[(i*nrow+j)*lbd+0]=nxtr/2.+i*nxtr;
   tracc->locsini[(i*nrow+j)*lbd+1]=nytr/2.+j*nytr;
   tracc->locsini[(i*nrow+j)*lbd+2]=1.0;
   //printf("%d %d %f %f %f\n",i,j,tracc->locsini[(i*nrow+j)*lbd+0],tracc->locsini[(i*nrow+j)*lbd+1],tracc->locsini[(i*nrow+j)*lbd+2]);
} }
for(int l=0;l<ntracers;l++) {
  tracc->displm[l]=0;
  tracc->locs[l*lbd]=tracc->locsini[l*lbd];
  tracc->locs[l*lbd+1]=tracc->locsini[l*lbd+1];
  tracc->locs[l*lbd+2]=tracc->locsini[l*lbd+2];
  tracc->locsanyt[l*lbd]=tracc->locsini[l*lbd];
  tracc->locsanyt[l*lbd+1]=tracc->locsini[l*lbd+1];
  tracc->locsanyt[l*lbd+2]=tracc->locsini[l*lbd+2];
  }
writetracers(tracc, tini);
return;
}

void tracertrackactual(lblattice *latv, tracedyn *tracc, int tm) {
int llt,llb,lrt,lrb;
int i,j,k,ip,jp;
double xd,yd,Ui,c0,c1;
double *locs=&tracc->locs[0];
double *locsini=&tracc->locsini[0];
double *locsanyt=&tracc->locsanyt[0];
double Dt=latv->Dt;
for(int l=0;l<ntracers;l++) {
  i=locs[l*lbd+0];
  j=locs[l*lbd+1];
  k=locs[l*lbd+2];
  ip=i+1;
  jp=j+1;
  if(ip==nx+1) ip=1;
  if(jp==ny+1) jp=1;
  llt = ((i*ny2+j)*nz2+k)*lbd;
  llb = ((i*ny2+jp)*nz2+k)*lbd;
  lrt = ((ip*ny2+j)*nz2+k)*lbd;
  lrb = ((ip*ny2+jp)*nz2+k)*lbd;
  xd=locs[l*lbd]-i;
  yd=locs[l*lbd+1]-j;
  c0=latv->u[llt]*(1-xd)+latv->u[lrt]*(xd);
  c1=latv->u[llb]*(1-xd)+latv->u[lrb]*(xd);
  Ui=c0*(1-yd)+c1*yd;
  locs[l*lbd+0]+=Ui*Dt;
  locsanyt[l*lbd+0]+=Ui*Dt;
  if(locs[l*lbd]<0) locs[l*lbd]=nx+locs[l*lbd];
  else if(locs[l*lbd]>nx+1) locs[l*lbd]=locs[l*lbd]-nx;
  c0=latv->u[llt+1]*(1-xd)+latv->u[lrt+1]*(xd);
  c1=latv->u[llb+1]*(1-xd)+latv->u[lrb+1]*(xd);
  Ui=c0*(1-yd)+c1*yd;
  locs[l*lbd+1]+=Ui*Dt;
  locsanyt[l*lbd+1]+=Ui*Dt;
  if(locs[l*lbd+1]<0) locs[l*lbd+1]=nx+locs[l*lbd+1];
  else if(locs[l*lbd+1]>ny+1) locs[l*lbd+1]=locs[l*lbd+1]-ny;
  tracc->displm[l]=sqrt(((locsanyt[l*lbd+0]-locsini[l*lbd+0])*(locsanyt[l*lbd+0]-locsini[l*lbd+0]))+
                  			((locsanyt[l*lbd+1]-locsini[l*lbd+1])*(locsanyt[l*lbd+1]-locsini[l*lbd+1]))+
                  			((locsanyt[l*lbd+2]-locsini[l*lbd+2])*(locsanyt[l*lbd+2]-locsini[l*lbd+2])));
//  printf("%d %f %f %f %f %d\n",l,locs[l*lbd],locs[l*lbd+1],locs[l*lbd+2],tracc->displm[l],tm);
}
return;
}

void writetracers(tracedyn *tracc, int tm) {
FILE *vptr,*mptr;
char nname[500];
sprintf(nname,"%s/output/tracersloc.dat",DPATH);
if(tm==tini) {
vptr=fopen(nname,"w");}
else {vptr=fopen(nname,"a+");}
sprintf(nname,"%s/output/tracersmsd.dat",DPATH);
if(tm==tini) {
mptr=fopen(nname,"w");}
else {mptr=fopen(nname,"a+");}
double sum=0;
fprintf(vptr,"%d ",tm);
for(int l=0;l<ntracers;l++) {
  fprintf(vptr,"%f %f ",tracc->locsanyt[l*lbd],tracc->locsanyt[l*lbd+1]);
  sum+=tracc->displm[l];
}
  fprintf(vptr,"\n");
  fprintf(mptr,"%d %f \n",tm-tminfortracers, sum/ntracers);
fclose(vptr);
fclose(mptr);
return;
}
