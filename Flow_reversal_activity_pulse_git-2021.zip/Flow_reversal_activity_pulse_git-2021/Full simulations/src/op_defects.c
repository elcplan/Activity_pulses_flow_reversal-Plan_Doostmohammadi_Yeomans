/*Allocating spaces if defects to be tracked*/
deflattice *defsetting(lclattice *latc) {
deflattice *lat=(deflattice *)malloc(sizeof(deflattice));/*variable associated with all lattice parameters*/
lat->mcharge=latc->mcharge;
int nreq,ntreq;
if(indtrack) {nreq=1;ntreq=indtimetrackmax;}
if(trackdef) {nreq=ndefsmax;ntreq=timetrackmax;} 
if(trackdef||(indtrack)) {/*allocate only if required*/
lat->defexist = (int *)malloc(nx2*ny2*nz2*sizeof(int));/*Exisitence of a defect at a node*/
lat->defect_tag = (int *)malloc(nreq*sizeof(int));/*1-Tag*/
lat->defect_chg = (double *)malloc(nreq*sizeof(double));/*2-charge*/
lat->defect_xlc = (double *)malloc(nreq*sizeof(double));/*3-xloc*/
lat->defect_ylc = (double *)malloc(nreq*sizeof(double));/*4-yloc*/
lat->defect_liv = (int *)malloc(nreq*sizeof(int));/*7-live or dead*/
lat->defect_lif = (int *)malloc(nreq*sizeof(int));/*8-life time*/
lat->defect_nop = (int *)malloc(nreq*sizeof(int));/*9-no of points*/
lat->defect_dis = (double *)malloc(nreq*sizeof(double));/*10-distance travelled*/
lat->defect_xbirth = (double *)malloc(nreq*sizeof(double));/*birth-xloc*/
lat->defect_ybirth = (double *)malloc(nreq*sizeof(double));/*birth-yloc*/
lat->defect_xanyt = (double *)malloc(nreq*sizeof(double));/*anytime-xloc*/
lat->defect_yanyt = (double *)malloc(nreq*sizeof(double));/*anytime-yloc*/
lat->dalpha = (int *)malloc(ntreq*sizeof(int));/*No of defects created*/
lat->dbeta = (int *)malloc(ntreq*sizeof(int));/*No of defects destroyed*/
lat->nrmsp = (int *)malloc(ntreq*sizeof(int));/*Number of by +ve defects analyzed*/
lat->nrmsn = (int *)malloc(ntreq*sizeof(int));/*Number of by -ve defects analyzed*/
lat->drmsp = (double *)malloc(timetrackmax*sizeof(double));/*Distance travelled by +ve defects*/
lat->drmsn = (double *)malloc(timetrackmax*sizeof(double));/*Distance travelled by -ve defects*/
lat->deftm = (int *)malloc(timetrackmax*sizeof(int));/*Tracking time of defects*/
lat->dcharge=(int *)malloc(nx2*ny2*nz2*sizeof(int));/*Defects stored as +/- 5 for comparison purposes*/;
for(int l=0;l<nx2*ny2*nz2;l++) {lat->defexist[l]=0;} /*Filling up with zeros*/
lat->nrmsp[0]=0; lat->nrmsn[0]=0; lat->drmsp[0]=0; lat->drmsn[0]=0; lat->deftm[0]=0;
lat->dalpha[0]=0;
lat->dbeta[0]=0;
FILE *vptr;
char nname[500];
sprintf(nname,"%s/output/defcreation.dat",DPATH); vptr=fopen(nname,"w");
fclose(vptr);
}
lat->ndefects=0;/*Number of defects actually tracked*/
return lat;
}

/*Details of tracking defects*/
void trackdefects(deflattice *lat, int tm) {
for(int l=0;l<nx2*ny2*nz2;l++) {lat->defexist[l]=0;} /*Filling up with zeros afresh*/
int l=tm-tini;
if(l>timetrackmax) return; 
lat->nrmsp[l]=0;
lat->nrmsn[l]=0;
lat->drmsp[l]=0;
lat->drmsn[l]=0;
lat->deftm[l]=l;
lat->dbeta[l]=deftagfollow(lat);
if(lat->ndefects>=ndefsmax) return; 
lat->dalpha[l]=deftagging(lat,tm);
return;
}

/*Details of tracking of individual defects*/
void indtrackdefects(deflattice *lat, int tm) {
if(tm==deft) {
  lat->ndefects=inddeftagging(lat,tm);}
else if(tm>deft) {
  for(int l=0;l<nx2*ny2*nz2;l++) {lat->defexist[l]=0;} /*Filling up with zeros afresh*/
  int l=tm-deft;
  lat->nrmsp[l]=0;
  lat->nrmsn[l]=0;
  lat->drmsp[l]=0;
  lat->drmsn[l]=0;
  lat->deftm[l]=l;
  lat->dbeta[0]=deftagfollow(lat);
  }
return;
}

/*To keep the defects as integers to find simply connected regions later on easily*/
void defectoint(lclattice *latc, deflattice *latd) {
double lp;
for(int l=0;l<nx2*ny2*nz2; l++) {
  lp = latc->dcharge[l]*10;
  latd->dcharge[l]=(lp>=0 ? (int)(lp+0.5):(int)(lp-0.5));}
return;
}

/*Getting defects from Q field through director calcs*/
void getdefects(lblattice *latv, lclattice *latc, wedge *latw, deflattice *latd) {
qton(latc,latw);
(*latc->bc_func)(latv,latc,latw,&latc->dir[0],(lcd+1));
detectdefectsinxy(latc, latw);
(*latc->bc_func)(latv,latc,latw,&latc->dcharge[0],1);
if(trackdef||indtrack) defectoint(latc, latd);
}

/*Detecting defects from director field*/
void detectdefectsinxy(lclattice *lat,wedge *latw) {
double ar2_x, ar2_y, ar4_x, ar4_y, ar1_x, ar1_y, ar3_x, ar3_y;
double ar5_x, ar5_y, ar8_x, ar8_y, ar6_x, ar6_y, ar7_x, ar7_y, ang;
int l;
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      l=(i*ny2+j)*nz2+k;
      if(latw->w[l]<lwall) {lat->dcharge[l]=0;} else {
      ar1_x=lat->dir[(((i  )*ny2+(j-1))*nz2+k)*(lcd+1)+1];
      ar1_y=lat->dir[(((i  )*ny2+(j-1))*nz2+k)*(lcd+1)+2];/*x,y components*/
      ar2_x=lat->dir[(((i+1)*ny2+(j  ))*nz2+k)*(lcd+1)+1];
      ar2_y=lat->dir[(((i+1)*ny2+(j  ))*nz2+k)*(lcd+1)+2];/*x,y components*/
      ar3_x=lat->dir[(((i  )*ny2+(j+1))*nz2+k)*(lcd+1)+1];
      ar3_y=lat->dir[(((i  )*ny2+(j+1))*nz2+k)*(lcd+1)+2];/*x,y components*/
      ar4_x=lat->dir[(((i-1)*ny2+(j  ))*nz2+k)*(lcd+1)+1];
      ar4_y=lat->dir[(((i-1)*ny2+(j  ))*nz2+k)*(lcd+1)+2];/*x,y components*/
      ar5_x=lat->dir[(((i+1)*ny2+(j-1))*nz2+k)*(lcd+1)+1];
      ar5_y=lat->dir[(((i+1)*ny2+(j-1))*nz2+k)*(lcd+1)+2];/*x,y components*/
      ar6_x=lat->dir[(((i+1)*ny2+(j+1))*nz2+k)*(lcd+1)+1];
      ar6_y=lat->dir[(((i+1)*ny2+(j+1))*nz2+k)*(lcd+1)+2];/*x,y components*/
      ar7_x=lat->dir[(((i-1)*ny2+(j+1))*nz2+k)*(lcd+1)+1];
      ar7_y=lat->dir[(((i-1)*ny2+(j+1))*nz2+k)*(lcd+1)+2];/*x,y components*/
      ar8_x=lat->dir[(((i-1)*ny2+(j-1))*nz2+k)*(lcd+1)+1];
      ar8_y=lat->dir[(((i-1)*ny2+(j-1))*nz2+k)*(lcd+1)+2];/*x,y components*/
      ang =smallestangle(ar2_x,ar2_y,ar6_x,ar6_y);
      ang+=smallestangle(ar6_x,ar6_y,ar3_x,ar3_y);
      ang+=smallestangle(ar3_x,ar3_y,ar7_x,ar7_y);
      ang+=smallestangle(ar7_x,ar7_y,ar4_x,ar4_y);
      ang+=smallestangle(ar4_x,ar4_y,ar8_x,ar8_y);
      ang+=smallestangle(ar8_x,ar8_y,ar1_x,ar1_y);
      ang+=smallestangle(ar1_x,ar1_y,ar5_x,ar5_y);
      ang+=smallestangle(ar5_x,ar5_y,ar2_x,ar2_y);
      lat->dcharge[l]=ang/2/PI;}
      }}}
}

double smallestangle(double x1_x, double x1_y, double x2_x, double x2_y) {
double dot, det, ang, sgn;
dot = x1_x*x2_x + x1_y*x2_y;
det = x1_x*x2_y - x1_y*x2_x;
ang = atan2(fabs(det),dot);
if (ang>PI/2) {x2_x=-x2_x; x2_y=-x2_y;}
dot = x1_x*x2_x + x1_y*x2_y;
det = x1_x*x2_y - x1_y*x2_x;
sgn = (det>0)-(det<0);
ang = sgn*atan2(fabs(det),dot);
return ang;
}

/*Converting Q to n*/
void qton(lclattice *lat,wedge *latw) {
int l,llc,llf;
float **dq;
float *diag,*offdiag;
int evmax;
dq = matrix(1,3,1,3);
diag=vector(1,3);
offdiag=vector(1,3);
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      l=(i*ny2+j)*nz2+k;
      llc=l*lcq;llf=l*(lcd+1);
      dq[1][1]=lat->q[llc];  dq[1][2]=lat->q[llc+3];dq[1][3]=lat->q[llc+4];
      dq[2][1]=lat->q[llc+3];dq[2][2]=lat->q[llc+1];dq[2][3]=lat->q[llc+5];
      dq[3][1]=lat->q[llc+4];dq[3][2]=lat->q[llc+5];dq[3][3]=lat->q[llc+2];
      if(~((isgeom)&&(latw->w[l]<swall))) {
      tred2(dq,lbd,diag,offdiag);
      tqli(diag,offdiag,lbd,dq);}
      evmax=1;
      if(diag[2]>diag[evmax]) evmax=2;
      if(diag[3]>diag[evmax]) evmax=3;
      lat->dir[llf]=diag[evmax];
      lat->dir[llf+1]=dq[1][evmax];
      lat->dir[llf+2]=dq[2][evmax];
      lat->dir[llf+3]=dq[3][evmax];
} } }
}

int deftagfollow(deflattice *lat) {
int *nd=&lat->ndefects;
int *dcharge=&lat->dcharge[0];
int *defect_lif=&lat->defect_lif[0];
int k=1,b1,cmbk,na,ltemp,chglocal,noplocal,scanrad,xni,yni,xl,xh,yl,yh,xlp=1,xhp=1,ylp=1,yhp=1,ltempp=1;/*last 5-Required to keep deformed/fragmented defects location temporarily*/
double xorig,yorig,xa,ya,xdiff,ydiff;
int dead=0;
for(int im=0;im<*nd;im++) { /*All defects so far considered*/ if(lat->defect_liv[im]>0) {/*only if it is live*/
  chglocal=(lat->defect_chg[im]>=0 ? (int)(lat->defect_chg[im]*10+0.5):(int)(lat->defect_chg[im]*10-0.5));/*converting to integer charge*/
  xorig = lat->defect_xlc[im];
  yorig = lat->defect_ylc[im];
  xni = (int)(xorig);
  yni = (int)(yorig);
  pbc(&xni,&yni);/*converting to integer location*/
  b1=0;/*assume its dead*/
  cmbk=0;/*assume we will find a 4 point defect*/
  scanrad=0;
  while (scanrad<=scand) {/*Scan starts from the centre of the approximate region. For a dead one it may look at scanrad=1 and scanrad=0 points repeatedly. But it is ok, as it necessary to avoid mistaking one for another if there are similar charged defects very close to each other. Also this loss of time may be compensated in finding the living ones faster.*/
      for(int ia=xni-scanrad;ia<=xni+scanrad;ia++) {
        for(int ib=yni-scanrad;ib<=yni+scanrad;ib++) {
          ltemp=lpoint(ia,ib,k);
          if(dcharge[ltemp]==chglocal) {
            noplocal = detectdefectbound(ia,ib,k,&dcharge[0],chglocal,&xl,&xh,&yl,&yh);
            if((noplocal==4) || (scanrad<=1&&((noplocal==3)||(noplocal==5)))) {/*May be its a deformed, fragmented defect*/
              b1=1;/*says it is still alive, otherwise dead*/
              break; }
            else if((noplocal==3)||(noplocal==5)) {/*may be its a deformed, fragmented defect so worth keeping and can be discarded if found another good one*/
              xlp=xl;xhp=xh;ylp=yl;yhp=yh;ltempp=ltemp;
              cmbk=1;}
        } }
        if(b1) {break;}
      }
      if(b1) {break;}
      scanrad=scanrad+1;
  }/*while loop ends*/
  if(cmbk&&(b1==0)) {b1=1; xl=xlp;xh=xhp;yl=ylp;yh=yhp;ltemp=ltempp;}/*If found a fragmented/deformed defect but didn't consider to be alive, make it alive*/
  if((b1>0)&&(lat->defexist[ltemp]==0)) {/*If it is alive, then tag it at all points spanned by the defect*/
      na=0; xa=0; ya=0;
      lat->defexist[ltemp]=lat->defect_tag[im];
      for(int ic=xl-1;ic<=xh+1;ic++) {
        for(int id=yl-1;id<=yh+1;id++) {
          ltemp=lpoint(ic,id,k);
          if(dcharge[ltemp]==chglocal) {lat->defexist[ltemp]=lat->defect_tag[im]; na=na+1; xa=xa+ic; ya=ya+id;}
      } }
      lat->defect_xlc[im]=1.0*xa/na;/*Locations inside the domain*/
      lat->defect_ylc[im]=1.0*ya/na;
      xdiff=lat->defect_xlc[im]-xorig;/*Actual displacements from previous location*/
      ydiff=lat->defect_ylc[im]-yorig;
      if(xdiff>(nx/2.)) xdiff=xdiff-nx;
      if(xdiff<(-nx/2.)) xdiff=xdiff+nx;
      if(ydiff>(ny/2.)) ydiff=ydiff-ny;
      if(ydiff<(-ny/2.)) ydiff=ydiff+ny;
      lat->defect_xanyt[im]+=xdiff;/*Actual location if it does not re-enter due to pbcs*/
      lat->defect_yanyt[im]+=ydiff;
      lat->defect_nop[im]=na;
      lat->defect_liv[im]=b1;
      if(im>=lat->nd0) {/*Contributing to RMS displacement since we account for them starting their birth,im>= because im starts at 0*/
        xdiff=fabs(lat->defect_xbirth[im]-lat->defect_xanyt[im]);
        ydiff=fabs(lat->defect_ybirth[im]-lat->defect_yanyt[im]);
        lat->defect_dis[im]=sqrt(xdiff*xdiff+ydiff*ydiff);
        defect_lif[im]+=1;/*Increasing the life time*/
        if(chglocal>0) {
          lat->drmsp[defect_lif[im]]+=lat->defect_dis[im];/*Adding to the relevant(defect_lif[im]th) row of the table*/
          lat->nrmsp[defect_lif[im]]+=1; 
          }
        else {
          lat->drmsn[defect_lif[im]]+=lat->defect_dis[im];
          lat->nrmsn[defect_lif[im]]+=1; }
      }/*RMS displacement calculated*/
  }
  else {lat->defect_liv[im]=0; dead+=1; }/*else it is considered dead*/
}}
return dead;
}

int deftagging(deflattice *lat,int tm) {
int *nd=&lat->ndefects;
int *dcharge=&lat->dcharge[0];
int *defexist=&lat->defexist[0];
int dchargelocal,l,noplocal,xl,xh,yl,yh,ic,id,na,xa,ya,ltemp;
int birth=0;
FILE *vptr;
char nname[500];
sprintf(nname,"%s/output/defcreation.dat",DPATH); vptr=fopen(nname,"a+");
for(int k=1;k<=nz;k++) {
  for(int j=1;j<=ny;j++) {
    for(int i=1;i<=nx;i++) {
      l=(i*ny2+j)*nz2+k;
      dchargelocal=dcharge[l];
      if((abs(dchargelocal)>4)&&(defexist[l]==0)) {
        noplocal = detectdefectbound(i,j,k,&dcharge[0],dchargelocal,&xl,&xh,&yl,&yh);
        if((noplocal==4)&&((xh-xl)<2)&&((yh-yl)<2)) {/*To ensure that we are looking at 4 point defect*/
          lat->ndefects=lat->ndefects+1;
          if(lat->ndefects>=ndefsmax) {return ndefsmax;}
          defexist[l]=lat->ndefects;
          na=0; xa=0; ya=0;
          for(ic=xl-1;ic<=xh+1;ic++) {
            for(id=yl-1;id<=yh+1;id++) {
              ltemp=lpoint(ic,id,k);
              if(dcharge[ltemp]==dchargelocal) {
                defexist[ltemp]=lat->ndefects;
                na=na+1; xa=xa+ic; ya=ya+id;}
            }
          }
          if(na==4) {/*in case it happens - its part of a larger one and we don't count them along with fresh ones*/
            lat->defect_tag[*nd-1]=*nd;
            lat->defect_chg[*nd-1]=dchargelocal/10.0;/*Converting back to float*/
            lat->defect_xlc[*nd-1]=1.0*xa/na;
            lat->defect_ylc[*nd-1]=1.0*ya/na;
            lat->defect_xbirth[*nd-1]=1.0*xa/na;
            lat->defect_ybirth[*nd-1]=1.0*ya/na;
            lat->defect_xanyt[*nd-1]=1.0*xa/na;
            lat->defect_yanyt[*nd-1]=1.0*ya/na;
            lat->defect_liv[*nd-1]=1;
            lat->defect_lif[*nd-1]=0;
            lat->defect_nop[*nd-1]=na;
            lat->defect_dis[*nd-1]=0;
            birth+=1;
            fprintf(vptr,"%d %f %f %f %d %d \n",lat->defect_tag[*nd-1],lat->defect_chg[*nd-1], lat->defect_xlc[*nd-1], lat->defect_ylc[*nd-1], tm, lat->defect_nop[*nd-1]);
          }
          else { /*undoing the previous loop, may not be needed at all but keeping it for safe*/
            lat->ndefects=lat->ndefects-1;
            for(ic=xl-1;ic<=xh+1;ic++) { for(id=yl-1;id<=yh+1;id++) { defexist[lpoint(ic,id,k)]=0; } }
          }
        }
      }
} } }
fclose(vptr);
return birth;
}

int inddeftagging(deflattice *lat,int tm) {
int *nd=&lat->ndefects;
int *dcharge=&lat->dcharge[0];
int *defexist=&lat->defexist[0];
int dchargelocal,l,noplocal,xl,xh,yl,yh,ic,id,na,xa,ya,ltemp;
int birth=0;
int i=(int)defx;
int j=(int)defy;
int k=1;
l=(i*ny2+j)*nz2+k;
dchargelocal=defc;
noplocal = detectdefectbound(i,j,k,&dcharge[0],dchargelocal,&xl,&xh,&yl,&yh);
if((noplocal==4)&&((xh-xl)<2)&&((yh-yl)<2)) {/*To ensure that we are looking at 4 point defect*/
  lat->ndefects=lat->ndefects+1;
  defexist[l]=lat->ndefects;
  na=0; xa=0; ya=0;
    for(ic=xl-1;ic<=xh+1;ic++) {
      for(id=yl-1;id<=yh+1;id++) {
        ltemp=lpoint(ic,id,k);
        if(dcharge[ltemp]==dchargelocal) {
          defexist[ltemp]=lat->ndefects;
            na=na+1; xa=xa+ic; ya=ya+id;}
        }
    }
    if(na==4) {/*in case it happens - its part of a larger one and we don't count them along with fresh ones*/
      lat->defect_tag[*nd-1]=*nd;
      lat->defect_chg[*nd-1]=dchargelocal/10.0;/*Converting back to float*/
      lat->defect_xlc[*nd-1]=1.0*xa/na;
      lat->defect_ylc[*nd-1]=1.0*ya/na;
      lat->defect_xbirth[*nd-1]=1.0*xa/na;
      lat->defect_ybirth[*nd-1]=1.0*ya/na;
      lat->defect_xanyt[*nd-1]=1.0*xa/na;
      lat->defect_yanyt[*nd-1]=1.0*ya/na;
      lat->defect_liv[*nd-1]=1;
      lat->defect_lif[*nd-1]=0;
      lat->defect_nop[*nd-1]=na;
      lat->defect_dis[*nd-1]=0;
      birth+=1;
    }
    else { /*undoing the previous loop, may not be needed at all but keeping it for safe*/
      lat->ndefects=lat->ndefects-1;
      for(ic=xl-1;ic<=xh+1;ic++) { for(id=yl-1;id<=yh+1;id++) { defexist[lpoint(ic,id,k)]=0; } }
    }
  }
return birth;
}

/*For detecting the coordinates enveloping the defect*/
int detectdefectbound(int ic, int id, int k, int *dcharge, int dchargelocal,int *yl, int *yh, int *zl, int *zh) {
*yl=ic;*yh=ic;*zl=id;*zh=id;
/*travelling along east*/
int e1 =(dcharge[lpoint(ic+1,id+0,k)]==dchargelocal), e2p=(dcharge[lpoint(ic+2,id-1,k)]==dchargelocal);
int e20=(dcharge[lpoint(ic+2,id+0,k)]==dchargelocal);
int e2m=(dcharge[lpoint(ic+2,id+1,k)]==dchargelocal);
/*travelling along north-east*/
int ne1 =(dcharge[lpoint(ic+1,id+1,k)]==dchargelocal);
int ne2m=e2m;/*no need of this to ndef, as it would have been counted already*/
int ne20=(dcharge[lpoint(ic+2,id+2,k)]==dchargelocal);
int ne2p=(dcharge[lpoint(ic+1,id+2,k)]==dchargelocal);
/*travelling along north*/
int n1 =(dcharge[lpoint(ic+0,id+1,k)]==dchargelocal);
int n2m=(dcharge[lpoint(ic-1,id+2,k)]==dchargelocal);
int n20=(dcharge[lpoint(ic+0,id+2,k)]==dchargelocal);
int n2p=ne2p;
/*travelling along north west*/
int nw1 =(dcharge[lpoint(ic-1,id+1,k)]==dchargelocal);
int nw2m=n2m; 
int nw20=(dcharge[lpoint(ic-2,id+2,k)]==dchargelocal);
int nw2p=(dcharge[lpoint(ic-2,id+1,k)]==dchargelocal);
/*travelling along west*/
int w1 =(dcharge[lpoint(ic-1,id+0,k)]==dchargelocal);
int w2m=(dcharge[lpoint(ic-2,id-1,k)]==dchargelocal);
int w20=(dcharge[lpoint(ic-2,id+0,k)]==dchargelocal);
int w2p=nw2p;
/*travelling along south west*/
int sw1 =(dcharge[lpoint(ic-1,id-1,k)]==dchargelocal);
int sw2m=(dcharge[lpoint(ic-1,id-2,k)]==dchargelocal);
int sw20=(dcharge[lpoint(ic-2,id-2,k)]==dchargelocal);
int sw2p=w2m;
/*travelling along south*/
int s1 =(dcharge[lpoint(ic+0,id-1,k)]==dchargelocal);
int s2m=sw2m;
int s20=(dcharge[lpoint(ic+0,id-2,k)]==dchargelocal);
int s2p=(dcharge[lpoint(ic+1,id-2,k)]==dchargelocal);
/*travelling along south east*/
int se1 =(dcharge[lpoint(ic+1,id-1,k)]==dchargelocal);
int se2m=s2p;
int se20=(dcharge[lpoint(ic+2,id-2,k)]==dchargelocal);
int se2p=e2p;
/*The following are to find the simply connected regions*/
int edia =e1*e20, nedia=ne1*ne20, ndia =n1*n20, nwdia=nw1*nw20, wdia =w1*w20, swdia=sw1*sw20, sdia=s1*s20, sedia=se1*se20;
int eda1=(e1*e2m||ne1*ne2m), eda2=(ne1*ne2p||n1*n2p), eda3=(n1*n2m||nw1*nw2m), eda4=(nw1*nw2p||w1*w2p);
int eda5=(w1*w2m||sw1*sw2p), eda6=(sw1*sw2m||s1*s2m), eda7=(s1*s2p||se1*se2m), eda8=(se1*se2p||e1*e2p);
if(nwdia||eda4||wdia||eda5||swdia) *yl=ic-2; else if(nw1||w1||sw1) *yl=ic-1;
if(nedia||eda1||edia||eda8||sedia) *yh=ic+2; else if(ne1||e1||se1) *yh=ic+1;
if(swdia||eda6||sdia||eda7||sedia) *zl=id-2; else if(sw1||s1||se1) *zl=id-1;
if(nwdia||eda3||ndia||eda2||nedia) *zh=id+2; else if(nw1||n1||ne1) *zh=id+1;

/*This provides the number of points in a defect. It may be generally 4, occasionally it goes smaller or larger due to some deformations, fragmentations and so on. Therefore its checked before identifying it as a defect*/
return 1+e1+ne1+n1+nw1+w1+sw1+s1+se1+edia+nedia+ndia+nwdia+wdia+swdia+sdia+sedia+eda1+eda2+eda3+eda4+eda5+eda6+eda7+eda8;/*1-for starting point*/
}

int lpoint(int ia, int ib, int k) {
pbc(&ia,&ib);
return (ia*ny2+ib)*nz2+k;
}

void pbc(int *ia, int *ib) {
if(*ia<1) *ia=nx + *ia;
if(*ib<1) *ib=ny + *ib;
if(*ia>nx) *ia=*ia-nx;
if(*ib>ny) *ib=*ib-ny;
return;
}
