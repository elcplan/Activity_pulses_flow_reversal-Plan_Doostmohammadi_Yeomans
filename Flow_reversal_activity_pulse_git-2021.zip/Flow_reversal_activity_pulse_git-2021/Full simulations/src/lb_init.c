/* functions associated with initialisation of d3q15 lattice LB simulation*/

void initial_conditions_lb(lblattice *latv, lclattice *latc, int i, int i_min, int i_max) {
switch (i) {
case 0:
  latv->ic_func=&init_readf;
  break;
case 1:
  latv->ic_func=&init_stag;
  break;
case 2:
  latv->ic_func=&init_inletbc;
  break;
case 3:
  latv->ic_func=&init_randomvel;
  break;
case 4:
  latv->ic_func=&init_bidirectionalflow;
  break;
case 5:
  latv->ic_func=&init_khwithfinitethick;
  break;
case 6:
  latv->ic_func=&init_genkhwithfinitethick;
  break;
case 7:
  latv->ic_func=&init_polyflow;
  break;
}
	if ( i == 10 )
	{
		int nx2_in    = nx2/2+1;
		int ny2_in    = ny2;
		int nz2_in    = nz2;
		
		double* lat_f = (double *)malloc(nx2_in*ny2_in*nz2_in*lbq*sizeof(double));
		
		init_read_eq_f(lat_f,nx2_in,ny2_in,nz2_in);
		
		for(int i=0;i<nx2;i++)
		{
			for(int j=0;j<ny2;j++)
			{
				for(int k=0;k<nz2;k++)
				{
					int i_in;
					
					if ((i>0) && (i<nx2_in-1))
					{
						if (i-nx/2+i_max > 0) i_in = i-nx/2+i_max;
						else i_in = i+i_max;
					}
					
					else if ((i>0) && (i<nx2-1))
					{
						if (i-nx/2-1+i_min < nx/2+1) i_in = i-nx/2-1+i_min;
						else i_in = i+i_min-nx-1;
					}
					
					else if (i == 0) i_in = i_min-1;
					else i_in = i_max+1;
					
					int l    = (i   *ny2+j)*nz2+k;
					int l_in = (i_in*ny2+j)*nz2+k;
					
					for (int m=0; m<lbq; m++) latv->f[l*lbq+m] = lat_f[l_in*lbq+m];
				}
			}
		}
	}
	
	else
	{
		(*latv->ic_func)(latv);
		if(i>0) finitialise(latv, latc);
	}
}


/*Initialisation of distribution functions with eq*/
void finitialise(lblattice *latv, lclattice *latc) {
for(int i=0;i<nx2;i++) {
   for(int j=0;j<ny2;j++) {
      for(int k=0;k<nz2;k++) {
    	 feqcal(latv,latc,i,j,k,&latv->f[((i*ny2+j)*nz2+k)*lbq]);
    	 //for(int m=0;m<lbq;m++) latv->f[(((i*ny2+j)*nz2+k)*lbq)+m]=latv->rho[0]/15.0;
//	 for(int m=0;m<lbq;m++) printf("in initil %d %f\n",m, latv->f[((i*ny2+j)*nz2+k)*lbq+m]);
}; }; };
return;
}

/*To start from a inlet boundary condition*/
void init_inletbc(lblattice *lat) {
int l;
for(int i=0;i<nx2;i++)
  for(int j=0;j<ny2;j++)
    for(int k=0;k<nz2;k++) {
      l = (i*ny2+j)*nz2+k;
      lat->rho[l]= rho0;
      lat->u[l*lbd+0]=u0[0];
    	lat->u[l*lbd+1]=u0[1];
  	  lat->u[l*lbd+2]=u0[2];
	 }
//for(int i=nx/2;i<nx/2+1;i++)
//   for(int j=1;j<ny2;j++)
//      for(int k=1;k<nz2;k++) {
//        l = (i*ny2+j)*nz2+k;
//    	  lat->u[l*lbd]=0.001;
//  	 }
return;
}

/*To start from a completely stagnant situation with unit density*/
void init_stag(lblattice *lat) {
int l;
for(int i=0;i<nx2;i++)
   for(int j=0;j<ny2;j++)
      for(int k=0;k<nz2;k++) {
        l = (i*ny2+j)*nz2+k;
        lat->rho[l]= rho0;
        lat->u[l*lbd+0]=u0[0];
        lat->u[l*lbd+1]=u0[1];
        lat->u[l*lbd+2]=u0[2];
	//printf("u at %d,%d,%d:%f,%f,%f.\n",i,j,k,lat->u[l*lbd+0],lat->u[l*lbd+1],lat->u[l*lbd+2]); //EC:ok
      }
return;
}

/*To start from a completely random situation with unit density*/
void init_randomvel(lblattice *lat) {
int l;
for(int i=0;i<nx2;i++)
   for(int j=0;j<ny2;j++)
      for(int k=0;k<nz2;k++) {
        l = (i*ny2+j)*nz2+k;
        lat->rho[l]=ran2(&seed);// rho0;
        lat->u[l*lbd+0]=ran2(&seed)/1000.;/*divided by to get small initial velocities*/
        lat->u[l*lbd+1]=ran2(&seed)/1000.;
        lat->u[l*lbd+2]=ran2(&seed)/1000.;
     }
return;
}

/*To start from a inlet boundary condition*/
void init_bidirectionalflow(lblattice *lat) {
int l;
int jwid=15;
int l1=ny/2-2*jwid;
int l2=l1+jwid;
int l3=l2+2*jwid;
int l4=l3+jwid;
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l = (i*ny2+j)*nz2+k;
      lat->rho[l]= rho0;
      if(j<=l1) {
        lat->u[l*lbd+0]=0;
      }
      else if((j>l1)&&(j<=l2)) {
      lat->u[l*lbd+0]=-u0[0]/jwid*(j-l1);}
      else if((j>l2)&&(j<=l3)) {
      lat->u[l*lbd+0]=-u0[0]+u0[0]/jwid*(j-l2);}
      else if((j>l3)&&(j<=l4)) {
      lat->u[l*lbd+0]=u0[0]-u0[0]/jwid*(j-l3);}
      else {
      lat->u[l*lbd+0]=0;
      }
    	lat->u[l*lbd+1]=u0[1];
  	  lat->u[l*lbd+2]=u0[2];
   } } }
return;
}

/*To start with kinks in vel profile */
void init_khwithfinitethick(lblattice *lat) {
int l;
int jwid=15;
int l1=ny/2-jwid;
int l2=l1+2*jwid;
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l = (i*ny2+j)*nz2+k;
      lat->rho[l]= rho0;
      if(j<=l1) {
        lat->u[l*lbd+0]=0;
      }
      else if((j>l1)&&(j<=l2)) {
      lat->u[l*lbd+0]=u0[0]/(2*jwid)*(j-l1);}
      else {
      lat->u[l*lbd+0]=u0[0];
      }
    	lat->u[l*lbd+1]=u0[1];
  	  lat->u[l*lbd+2]=u0[2];
	  //printf("%d %d %d %d %f\n",i,j,k,l*lbd,lat->u[l*lbd]);
   } } }
return;
}

/*To start with kinks in vel profile and non zero gradients*/
void init_genkhwithfinitethick(lblattice *lat) {
int l;
int jwid=10;
int l1=ny/2-jwid;
int l2=l1+2*jwid;
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l = (i*ny2+j)*nz2+k;
      lat->rho[l]= rho0;
      if(j<=l1) {
        lat->u[l*lbd+0]=u0[0]/l1*j;
      }
      else if((j>l1)&&(j<=l2)) {
      lat->u[l*lbd+0]=u0[0]+u0[0]/(2*jwid)*(j-l1);}
      else {
      lat->u[l*lbd+0]=u0[0]/l1*(j-l2)+2*u0[0];
      }
    	lat->u[l*lbd+1]=u0[1];
  	  lat->u[l*lbd+2]=u0[2];
   } } }
return;
}

/*To start with a polyflowflow*/
void init_polyflow(lblattice *lat) {
int l;
int flowp=2;/*power for velocity profile*/
for(int i=0;i<nx2;i++) {
  for(int j=0;j<ny2;j++) {
    for(int k=0;k<nz2;k++) {
      l = (i*ny2+j)*nz2+k;
      lat->rho[l]= rho0;
      lat->u[l*lbd+0]=u0[0]*pow((1.0*j)/(1.0*ny2),flowp);
      lat->u[l*lbd+1]=u0[1];
      lat->u[l*lbd+2]=u0[2];
   } } }
return;
}
