/*definition of an lb lattice structure*/
typedef struct lblattice {
    double tau;    		/*relaxation time/times for lb*/
    double *f;    		/*f's for lb*/
    double *fnew;    		/*after collision propagation f's for lb*/
    double *wt;    		/*weights for lb*/
    double *xi;    		/*velocities for lb*/
    double *u;    		/*velocities for lb*/
    double *rho;    		/*densities for lb*/
    double *force;    		/*forces for lb*/
    double *p;    		/*force function distibution*/
    double *bforce;		/*body forces*/
    double *vstress;		/*viscous stresses*/
    int *complement;    	/*complement for velocities for lb bc*/
    int tbwall;    		/*top bottom boundary condition - logical variable*/
    double Dt;    		/* time increment*/
    double cs2;    		/*sound speed squared*/
    double *o;    		/*vorticity lb*/
    double *leef; 		/*extra space for lb fs*/
    
    /*pointers to functions*/
    void (*ic_func)();		/*Initial conditions*/
    void (*bc_func)();		/*Boundary conditions*/
    void (*force_func)();	/*Force calculation*/
} lblattice;

/*liquid crystal dynamics variables and function declarations*/
typedef struct lclattice {
    double *q;    		/*q's for lc,1-11, 2-22, 3-33, 4-12, 5-13, 6-23*/
    double *qnew;    		/*after update */
    double *qkep;    		/*mid for update by rk*/
    double *qflux;    		/*for update */
    double *H;    		/*molecular field for lc,1-11, 2-22, 3-33, 4-12, 5-13, 6-23*/
    double *qeef;    		/*extra q's for lee-edeards*/
    double *estress; 		/*stresses that will go into equilibrium calculations*/
    double *bstress; 		/*stresses that will go into body forces*/
    double *presure; 		/*pressure if required*/
    double *vstress;		/*viscous stresses*/
    double *tforce;		/*total forces*/
    double *mcharge;		/*charge from Q*/
    double *dcharge;		/*charge from director*/
    double *dir;		/*S and d from Q*/
    double Dt;    		/* time increment*/
    int tbwall;
    void (*methodofintg)();	/*method of integration*/
    double *fe_nematics;	// free energy from Q
    double *viscstress;		//stresses Emmanuel's method, along with polystress
    double *elasstress;
    double *actstress;
    double *capstress;		//related to phi
    double *totstress;		//related to phi
    
    /*pointers to functions*/
    void (*ic_func)();		/*Initial conditions*/
    void (*bc_func)();		/*boundary conditions*/
    void (*bc_derv)();		/*boundary conditions*/

    /*pointers for option with phi*/
    double *phi;    		/*Concentration of nematic phase*/
    double *phinew;		/*Concentration of nematic phase*/
    double *phikep;		/*mid update by rk*/
    double *phiflux;		/*for update*/
    double *dphidx;    		/*Gradient of concentration in x-direction*/
    double *dphidy;    		/*Gradient of concentration in y-direction*/
    double *dphidz;    		/*Gradient of concentration in z-direction*/
    double *mu;    		/*Chemical potential*/
    void (*bc_funcphi)();	/*boundary conditions for phi*/
    void (*bc_dervphi)();	/*boundary conditions for phi*/
    void (*bc_funcmu)();	/*boundary conditions for phi*/
    void (*bc_dervmu)();	/*boundary conditions for phi*/
    double *fe_phi;		// free energy related to phi, pointer

    /*pointers for dividing cells*/ //Emmanuel's version
    int *locxcelldiv;
    int *locycelldiv;
    int *timecelldiv;
    double *statuscelldiv;

    /*pointers for dividing cells*/
    int *locelld;		/*Location of dividing cells*/
    int *tmcelld;		/*Location of dividing cells*/

       

    /*pointers for option with polymers*/
    double *c;    		/*C's for polymer,0-C_11, 1-C_22, 2-C_33, 3-C_12=C_21, 4-C_13=C_31, 5-C_23=C_32*/
    double *cinverse; 		/*C inverse*/
    double *cnew;    		/*after update */
    double *ckep;    		/*mid for update by rk*/
    double *cflux;    		/*for update */
    double *l;
    double *lnew;//for log conformation of c
    double *lkep;
    double *lflux;
    double *tau_poly;		// relation time of the polymer
    double *poly_a;		// parameter to choose mode of relaxation, a=1 is Oldroyd-B model
    double A_c;		//elastic modulus
    double ellsq_poly;		// turns on polymers, coefficient in polypotential/free energy
    double *phi_c;		// concentration of C particles, initially 1-phi (phi from inphase)
    double *h_poly; 		/*molecular field for polymer 0-C_11, 1-C_22, 2-C_33, 3-C_12, 4-C_13, 5-C_23*/
				//Note that the extra terms in H_Q and H_phi (and free energies) 
				// due to the additional terms in the free energy due to the 
				// polymers/coupling are added in if loops in the parts when they are calculated
    double *stress_poly; 	/*stress that will go into equilibrium calculations*/
    void (*bc_func_c)();	/*boundary conditions for c*/
    void (*bc_derv_c)();	/*boundary conditions for c*/
    double *kappaqc;		//turns on coefficient of QC in free energy with polymers
    double *chiqc;		//turns on coefficient of QC in free energy with poymers
				//f_QC=kappa Tr(C-I)Tr(Q^2)+2chi Tr(CQ)
    double *fe_poly;		//free energy coming for the polymers, not including coupling terms
    double *fe_qc;		//free energy coming form the coupling of Q and C, contolled by kappaqc and chiqc
    double *polystress; 		/*polymer stress*/
    void (*ic_func_c)();

    int ringstat;
} lclattice;

typedef struct wedge {
    int *w;
    int *lpv;/*to calculate the derivatives*/
    double *wlp;/*to know the weights when calculating derivatives near walls*/
    double *markers;/*location of a marker point on the particle*/
    double *bodyomega;/*angular velocity of immersed particle*/
    double *bodyomegaold;/*angular velocity of immersed particle*/
    double *torque;/*angular velocity of immersed particle*/
    double *torqueold;/*angular velocity of immersed particle*/
    double *forceb;/*angular velocity of immersed particle*/
    double *forcebold;/*angular velocity of immersed particle*/
    double *angseries;/*series of angular velocity of immersed particle*/
    double *corrang;/*correlation */
    int *corrangrealzn;/*correlation */
    double *partloc;/*location of particles*/
    int *partmark;/*to identify the particle*/
    double *numforomega;/*ang vel calculation numerator-useful for multiple particles*/
    double *denforomega;/*ang vel calculation denominator-useful for multiple particles*/
    int swallcnt;/*number of grid points with swall*/
    int *neighswall;/*neighbours of swalls*/
    double *diffneigh;/*differences needed for interpolation*/
    double *qeonswall;/*Q on surface of the particle*/
    int lwallcnt;/*number of grid points with lwall*/
    int *lwallloc;/*locations of lwall*/
    double *qeonlwall;/*Q on surface/lwall*/
} wedge;

/*lb functions*/
lblattice *lbsetting();/*Just to set lb parameters*/
lblattice *d3q15_initialise();/*To initialise lb parameters*/
void initial_conditions_lb(lblattice *,lclattice *, int, int, int);/*To set initial conditions for u and rho and f*/
void init_stag(lblattice *);/*Stagnant initial conditions*/
void init_randomvel(lblattice *);/*Random velocity initial conditions*/
void init_bidirectionalflow(lblattice *);/*Random velocity initial conditions*/
void init_khwithfinitethick(lblattice *);/*Random velocity initial conditions*/
void init_genkhwithfinitethick(lblattice *);/*Random velocity initial conditions*/
void init_polyflow(lblattice *);/*Random velocity initial conditions*/
void init_inletbc(lblattice *);/*Inlet boundary conditions to initialise*/
void init_readf(lblattice *);/*Reading f to initialise*/
void init_read_eq_f(double*, int, int, int);
void boundary_conditions_lb(lblattice *, int );/*Boundary conditions for lb*/
void lbhydrodynamics(lblattice *, lclattice *, wedge *, int);/*Doing LB simulation*/
void (*colliding)(lblattice *, lclattice *, wedge *);/*Doing collisions*/
void lbcolliding(lblattice *, lclattice *, wedge *);/*Doing the collision step*/
void nocolliding(lblattice *, lclattice *, wedge *);/*Doing no collision step*/
void streaming(lblattice *, wedge *);/*Doing the streaming step*/
void hydrocalc(lblattice *);/*Calculating u and rho from f*/
void forcedistributions(lblattice *);/*Calculating distribution functions of forces*/
void finitialise(lblattice *, lclattice *);/*Initialsing f with initial prescribed flow*/
void feqcal(lblattice *, lclattice *, int , int , int ,double *);/*Equilibrium f calculations*/
void normalfeqcal(lblattice *, int , int , int ,double *);/*Equilibrium f calcualtions without stresses*/
double sumof(double *, int ,int *,int );/*Used to check conservations*/
int lbnewwall(int , int , int , int ,int );/*Used to see where f propagates to*/
void swapffs(double **, double **);/*Used to swap f or any arrays*/
void copyffs(double *, double *, int);/*Used to copy f or any arrays*/
void lbwalls_xz(lblattice *, lclattice *, wedge *, double *, int );/*Used in applying wall bcs*/
void lbwalls_xzandyz(lblattice *, lclattice *, wedge *, double *, int );/*Used in applying wall bcs*/
void lbwalls_xz(lblattice *, lclattice *, wedge *, double *, int );/*Used in applying wall bcs*/
void lbleeed_xz(lblattice *, lclattice *, wedge *, double *, int ,int );/*Used in applying wall bcs*/
void lbwalls_leftright(lblattice *);/*For left right walls*/
void lbwalls_topbottom(lblattice *);/*For top bottom walls*/
void lbwalls_frontback(lblattice *);/*For front back walls*/
void lbleeed_topbottom(lblattice *,int );/*For top bottom walls*/
void lbleeed_calculate(lblattice *, int );/*For top bottom walls*/
void lbleeed_interpolate(lblattice *,int );/*For top bottom walls*/
void lbleeed_initialise(lblattice *);/*For top bottom walls*/
void fdqcal(lblattice *, int , int , int ,double *,double *);/*f increment calculations for Lee-Edwards*/
void tobounceapply(lblattice *, int ,int , int, int ,int );/*Real copying*/
void wallbc(lblattice *);/*Used in applying wall bcs*/
void wallbcapply(lblattice *,int , int , int , int , int );/*Real wall bc applied*/


lclattice *lcsetting(int );
lclattice *liqcry_initialise(int );
void initial_conditions_lc(lclattice *,int ,int ,int, double , double , double, int*, int*);
void modify_initial_conditions_lc(lclattice *,wedge *);
void find_for_anchoring_lc(lclattice *,wedge *);
void boundary_conditions_lc(lclattice *, wedge *, int , int , int ,double , double , double ,int );
void lcwalls_xzandyz(lblattice *, lclattice *, wedge*,  double *, int);/*For applying bcs for lc*/
void lcwalls_xz(lblattice *, lclattice *, wedge *, double *, int);/*For applying bcs for lc*/
void lcwalls_xzandyz_initialise(lclattice *, double , double , double ,int );
void lcwalls_xz_initialise(lclattice *, double , double , double ,int );
void lcwalls_leftright_initial(lclattice *, double , double , double , double );
void lcwalls_topbottom_initial(lclattice *, double , double , double , double ,int );
void lcwalls_frontback_initial(lclattice *, double , double , double , double );
void lcwalls_dervsxzandyz(lblattice *, lclattice *, wedge *, double *, int );
void lcwalls_dervsxz(lblattice *, lclattice *, wedge *, double *, int );
void lcwalls_dervsleftright(double *, int , double , double );
void lcwalls_dervstopbottom(double *, int , double , double );
void lcwalls_dervsfrontback(double *, int , double , double );
void swapusforbc(double * , int , int , int , int , double , double );
void qassign(double *, double , double , double , double );
void lcwalls_nofluxxz(lblattice *, lclattice *, wedge *, double *, int);/*For applying wall bcs for lc phi and mu*/
void lcwalls_nofluxxzandyz(lblattice *, lclattice *, wedge *, double *, int);
void lcwalls_nofluxxz_u(double *, int );/*Copying to ensure no flux through the wall*/
void lcwalls_nofluxyz_u(double *, int );/*Copying to ensure no flux through the wall*/
void lcleeed_xz_initialise(lclattice *, double , double , double ,int );
void lcleeed_xz(lblattice *, lclattice *, wedge *, double *, int ,int );/*For applying bcs for lc*/
void lcleeed_topbottom(double *, int, int , double *);/*For applying bcs for lc*/
void lcleeed_calculate(double *, int , double *);/*For applying bcs for lc*/
void lcleeed_interpolate(double *, int ,int );/*For applying bcs for lc*/
void lccircbc(lblattice *, lclattice *, wedge *, double *, int ,int );/*For applying bcs for lc*/
void lcwalls_circ(lclattice *, wedge *);
void init_nematic_equi(lclattice *,double , double , double );
void init_isotropic(lclattice *,double , double , double );
void init_nematic_equi_withran(lclattice *,double , double , double );
void init_tiltmiddleqs(lclattice *,double , double , double );
void init_bendatmiddle(lclattice *);
void init_nothing(lclattice *);
void init_randomqs(lclattice *);
void init_readq(lclattice *, double , double , double );
void init_read_eq_q(double*, int, int, int);
void liqcrdynamics(lblattice *, lclattice *, wedge *, int);
void euler_update_onestep(lblattice *, lclattice *, wedge *, int ,double ,int, double *, double *,double *, double *,double *, double *, double *, double *);
void qflux_calc(lblattice *, lclattice *, wedge *, int ,int);
void phiflux_calc(lblattice *, lclattice *, wedge *, int);
void euler_update(lblattice *, lclattice *, wedge *,int ,double ,int );
void rk2_update(lblattice *, lclattice *, wedge *, int ,double ,int );
void eulerrk2_update(lblattice *, lclattice *, wedge *, int ,double ,int );
void phi_fluxcalcon(double *, double *, double *, double *, int *, int ,int , int , int ,int);
void phi_fluxcalcoff(double *, double *, double *, double *, int *, int ,int , int , int ,int);
void (*phi_fluxcalc)(double *, double *, double *, double *, int *, int ,int , int , int ,int);
double lap_cd(double *, int, int *, int);
double lap_d3q15(double *, int, int *, int);
void diffusive_flux_q(lclattice *, double *, double *, int ,double *, int *, double *, double *, double *,double ,int, int);
double (*diffusive_flux_phi)(double *, int *, int);
double diffusive_flux_phion(double *, int *, int);
double diffusive_flux_phioff(double *, int *, int );
double (*advective_flux_phi)(double *, double *, int *,int ,int);
double advective_flux_phion(double *, double *, int *, int ,int);
double advective_flux_phioff(double *, double *, int *,int ,int);
void (*advective_flux)(double *, int ,double *, double *, double *, double *);
void advective_fluxon(double *, int ,double *, double *, double *, double *);
void advective_fluxoff(double *, int ,double *, double *, double *, double *);
void (*corotatnl_flux)(double *, int ,double *, double *, double *, double *);
void corotatnl_fluxon(double *, int ,double *, double *, double *, double *);
void corotatnl_fluxoff(double *, int ,double *, double *, double *, double *);
void active_flux(double *, int ,double *);
void (*qnoise_flux)(double *, double);
void qnoise_fluxinxy(double *, double);
void qnoise_fluxin3d(double *, double);
void qnoise_fluxnone(double *, double);
void derivativesN(int ,int , int ,int *);
void derivativesQ(double *, double *, double *, double *, int *);
void derivativesphi(lclattice *, double*, double, double, double, int *);
void derivativesU(double *,double *, double *, double *, int *,double *);
void l1forchiral(double *, int, int *, double *, double *, double *, double *, double *,double *);
void l2l3derivforh(double *, int , int *, double *, double *, double *, double *, double *, double *);
void l2l3forstress(double *, int , double *, double *, double *, double *, double *, double *, double *);
void lchiralforstress(double *, int, double *, double *, double *, double *, double *);
double qeq();
void liqcforcecalc(lblattice *, lclattice *, wedge *);
void liqcstresses(lclattice *, int ,double ,double *, double *, double *, double ,double *,int *,double *,double *,double *,double *,double *, int);
double chargecalc(double *, double *, double *);

wedge *wedge_initialise(lblattice *);/*To initialise lb parameters*/
void wedge_initial(lblattice *, wedge *);
void twowedge_initial(lblattice *, wedge *);
void wedge_fill_marker(wedge *);
void twowedge_fill_marker(wedge *);
void simply_fill_marker(wedge *);
void wedge_top_correction(wedge *);
void wedge_bottom_correction(wedge *);
void wedge_boun_ini(wedge *, lblattice *);
void derivNwedge(wedge *);
void printing_geometry(wedge *);
void lbwedge_inxy(lblattice *, lclattice *, wedge *, double *, int );/*Used in applying wall bcs of wedge*/
void lbwalls_top(lblattice *);/*For top bottom walls*/
void lbwedgeindomain(lblattice *, wedge *);/*Reverses f on solid walls, bounce back*/
void lcwedgebcinitialise(lclattice *, wedge *);
void lctwowedgebcinitialise(lclattice *, wedge *);
void lcwedgewalls_initialise(lclattice *, wedge *);
void lctwowedgewalls_initialise(lclattice *, wedge *);
void lcwalls_dervsonwedge(lblattice *, lclattice *, wedge *, double *, int ,int );
void lcwalls_wedge(lblattice *, lclattice *, wedge *, double *, int, int);
void init_wedgeranplusnemqs(lclattice *);
void init_readg(wedge *);/*Reading geometry to initialise*/
void lbgeominside_inxy(lblattice *, lclattice *, wedge *, double *, int );/*Used in applying wall bcs on geometry inside the domain*/
void lbgeominxyleeedinxz(lblattice *, lclattice *, wedge *, double *, int ,int );/*Used in applying wall bcs on geometry inside the domain with leeeds*/
void lbgeominxyplatesinxz(lblattice *, lclattice *, wedge *, double *, int ,int );/*Used in applying wall bcs on geometry inside the domain with leeeds*/
void box_initial(lblattice *, wedge *);
void cir_initial(lblattice *, wedge *);
void couette_initial(lblattice *, wedge *);
void box_fill_marker(wedge *);
void cir_fill_marker(wedge *);
void couette_fill_marker(wedge *);
void lcboxwalls_initialise(lclattice *, wedge *);
void lccirwalls_initialise(lclattice *, wedge *);
void lcboxbcinitialise(lclattice *, wedge *);
void lccirbcinitialise(lclattice *, wedge *);
void lcwalls_dervsonbox(lblattice *, lclattice *, double *, int );
void angvelcalc(lblattice *, lclattice *, wedge *, int );
void dragftcalc(lblattice *, lclattice *, wedge *, int );

// Function for option with polymers
void poly_initialise(lclattice *);
void derivatives_C(double *, double *, double *, double *, int *);
void stretching_flux_C(double *, double *, double *);
void stretching2_flux_C(double *, double *, double *);
void relaxation_flux_C(double *, double *, double *, double *);
void diffusion_flux_C(double *, int, int *, double *);
void invert_matrix(double *, double *,int);
double determinant_matrix(double *);
void init_poly_eq(lclattice *);
void init_poly_stretch_ran(lclattice *);
void init_poly_ori_stretch_ran(lclattice *);
void init_poly_ori_stretch_bor(lclattice *);
double polylength(double *, int ,int *,int );

void prinstress(lblattice *,lclattice *, wedge *,int);
void stiffness(lblattice *,lclattice *, int);
void stiffness_nopoly(lblattice *,lclattice *, int);
void stressgrad(lblattice *, lclattice *, wedge *,int);
void prin_eigen(float **, int , float d[], float offd[], int *);
void prin_eigen_c(float **, int , float d[], float offd[], int *);
double perimeter_flat(lclattice *,int);
double perimeter_drop(lclattice *,int);
void celldivision_init(lclattice *);
void celldivision(lclattice *,int);
void newloc_celldiv(lclattice *,int);
void init_readc(lclattice *, double , double , double );
void centreofmass(lclattice *, wedge *,int, double *, double *);

//double clock_gettime();
//double CLOCK_REALTIME();

//void fewrite(fe_tot,fe_Q,fe_C,fe_QC,fe_phi)
