function nemangle_dimless_2
clear all
global angledeg Cangledeg vectornone vectorzero vector
eta=2/3;
zetamain=0.010;
zeta=zetamain;
kapparat=0.25;
fign=2;

dt=0.1;
lambda=1.1;
poly=1;

delayv=[800 700 600 500 400 300 200 150 100 50];
delayv=[500];
ndelay=length(delayv);

gammainvv=[180 160 140 120 100 80 60];
ngammainv=length(gammainvv);

gammaCv=[800 700 600 500 400 300 200 150 100 50];
% this functions as tau
ngammaC=length(gammaCv);

warning=zeros(ndelay,ngammainv,ngammaC);
reversal=zeros(ndelay,ngammainv,ngammaC);
ndata=ndelay*ngammainv*ngammaC;
datanoflow=zeros(100,3);
datarev=zeros(100,3);
datanorev=zeros(100,3);
noflowcount=1;
revcount=1;
norevcount=1;


istart=0;
tstart2=istart;
iend=30000;
tend2=iend;
tstart=tend2/2;
tend=tstart+600
nsteps=(iend-istart)/dt;
time=transpose(istart:dt:iend);

    figure(10);
    clf
    set(gcf, 'Position',  [800, 500, 1000, 330])
    
    hold on;
    h2 = gca;
    set(gca,'fontsize',14)
    box on;
    set(h2,'XTickLabel', []);
    labelh2=ylabel(h2,{['Nematic angle \theta_n'];'(Simplified model)'},'Fontsize',13);
    h2.Position = [0.09 0.17  0.9 0.82];
    ylim([-16,16])
    
    ax2x1=0.77;
    ax2y1=0.30;
    ax2l=0.2;
    ax2w=0.5;
    ax2=axes('Position',[ax2x1 ax2y1 ax2l ax2w]);
    ax2 = gca;
    set(gca,'fontsize',14)
    hold on;
    box on;
    xlim(ax2,[tstart tend]);
    set(ax2,'XTickLabel', [],'YTickLabel', []);
    ylim(ax2,[-3 6])
    
 
    xline(h2,15000,':k','HandleVisibility','off','Linewidth',1.5);
    xline(h2,15000+400,':r','HandleVisibility','off','Linewidth',1.5);
    xline(h2,15000+200,':b','HandleVisibility','off','Linewidth',1.5);
    yline(h2,0,':k','HandleVisibility','off','Linewidth',1.5);

    xlim(h2,[tstart2 tend2]);
    xticks(h2);
    xticklabels(h2,'auto');


    xline(ax2,15000,':k','HandleVisibility','off','Linewidth',1.5);
    xline(ax2,15000+400,':r','HandleVisibility','off','Linewidth',1.5);
    xline(ax2,15000+200,':b','HandleVisibility','off','Linewidth',1.5);
    yline(ax2,0,':k','HandleVisibility','off','Linewidth',1.5); 
    xticks(ax2,[])
    yticks(ax2,[]);
    
    labelh1.Position(1) =-13000; % change horizontal position of ylabel
    labelh1.Position(2) =-0; % change vertical position of ylabel
    labelh2.Position(1) =-1400; % change horizontal position of ylabel
    labelh2.Position(2) =0; % change vertical position of ylabel
    xlabel(h2,'Time')
    
    
for igammainv=1:ngammainv
for idelay=1:ndelay
for igammaC=1:ngammaC
    

    
fign=igammainv;
fign=11;
hold on;
        
delay=delayv(idelay);
tn=gammainvv(igammainv);
tp=gammaCv(igammaC);

        make=1;icol=4;
    if (tp==600)&&(delay==400)&&(tn==150) make=1; icol=1; end %red
    if (tp==600)&&(delay==200)&&(tn==150) make=1; icol=2; end %blue dashed
    if (tp==300)&&(delay==200)&&(tn==150) make=1; icol=3; end %blue

if(make==1)
kappavec=zeros(nsteps+1,1);
angledeg=zeros(nsteps+1,1);
Cangledeg=zeros(nsteps+1,1);

angledeg(1)=0.01;
angle=angledeg(1)*pi/180;
Cangledeg(1)=0.01;
Cangle=Cangledeg(1)*pi/180;


    
for i=1:nsteps/2
    kappa=zeta*sin(2*angle)/(4*eta)-poly*1/tp*cos(Cangle)*sin(Cangle)/(2*eta); %OK from stress balance
    
    %nematic
    shearing=kappa*lambda*cos(2*angle);
    angchange=shearing-1/tn*angle;
    angle=angle+dt*angchange;
    angledeg(i+1)=angle*180/pi;
    
    %poly and polyevol
    polyshear=kapparat*kappa*lambda*cos(2*Cangle);
    polychange=polyshear-1/tp*Cangle;
    Cangle=Cangle+dt*polychange;
    Cangledeg(i+1)=Cangle*180/pi;

    
end
%pause()
for i=nsteps/2+1:nsteps
    if and(i>nsteps/2,i<nsteps/2+delay/dt)
        zeta=0.0;
    else
        zeta=zetamain;
    end

    kappa=zeta*sin(2*angle)/(4*eta)-poly*1/tp*cos(Cangle)*sin(Cangle)/(2*eta); %OK from stress balance
    
    %nematic
    shearing=kappa*lambda*cos(2*angle);
    angchange=shearing-1/tn*angle;
    angle=angle+dt*angchange;
    angledeg(i+1)=angle*180/pi;
    
    %poly and polyevol
    polyshear=kapparat*kappa*lambda*cos(2*Cangle);
    polychange=polyshear-1/tp*Cangle;
    Cangle=Cangle+dt*polychange;
    Cangledeg(i+1)=Cangle*180/pi;
end

reversaln=angledeg(nsteps/2-1)/angledeg(nsteps-1);
reversal(idelay,igammainv,igammaC)=reversaln;
warningn=0;
if abs(angledeg(nsteps/2-1))<0.001
    warningn=1;
    warning(idelay,igammainv,igammaC)=warningn;
end

x1=zeta*tn;
y1=zeta;

x2=tp/tn;
y2=delay/tn;


if(warningn<0.5)
    figure(20)
    hold on;
    plot(x1,y1,'ob');
    hold off;
    xlabel('\zeta/t_n')
    ylabel('zeta')

if (reversaln<0) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  with reversal
%    figure(1)
 
     hold on;
     if(icol==1) 
     txt=horzcat('{\color{red}e}: d=',int2str(delay),', \tau=',int2str(tp));
     plot(h2,time,angledeg,'-r','Linewidth',2,'DisplayName',txt); 
     plot(ax2,time,angledeg,'-r','Linewidth',2);
     end
     if(icol==2) 
     txt=horzcat('{\color{blue}f }: d=',int2str(delay),', \tau=',int2str(tp));
     plot(h2,time,angledeg,'--b','Linewidth',2,'DisplayName',txt);
     plot(ax2,time,angledeg,'--b','Linewidth',2);
     end
     legend('off');
     
    figure(fign)
    hold on;
    plot(x2,y2,'ob');
    hold off;
    xlabel('\tau/t_n')
    ylabel('delay/\tau_n')

    datarev(revcount,1)=gammainvv(igammainv);
    datarev(revcount,2)=delayv(idelay);
    datarev(revcount,3)=gammaCv(igammaC);
    revcount=revcount+1;
   
else %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% no reversal
    figure(10)
     hold on;
     if(icol==3) 
     txt=horzcat('{\color{blue}g}: d=',int2str(delay),', \tau=',int2str(tp));
     plot(h2,time,angledeg,'-b','Linewidth',2,'DisplayName',txt); 
     plot(ax2,time,angledeg,'-b','Linewidth',2);end
   
    figure(fign)
    hold on;
    plot(x2,y2,'+r');
    hold off;
    set(gca,'YScale','lin');

    datanorev(norevcount,1)=gammainvv(igammainv);
    datanorev(norevcount,2)=delayv(idelay);
    datanorev(norevcount,3)=gammaCv(igammaC);
    norevcount=norevcount+1;
    
end


else %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% no flow
    figure(20)
    hold on;
    plot(x1,y1,'xr');
    hold off;
    
    figure(21)
    hold on;
    plot(time,angledeg,'-b','Linewidth',2,'HandleVisibility','off');
    hold off;
        
    datanoflow(noflowcount,1)=gammainvv(igammainv);
    datanoflow(noflowcount,2)=delayv(idelay);
    datanoflow(noflowcount,3)=gammaCv(igammaC);
    noflowcount=noflowcount+1;
end


end %make
end %gammaC
end %delay
end %gammainv


    %% inset
    figure(10)
   
    p102=patch(h2,[15000 15000 15600 15600],[-3 6 6 -3],[0.5 0.3 0.3],'HandleVisibility','off');
    set(p102,'FaceAlpha','0.01','EdgeAlpha','0.99');
    xl = [0.541 ax2x1];
    yl = [0.735 ax2y1+ax2w];
    annotation('line',xl,yl)
    xl = [.541 ax2x1];
    yl = [.505 ax2y1];
    annotation('line',xl,yl)
    leg=legend(h2,'Location','best')
    
annotation('textbox',[0.55 0.24 0.1 0.1],'String','e','FitBoxToText','on','Linestyle','none','Color','red','Fontsize',13);
annotation('textbox',[0.58 0.3 0.1 0.1],'String','f','FitBoxToText','on','Linestyle','none','Color','blue','Fontsize',13);
annotation('textbox',[0.60 0.65 0.1 0.1],'String','g','FitBoxToText','on','Linestyle','none','Color','blue','Fontsize',13);

     
h4=gcf;
set(h4,'PaperSize',[10.5 3.6]); %set the paper size to what you want  
print(h4,'fig2b','-dpdf') % then print it

end %end function
